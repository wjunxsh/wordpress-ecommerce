import * as cron from 'node-cron';
import dayjs from 'dayjs';
import { SYNC_PRODUCT_KEY } from '../lib/variable';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ShopModel } from '../model/shop.model';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { JobInterface, Queues } from './interface';
import { JobBasis } from './job-base';
dayjs.extend(utc);
dayjs.extend(timezone);
export class ProductJob extends JobBasis {
  private queues: Queues = {};
  constructor(bootstrap: JobInterface, queues: Queues) {
    super(bootstrap);
    this.queues = queues;
    this.initial();
  }
  initial() {
    // this.getOrder();
    //异步删除活动已经软删除的对应code，也基本上用不到，防止服务器异常导致code没有及时删除的操作
    cron.schedule('1 1 * * * *', this.getProductFromShopify.bind(this));

    //获取店铺经营区域，暂时做实验用的
    //cron.schedule('1 * * * * *', this.getRegionsFromShopify.bind(this));

    return this;
  }
  async getProductFromShopify() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    for (let shopInfo of shopList) {
      let shopifyShopId = shopInfo['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        return false;
      }
      this.queues[shopifyShopId].add(SYNC_PRODUCT_KEY, {
        shopify_shop_id: shopInfo['shopify_id'],
        shop_id: shopInfo['id'],
        shopify_domain: shopInfo['shopify_domain']
      });
    }
  }
  async getRegionsFromShopify() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    let shopInfo = shopList[0];
    let offlineSessionId = this.api.session.getOfflineId(shopInfo['shopify_domain']);
    let session = await this.sessionStorage.loadSession(offlineSessionId);
    let shopifyApiLib = new ShopifyApiLib(session, this.api);
    try {
      let data = await shopifyApiLib.apiGet('countries', {});
      console.log(data);
    } catch (e) {
      console.log(e);
    }
  }

  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
}
