import { ProductJob } from './product-job';
import { JobInterface } from './interface';
import { ShopQueueBasis } from './queue-basis';
export const COMMON_QUEUE_KEY = 'function_promotion_queue';
const jobList = [ProductJob];
export class JobClass extends ShopQueueBasis {
  constructor(bootstrap: JobInterface) {
    super(bootstrap, COMMON_QUEUE_KEY);
    this.initial(bootstrap);
  }
  initial(bootstrap: JobInterface) {
    this.initialize();
    jobList.forEach(JobClass => {
      new JobClass(
        {
          ...bootstrap
        },
        this.queues
      ).initial();
    });
  }
}
