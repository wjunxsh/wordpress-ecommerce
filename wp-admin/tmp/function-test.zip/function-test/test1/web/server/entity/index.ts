import { VariantEntity } from './variant.entity';
import { ProductEntity } from './product.entity';
import { WebhookEntity } from './webhook.entity';
import { DiscountEntity } from './discount.entity';
import { DiscountMetafieldsEntity } from './discount.metafields.entity';
export const allEntitys = [ProductEntity, VariantEntity, WebhookEntity, DiscountEntity, DiscountMetafieldsEntity];
