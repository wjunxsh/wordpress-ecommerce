import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Unique,
  DeleteDateColumn,
  Index,
  CreateDateColumn,
  UpdateDateColumn
} from 'typeorm';
import { ShopEntity } from './shop.entity';
import { VariantEntity } from './variant.entity';
@Entity('products', { schema: 'public', synchronize: true })
@Unique(['shopify_id'])
@Index(['shop_id'])
export class ProductEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: number;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopify_id: number | null;

  @Column('timestamp without time zone', {
    name: 'shopify_created_at',
    nullable: true
  })
  shopify_created_at: Date | null;

  @Column('timestamp without time zone', {
    name: 'shopify_updated_at',
    nullable: true
  })
  shopify_updated_at: Date | null;

  @Column('bigint', { name: 'shop_id', nullable: true })
  shop_id: number | null;

  @Column('text', { name: 'body_html', nullable: true })
  body_html: string | null;

  @Column('character varying', { name: 'handle', nullable: true })
  handle: string | null;

  @Column('jsonb', { name: 'images', nullable: true })
  images: object | null;

  @Column('jsonb', { name: 'options', nullable: true })
  options: object | null;

  @Column('character varying', { name: 'product_type', nullable: true })
  product_type: string | null;

  @Column('timestamp without time zone', {
    name: 'published_at',
    nullable: true
  })
  published_at: Date | null;

  @Column('character varying', { name: 'published_scope', nullable: true })
  published_scope: string | null;

  @Column('character varying', { name: 'tags', nullable: true })
  tags: string | null;

  @Column('character varying', { name: 'template_suffix', nullable: true })
  template_suffix: string | null;

  @Column('character varying', { name: 'title', nullable: true })
  title: string | null;

  @Column('character varying', { name: 'vendor', nullable: true })
  vendor: string | null;

  @Column('jsonb', { name: 'metafields', nullable: true })
  metafields: object | null;

  @DeleteDateColumn()
  deleted_at: Date;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column('character varying', { name: 'status', nullable: true })
  status: string | null;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity | null;

  @OneToMany(() => VariantEntity, variant => variant.product)
  variants: VariantEntity[] | null;
}
