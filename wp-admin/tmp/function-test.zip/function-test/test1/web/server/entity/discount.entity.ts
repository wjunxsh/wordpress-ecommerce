import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  Unique,
  DeleteDateColumn,
  Index,
  CreateDateColumn,
  UpdateDateColumn
} from 'typeorm';
import { ShopEntity } from './shop.entity';
export interface CombinesWith {
  order_discounts: boolean;
  product_discounts: boolean;
  shipping_discounts: boolean;
}
@Unique(['shopify_id'])
@Index(['shop_id'])
@Entity('discount', { schema: 'public', synchronize: true })
export class DiscountEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: number;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopify_id: number | null;

  @Column({ comment: 'shopify活动id号', nullable: true })
  graphql_shopify_id: string;

  @Column({ comment: '活动标题', nullable: true })
  title: string;

  @Column({ comment: 'code', nullable: true })
  code: string;

  @Column('bigint', { name: 'shop_id', nullable: true })
  shop_id: number | null;

  @Column({ comment: '店铺域名', nullable: true })
  shopify_domain: string;

  @Column({ name: 'function_id', nullable: true })
  function_id: string;

  @Column({ name: 'function_type', comment: '活动类型', nullable: true })
  function_type: string;

  @Column('timestamp without time zone', {
    name: 'shopify_created_at',
    nullable: true
  })
  shopify_created_at: Date | null;

  @Column('timestamp without time zone', {
    name: 'shopify_updated_at',
    nullable: true
  })
  shopify_updated_at: Date | null;

  @Column('jsonb', { name: 'metafields', nullable: true })
  metafields: object | null;

  @Column('jsonb', { name: 'metafields_source', nullable: true })
  metafields_source: object | null;

  @Column({ type: 'jsonb', comment: '和其他活动兼容', nullable: true })
  combines_with: CombinesWith;

  @Column({ comment: '客户选择', type: 'jsonb', nullable: true })
  customer_selection: any;

  @Column({ nullable: true })
  usage_limit: number;

  @DeleteDateColumn()
  deleted_at: Date;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({
    type: 'timestamp without time zone',
    nullable: true
  })
  starts_at: Date;

  @Column({
    type: 'timestamp without time zone',
    nullable: true
  })
  ends_at: Date;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity | null;
}
