import { Column, Entity, PrimaryGeneratedColumn, Unique } from "typeorm";
@Entity("webhooks", { schema: "public", synchronize: true })
@Unique(['shopify_domain','topic'])
export class WebhookEntity {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id:number;
  
  @Column("character varying", { name: "shopify_domain" })
  shopify_domain: string;

  @Column("bigint", { name: "shopify_id", nullable: true })
  shopify_id: number | null;

  @Column("character varying", { name: "topic", nullable: true })
  topic: string;

  @Column("character varying", { name: "address", nullable: true })
  address: string;

  @Column( { type:'jsonb', name: "fields", nullable: true })
  fields: object;

  @Column("timestamp without time zone", { name: "created_at" })
  created_at: Date;

  @Column("timestamp without time zone", { name: "updated_at" })
  updated_at: Date;
}
