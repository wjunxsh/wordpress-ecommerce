import { DataSource } from 'typeorm';
import { WebhookModel } from '../model/webhook.model';
import { Session, Shopify } from '@shopify/shopify-api';

export class WebhookService {
  private webhookModel: WebhookModel;
  private api: Shopify;
  constructor(database: DataSource, api: Shopify) {
    this.api = api;
    this.webhookModel = new WebhookModel(database);
  }
  async init(offlineSession: Session) {
    this.createWebhook(offlineSession, 'products/create', `${process.env.HOST}/api/webhook/product/create`);
    this.createWebhook(offlineSession, 'products/update', `${process.env.HOST}/api/webhook/product/update`);
    this.createWebhook(offlineSession, 'products/delete', `${process.env.HOST}/api/webhook/product/delete`);
    this.createWebhook(offlineSession, 'shop/update', `${process.env.HOST}/api/webhook/shop/update`);
    this.createWebhook(offlineSession, 'app/uninstalled', `${process.env.HOST}/api/webhook/uninstall`);
  }
  async createWebhook(session: Session, topic: string, address: string, format = 'json') {
    try {
      let webhookArr = await this.api.rest.Webhook.all({
        session,
        topic
      });
      let webhook = null;
      if (webhookArr.data.length > 0) {
        webhook = webhookArr.data[0];
      } else {
        webhook = new this.api.rest.Webhook({
          session
        });
      }
      webhook.topic = topic;
      webhook.address = address;
      webhook.format = format;
      webhook.metafield_namespaces = ['admin'];
      await webhook.save({
        update: true
      });
      await this.webhookModel.upsert({
        id: 0,
        shopify_domain: session.shop,
        shopify_id: webhook.id,
        address: webhook.address,
        topic: webhook.topic,
        updated_at: webhook.updated_at,
        created_at: webhook.created_at,
        fields: webhook.fields
      });
    } catch (error) {
      console.log('webhook error', error, topic, address, session.shop);
    }
  }
}
