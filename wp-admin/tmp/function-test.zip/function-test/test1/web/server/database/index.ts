import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { ShopEntity } from '../entity/shop.entity';
import { allEntitys } from '../entity';
class Database extends DataSource {
  public static async initial() {
    let database = new Database([...allEntitys]);
    await database.initialize();
    return database;
  }
  constructor(entities: any) {
    super({
      type: 'postgres',
      host: process.env.DATABASE_HOST || '127.0.0.1',
      port: parseInt(process.env.DATABASE_PORT || '5432'),
      username: process.env.DATABASE_USERNAME || 'postgres',
      password: process.env.DATABASE_PASSWORD || '',
      database: process.env.DATABASE_NAME || 'discount-app',
      synchronize: true,
      logging: false,
      entities: [ShopEntity, ...entities],
      migrations: [],
      ssl: false,
      subscribers: []
    });
  }
}

export default Database;
