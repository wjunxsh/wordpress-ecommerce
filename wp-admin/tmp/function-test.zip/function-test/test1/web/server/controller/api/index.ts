import { ShopifyAuthController } from './auth';
import { AuthInterface } from './auth/shopify-auth';
import { BasicController } from './basic/basic.controller';
import { DiscountController } from './discount/discount.controller';
import { WebhooksController } from './webhooks';

export const apiInit = async (bootstrap: AuthInterface) => {
  let authControllers = [WebhooksController, ShopifyAuthController];
  for (let controller of authControllers) {
    new controller({
      ...bootstrap
    });
  }
  bootstrap.app.use('/api/*', bootstrap.shopify.validateAuthenticatedSession());
  let apiControllers = [BasicController, DiscountController];
  for (let controller of apiControllers) {
    await new controller({
      ...bootstrap
    });
  }
};

// function validateAuthenticatedSession(shopify:ShopifyApp) {
//   return async (req: Request, res: Response, next: NextFunction) => {
//     shopify.config.logger.info('Running validateAuthenticatedSession');

//     let sessionId: string | undefined;
//     try {
//       sessionId = await shopify.api.session.getCurrentId({
//         isOnline: shopify.config.useOnlineTokens,
//         rawRequest: req,
//         rawResponse: res,
//       });
//     } catch (error) {
//       shopify.config.logger.error(
//         `Error when loading session from storage: ${error}`,
//       );

//       handleSessionError(req, res, error);
//       return undefined;
//     }

//     let session: Session | undefined;
//     if (sessionId) {
//       try {
//         session = await shopify.config.sessionStorage.loadSession(sessionId);
//       } catch (error) {
//         shopify.config.logger.error(
//           `Error when loading session from storage: ${error}`,
//         );

//         res.status(500);
//         res.send(error.message);
//         return undefined;
//       }
//     }

//     let shop = req.query.shop || session?.shop;

//     if (session && shop && session.shop !== shop) {
//       shopify.config.logger.debug(
//         'Found a session for a different shop in the request',
//         {currentShop: session.shop, requestShop: shop},
//       );

//       return 'sfsadfsadf';
//     }

//     if (session) {
//       shopify.config.logger.debug('Request session found and loaded', {
//         shop: session.shop,
//       });

//       if (session.isActive(shopify.api.config.scopes)) {
//         shopify.config.logger.debug('Request session exists and is active', {
//           shop: session.shop,
//         });
//         console.log(session);
//         if (await hasValidAccessToken(shopify.api, session)) {
//           shopify.config.logger.info('Request session has a valid access token', {
//             shop: session.shop,
//           });

//           res.locals.shopify = {
//             ...res.locals.shopify,
//             session,
//           };
//           return next();
//         }
//       }
//     }

//     const bearerPresent = req.headers.authorization?.match(/Bearer (.*)/);
//     if (bearerPresent) {
//       if (!shop) {
//         shop = await setShopFromSessionOrToken(
//           shopify.api,
//           session,
//           bearerPresent[1],
//         );
//       }
//     }

//     const redirectUri = `${shopify.config.auth.path}?shop=${shop}`;
//     shopify.config.logger.info(
//       `Session was not valid. Redirecting to ${redirectUri}`,
//       {shop},
//     );

//     return 'ssss';
//   };
// };
// function handleSessionError(_req: Request, res: Response, error: Error) {
//   switch (true) {
//     case error instanceof InvalidJwtError:
//       res.status(401);
//       res.send(error.message);
//       break;
//     default:
//       res.status(500);
//       res.send(error.message);
//       break;
//   }
// }

// function redirectOutOfApp({
//   config,
// }: RedirectOutOfAppParams) {

// }

// async function setShopFromSessionOrToken(
//   api: Shopify,
//   session: Session | undefined,
//   token: string,
// ): Promise<string | undefined> {
//   let shop: string | undefined;

//   if (session) {
//     shop = session.shop;
//   } else if (api.config.isEmbeddedApp) {
//     const payload = await api.session.decodeSessionToken(token);
//     shop = payload.dest.replace('https://', '');
//   }
//   return shop;
// }
// const TEST_GRAPHQL_QUERY = `query shopifyAppShopName {
//   shop {
//     name
//   }
// }`;
// export async function hasValidAccessToken(
//   api: Shopify,
//   session: Session,
// ): Promise<boolean> {
//   try {
//     console.log('-------------');
//     const client = new api.clients.Graphql({session});
//     console.log('-------------');
//     await client.query({data: TEST_GRAPHQL_QUERY});
//     console.log('-------------');
//     return true;
//   } catch (error) {
//     console.log(error);
//     if (error instanceof HttpResponseError && error.response.code === 401) {
//       // Re-authenticate if we get a 401 response
//       return false;
//     } else {
//       throw error;
//     }
//   }
// }
