export const SHOP_COUNTRIES_QUERY = `
  query GetShopCountries {
    shop {
      id
      countriesInShippingZones {
        countryCodes
        includeRestOfWorld
      }
    }
  }
`;
export const CUSTOMER_PICKER_QUERY = `
query GetCustomers($first: Int!, $searchQuery: String = "", $after: String) {
  customers(
    first: $first
    query: $searchQuery
    after: $after
    sortKey: NAME
  ) {
    edges {
      cursor
      node {
        id
        displayName
        email
      }
    }
    pageInfo {
      hasNextPage
    }
  }
}
`;
export const CREATE_AUTOMATIC_MUTATION = `
  mutation discountAutomaticAppCreate($automaticAppDiscount: DiscountAutomaticAppInput!) {
    discountAutomaticAppCreate(
      automaticAppDiscount: $automaticAppDiscount
    ) {
      userErrors {
        code
        message
        field
      }
      automaticAppDiscount {
        discountId
        title
        startsAt
        endsAt
        status
        appDiscountType {
          appKey
          functionId
        }
        combinesWith {
          orderDiscounts
          productDiscounts
          shippingDiscounts
        }
      }
    }
  }
`;

export const CREATE_CODE_MUTATION = `
mutation discountCodeAppCreate($codeAppDiscount: DiscountCodeAppInput!) {
  discountCodeAppCreate(codeAppDiscount: $codeAppDiscount) {
    codeAppDiscount {
      createdAt
      discountId
    }
    userErrors {
      field
      message
    }
  }
}
`;

export const UPDATE_CODE_MUTATION = `
mutation discountCodeAppUpdate($codeAppDiscount: DiscountCodeAppInput!, $id: ID!) {
  discountCodeAppUpdate(codeAppDiscount: $codeAppDiscount, id: $id) {
    codeAppDiscount {
      createdAt
      discountId
    }
    userErrors {
      field
      message
    }
  }
}
`;
export const UPDATE_AUTOMATIC_MUTATION = `
mutation discountAutomaticAppUpdate($automaticAppDiscount: DiscountAutomaticAppInput!, $id: ID!) {
  discountAutomaticAppUpdate(automaticAppDiscount: $automaticAppDiscount, id: $id) {
    automaticAppDiscount {
      createdAt
      discountId
    }
    userErrors {
      field
      message
    }
  }
}
`;

export const QUERY_CODE_MUTATION = `query discountCodeQuery($id:ID!,$namespace: String!, $key: String!) {
  codeDiscountNode(id: $id) {
    id
    metafield (namespace: $namespace, key: $key) {
      id
    }
  }
}`
export const QUERY_AUTOMATION_MUTATION = `query discountAutomationQuery($id:ID!,$namespace: String!, $key: String!) {
  automaticDiscountNode(id: $id) {
    id
    metafield (namespace: $namespace, key: $key) {
      id
    }
  }
}`;
