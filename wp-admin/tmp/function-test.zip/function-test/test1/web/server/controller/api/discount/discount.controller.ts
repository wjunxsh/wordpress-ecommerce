import { Request, Response } from 'express';
import {
  CREATE_AUTOMATIC_MUTATION,
  CREATE_CODE_MUTATION,
  QUERY_AUTOMATION_MUTATION,
  QUERY_CODE_MUTATION,
  UPDATE_AUTOMATIC_MUTATION,
  UPDATE_CODE_MUTATION,
} from './discount.graphql';
import { LATEST_API_VERSION } from '@shopify/shopify-api';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { DiscountModel } from '../../../model/discount.mode';
import { DiscountEntity } from '../../../entity/discount.entity';
import { DiscountMetafieldsEntity } from '../../../entity/discount.metafields.entity';
import { ShopifyGraphQLLib } from '../../../lib/shopify-graphql.lib';
import { BuyMainSendGift } from './tools/buy-main-send-gift';
import { ShopEntity } from '../../../entity/shop.entity';
import { Metafield, ToolsClass } from './tools/interface';
import timezone from 'dayjs/plugin/timezone';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import { ShopModel } from '../../../model/shop.model';
import { ManLiJian } from './tools/man-li-jian';
dayjs.extend(utc);
dayjs.extend(timezone);
export class DiscountController extends ControllerBase {
  discountModel: DiscountModel;
  private shopModel: ShopModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    this.shopModel = new ShopModel(this.database);
    this.app.post('/api/promotion/save', this.createDiscount.bind(this));
    this.app.get('/api/promotion/info', this.getDiscountInfo.bind(this));
    this.discountModel = new DiscountModel(this.database);
  }
  async createDiscount(req: Request, res: Response) {
    let body = req.body;
    let shopifyDomain = await this.getCurrentShopifyName(req, res);
    let discountMetafieldsRspt = this.database.getRepository(DiscountMetafieldsEntity);
    let shopRspt = this.database.getRepository(ShopEntity);
    let shopInfo = await shopRspt.findOneBy({ shopify_domain: shopifyDomain });
    let saveData = new DiscountEntity();
    saveData.function_type = body.type;
    saveData.shop_id = shopInfo.id;
    saveData.function_id = body.function_id;
    saveData.shopify_domain = shopifyDomain;
    saveData.metafields_source = body.metafields_source;
    saveData.starts_at = dayjs.tz(body.starts_at, shopInfo['iana_timezone']).toDate();
    saveData.ends_at = body.ends_at ? dayjs.tz(body.ends_at, shopInfo['iana_timezone']).toDate() : null;
    saveData.code = body.code || null;
    saveData.title = body.title;
    saveData.customer_selection = { all: true };
    saveData.usage_limit = body.usage_limit || null;
    saveData.combines_with = body.combines_with;
    if (body.id) {
      saveData.id = body.id;
      saveData.shopify_id = body.shopify_id;
    }
    let frontendMetafields: DiscountMetafieldsEntity[] = [];
    let discountMetafields: Metafield[] = [];
    let tools: ToolsClass<any, any>;
    switch (body.type) {
      case 'buy_main_send_gift':
        tools = new BuyMainSendGift();
        try {
          frontendMetafields = tools.makeFrontendMetafields(body);
          discountMetafields = tools.makeDiscountMetafields(body);
          saveData.metafields = discountMetafields;
        } catch (e) {
          console.log(e);
        }
        break;
      case 'man_li_jian':
        tools = new ManLiJian();
        try {
          frontendMetafields = tools.makeFrontendMetafields(body);
          discountMetafields = tools.makeDiscountMetafields(body);
          saveData.metafields = discountMetafields;
        } catch (e) {
          console.log(e);
        }
        break;
    }
    if (body.id) {
      let oldMetafields = await discountMetafieldsRspt.findBy({ discount_id: body.id });
      oldMetafields.length && this.compaireMetaifields(oldMetafields, frontendMetafields);
    }
    let discountInfo = {};
    let discount: any = {
      combinesWith: {
        orderDiscounts: saveData.combines_with.order_discounts || false,
        productDiscounts: saveData.combines_with.product_discounts || false,
        shippingDiscounts: saveData.combines_with.shipping_discounts || false
      },
      endsAt: saveData.ends_at,
      functionId: saveData.function_id,
      metafields: saveData.metafields,
      startsAt: saveData.starts_at,
      title: saveData.title,
    };
    if (saveData.code) {
      discount.code = saveData.code;
      discount.customerSelection = {
        all: true
      };
      discount.appliesOncePerCustomer = false;
      discount.usageLimit = saveData.usage_limit;
    }
    try {
      const result = await this.saveDiscountToShopify(req, res, discount);
      if (result['userErrors'].length) {
        return res.status(200).json({
          code: 1001,
          msg: '',
          data: {
            userErrors: result['userErrors']
          }
        });
      }
      let key = body.code ? 'codeAppDiscount' : 'automaticAppDiscount';
      let graphqlDiscountId: string = result[key]['discountId'];
      let createdAt = result[key]['createdAt'];
      let discountId = graphqlDiscountId.split('/').pop();

      discountInfo = await this.discountModel.saveDiscount(
        {
          ...saveData,
          shopify_id: parseInt(discountId),
          created_at: createdAt,
          graphql_shopify_id: graphqlDiscountId
        },
        frontendMetafields
      );
    } catch (e) {
      console.log(e);
      return res.status(200).json({
        code: 301,
        data: { userErrors: [], msg: 'Save failed!', discountInfo }
      });
    }
    return res.status(200).json({
      code: 200,
      data: { userErrors: [], discountInfo }
    });
  }
  async getDiscountInfo(req: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    let discountRspt = this.database.getRepository(DiscountEntity);
    let discountInfo = await discountRspt.findOneBy({
      shopify_id: req.query.id
    });
    if (!discountInfo) return res.status(200).json({ code: 401, msg: 'Not found', data: '' });
    return res.status(200).json({
      code: 200, data: {
        discountInfo: {
          ...discountInfo,
          starts_at: this.formatShowDate(dayjs(discountInfo.starts_at).format(), shopInfo.iana_timezone),
          ends_at: discountInfo.ends_at ? this.formatShowDate(dayjs(discountInfo.ends_at).format(), shopInfo.iana_timezone) : null
        }
      }
    });
  }
  compaireMetaifields(oldMetafields: DiscountMetafieldsEntity[], newMetafields: DiscountMetafieldsEntity[]) {
    //将id插入更新的列中
    newMetafields.forEach((item: DiscountMetafieldsEntity) => {
      oldMetafields.forEach(val => {
        if (item.target_shopify_id == val.target_shopify_id) {
          item.metafield_shopify_id = val.metafield_shopify_id;
          item.id = val.id;
          return false;
        }
      });
    });
    //获取要删除的数据
    oldMetafields.forEach(item => {
      let isDelete = true;
      newMetafields.forEach(val => {
        if (item.target_shopify_id == val.target_shopify_id) {
          isDelete = false;
        }
      });
      if (isDelete) {
        newMetafields.push({ ...item, is_need_delete: true });
      }
    });
  }
  async runDiscountMutation(variables, res, mutation) {
    const client = new this.api.clients.Graphql({
      session: res.locals.shopify.session,
      apiVersion: LATEST_API_VERSION
    });
    const data = await client.query({
      data: {
        query: mutation,
        variables
      }
    });
    return data;
  }
  async getProductsFromShopify(res: Response, productIds: string[]) {
    let graphQlHandle = new ShopifyGraphQLLib(res.locals.shopify.session, this.api);
    let queryStr = '';
    productIds.forEach(item => {
      queryStr += `
      show_${item}:product(id: "gid://shopify/Product/${item}") {
        handle
        id
      }`;
    });
    let query = `query {${queryStr}
    }`;
    let result = await graphQlHandle.graphOnlineQL(query);
    let products = Object.values(result.body['data']);
    return products;
  }
  async saveDiscountToShopify(req: Request, res: Response, discount: any) {
    let shopify_id = req.body.shopify_id || 0;
    let graphql_shopify_id = req.body.graphql_shopify_id || '';
    let graphQlHandle = new ShopifyGraphQLLib(res.locals.shopify.session, this.api);
    try {
      let result = null;
      if (shopify_id) {
        if (discount.code) {
          let discountResult = await graphQlHandle.graphOnlineQL(QUERY_CODE_MUTATION, {
            id: graphql_shopify_id,
            namespace: discount['metafields'][0]['namespace'],
            key: discount['metafields'][0]['key']
          });
          console.log('metafiled----discountResult', discountResult.body.data['codeDiscountNode']);
          discount['metafields'][0]['id'] = discountResult.body.data['codeDiscountNode']['metafield']['id'];
          result = await this.runDiscountMutation(
            {
              codeAppDiscount: discount,
              id: graphql_shopify_id
            },
            res,
            UPDATE_CODE_MUTATION
          );
        } else {
          console.log(discount);
          let discountResult = await graphQlHandle.graphOnlineQL(QUERY_AUTOMATION_MUTATION, {
            id: graphql_shopify_id,
            namespace: discount['metafields'][0]['namespace'],
            key: discount['metafields'][0]['key']
          });
          console.log(discountResult);
          discount['metafields'][0]['id'] = discountResult.body.data['automaticDiscountNode']['metafield']['id'];
        
          result = await this.runDiscountMutation(
            {
              automaticAppDiscount: discount,
              id: graphql_shopify_id
            },
            res,
            UPDATE_AUTOMATIC_MUTATION
          );
        }
      } else {
        if (discount.code) {
          result = await this.runDiscountMutation({ codeAppDiscount: discount }, res, CREATE_CODE_MUTATION);
        } else {
          result = await this.runDiscountMutation({ automaticAppDiscount: discount }, res, CREATE_AUTOMATIC_MUTATION);
        }
      }
      console.log('=========');
      console.log(result['body']['data']);
      return (
        result['body']['data']['discountCodeAppCreate'] ||
        result['body']['data']['discountCodeAppUpdate'] ||
        result['body']['data']['discountAutomaticAppCreate'] ||
        result['body']['data']['discountAutomaticAppUpdate']
      );
    } catch (e) {
      console.log('error=======', e);
      return {
        userErrors: e.response.errors.map(item => item.message)
      };
    }
  }
  async getCurrentShopifyName(req: Request, res: Response) {
    let sessionId = await this.api.session.getCurrentId({
      isOnline: true,
      rawRequest: req,
      rawResponse: res
    });
    const session = await this.sessionStorage.loadSession!(sessionId);
    return session.shop;
  }
  private formatShowDate(date: string, timezone: string): string {
    return dayjs(date).tz(timezone).format('YYYY-MM-DD HH:mm:ssZZ');
  }
}
