import { ControllerBase } from '../../controllerBasic';
import { ShopModel } from '../../../model/shop.model';
import { Request, Response } from 'express';
import { ProductModel } from '../../../model/product.model';
import { VariantModel } from '../../../model/variant.model';
import { VariantEntity } from '../../../entity/variant.entity';
import { AuthInterface } from '../auth/shopify-auth';
import { ShopifyApp } from '@shopify/shopify-app-express';
import GDPRWebhookHandlers from '../../../../gdpr';
export class WebhooksController extends ControllerBase {
  private shopModel: ShopModel;
  private productModel: ProductModel;
  private variantModel: VariantModel;
  private shopify: ShopifyApp;
  constructor(bootstrap: AuthInterface) {
    super(bootstrap);
    this.shopify = bootstrap.shopify;
    this.shopModel = new ShopModel(bootstrap.database);
    this.productModel = new ProductModel(bootstrap.database);
    this.variantModel = new VariantModel(bootstrap.database);
    this.app.post(
      this.shopify.config.webhooks.path,
      this.shopify.processWebhooks({ webhookHandlers: GDPRWebhookHandlers as any })
    );

    this.app.post('/api/webhook/uninstall', this.verifyhook(), this.appUninstall.bind(this));
    this.app.post('/api/webhook/shop/update', this.verifyhook(), this.updateShop.bind(this));
    this.app.post('/api/webhook/product/create', this.verifyhook(), this.createProduct.bind(this));
    this.app.post('/api/webhook/product/update', this.verifyhook(), this.updateProduct.bind(this));
    this.app.post('/api/webhook/product/delete', this.verifyhook(), this.deleteProduct.bind(this));
  }
  async createProduct(req: Request, res: Response) {
    let product = req.body;
    let variants = req.body.variants;
    let shopifyDomain = req.authData.shop;
    let shopInfo = await this.shopModel.getShopByShopDomain(shopifyDomain);
    //查询已经存在的product
    let productInfo = await this.productModel.getInfo(product.id);
    if (productInfo) {
      await this.productModel.save({
        ...product,
        id: productInfo.id,
        shopify_id: product.id
      });
    } else {
      productInfo = await this.productModel.save({
        ...product,
        id: 0,
        shopify_id: product.id,
        shop_id: shopInfo['id'],
        shopify_created_at: product.created_at,
        shopify_updated_at: product.updated_at
      });
    }

    if (variants && variants.length) {
      this.variantModel.insertOrUpdate(
        variants.map(variant => {
          let variantData = new VariantEntity();
          return {
            ...variantData,
            ...variant,
            id: 0,
            shopify_id: variant['id'],
            product_id: productInfo.id,
            shop_id: shopInfo['shop_id'],
            shopify_created_at: product.created_at,
            shopify_updated_at: product.updated_at
          };
        })
      );
    }

    return res.status(200).send('');
  }
  async updateProduct(req: Request, res: Response) {
    let product = req.body;
    let variants = req.body.variants;
    let shopifyDomain = req.authData.shop;
    let shopInfo = await this.shopModel.getShopByShopDomain(shopifyDomain);
    //查询已经存在的product
    let productInfo = await this.productModel.getInfo(product.id);
    if (productInfo) {
      await this.productModel.save({
        ...product,
        id: productInfo.id,
        shopify_id: product.id,
        shop_id: shopInfo['id'],
        shopify_created_at: product.created_at,
        shopify_updated_at: product.updated_at
      });
    } else {
      productInfo = await this.productModel.save({
        ...product,
        id: 0,
        shopify_id: product.id,
        shop_id: shopInfo['id'],
        shopify_created_at: product.created_at,
        shopify_updated_at: product.updated_at
      });
    }

    if (variants && variants.length) {
      //获取当前已经存在的variant
      let variantList = productInfo.variants;
      //如果variant已经被删除，则也物理删除
      let variantShopifyIds = variants.map(variant => variant.id);
      variantList = variantList.filter(variant => !variantShopifyIds.includes(parseInt(`${variant['shopify_id']}`)));
      if (variantList.length) {
        await this.variantModel.multDeleteByIds(variantList.map(item => item.id));
      }
      await this.variantModel.insertOrUpdate(
        variants.map(variant => {
          let variantData = new VariantEntity();
          return {
            ...variantData,
            ...variant,
            id: 0,
            shopify_id: variant.id,
            product_id: productInfo.id,
            shop_id: shopInfo['shop_id'],
            shopify_created_at: product.created_at,
            shopify_updated_at: product.updated_at
          };
        })
      );
    }

    return res.status(200).send('');
  }
  async deleteProduct(req: Request, res: Response) {
    let shopifyId = req.body.id;
    this.productModel.delete(shopifyId);
    return res.status(200).send();
  }
  async appUninstall(req: Request, res: Response) {
    let shop = req.body;
    //获取店铺信息
    await this.shopModel.unInstallShop(shop.myshopify_domain);
    console.log('uninstall app api trigger --->>', shop);
    res.status(200).json({
      status: 200,
      message: 'Successfully'
    });
  }
  async updateShop(req: Request, res: Response) {
    let shop = req.body;
    //获取shop
    let shopInfo = await this.shopModel.getShopByShopDomain(shop.myshopify_domain);
    await this.shopModel.updateShop({
      ...shopInfo,
      ...shop,
      id: shopInfo.id,
      custom_domain: shop.domain,
      shopify_id: shop.id,
      shopify_domain: shop.myshopify_domain
    });
    res.status(200).json('');
  }
  async process(req: Request, res: Response) {
    try {
      await this.api.webhooks.process({
        rawBody: req.body,
        rawRequest: req,
        rawResponse: res
      });
      await this.logger.info('Webhook processed, returned status code 200');
    } catch (error) {
      await this.logger.error(`Failed to process webhook: ${error}`);

      // The library will respond even if the handler throws an error
    }
  }
}
