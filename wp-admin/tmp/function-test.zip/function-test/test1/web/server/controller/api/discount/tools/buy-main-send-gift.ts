import { DiscountMetafieldsEntity } from '../../../../entity/discount.metafields.entity';
import { DiscountFormData, LabelData, Metafield, ProductSelect, ToolsClass } from './interface';

const METAFIELD_NAMESPACE = 'buy-main-send-gift';
const METAFIELD_CONFIGURATION_KEY = 'send-gift';
export interface MainSendMetafields {
  gift_rules: {
    main_skus: ProductSelect[];
    gift_skus: ProductSelect[];
    quantity: number;
  }[];
  labels: LabelData[];
  gift_send_type: 'online' | 'multi';
  message: string;
  property_key: string;
}
export interface GiftItem {
  handle: string;
  sku: string;
  gift_num: number;
  variant_shopify_id: number;
}
export class BuyMainSendGift implements ToolsClass<MainSendMetafields, any> {
  metafield_namespace:string;
  metafield_key:string;
  constructor() {
    //this.variantService = variantService;
    this.metafield_key = METAFIELD_CONFIGURATION_KEY;
    this.metafield_namespace = METAFIELD_NAMESPACE;
  }
  getTargetIds(metafielsSource: MainSendMetafields) {
    let variantIds: number[] = [];
    let giftRules = metafielsSource.gift_rules;
    for (let giftRule of giftRules) {
      for (let product of giftRule.main_skus) {
        for (let variant of product['variants']) {
          variantIds.push(variant.shopify_id);
        }
      }
      for (let product of giftRule.gift_skus) {
        for (let variant of product['variants']) {
          variantIds.push(variant.shopify_id);
        }
      }
    }
    return variantIds;
  }
  makeFrontendMetafields(body: DiscountFormData<MainSendMetafields>) {
    let metafieldsSource = body.metafields_source;
    let metafields: DiscountMetafieldsEntity[] = [];
    let giftRules = metafieldsSource.gift_rules;
    giftRules.forEach(giftRule => {
      giftRule.main_skus.forEach(mainSku => {
        let metafieldsData = new DiscountMetafieldsEntity();
        let giftList: GiftItem[] = [];
        giftRule.gift_skus.forEach(giftSku => {
          giftSku.variants.forEach(variant => {
            giftList.push({
              handle: giftSku.handle,
              sku: variant.sku,
              gift_num: giftRule.quantity,
              variant_shopify_id: variant.shopify_id
            });
          });
        });
        let metafieldValue = {
          count: metafieldsSource.gift_send_type == 'multi' ? giftList.length : 1,
          list: giftList,
          discountType: 'percentage',
          property: metafieldsSource.property_key,
          labels: metafieldsSource.labels ? metafieldsSource.labels.map(item => item.value) : []
        };
        mainSku.variants.forEach(variant => {
          metafieldsData = {
            id: 0,
            target_shopify_id: variant.shopify_id,
            target_type: 'variant',
            discount_id: 0,
            metafield_shopify_id: 0,
            is_need_delete: false,
            created_at: new Date(),
            metafield_type: 'json',
            updated_at: new Date(),
            start_sync_at: body.starts_at,
            sync_at: null,
            metafield_value: metafieldValue,
            metafield_namespace: 'free_gift',
            metafield_key: 'freeGift'
          };
          metafields.push(metafieldsData);
        });
      });
    });

    return metafields;
  }
  makeDiscountMetafields(body: DiscountFormData<MainSendMetafields>): Metafield[] {
    let metafieldsSource = body.metafields_source;
    let metafields: Metafield[] = [
      {
        namespace: METAFIELD_NAMESPACE,
        key: METAFIELD_CONFIGURATION_KEY,
        type: 'json',
        value: ''
      }
    ];
    let giftRules = metafieldsSource.gift_rules;
    let metafieldsValue = {
      gift_send_type: body.metafields_source.gift_send_type,
      message: body.metafields_source.message,
      property_key: body.metafields_source.property_key,
      giftRules: []
    };
    giftRules.forEach(giftRule => {
      let mainVariants: string[] = [];
      let giftVariants: string[] = [];
      giftRule.main_skus.forEach(mainSku => {
        mainVariants = [...mainVariants, ...mainSku.variants.map(item => 'gid://shopify/ProductVariant/' + item.shopify_id)];
      });
      giftRule.gift_skus.forEach(giftSku => {
        giftVariants = [...giftVariants, ...giftSku.variants.map(item => 'gid://shopify/ProductVariant/' + item.shopify_id)];
      });
      let valueItem = {
        mainVariants,
        giftVariants,
        quantity: giftRule.quantity
      };
      metafieldsValue['giftRules'].push(valueItem);
    });
    metafields[0]['value'] = JSON.stringify(metafieldsValue);
    return metafields;
  }
}
