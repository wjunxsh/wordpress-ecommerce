import { DiscountMetafieldsEntity } from '../../../../entity/discount.metafields.entity';

export interface ToolsClass<T, FM> {
  metafield_namespace:string;
  metafield_key:string;
  makeFrontendMetafields: (body: DiscountFormData<T>) => DiscountMetafieldsEntity[];
  makeDiscountMetafields: (body: DiscountFormData<T>) => FM;
}

export interface VariantSelect {
  id: number;
  shopify_id: number;
  sku: string;
}
export interface ProductSelect {
  avatar: string;
  handle: string;
  id: number;
  title: string;
  variants: VariantSelect[];
}
export interface DiscountFormData<T> {
  metafields_source: T;
  starts_at;
  ends_at;
}

export interface LabelData {
  name: string;
  value: string;
}

export interface Metafield {
  namespace: string;
  key: string;
  type: 'json';
  value: any;
}
