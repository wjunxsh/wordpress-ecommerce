import { Redis } from 'ioredis';
import { DataSource } from 'typeorm';
import { Express, Router } from 'express';
import { RequestHandler } from 'express';
import * as crypto from 'crypto';
import { Shopify } from '@shopify/shopify-api';
import { Logger } from 'winston';
import { PostgreSQLSessionStorage } from '../lib/session.storage';
enum WebhookHeader {
  Hmac = 'X-Shopify-Hmac-Sha256',
  Topic = 'X-Shopify-Topic',
  Domain = 'X-Shopify-Shop-Domain'
}
export interface ControllerBaseInterface {
  app: Express;
  redis: Redis;
  database: DataSource;
  router: Router;
  api: Shopify;
  logger: Logger;
  sessionStorage: PostgreSQLSessionStorage;
}

export class ControllerBase {
  public sessionStorage: PostgreSQLSessionStorage;
  public app: Express;
  public redis: Redis;
  public database: DataSource;
  public router: Router;
  public api: Shopify;
  public logger: Logger;
  constructor(bootstrap: ControllerBaseInterface) {
    this.app = bootstrap.app;
    this.redis = bootstrap.redis;
    this.database = bootstrap.database;
    this.router = bootstrap.router;
    this.api = bootstrap.api;
    this.sessionStorage = bootstrap.sessionStorage;
    this.logger = bootstrap.logger;
  }
  public verifyhook(): RequestHandler {
    return async (req: any, res, next?: any) => {
      const resData = {};
      if (req.headers['x-shopify-shop-domain']) {
        resData['shop'] = req.headers['x-shopify-shop-domain'];
      }
      req.authData = resData;
      if (
        !(
          crypto.createHmac('SHA256', process.env.SHOPIFY_API_SECRET).update(req.rawBody, 'utf8').digest('base64') ===
          (req.headers[WebhookHeader.Hmac] ?? req.headers[WebhookHeader.Hmac.toLowerCase()])
        )
      ) {
        res.status(401).json({
          status: 401,
          message: 'forbidden'
        });
        return;
      } else {
        next();
      }
    };
  }
}
