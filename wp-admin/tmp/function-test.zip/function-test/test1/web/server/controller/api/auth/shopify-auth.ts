import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { ShopModel } from '../../../model/shop.model';
import { Session } from '@shopify/shopify-api';
import { ApiAndConfigParams, RedirectToShopifyOrAppRootMiddleware, ShopifyApp } from '@shopify/shopify-app-express';
import { WebhookService } from '../../../service/webhook.services';
import { Request, Response } from 'express';
export interface AuthInterface extends ControllerBaseInterface {
  shopify: ShopifyApp;
}
export class ShopifyAuthController extends ControllerBase {
  private shopModel: ShopModel;
  private shopify: ShopifyApp;
  constructor(bootstrap: AuthInterface) {
    super(bootstrap);
    this.shopify = bootstrap.shopify;
    this.shopModel = new ShopModel(bootstrap.database);
    this.initial();
  }
  private initial() {
    this.app.get(
      this.shopify.config.auth.callbackPath,
      this.shopify.auth.callback(),
      this.authCallback.bind(this),
      this.shopify.redirectToShopifyOrAppRoot()
    );
    this.app.get(this.shopify.config.auth.path, this.shopify.auth.begin());
  }
  private async authCallback(req, res, next) {
    const shop = req.query.shop;
    if (shop) {
      let offsessionId = this.api.session.getOfflineId(req.query.shop);
      let session = await this.sessionStorage.loadSession(offsessionId);
      if (session) {
        await this.initShopFromShopify(session);
        new WebhookService(this.database, this.api).init(session);
      }
    }
    return next();
  }
  async initShopFromShopify(session: Session) {
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    if (shopInfo) {
      await this.shopModel.updateShop({
        ...shopInfo,
        shopify_token: session.accessToken,
        uninstalled_at: null,
        scope: session.scope,
        state: 1
      });
    } else {
      let clients = new this.api.clients.Rest({
        session: session
      });
      let result: any = await clients.get({
        path: 'shop'
      });
      await this.shopModel.createShop({
        ...result.body.shop,
        state: 1,
        scope: session.scope,
        shopify_token: session.accessToken
      });
    }
  }
  redirectToShopifyOrAppRoot({ api, config }: ApiAndConfigParams): RedirectToShopifyOrAppRootMiddleware {
    return function () {
      return async function (req: Request, res: Response) {
        if ((res as any).headersSent) {
          config.logger.info('Response headers have already been sent, skipping redirection to host', {
            shop: (res as any).locals.shopify?.session?.shop
          });

          return;
        }

        const host = api.utils.sanitizeHost(req.query.host as string)!;
        const redirectUrl = api.config.isEmbeddedApp
          ? await api.auth.getEmbeddedAppUrl({
              rawRequest: req,
              rawResponse: res
            })
          : `/?shop=${res.locals.shopify.session.shop}&host=${encodeURIComponent(host)}`;

        config.logger.debug(`Redirecting to host at ${redirectUrl}`, {
          shop: res.locals.shopify.session.shop
        });

        res.redirect(redirectUrl);
      };
    };
  }
}
