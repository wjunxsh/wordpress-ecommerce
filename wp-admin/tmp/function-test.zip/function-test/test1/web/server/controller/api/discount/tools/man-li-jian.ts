import { DiscountMetafieldsEntity } from '../../../../entity/discount.metafields.entity';
import { DiscountFormData, LabelData, Metafield, ProductSelect, ToolsClass } from './interface';

const METAFIELD_NAMESPACE = 'man-li-jian';
const METAFIELD_CONFIGURATION_KEY = 'level-rules';
export interface ManLiJianMetafields {
    level_rules: {
    min_total:number;
    discount:number;
  }[];
  labels: LabelData[];
  excludes_variants:ProductSelect[],
  includes_variants:ProductSelect[],
  message: string;
  property_key: string;
  discount_type:'percentage'|'fixed_amount';
  limit_product_tag: string;
}
export interface GiftItem {
  handle: string;
  sku: string;
  gift_num: number;
  variant_shopify_id: number;
}
export class ManLiJian implements ToolsClass<ManLiJianMetafields, any> {
  metafield_namespace:string;
  metafield_key:string;
  constructor() {
    //this.variantService = variantService;
    this.metafield_key = METAFIELD_CONFIGURATION_KEY;
    this.metafield_namespace = METAFIELD_NAMESPACE;
    //this.variantService = variantService;
  }
  makeFrontendMetafields(body: DiscountFormData<ManLiJianMetafields>) {
    return [];
  }
  makeDiscountMetafields(body: DiscountFormData<ManLiJianMetafields>): Metafield[] {
    let metafields: Metafield[] = [
      {
        namespace: METAFIELD_NAMESPACE,
        key: METAFIELD_CONFIGURATION_KEY,
        type: 'json',
        value: ''
      }
    ];
    let metafieldsValue = {
      message: body.metafields_source.message,
      discount_type: body.metafields_source.discount_type,
      property_key: body.metafields_source.property_key || '',
      excludes_variant_ids:[],
      includes_variant_ids:[],
      limit_product_tag:body.metafields_source.limit_product_tag,
      limit_product_tags:body.metafields_source.limit_product_tag ? [body.metafields_source.limit_product_tag] : [],
      level_rules:body.metafields_source.level_rules,
    };
    let includesVariants = body.metafields_source.includes_variants;
    let excludesVariants = body.metafields_source.excludes_variants;
    let includesVariantIds: string[] = [];
    let excludesVariantIds: string[] = [];

    includesVariants.forEach(mainSku => {
      includesVariantIds = [...includesVariantIds, ...mainSku.variants.map(item => 'gid://shopify/ProductVariant/' + item.shopify_id)];
    });
    excludesVariants.forEach(giftSku => {
      excludesVariantIds = [...excludesVariantIds, ...giftSku.variants.map(item => 'gid://shopify/ProductVariant/' + item.shopify_id)];
    });
    metafieldsValue['excludes_variant_ids'] = excludesVariantIds;
    metafieldsValue['includes_variant_ids'] = includesVariantIds;
    metafields[0]['value'] = JSON.stringify(metafieldsValue);
    return metafields;
  }
}
