import { DataSource, In, Repository } from 'typeorm';
import { ProductEntity } from '../entity/product.entity';
import { VariantEntity } from '../entity/variant.entity';

export class ProductModel {
  productRspt: Repository<ProductEntity>;
  constructor(database: DataSource) {
    this.productRspt = database.getRepository(ProductEntity);
  }
  async insertOrUpdate(product: ProductEntity[]) {
    return this.productRspt
      .createQueryBuilder()
      .insert()
      .into(ProductEntity)
      .values(product)
      .orUpdate(
        ['title', 'handle', 'shopify_updated_at', 'shopify_created_at', 'images', 'metafields', 'tags', 'vendor', 'status'],
        ['shopify_id']
      )
      .execute();
  }
  async getInfo(shopifyId: number) {
    return await this.productRspt.findOne({ where: { shopify_id: shopifyId }, relations: ['variants'] });
  }
  async getListByShopifyIds(shopifyIds: number[]) {
    return await this.productRspt.findBy({ shopify_id: In(shopifyIds) });
  }
  async save(product: ProductEntity) {
    return await this.productRspt.save(product);
  }
  async multSave(product: ProductEntity[]) {
    return await this.productRspt.save(product);
  }
  async delete(shopifyId: number) {
    return this.productRspt.softDelete({ shopify_id: shopifyId });
  }
  async getPruductByIds(params: { ids: string[]; shop_id: number }): Promise<ProductEntity[]> {
    const { ids, shop_id } = params;
    return await this.productRspt
      .createQueryBuilder('p')
      .leftJoinAndMapMany('p.variants', VariantEntity, 'v', 'p.id=v.product_id')
      .where(`p.id in(${ids.join(',')}) and p.shop_id=${shop_id}`)
      .getMany();
  }
  async getProducts(params: { shop_id: number; search: string; current_page: number; page_size: number }) {
    const { search, current_page, page_size, shop_id } = params;
    let handle = this.productRspt.createQueryBuilder('v');
    handle.where(`1=1`);
    if (search) {
      handle.andWhere(`v.handle ilike '%${search}%'`);
    }
    if (shop_id) {
      handle.andWhere(`v.shop_id = ${shop_id}`);
    }
    handle.take(page_size).skip(page_size * (current_page - 1));
    return await handle.getMany();
  }

  async getProductsCount(params: { shop_id: number; search: string }) {
    const { search, shop_id } = params;
    let handle = this.productRspt.createQueryBuilder('v');
    handle.where(`1=1`);
    if (search) {
      handle.andWhere(`v.handle ilike '%${search}%'`);
    }
    if (shop_id) {
      handle.andWhere(`v.shop_id = ${shop_id}`);
    }
    return await handle.getCount();
  }
  async getProductsWithVariants(params: { shop_id: number; search: string; current_page: number; page_size: number }) {
    const { search, current_page, page_size, shop_id } = params;
    let handle = this.productRspt
      .createQueryBuilder('p')
      .leftJoinAndMapMany('p.variants', VariantEntity, 'v', 'v.product_id=p.id');
    handle.andWhere(`p.shop_id = ${shop_id}`);
    if (search && /^[0-9]*$/.test(search)) {
      handle.andWhere(`(p.shopify_id= '${search}' or v.shopify_id='${search}')`);
    } else if (search) {
      handle.andWhere(`(p.handle = '${search}' or p.title ilike '%${search}%' or v.sku = '${search}')`);
    }
    handle
      .take(page_size)
      .skip(page_size * (current_page - 1))
      .select(['v.id', 'v.shopify_id', 'p.handle', 'v.sku', 'v.title', 'p.title', 'p.id', 'p.shopify_id', 'p.images']);
    return await handle.getMany();
  }

  async getProductsWithVariantsCount(params: { shop_id: number; search: string }) {
    const { search, shop_id } = params;
    let handle = this.productRspt
      .createQueryBuilder('p')
      .leftJoinAndMapMany('p.variants', VariantEntity, 'v', 'v.product_id=p.id');
    handle.andWhere(`v.shop_id = ${shop_id}`);
    if (search && /^[0-9]*$/.test(search)) {
      handle.andWhere(`(p.shopify_id= '${search}' or v.shopify_id='${search}')`);
    } else if (search) {
      handle.andWhere(`(p.handle = '${search}' or p.title ilike '%${search}%' or v.sku = '${search}')`);
    }
    return await handle.getCount();
  }
}
