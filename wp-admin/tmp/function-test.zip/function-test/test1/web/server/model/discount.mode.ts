import { DataSource, Repository } from 'typeorm';
import { DiscountEntity } from '../entity/discount.entity';
import { DiscountMetafieldsEntity } from '../entity/discount.metafields.entity';
export class DiscountModel {
  discountRspt: Repository<DiscountEntity>;
  database: DataSource;
  constructor(database: DataSource) {
    this.discountRspt = database.getRepository(DiscountEntity);
    this.database = database;
  }
  async saveDiscount(data: DiscountEntity, metafields: DiscountMetafieldsEntity[]) {
    const queryRunner = this.database.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      if (data.id) {
        data.updated_at = new Date();
      } else {
        data.created_at = new Date();
        data.updated_at = new Date();
      }
      let discountInfo = await queryRunner.manager.save(DiscountEntity, data);
      metafields.forEach(item => {
        item.discount_id = discountInfo.id;
      });
      console.log('-----------metafields--------------', metafields);
      if (metafields.length) {
        await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(DiscountMetafieldsEntity)
          .values(metafields)
          .orUpdate(['is_need_delete', 'metafield_value', 'start_sync_at', 'sync_at'], ['id'])
          .execute();
      }
      await queryRunner.commitTransaction();
      return discountInfo;
    } catch (e) {
      await queryRunner.rollbackTransaction();
      throw e;
    } finally {
      await queryRunner.release();
    }
  }
}
