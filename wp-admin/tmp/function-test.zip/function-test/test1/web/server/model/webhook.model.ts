import { DataSource, FindOneOptions, In, Like, Repository } from "typeorm";
import { WebhookEntity } from "../entity/webhook.entity";
import { Session } from "@shopify/shopify-api";

export class WebhookModel {
  webhookRspt:Repository<WebhookEntity>
    constructor(database: DataSource) {
        this.webhookRspt = database.getRepository(WebhookEntity);
    }

    async upsert(data:WebhookEntity) {
      delete data.id;
      return await this.webhookRspt.upsert(data,['shopify_domain','topic']);
    }    
}