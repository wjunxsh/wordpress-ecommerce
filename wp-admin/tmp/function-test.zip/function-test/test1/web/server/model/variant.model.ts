import { DataSource, In, Repository } from 'typeorm';
import { VariantEntity } from '../entity/variant.entity';
import { ProductEntity } from '../entity/product.entity';

export class VariantModel {
  variantRspt: Repository<VariantEntity>;
  constructor(database: DataSource) {
    this.variantRspt = database.getRepository(VariantEntity);
  }
  async insertOrUpdate(variants: VariantEntity) {
    return this.variantRspt
      .createQueryBuilder()
      .insert()
      .into(VariantEntity)
      .values(variants)
      .orUpdate(
        [
          'title',
          'compare_at_price',
          'shopify_created_at',
          'shopify_updated_at',
          'price',
          'sku',
          'option1',
          'option2',
          'option3',
          'product_id',
          'inventory_quantity',
          'inventory_item_id'
        ],
        ['shopify_id']
      )
      .execute();
  }
  async multDeleteByIds(ids: number[]) {
    return this.variantRspt.delete({ id: In(ids) });
  }
  async multSave(variants: VariantEntity[]) {
    return this.variantRspt.save(variants);
  }
  async getVariantsByIds(params: { ids: string[]; shop_id: number }) {
    const { ids, shop_id } = params;
    return await this.variantRspt
      .createQueryBuilder('v')
      .leftJoinAndMapOne('v.product', ProductEntity, 'p', 'p.id=v.product_id')
      .where(`v.id in(${ids.join(',')}) and p.shop_id=${shop_id}`)
      .getMany();
  }
  async getVariantsByShopifyIds(params: { shopifyIds: number[]; shop_id: number }) {
    const { shopifyIds, shop_id } = params;
    return await this.variantRspt
      .createQueryBuilder('v')
      .leftJoinAndMapOne('v.product', ProductEntity, 'p', 'p.id=v.product_id')
      .where(`v.shopify_id in(${shopifyIds.join(',')}) and p.shop_id=${shop_id}`)
      .getMany();
  }
  async getVariantsByProductId(params: { ids: number[]; shop_id: number }) {
    const { ids, shop_id } = params;
    return await this.variantRspt
      .createQueryBuilder('v')
      .leftJoinAndMapOne('v.product', ProductEntity, 'p', 'p.id=v.product_id')
      .where(`v.id in(${ids.join(',')}) and p.shop_id=${shop_id}`)
      .getMany();
  }
  async getVariantsByOthers(params: { skus: string[]; handles: string[]; shop_id: string }) {
    const { skus, handles, shop_id } = params;
    return await this.variantRspt
      .createQueryBuilder('v')
      .leftJoinAndMapOne('v.product', ProductEntity, 'p', 'p.id=v.product_id')
      .where(`p.shop_id=${shop_id} and v.sku in('${skus.join(`','`)}') and p.handle in('${handles.join(`','`)}')`)
      .getMany();
  }
  async getVariants(params: { shop_id: number; search: string; current_page: number; page_size: number }) {
    const { search, current_page, page_size, shop_id } = params;
    let handle = this.variantRspt
      .createQueryBuilder('v')
      .leftJoinAndMapOne('v.product', ProductEntity, 'p', 'p.id=v.product_id');
    handle.where(`1=1`);
    if (search) {
      handle.andWhere(`v.sku ilike '%${search}%'`);
    }
    if (shop_id) {
      handle.andWhere(`p.shop_id = ${shop_id}`);
    }
    handle.take(page_size).skip(page_size * (current_page - 1));
    return await handle.getMany();
  }

  async getVariantsCount(params: { shop_id: number; search: string }) {
    const { search, shop_id } = params;
    let handle = this.variantRspt
      .createQueryBuilder('v')
      .leftJoinAndMapOne('v.product', ProductEntity, 'p', 'p.id=v.product_id');
    handle.where(`1=1`);
    if (search) {
      handle.andWhere(`v.sku ilike '%${search}%'`);
    }
    if (shop_id) {
      handle.andWhere(`p.shop_id = ${shop_id}`);
    }
    return await handle.getCount();
  }
}
