import { validate } from 'class-validator';
export class ToolsLib {
  // 延迟
  static async sleep(time: any) {
    return new Promise((resolve: any) => setTimeout(() => resolve(), time));
  }

  static formatErr(msg: string, code?: number) {
    return { msg, code: code ? code : 500 };
  }
  static async validateData(Dto: any, data: { [key: string]: any }) {
    let dto = new Dto();
    for (let key in data) {
      dto[key] = data[key];
    }
    let msg = {};
    let errorData = await validate(dto);
    if (errorData.length) {
      errorData.forEach(item => {
        msg[item.property] = Object.values(item.constraints);
      });
    }
    if (Object.keys(msg).length) {
      return msg;
    }
    return true;
  }
  /**
   *
   * @param str 将驼峰法更改为下划线
   * @returns
   */
  static camelToUnderline(str: string) {
    return str.replace(/([A-Z])/g, '_$1').toLowerCase();
  }
  /**
   *
   * @param str 将下划线更改为驼峰
   * @returns
   */
  static underlineToCamel(str: string) {
    return str.replace(/\_(\w)/g, (all, letter) => letter.toUpperCase());
  }
}
