import 'dotenv/config';
import { LATEST_API_VERSION, Session } from '@shopify/shopify-api';
import { Shopify } from '@shopify/shopify-api';
import { ToolsLib } from './tools.lib';
export class ShopifyGraphQLLib {
  public session: Session;
  public api: Shopify;
  private SHOPIFY_RETRY = 10;
  constructor(session: Session, api: Shopify) {
    this.session = session;
    this.api = api;
  }
  async graphOnlineQL(mutation: string, variables: any = null, retryCount = 0) {
    const client = new this.api.clients.Graphql({ session: this.session, apiVersion: LATEST_API_VERSION });
    try {
      if (variables && Object.keys(variables).length) {
        let result = await client.query({
          data: {
            query: mutation,
            variables
          }
        });
        return result;
      } else {
        let result = await client.query({
          data: {
            query: mutation
          }
        });
        return result;
      }
    } catch (e) {
      retryCount++;
      if (await this.errorProcess(e, retryCount)) {
        if (retryCount <= this.SHOPIFY_RETRY) {
          return await this.graphOnlineQL(mutation, variables, retryCount);
        } else {
          return Promise.reject({
            code: 429,
            message: `Maximum ${this.SHOPIFY_RETRY} of of retry Count`
          });
        }
      } else {
        return Promise.reject({
          code: e.response.code,
          message: e.response.statusText
        });
      }
    }
  }
  async graphOfflineQL(mutation: string, variables: any = null, retryCount = 0) {
    const client = new this.api.clients.Graphql({ session: this.session, apiVersion: LATEST_API_VERSION });
    try {
      if (variables && Object.keys(variables).length) {
        let result = await client.query({
          data: {
            query: mutation,
            variables
          }
        });
        return result;
      } else {
        let result = await client.query({
          data: {
            query: mutation
          }
        });
        return result;
      }
    } catch (e) {
      retryCount++;
      if (await this.errorProcess(e, retryCount)) {
        if (retryCount <= this.SHOPIFY_RETRY) {
          return await this.graphOfflineQL(mutation, variables, retryCount);
        } else {
          return Promise.reject({
            code: 429,
            message: `Maximum ${this.SHOPIFY_RETRY} of of retry Count`
          });
        }
      } else {
        return Promise.reject({
          code: e.response.code,
          message: e.response.statusText
        });
      }
    }
  }
  async errorProcess(err, retryCount) {
    if (err && err.response) {
      console.log(err.response, err.response['errors'][0]['locations']);
      switch (err.response.code) {
        case 401:
          console.log('sdfsfs====');
          //未鉴权报错,如果是offline，则将店铺状态设置为0
          if (!this.session.isOnline) {
            //将店铺状态设置为0
          }
          return false;
        case 404:
          //接口不存在报错
          return false;
        case 429:
          //请求过多报错处理
          await ToolsLib.sleep((5 - (retryCount < 4 ? retryCount : 3)) * 1000);
          // await utilsDelay(1000);
          return true;
        case 422:
          return false;
        default:
          await ToolsLib.sleep((5 - (retryCount < 4 ? retryCount : 3)) * 1000);
          return true;
      }
    } else {
      return true;
    }
    return false;
  }
}
