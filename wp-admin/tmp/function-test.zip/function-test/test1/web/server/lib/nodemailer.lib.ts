const nodemailer = require("nodemailer");

interface CustomerMailerArgs {
  from: string; // sender address
  to: string; // list of receivers
  subject: string; // Subject line
  text: string; // plain text body
  html: string; // html body
}
export class NodeMailerLib {
  transporter: any;
 constructor() {
  this.initial();
 }
 initial(){
  this.transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
 }
 async sendEmail(options:CustomerMailerArgs) {
  const info = await this.transporter.sendMail(options);
  return info;
 }
}
