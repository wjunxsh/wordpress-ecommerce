import 'dotenv/config';
import { DataType, GetRequestParams, LATEST_API_VERSION, PostRequestParams, Session } from '@shopify/shopify-api';
import { Shopify } from '@shopify/shopify-api';
import { ToolsLib } from './tools.lib';
export class ShopifyApiLib {
  public session: Session;
  public api: Shopify;
  private SHOPIFY_RETRY = 10;
  constructor(session: Session, api: Shopify) {
    this.session = session;
    this.api = api;
  }
  async apiGet(path: string, query: GetRequestParams['query']) {
    try {
      let result = await this.apiGetAllRes(path, query);
      return result['body'];
    } catch (e) {
      return Promise.reject(e);
    }
  }
  async apiGetAllRes(path: string, query: GetRequestParams['query'], retryCount = 0) {
    const client = new this.api.clients.Rest({ session: this.session, apiVersion: LATEST_API_VERSION });
    try {
      let result = await client.get({
        path: path,
        type: DataType.JSON,
        query: query
      });
      return result;
    } catch (e) {
      retryCount++;
      if (await this.errorProcess(e, retryCount)) {
        if (retryCount <= this.SHOPIFY_RETRY) {
          await ToolsLib.sleep((3 + retryCount) * 1000);
          return await this.apiGetAllRes(path, query, retryCount);
        } else {
          return Promise.reject({
            code: 429,
            message: `Maximum ${this.SHOPIFY_RETRY} of retry Count`
          });
        }
      } else {
        return Promise.reject({
          code: e.response.code,
          message: e.response.statusText
        });
      }
    }
  }
  async apiPost(data: PostRequestParams, retryCount = 0) {
    const client = new this.api.clients.Rest({ session: this.session, apiVersion: LATEST_API_VERSION });
    try {
      let result = await client.post(data);
      return result;
    } catch (e) {
      console.log('update post mult=========');
      console.log(e);
      retryCount++;
      if (await this.errorProcess(e, retryCount)) {
        if (retryCount <= this.SHOPIFY_RETRY) {
          await ToolsLib.sleep((3 + retryCount) * 1000);
          return await this.apiPost(data, retryCount);
        } else {
          return Promise.reject({
            code: 429,
            message: `Maximum ${this.SHOPIFY_RETRY} of of retry Count`
          });
        }
      } else {
        return Promise.reject({
          code: e.response.code,
          message: e.response.body.errors
        });
      }
    }
  }
  async apiPut(data: PostRequestParams, retryCount = 0) {
    const client = new this.api.clients.Rest({ session: this.session, apiVersion: LATEST_API_VERSION });
    try {
      let result = await client.put(data);
      return result;
    } catch (e) {
      console.log('update put mult=========', data);
      console.log(e);
      retryCount++;
      if (await this.errorProcess(e, retryCount)) {
        if (retryCount <= this.SHOPIFY_RETRY) {
          await ToolsLib.sleep((3 + retryCount) * 1000);
          return await this.apiPut(data, retryCount);
        } else {
          return Promise.reject({
            code: 429,
            message: `Maximum ${this.SHOPIFY_RETRY} of of retry Count`
          });
        }
      } else {
        return Promise.reject({
          code: e.response.code,
          message: e.response.body.errors
        });
      }
    }
  }
  async apiDelete(path: string, retryCount = 0) {
    const client = new this.api.clients.Rest({ session: this.session, apiVersion: LATEST_API_VERSION });
    try {
      let result = await client.delete({
        path: path,
        type: DataType.JSON
      });
      return result;
    } catch (e) {
      retryCount++;
      if (await this.errorProcess(e, retryCount)) {
        if (retryCount <= this.SHOPIFY_RETRY) {
          await ToolsLib.sleep((3 + retryCount) * 1000);
          return await this.apiDelete(path, retryCount);
        } else {
          return Promise.reject({
            code: 429,
            message: `Maximum ${this.SHOPIFY_RETRY} of of retry Count`
          });
        }
      } else {
        return Promise.reject({
          code: e.response.code,
          message: e.response.statusText
        });
      }
    }
  }
  async errorProcess(err, retryCount) {
    if (err && err.response) {
      switch (err.response.code) {
        case 400:
          //未鉴权报错,如果是offline，则将店铺状态设置为0
          console.log(err.response.body);
          return false;
        case 401:
          //未鉴权报错,如果是offline，则将店铺状态设置为0
          if (!this.session.isOnline) {
            //将店铺状态设置为0
          }
          return false;
        case 404:
          //接口不存在报错
          return false;
        case 429:
          //请求过多报错处理
          await ToolsLib.sleep((5 - (retryCount < 4 ? retryCount : 3)) * 1000);
          // await utilsDelay(1000);
          return true;
        case 422:
          return false;
        default:
          await ToolsLib.sleep((5 - (retryCount < 4 ? retryCount : 3)) * 1000);
          return true;
      }
    } else {
      return true;
    }
    return false;
  }
}
