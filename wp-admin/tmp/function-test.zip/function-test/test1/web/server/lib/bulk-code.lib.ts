interface BulkConfig {
  prefix: string;
  suffix: string;
  quantity: number;
  random_length: number;
  character_type: string;
}
export class BulkCodeLib {
  public config: BulkConfig;
  public codeFormat = '';
  createCodes(config: BulkConfig, existsCodes: string[] = []): string[] {
    let codes: string[] = [];
    const { prefix, suffix, quantity, random_length, character_type } = config;
    for (let i = 0; i < quantity; i++) {
      let code = `${(prefix || '').toUpperCase()}${this.randomStr(random_length, character_type)}${(
        suffix || ''
      ).toUpperCase()}`;
      if (this.codeIsExists([...codes, ...existsCodes], code)) {
        i--;
        continue;
      }
      codes.push(code);
    }
    return codes;
  }
  randomStr(length: number, character_type: string) {
    const numbers = '0123456789';
    const chars = 'ABCDEFGHIGKLMNOPQRSTUVWXYZ';
    let charSource = '';
    switch (character_type) {
      case 'number':
        charSource = numbers;
        break;
      case 'letter':
        charSource = chars;
        break;
      default:
        charSource = chars + numbers;
        break;
    }
    let str: string = '';
    let len = charSource.length;
    for (let i = 0; i < length; i++) {
      let cIndex = Math.round(Math.random() * (len - 1));
      let c = charSource[cIndex];
      str += c;
    }
    return str;
  }
  private codeIsExists(codes: string[], code: string) {
    if (codes.length) {
      for (let i = 0, len = codes.length; i < len; i++) {
        if (code == codes[i]) {
          return true;
        }
      }
    } else {
      return false;
    }
    //敏感词判断
    return false;
  }
}
