import IoRedis from 'ioredis';

export class RedisStorage extends IoRedis {
  constructor() {
    super(process.env.REDIS_URL, {
      maxRetriesPerRequest: null,
      enableReadyCheck: false,
      db: parseInt(`${process.env.REDIS_DB || 1}`)
    });
  }
  async init() {
    await this.flushall(err => {
      if (err) {
        console.error(err);
      } else {
        console.log('All keys have been cleared.');
      }
    });
  }
}
