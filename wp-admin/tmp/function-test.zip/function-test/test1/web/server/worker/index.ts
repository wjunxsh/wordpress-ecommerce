import { WorkerInterface } from './interface';
import { ProductWorker } from './product.worker';
export const workerInit = (bootstrap: WorkerInterface) => {
  const workerkList = [ProductWorker];
  workerkList.forEach(workerClass => {
    new workerClass({
      ...bootstrap
    }).initial();
  });
};
