import { Shopify } from '@shopify/shopify-api';
import { Redis } from 'ioredis';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { PostgreSQLSessionStorage } from '../lib/session.storage';

export interface WorkerInterface {
  redis: Redis;
  database: DataSource;
  api: Shopify;
  logger: Logger;
  sessionStorage: PostgreSQLSessionStorage;
}
