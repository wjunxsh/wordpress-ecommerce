import { Job } from 'bullmq';
import { WorkerBasis } from './wooker-basis';
import { SYNC_PRODUCT_KEY } from '../lib/variable';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ShopModel } from '../model/shop.model';
import { Session } from '@shopify/shopify-api';
import { ProductEntity } from '../entity/product.entity';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { ProductModel } from '../model/product.model';
import { VariantModel } from '../model/variant.model';
import { VariantEntity } from '../entity/variant.entity';
import { WorkerInterface } from './interface';
import { COMMON_QUEUE_KEY } from '../jobs';
dayjs.extend(utc);
dayjs.extend(timezone);
export class ProductWorker extends WorkerBasis {
  shopModel: ShopModel;
  productModel: ProductModel;
  variantModel: VariantModel;
  constructor(bootstrap: WorkerInterface) {
    super(bootstrap, COMMON_QUEUE_KEY);
    this.shopModel = new ShopModel(this.database);
    this.productModel = new ProductModel(this.database);
    this.variantModel = new VariantModel(this.database);
  }
  async initial() {
    this.initialize(this.process.bind(this));
  }

  async process(job: Job<any, any, string>) {
    switch (job.name) {
      case SYNC_PRODUCT_KEY:
        return await this.getProductFromShopify(job.data);
      default:
        return true;
    }
  }
  async getProductFromShopify({
    shopify_domain,
    shop_id
  }: {
    shop_id: number;
    shop_shopify_id: number;
    shopify_domain: string;
  }) {
    const offlineSessionId = this.api.session.getOfflineId(shopify_domain);
    let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
    let apiClient = new ShopifyApiLib(session, this.api);
    let sinceId: number = 0;
    try {
      // let result: { data: ProductEntity[] } = await this.api.rest.Product.all({ session, since_id: sinceId, limit: 5 });
      //获取所有产品
      while (true) {
        let result = await apiClient.apiGet(`products`, {
          since_id: sinceId,
          limit: 100
        });
        let products: ProductEntity[] = result.products;

        if (!products?.length) {
          break;
        }
        sinceId = products[products.length - 1]['id'];
        let shopifyProductIds = products.map(item => item.id);
        let productList = await this.productModel.getListByShopifyIds(shopifyProductIds);
        if (productList.length) {
          shopifyProductIds = productList.map(product => parseInt(`${product.shopify_id}`));
          products = products.filter(product => !shopifyProductIds.includes(product.id));
        }
        if (products.length) {
          for (let product of products) {
            let variants = product.variants;
            let productInfo = await this.productModel.save({
              ...product,
              id: 0,
              shopify_id: product.id,
              shop_id: shop_id,
              shopify_created_at: product.created_at,
              shopify_updated_at: product.updated_at
            });
            await this.variantModel.multSave(
              variants.map(variant => {
                let variantData = new VariantEntity();
                return {
                  ...variantData,
                  ...variant,
                  id: 0,
                  product_id: productInfo.id,
                  shop_id: shop_id,
                  shopify_id: variant.id,
                  shopify_created_at: product.created_at,
                  shopify_updated_at: product.updated_at
                };
              })
            );
          }
        }
      }
    } catch (e) {
      console.log(e);
    }
    return true;
  }

  async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  async unLock(key) {
    if (this.redis.get(`setnx-${key}`)) {
      this.redis.del(`setnx-${key}`);
    }
  }
}
