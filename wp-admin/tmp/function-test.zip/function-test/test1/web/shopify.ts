import { BillingInterval, LATEST_API_VERSION } from "@shopify/shopify-api";
import { shopifyApp } from "@shopify/shopify-app-express";
import { restResources } from "@shopify/shopify-api/rest/admin/2023-04";
import { PostgreSQLSessionStorage } from "./server/lib/session.storage";
import * as dotenv from 'dotenv';
dotenv.config({ override: true });
export const sessionStorage = PostgreSQLSessionStorage.withCredentials(
  process.env.DATABASE_HOST || '127.0.0.1',
  process.env.DATABASE_NAME || 'anker_promotion',
  process.env.DATABASE_USERNAME || 'postgres',
  process.env.DATABASE_PASSWORD || '',
  { port: 5432 }
);
const shopify = shopifyApp({
  api: {
    apiVersion: LATEST_API_VERSION,
    restResources,
    billing: undefined, // or replace with billingConfig above to enable example billing
  },
  useOnlineTokens:true,
  auth: {
    path: "/api/auth",
    callbackPath: "/api/auth/callback",
  },
  webhooks: {
    path: "/api/webhooks",
  },
  // This should be replaced with your preferred storage strategy
  sessionStorage: sessionStorage,
});
export default shopify;
