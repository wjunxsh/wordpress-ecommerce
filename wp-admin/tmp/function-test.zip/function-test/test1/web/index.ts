import { join } from 'path';
import * as dotenv from 'dotenv';
import { readFileSync } from 'fs';
import express from 'express';
import serveStatic from 'serve-static';
import shopify, { sessionStorage } from './shopify';
import Database from './server/database';
import { RedisStorage } from './server/redis';
import { apiInit } from './server/controller/api';
import { logger } from './server/logger';
import { JobClass } from './server/jobs';
import { workerInit } from './server/worker';
dotenv.config({ override: true });
const PORT = parseInt(process.env.BACKEND_PORT || process.env.PORT || '3000', 10);

const STATIC_PATH = process.env.NODE_ENV === 'production' ? `${process.cwd()}/frontend/dist` : `${process.cwd()}/frontend/`;

export async function createServer() {
  const app = express();
  const database = await Database.initial();
  const redis = new RedisStorage();
  const authRoute = express.Router();
  app.use(
    express.json({
      limit: '50mb',
      verify: (req: any, res, buf) => {
        if (req.url.startsWith('/api/webhook')) {
          req.rawBody = buf;
        }
      }
    })
  );

  await apiInit({
    app,
    redis,
    database,
    router: authRoute,
    api: shopify.api,
    logger: logger,
    shopify,
    sessionStorage: sessionStorage
  });
  new JobClass({ redis, database, api: shopify.api, logger, sessionStorage });
  workerInit({ redis, database, api: shopify.api, logger, sessionStorage });
  app.use(authRoute);
  //shopify api 接口校验相关中间件
  //前端校验 除了api都会走这里
  app.use(shopify.cspHeaders());

  app.use(serveStatic(STATIC_PATH, { index: false }));

  app.use('/*', shopify.ensureInstalledOnShop(), async (_req, res) => {
    return res
      .status(200)
      .set('Content-Type', 'text/html')
      .send(readFileSync(join(STATIC_PATH, 'index.html')));
  });

  return { app };
}
createServer().then(({ app }) => app.listen(PORT));
