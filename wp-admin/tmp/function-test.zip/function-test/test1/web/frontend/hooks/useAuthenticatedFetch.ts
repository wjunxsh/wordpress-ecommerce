import { authenticatedFetch } from '@shopify/app-bridge/utilities';
import { useAppBridge } from '@shopify/app-bridge-react';
import { Redirect } from '@shopify/app-bridge/actions';
import * as qs from 'qs';
/**
 * A hook that returns an auth-aware fetch function.
 * @desc The returned fetch function that matches the browser's fetch API
 * See: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
 * It will provide the following functionality:
 *
 * 1. Add a `X-Shopify-Access-Token` header to the request.
 * 2. Check response for `X-Shopify-API-Request-Failure-Reauthorize` header.
 * 3. Redirect the user to the reauthorization URL if the header is present.
 *
 * @returns {Function} fetch function
 */
export function useAuthenticatedFetch() {
  const app = useAppBridge();
  const fetchFunction = authenticatedFetch(app);

  return async (uri: string, options: any) => {
    let url = paramUrl(uri, options.query);
    try {
      if (['POST', 'PUT'].includes(options.method.toUpperCase())) {
        if (!options['headers'] || options['headers']['Content-Type'] === undefined) {
          options['headers'] = { 'Content-Type': 'application/json' };
        }
      }
      if (options.body) {
        options.body = JSON.stringify(options.body);
      }
      const response = await fetchFunction(url, options);
      checkHeadersForReauthorization(response.headers, app);
      if (response.status != 200) {
        return Promise.reject({
          code: response.status || 500,
          msg: response.statusText || 'Server error!'
        });
      } else {
        let data = await response.json();
        if (!data.code || data.code !== 200) {
          return Promise.reject({
            code: data.code || 500,
            msg: data.msg || 'Server error!'
          });
        }
        return data.data;
      }
    } catch (e) {
      Promise.reject({ code: 500, msg: 'Server error!' });
    }
  };
}

function checkHeadersForReauthorization(headers: any, app: any) {
  if (headers.get('X-Shopify-API-Request-Failure-Reauthorize') === '1') {
    const authUrlHeader = headers.get('X-Shopify-API-Request-Failure-Reauthorize-Url') || `/api/auth`;

    const redirect = Redirect.create(app);
    redirect.dispatch(
      Redirect.Action.REMOTE,
      authUrlHeader.startsWith('/') ? `https://${window.location.host}${authUrlHeader}` : authUrlHeader
    );
  }
}

function paramUrl(uri: string, query: any) {
  let params = '';
  if (query && Object.keys(query).length) {
    params += qs.stringify(query);
  }
  let url = uri;
  if (uri.indexOf('?') === -1) {
    url = uri + '?' + params;
  } else {
    url = uri + params;
  }
  return url;
}
