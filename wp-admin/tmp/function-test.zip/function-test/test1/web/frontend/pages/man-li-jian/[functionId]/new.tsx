import { ManLiJian } from '@components/functions/man-li-jian';
import React from 'react';
const MainLiJianCreate = () => {
    return <ManLiJian/>
}

export default MainLiJianCreate;