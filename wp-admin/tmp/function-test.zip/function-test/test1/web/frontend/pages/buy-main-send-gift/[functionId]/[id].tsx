import { BuyMainSendGift } from '@components/functions/buy-main-send-gift';
import React from 'react';
const BuyMainSendGiftDetails = () => {
    return <BuyMainSendGift/>
}
export default BuyMainSendGiftDetails;