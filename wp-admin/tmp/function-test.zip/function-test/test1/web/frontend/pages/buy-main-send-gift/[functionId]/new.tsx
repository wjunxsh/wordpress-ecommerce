import React from 'react';
import { BuyMainSendGift } from '@components/functions/buy-main-send-gift';
const BuyMainSendGiftCreate = () => {
    return <BuyMainSendGift/>
};
export default BuyMainSendGiftCreate;
