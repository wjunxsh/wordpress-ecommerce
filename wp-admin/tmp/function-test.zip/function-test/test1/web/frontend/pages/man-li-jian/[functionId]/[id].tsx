import { ManLiJian } from '@components/functions/man-li-jian';
import React from 'react';
const MainLiJianDetails = () => {
    return <ManLiJian/>
}

export default MainLiJianDetails;