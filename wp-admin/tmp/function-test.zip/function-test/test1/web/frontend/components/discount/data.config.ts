export const discountTypes = [
  { label: '固定折扣%', value: 'percentage' },
  { label: '固定价格', value: 'fix_amount' },
  { label: '固定折扣金额', value: 'fix_discount_amount' }
];

export const accessoryBuyTypes = [
  { label: '前一个附属产品(赠品)数量满足不了优惠，则自动落到下一个附属产品(赠品)上', value: 'alone' },
  { label: '每个附属产品针对主商品优惠一次', value: 'multi' }
];
