import { CampaignType, DiscountType } from '@components/common_interface';
import { Button, Input, InputProps, Space, Typography } from 'antd';
import { ChangeEventHandler } from 'react';
const { Text } = Typography;
interface CodeInputProps extends InputProps {
  campaign_type: CampaignType;
  onButtonClick: () => void;
  value?: string;
  onChange?: ChangeEventHandler<HTMLInputElement>;
  notice?: string;
}
export const CodeInput = (props: CodeInputProps) => {
  return (
    <>
      <Space.Compact style={{ width: '100%' }}>
        <Input onChange={e => props.onChange && props.onChange(e)} value={props.value} />
        {props.campaign_type == 'discount_code' ? (
          <Button style={{ width: 80 }} type="primary" onClick={props.onButtonClick}>
            Generate
          </Button>
        ) : null}
      </Space.Compact>
      <Text type="secondary">
        {props.campaign_type == 'automatic'
          ? 'Customers will see this in their cart and at checkout.'
          : 'Customers must enter this code at checkout.'}
      </Text>
    </>
  );
};
