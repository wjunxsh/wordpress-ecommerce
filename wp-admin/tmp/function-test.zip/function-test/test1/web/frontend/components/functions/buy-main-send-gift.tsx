import { CodeInput } from '@components/common/code_input';
import { CampaignType, DiscountType } from '@components/common_interface';
import { Layout, Page, PageActions } from '@shopify/polaris';
import { onBreadcrumbAction } from '@shopify/discount-app-components';
import {
    Button,
    Form,
    Radio,
    Space,
    Typography,
    Card,
    Tooltip,
    Select,
    Input,
    DatePicker,
    Checkbox,
    Row,
    Col,
    InputNumber
} from 'antd';
import React, { useEffect, useState } from 'react';
import { useAppBridge } from '@shopify/app-bridge-react';
import { Redirect } from '@shopify/app-bridge/actions';
import { InfoCircleOutlined, MinusCircleOutlined, PlusOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { accessoryBuyTypes } from '@components/discount/data.config';
import { VariantSelect } from '@components/common/variant_select';
import dayjs, { Dayjs } from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { randomStr } from '@components/lib/bulk-code.lib';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
import { useParams } from 'react-router-dom';
dayjs.extend(utc);
dayjs.extend(timezone);
const { Title } = Typography;
export const BuyMainSendGift = () => {
    const app = useAppBridge();
    const { id, functionId } = useParams();
    const redirect = Redirect.create(app);
    const [form] = Form.useForm();
    const [campaignType, setCampaignType] = useState<CampaignType>('discount_code');
    const [isSetEndsDate, setEndsDate] = useState<boolean>(false);
    const authenticatedFetch = useAuthenticatedFetch();
    const disabledDate = (current: Dayjs) => {
        return current && current < dayjs().subtract(1, 'day').startOf('day');
    };
    const [loading, setLoading] = useState<boolean>(false);
    const [discountInfo, setDiscountInfo] = useState<any>(null);
    const generateCode = () => {
        let code = randomStr(12, 'all');
        form.setFieldValue('title', code);
    };
    useEffect(() => {
        id && getInfo();
    }, []);
    const getInfo = async () => {
        setLoading(true);
        try {
            let result = await authenticatedFetch('/api/promotion/info', {
                method: "get",
                query: {
                    id
                }
            });
            
            if(result.discountInfo) {
                let combines_with = [];
                result.discountInfo.combines_with?.product_discounts && combines_with.push('product_discounts');
                result.discountInfo.combines_with?.order_discounts && combines_with.push('order_discounts');
                result.discountInfo.combines_with?.shipping_discounts && combines_with.push('shipping_discounts');
                result.discountInfo.combines_with = combines_with;
            }
            setDiscountInfo(result.discountInfo);
            setCampaignType(result.discountInfo.code ? 'discount_code' : 'automatic');
            setEndsDate(result.discountInfo.ends_at ? true : false);
            form.resetFields();
        } catch (e) {
            console.error(e);
        }
        setLoading(false);
    }
    const onCreate = async (data: any) => {
        if (loading) return;
        setLoading(true);
        try {
            let result = await authenticatedFetch('/api/promotion/save', {
                method: 'post',
                body: {
                    title: data.title,
                    type: 'buy_main_send_gift',
                    code: campaignType == 'discount_code' ? data.title : null,
                    starts_at: dayjs(data.starts_at).format('YYYY-MM-DD HH:mm:ss'),
                    ends_at: isSetEndsDate ? dayjs(data.ends_at).format('YYYY-MM-DD HH:mm:ss') : null,
                    function_id: functionId,
                    shopify_id:discountInfo?.shopify_id || 0,
                    graphql_shopify_id:discountInfo?.graphql_shopify_id || '',

                    id: discountInfo?.id ?? 0,
                    combines_with: {
                        product_discounts:data.combines_with?.includes('product_discounts'),
                        order_discounts:data.combines_with?.includes('order_discounts'),
                        shipping_discounts:data.combines_with?.includes('shipping_discounts')
                    },
                    usage_limit: data.usage_limit,
                    metafields_source: {
                        message: data.message,
                        gift_send_type: data.gift_send_type,
                        property_key: data.property_key,
                        gift_rules: data.gift_rules
                    }
                }
            });
            onBreadcrumbAction(redirect, true)
        } catch (e) {
            console.error(e);
        }
        setLoading(false);
    };
    const onSubmit = () => {
        form
            .validateFields()
            .then(values => {
                onCreate(values);
            })
            .catch(info => {
                console.log('Validate Failed:', info);
            });
    };
    return (
        <Page
            title="买X 送 Y"
            backAction={{
                content: 'Discounts',
                onAction: () => onBreadcrumbAction(redirect, true)
            }}
            primaryAction={{
                content: 'Save',
                onAction: onSubmit,
                disabled: false,
                loading: loading
            }}
        >
            <Layout>
                <Layout.Section>
                    <Form layout="vertical" disabled={loading} form={form}>
                        <Card style={{ marginBottom: '8px' }}>
                            <Title level={5}>Amount off products</Title>

                            <Form.Item hidden={!discountInfo || discountInfo.code ? false : true} initialValue={campaignType} label="Method" name="campaign_type">
                                <Radio.Group
                                    onChange={e => {
                                        setCampaignType(e.target.value);
                                        form.setFieldValue('title', '');
                                    }}
                                >
                                    <Space direction="vertical">
                                        <Radio value="discount_code"> Discount code </Radio>
                                        <Radio value="automatic"> Automatic discount </Radio>
                                    </Space>
                                </Radio.Group>
                            </Form.Item>
                            <Form.Item
                                rules={[{ required: true }]}
                                name="title"
                                initialValue={discountInfo?.code || discountInfo?.title || ''}
                                label={campaignType !== 'discount_code' ? 'Title' : 'Discount code'}
                            >
                                <CodeInput onButtonClick={generateCode} campaign_type={campaignType} />
                            </Form.Item>
                            <Title level={5}>活动规则</Title>
                            <Form.Item
                                name="gift_send_type"
                                initialValue={discountInfo?.metafields_source?.gift_send_type || null}
                                rules={[{ required: true, message: '请选择活动方式' }]}
                                label={
                                    <Tooltip
                                        title="如果一个主商品对应多个附属产品做优惠，并且客户将多个附属产品都加入了购物车，则活动会根据这个选项决定是1对多优惠还是1对1优惠"
                                        color="geekblue"
                                    >
                                        多附属产品的购买方式
                                        <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                                    </Tooltip>
                                }
                            >
                                <Select options={accessoryBuyTypes} />
                            </Form.Item>
                            <Form.Item
                                label="Checkout页展示的文案"
                                name="message"
                                initialValue={discountInfo?.metafields_source?.message || ''}
                                rules={[{ required: true, message: '活动文案必须填写' }]}
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="property_key"
                                initialValue={discountInfo?.metafields_source?.property_key || ''}
                                label={
                                    <Tooltip
                                        title="如果活动是针对特定主题页的，则此属性为必填项目。不填则默认为针对全场活动，而且属性必须以__划线开头"
                                        color="geekblue"
                                    >
                                        专题页活动特有属性
                                        <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                                    </Tooltip>
                                }
                            >
                                <Input />
                            </Form.Item>
                        </Card>
                        <Card style={{ marginBottom: '8px' }}>
                            <Form.List initialValue={discountInfo?.metafields_source?.gift_rules || [{ gift_skus: [], main_skus: [] }]} name="gift_rules">
                                {(fields, { add, remove }) => (
                                    <>
                                        {fields.map(({ key, name }) => (
                                            <div key={key} className="form-list-item">
                                                {fields.length > 1 ? (
                                                    <Button
                                                        onClick={() => remove(name)}
                                                        style={{ zIndex: 100, position: 'absolute', right: 0, top: 0 }}
                                                        type={'link'}
                                                        icon={<MinusCircleOutlined />}
                                                    />
                                                ) : null}
                                                <Form.Item rules={[{ required: true, message: '请选择主商品' }]} name={[name, 'main_skus']} label="">
                                                    <VariantSelect buttonLabel="选择主商品" />
                                                </Form.Item>
                                                <Form.Item rules={[{ required: true, message: '请选择赠品' }]} name={[name, 'gift_skus']} label="">
                                                    <VariantSelect buttonLabel="选择赠品" />
                                                </Form.Item>
                                                <Form.Item
                                                    rules={[
                                                        { required: true, message: '请输入赠送数量' },
                                                        {
                                                            validator: (rule, value) => {
                                                                if (value < 1) {
                                                                    return Promise.reject('必须大于0');
                                                                }
                                                                return Promise.resolve();
                                                            }
                                                        }
                                                    ]}
                                                    name={[name, 'quantity']}
                                                    label="每个主商品赠送赠品数量"
                                                >
                                                    <InputNumber />
                                                </Form.Item>
                                            </div>
                                        ))}
                                        <Button icon={<PlusOutlined />} type={'link'} size={'large'} onClick={() => add()} />
                                    </>
                                )}
                            </Form.List>
                        </Card>
                        <Card style={{ marginBottom: '8px' }}>
                            <Form.Item name="combines_with" initialValue={discountInfo?.combines_with} label="折扣可以与哪些折扣级别结合">
                                <Checkbox.Group>
                                    <Row>
                                        <Col span={24}>
                                            <Checkbox value={'product_discounts'} style={{ lineHeight: '32px' }}>
                                                Combines with product discounts.
                                            </Checkbox>
                                        </Col>
                                        <Col span={24}>
                                            <Checkbox value={'order_discounts'} style={{ lineHeight: '32px' }}>
                                                Combines with order discounts.
                                            </Checkbox>
                                        </Col>
                                        <Col span={24}>
                                            <Checkbox value={'shipping_discounts'} style={{ lineHeight: '32px' }}>
                                                Combines with shipping discounts.
                                            </Checkbox>
                                        </Col>
                                    </Row>
                                </Checkbox.Group>
                            </Form.Item>
                            <Form.Item name="usage_limit" label="折扣最大使用次数（无限次使用，则为空）">
                                <InputNumber />
                            </Form.Item>
                            <Form.Item
                                initialValue={discountInfo?.starts_at ? dayjs(discountInfo?.starts_at,'YYYY-MM-DD HH:mm:ss') : null}
                                rules={[{ required: true, message: '活动开始时间必须填写' }]}
                                name="starts_at"
                                label={
                                    <Tooltip title="时间对应的时区为shopify对应的店铺所在时区" color="geekblue">
                                        活动开始时间
                                        <ExclamationCircleOutlined
                                            style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }}
                                            size={10}
                                        />
                                    </Tooltip>
                                }
                            >
                                <DatePicker disabledDate={disabledDate} showTime format="YYYY-MM-DD HH:mm:ss" style={{ display: 'block' }} />
                            </Form.Item>
                            <Form.Item valuePropName="checked" initialValue={discountInfo?.ends_at ? true : false} name={'is_send_ends_date'}>
                                <Checkbox onChange={e => setEndsDate(e.target.checked)} >Set end date</Checkbox>
                            </Form.Item>
                            <Form.Item
                                name="ends_at"
                                initialValue={dayjs(discountInfo?.ends_at || new Date(),'YYYY-MM-DD HH:mm:ss')}
                                hidden={!isSetEndsDate}
                                rules={[
                                    {
                                        validator: (rule, value: Dayjs) => {
                                            if (!value) return Promise.resolve();
                                            if (value.isBefore(new Date(), 'day')) {
                                                return Promise.reject('结束时间不能晚于当前时间');
                                            }
                                            let starts_at = form.getFieldValue('starts_at');
                                            if (starts_at && value.isBefore(starts_at, 'day')) {
                                                return Promise.reject('结束时间不能早于开始时间');
                                            }
                                            return Promise.resolve();
                                        }
                                    },
                                    { required: isSetEndsDate, message: '结束时间必须填写' }
                                ]}
                                label={
                                    <Tooltip title="时间对应的时区为shopify对应的店铺所在时区" color="geekblue">
                                        活动结束时间
                                        <ExclamationCircleOutlined
                                            style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }}
                                            size={10}
                                        />
                                    </Tooltip>
                                }
                            >
                                <DatePicker  disabledDate={disabledDate} showTime format="YYYY-MM-DD HH:mm:ss" style={{ display: 'block' }} />
                            </Form.Item>

                            <PageActions
                                primaryAction={{
                                    content: 'Save discount',
                                    onAction: onSubmit,
                                    disabled: false,
                                    loading: loading
                                }}
                                secondaryActions={[
                                    {
                                        content: 'Discard',
                                        onAction: () => onBreadcrumbAction(redirect, true)
                                    }
                                ]}
                            />
                        </Card>
                    </Form>
                </Layout.Section>
                <Layout.Section secondary>
                    <Card>sdfadsfasdf</Card>
                </Layout.Section>
            </Layout>
        </Page>
    );
};