import { describe, it, expect } from 'vitest';
import { run } from './run';
import { FunctionResult, DiscountApplicationStrategy } from '../generated/api';

describe('product discounts function', () => {
  it('returns no discounts without configuration', () => {
    const result = run({
      "cart": {
        "lines": [
          {
            "quantity": 1,
            "cost": {
              "totalAmount": {
                "amount": "99.99"
              }
            },
            "merchandise": {
              "__typename": "ProductVariant",
              "id": "gid://shopify/ProductVariant/43120504340649"
            }
          },
          {
            "quantity": 2,
            "cost": {
              "totalAmount": {
                "amount": "279.98"
              }
            },
            "merchandise": {
              "__typename": "ProductVariant",
              "id": "gid://shopify/ProductVariant/42971030618281"
            }
          },
          {
            "quantity": 1,
            "cost": {
              "totalAmount": {
                "amount": "5.0"
              }
            },
            "merchandise": {
              "__typename": "ProductVariant",
              "id": "gid://shopify/ProductVariant/43094253109417"
            }
          }
        ],
        "attribute": {
          key:'__gift_line_attribute',
          value:'test'
        }
      },
      "discountNode": {
        "metafield": {
          "value": "{\"gift_send_type\":\"alone\",\"message\":\"Get more. Pay less.\",\"giftRules\":[{\"mainVariants\":[\"gid://shopify/ProductVariant/38017449263273\",\"gid://shopify/ProductVariant/43120504340649\"],\"giftVariants\":[\"gid://shopify/productVairant/42971030618281\",\"gid://shopify/productVairant/42971030618281\"],\"quantity\":1}]}"
        }
      }
    } as any);
    const expected: FunctionResult = {
      discounts: [],
      discountApplicationStrategy: DiscountApplicationStrategy.First,
    };

    expect(result).toEqual(expected);
  });
});