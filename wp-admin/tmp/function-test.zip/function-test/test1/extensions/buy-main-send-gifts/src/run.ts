import type {
  RunInput,
  FunctionRunResult,
  FunctionResult,
  Input,
  Target,
  ProductVariant
} from "../generated/api";
import {
  DiscountApplicationStrategy,
} from "../generated/api";

const EMPTY_DISCOUNT: FunctionRunResult = {
  discountApplicationStrategy: DiscountApplicationStrategy.First,
  discounts: [],
};
type giftRules = {
  mainVariants: string[];
  giftVariants: string[];
  quantity: number;
}
type giftResultRule = {
  mainVariant: string;
  giftVariants: string[];
  quantity: number;
}
type Configuration = {
  gift_send_type: 'multi' | 'alone';
  message: string;
  property_key: string;
  giftRules: giftRules[];
};

export function run(input: Input): FunctionRunResult {
  let discountResult: FunctionResult = {
    discountApplicationStrategy: DiscountApplicationStrategy.First,
    discounts: [],
  };
  const configuration: Configuration = JSON.parse(
    input?.discountNode?.metafield?.value ?? "{}"
  );
  let { giftRules, property_key, gift_send_type, message } = configuration;
  let lines = input.cart.lines;
  let attribute = input.cart.attribute || {};
  if (property_key && attribute['key'] != property_key) return discountResult;
  if (!giftRules.length) return discountResult;
  let giftRulesResult: giftResultRule[] = [];
  for (let giftRule of giftRules) {
    for (let mainVariant of giftRule['mainVariants']) {
      giftRulesResult.push({ mainVariant, quantity: giftRule.quantity, giftVariants: giftRule['giftVariants'] })
    }
  }
  let targets: Target[] = [];
  //将所有购物车商品弄出来
  let currentleftNumbers: { [id: string]: number } = {};
  for (let line of lines) {
    let id = (line.merchandise as ProductVariant).id || '';
    if (id && line.cost.totalAmount.amount >= 0) {
      currentleftNumbers[id] = currentleftNumbers[id] ? currentleftNumbers[id] + line.quantity : line.quantity;
    }
  }
  for (let giftRule of giftRulesResult) {
    let giftVariantIds = giftRule['giftVariants'];
    let mainVariantId = giftRule['mainVariant']
    let quantity = giftRule['quantity'];
    if(!currentleftNumbers[mainVariantId]) continue;
    //如果主商品是存在的则，检查赠品是否存在如果存在 则将赠品加入target
    for (let giftVariantId of giftVariantIds) {
      let mainQuantity = currentleftNumbers[mainVariantId];
      if (mainQuantity <= 0) continue;
      if (currentleftNumbers[giftVariantId]<= 0) continue;
      
      let target = targets.find(target => target.productVariant?.id === giftVariantId);
      //计算可以送的最大倍数
      let multiple = Math.floor(currentleftNumbers[mainVariantId] / (giftVariantId === mainVariantId ? (1 + quantity) : quantity) )
      let consumeQty = currentleftNumbers[giftVariantId] > quantity * multiple ? quantity * multiple : quantity * multiple;
      if (target) {
        target.productVariant.quantity += consumeQty;
      } else {
        targets.push({
          productVariant: {
            id: giftVariantId,
            quantity: consumeQty,
          },
        });
      }
      currentleftNumbers[giftVariantId] -= consumeQty;
      if (gift_send_type === 'alone') {
        currentleftNumbers[mainVariantId] -= Math.ceil(consumeQty / quantity);
      }
      console.log(currentleftNumbers);
    }
  }
  if (targets.length) {
    discountResult['discounts'].push({
      targets: targets,
      value: {
        percentage: { value: 100 },
      },
      message,
    });
  }
  return discountResult;
};