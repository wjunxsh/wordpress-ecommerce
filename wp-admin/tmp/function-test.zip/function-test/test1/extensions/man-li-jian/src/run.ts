import type {
  FunctionRunResult,
  FunctionResult,
  Input,
  ProductVariant,
  CartLine,
  Value
} from "../generated/api";
import {
  DiscountApplicationStrategy,
} from "../generated/api";

type levelRule = {
  min_total:number;
  discount:number;
}
type Configuration = {
  excludes_variant_ids:string[];
  includes_variant_ids:string[];
  message: string;
  property_value: string;
  level_rules: levelRule[];
  limit_product_tag:string;
  discount_type:'percentage'|'fixed_amount';
};

export function run(input: Input): FunctionRunResult {
  let discountResult: FunctionResult = {
    discountApplicationStrategy: DiscountApplicationStrategy.First,
    discounts: [],
  };
  const configuration: Configuration = JSON.parse(
    input?.discountNode?.metafield?.value ?? "{}"
  );
  let { discount_type,level_rules, property_value, excludes_variant_ids, includes_variant_ids, message,limit_product_tag } = configuration;
  let lines = input.cart.lines;
  let avaliableLines:CartLine[] = [];
  let excludedVariantIds:string[] = [];
  let attribute = input.cart.attribute || {};
  if (property_value && attribute['key'] !== property_value) return discountResult;
  if (!level_rules.length) return discountResult;
  
  for(let line of lines) {
    let variantId = (line.merchandise as ProductVariant).id;
    if((includes_variant_ids.length && !includes_variant_ids.includes(variantId)) || excludes_variant_ids.includes(variantId)) {
      excludedVariantIds.push(variantId);
      continue;
    }
    let tagResponses = (line.merchandise as ProductVariant).product.hasTags;
    if(limit_product_tag && !tagResponses.some(item => item.hasTag && item.tag == limit_product_tag)) {
      excludedVariantIds.push(variantId);
      continue;
    }
    avaliableLines.push(line);
  }
  //获取剩余商品的总金额
  let totalAmount = 0;
  for(let line of avaliableLines) {
    totalAmount += parseFloat(`${line.cost.totalAmount.amount}`);
  }
  //对level_rules 进行排序
  level_rules.sort((a,b)=>  b.min_total - a.min_total);
  let levelRule = level_rules.find(item=> item.min_total < totalAmount );
  if(levelRule) {
    let discount_value = levelRule.discount;
    let value:Value;
    if(discount_type == 'percentage') {
      value = {percentage:{value:discount_value}}
    }else {
      value = {fixedAmount:{amount:discount_value}}
    }
    discountResult['discounts'].push({
      value,
      message,
      targets:[{
        orderSubtotal:{excludedVariantIds:excludedVariantIds}
      }]
    })
  }
  return discountResult;
};