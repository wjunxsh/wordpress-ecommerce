import { describe, it, expect } from 'vitest';
import { run } from './index';
import { FunctionResult, DiscountApplicationStrategy } from '../generated/api';

describe('order discounts function', () => {
  it('returns no discounts without configuration', () => {
    const result = run({
      "cart": {
        "lines": [
          {
            "quantity": 1,
            "cost": {
              "totalAmount": {
                "amount": "99.99"
              }
            },
            "merchandise": {
              "__typename": "ProductVariant",
              "id": "gid://shopify/ProductVariant/43120504340649",
              "product": {
                "hasTags": [{
                  hasTag:false,
                }]
              }
            }
          },
          {
            "quantity": 2,
            "cost": {
              "totalAmount": {
                "amount": "279.98"
              }
            },
            "merchandise": {
              "__typename": "ProductVariant",
              "id": "gid://shopify/ProductVariant/42971030618281",
              "product": {
                "hasTags": [{
                  hasTag:false,
                }]
              }
            }
          },
          {
            "quantity": 1,
            "cost": {
              "totalAmount": {
                "amount": "5.0"
              }
            },
            "merchandise": {
              "__typename": "ProductVariant",
              "id": "gid://shopify/ProductVariant/43094253109417",
              "product": {
                "hasTags": [{
                  hasTag:false,
                }]
              }
            }
          }
        ],
        "attribute": {
          key:'__gift_line_attribute',
          value:'test'
        }
      },
      "discountNode": {
        "metafield": {
          "value": JSON.stringify({
            message:'test',
            property_key:'',
            limit_product_tag:'',
            discount_type:'percentage',
            includes_variant_ids:[],
            excludes_variant_ids:[],
            level_rules:[{min_total:200,discount:10},{min_total:500,discount:12}]
          })
        }
      }
    } as any);
    const expected: FunctionResult = {
      discounts: [{
        message:'test',
        targets:[{orderSubtotal:{excludedVariantIds:[]}}],
        value:{percentage:{value:10}},

      }],
      discountApplicationStrategy: DiscountApplicationStrategy.First,
    };

    expect(result).toEqual(expected);
  });
});