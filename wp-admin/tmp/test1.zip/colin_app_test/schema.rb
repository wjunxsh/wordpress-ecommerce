# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `rails
# db:schema:load`. When creating a new database, `rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2023_11_27_070649) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"
  enable_extension "uuid-ossp"

  create_table "abandoned_checkouts", force: :cascade do |t|
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.string "token"
    t.string "cart_token"
    t.string "email"
    t.string "gateway"
    t.boolean "buyer_accepts_marketing"
    t.string "landing_site"
    t.string "note"
    t.string "referring_site"
    t.boolean "taxes_included"
    t.float "total_weight"
    t.string "currency"
    t.datetime "completed_at"
    t.datetime "closed_at"
    t.bigint "shopify_user_id"
    t.bigint "shopify_location_id"
    t.string "source_identifier"
    t.string "source_url"
    t.string "device_id"
    t.string "phone"
    t.string "customer_locale"
    t.string "name"
    t.string "source"
    t.string "abandoned_checkout_url"
    t.string "source_name"
    t.string "presentment_currency"
    t.decimal "total_discounts", precision: 10, scale: 2
    t.decimal "total_line_items_price", precision: 10, scale: 2
    t.decimal "total_price", precision: 10, scale: 2
    t.decimal "total_tax", precision: 10, scale: 2
    t.decimal "subtotal_price", precision: 10, scale: 2
    t.decimal "total_duties", precision: 10, scale: 2
    t.jsonb "note_attributes"
    t.jsonb "shipping_lines"
    t.jsonb "line_items"
    t.jsonb "discount_codes"
    t.jsonb "tax_lines"
    t.jsonb "shipping_address"
    t.jsonb "customer"
    t.bigint "shop_id"
    t.datetime "deleted_at"
    t.jsonb "email_history"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.json "tel_history"
    t.index "((line_items -> 'sku'::text))", name: "index_abandoned_checkouts_on_line_items_sku", using: :gin
    t.index "((line_items -> 'sku'::text))", name: "index_abandoned_checkouts_on_line_items_sku_bak", using: :gin
    t.index ["email"], name: "index_abandoned_checkouts_on_email"
    t.index ["email"], name: "index_abandoned_checkouts_on_email_bak"
    t.index ["shop_id"], name: "index_abandoned_checkouts_on_shop_id"
    t.index ["shop_id"], name: "index_abandoned_checkouts_on_shop_id_bak"
    t.index ["shopify_created_at"], name: "index_abandoned_checkouts_on_shopify_created_at"
    t.index ["shopify_created_at"], name: "index_abandoned_checkouts_on_shopify_created_at_bak"
    t.index ["shopify_id"], name: "index_abandoned_checkouts_on_shopify_id", unique: true
    t.index ["shopify_id"], name: "index_abandoned_checkouts_on_shopify_id_bak", unique: true
  end

  create_table "abandoned_checkouts_bak", force: :cascade do |t|
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.string "token"
    t.string "cart_token"
    t.string "email"
    t.string "gateway"
    t.boolean "buyer_accepts_marketing"
    t.string "landing_site"
    t.string "note"
    t.string "referring_site"
    t.boolean "taxes_included"
    t.float "total_weight"
    t.string "currency"
    t.datetime "completed_at"
    t.datetime "closed_at"
    t.bigint "shopify_user_id"
    t.bigint "shopify_location_id"
    t.string "source_identifier"
    t.string "source_url"
    t.string "device_id"
    t.string "phone"
    t.string "customer_locale"
    t.string "name"
    t.string "source"
    t.string "abandoned_checkout_url"
    t.string "source_name"
    t.string "presentment_currency"
    t.decimal "total_discounts", precision: 10, scale: 2
    t.decimal "total_line_items_price", precision: 10, scale: 2
    t.decimal "total_price", precision: 10, scale: 2
    t.decimal "total_tax", precision: 10, scale: 2
    t.decimal "subtotal_price", precision: 10, scale: 2
    t.decimal "total_duties", precision: 10, scale: 2
    t.jsonb "note_attributes"
    t.jsonb "shipping_lines"
    t.jsonb "line_items"
    t.jsonb "discount_codes"
    t.jsonb "tax_lines"
    t.jsonb "shipping_address"
    t.jsonb "customer"
    t.bigint "shop_id"
    t.datetime "deleted_at"
    t.jsonb "email_history"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.json "tel_history"
  end

  create_table "active_admin_comments", force: :cascade do |t|
    t.string "namespace"
    t.text "body"
    t.string "resource_type"
    t.bigint "resource_id"
    t.string "author_type"
    t.bigint "author_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["author_type", "author_id"], name: "index_active_admin_comments_on_author_type_and_author_id"
    t.index ["namespace"], name: "index_active_admin_comments_on_namespace"
    t.index ["resource_type", "resource_id"], name: "index_active_admin_comments_on_resource_type_and_resource_id"
  end

  create_table "activities", id: :serial, force: :cascade do |t|
    t.string "email", null: false
    t.string "phone_number"
    t.string "genre", null: false
    t.string "source_ip", null: false
    t.string "shopify_domain", null: false
    t.string "country_code"
    t.string "register_source", null: false
    t.datetime "send_at"
    t.boolean "is_subscribed"
    t.jsonb "properties"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.text "images", array: true
    t.boolean "is_new_subscribe", comment: "是否为新订阅用户"
    t.jsonb "order_info", comment: "订单信息"
    t.string "name"
    t.jsonb "extend", comment: "是否为新订阅用户"
    t.index ["genre", "email", "shopify_domain"], name: "UQ_GENRE_EMAIL", unique: true
  end

  create_table "activities_form", id: :serial, force: :cascade do |t|
    t.integer "shop_id"
    t.string "shopify_domain", null: false
    t.string "email"
    t.string "order_name"
    t.string "genre", null: false
    t.string "source_ip", null: false
    t.string "register_source"
    t.jsonb "form_map", comment: "表单数据(数组型json存储 []object)"
    t.jsonb "extend", comment: "扩展字段(json存储 object)"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.jsonb "handled"
    t.date "handled_at"
    t.index ["genre"], name: "IDX_57a70a6fcf37f76236ab3bb411"
    t.index ["shop_id"], name: "IDX_ea3d815c55d488a386e1633fb0"
  end

  create_table "activities_interact", id: :serial, force: :cascade do |t|
    t.string "email", null: false
    t.string "name"
    t.text "content"
    t.string "genre", null: false
    t.string "source_ip", null: false
    t.string "shopify_domain", null: false
    t.string "country"
    t.string "country_code"
    t.string "register_source", null: false
    t.datetime "send_at"
    t.boolean "is_display", default: true
    t.jsonb "expand"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.boolean "is_top", default: false, comment: "是否置顶"
    t.string "code", comment: "gift card code str"
    t.jsonb "reply", comment: "回复内容"
  end

  create_table "activities_orders", id: :serial, force: :cascade do |t|
    t.bigint "order_id", comment: "订单ID"
    t.string "shopify_domain", null: false
    t.string "email", null: false
    t.string "genre", null: false
    t.jsonb "metafields", comment: "扩展元数据 jsonb 结构体"
    t.jsonb "expand", comment: "扩展数组型 jsonb 结构体"
    t.string "code", comment: "gift card code str"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["email"], name: "IDX_8a5013af8304059d17fbc1abeb"
    t.index ["expand"], name: "IDX_5bc82527786f84e17758c9a669", using: :gin
    t.index ["genre"], name: "IDX_8a5013af8304059d17fbc1aceb"
    t.index ["metafields"], name: "IDX_0ed45c283e86bcf6f49d4972df", using: :gin
    t.index ["order_id"], name: "IDX_8a5013af8304059d17fbc1baeb"
  end

  create_table "activity_configs", id: :serial, force: :cascade do |t|
    t.string "title", null: false, comment: "活动标题"
    t.string "genre", null: false
    t.string "shopify_domain", null: false, comment: "店铺域名"
    t.integer "shop_id", null: false, comment: "店铺id号"
    t.datetime "start_date", comment: "活动开始时间"
    t.datetime "end_date", comment: "活动结束时间"
    t.boolean "is_response_code", comment: "是否返回code给前端"
    t.string "price_rule_class", comment: "活动规则名称,和shopify的名称保持一致"
    t.string "rsys_campaign", comment: "edm配置,为空则不发送邮件"
    t.jsonb "edm_notices", comment: "edm配置,为空则不发送邮件"
    t.jsonb "extend", comment: "是否为新订阅用户"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.bigint "price_rule_id", comment: "活动规则shopify_id,和shopify的名称保持一致"
    t.index ["genre", "shop_id"], name: "UNIQUE_ACTIVE_IDX", unique: true
    t.index ["genre"], name: "IDX_7785c4b3e3af110088e5df372c"
    t.index ["shop_id"], name: "IDX_0758ecf3d20a916a209832a6c1"
  end

  create_table "addresses", force: :cascade do |t|
    t.bigint "customer_id"
    t.bigint "shopify_id"
    t.bigint "shopify_customer_id"
    t.string "address1"
    t.string "address2"
    t.string "phone"
    t.string "city"
    t.string "zip"
    t.string "province"
    t.string "country"
    t.string "first_name"
    t.string "last_name"
    t.string "latitude"
    t.string "longitude"
    t.string "name"
    t.string "company"
    t.string "country_code"
    t.string "province_code"
    t.boolean "default"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["shopify_id"], name: "index_addresses_on_shopify_id", unique: true
  end

  create_table "admin_users", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.string "uid"
    t.string "provider"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["email"], name: "index_admin_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_admin_users_on_reset_password_token", unique: true
  end

  create_table "admin_users_roles", id: false, force: :cascade do |t|
    t.bigint "admin_user_id"
    t.bigint "role_id"
    t.index ["admin_user_id", "role_id"], name: "index_admin_users_roles_on_admin_user_id_and_role_id"
    t.index ["admin_user_id"], name: "index_admin_users_roles_on_admin_user_id"
    t.index ["role_id"], name: "index_admin_users_roles_on_role_id"
  end

  create_table "affirm_checkout_events", force: :cascade do |t|
    t.string "checkout_token"
    t.string "event"
    t.datetime "event_timestamp"
    t.datetime "created"
    t.string "order_id"
    t.string "webhook_session_id"
    t.bigint "amount_financed"
    t.float "apr"
    t.bigint "downpayment_amount"
    t.string "email_address"
    t.bigint "finance_charge"
    t.string "first_name"
    t.datetime "first_payment_date"
    t.string "has_downpayment"
    t.string "last_name"
    t.bigint "number_of_payments"
    t.bigint "total"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "aicc_jobs", id: :serial, force: :cascade do |t|
    t.string "job_id", null: false, comment: "外呼任务id号"
    t.string "type", comment: "任务正对的业务类型"
    t.string "shopify_domain", comment: "店铺域名"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.integer "shop_id", comment: "店铺id"
    t.string "country_code", comment: "国家编码(手机号)"
    t.string "short_key", comment: "短连接token"
    t.string "short_domain", comment: "短链域名"
    t.jsonb "extend", comment: "额外补充信息"
    t.string "country_key", comment: "国家编码"
  end

  create_table "amazon_price_logs", force: :cascade do |t|
    t.bigint "shop_id"
    t.string "market"
    t.bigint "variant_id"
    t.string "sku"
    t.decimal "amazon_price", precision: 10, scale: 2
    t.decimal "amazon_old_price", precision: 10, scale: 2
    t.boolean "amazon_price_changed"
    t.boolean "price_invalid"
    t.string "price_invalid_reason"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["variant_id"], name: "index_amazon_price_logs_on_variant_id"
  end

  create_table "api_call_logs", force: :cascade do |t|
    t.string "url"
    t.text "req"
    t.text "resp"
    t.integer "status"
    t.boolean "has_error"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "awsdms_ddl_audit", primary_key: "c_key", force: :cascade do |t|
    t.datetime "c_time"
    t.string "c_user", limit: 64
    t.string "c_txn", limit: 16
    t.string "c_tag", limit: 24
    t.integer "c_oid"
    t.string "c_name", limit: 64
    t.string "c_schema", limit: 64
    t.text "c_ddlqry"
  end

  create_table "bundle_combinations", force: :cascade do |t|
    t.string "msku"
    t.string "sku_list"
    t.text "shopify_domains"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "bundle_creatives", force: :cascade do |t|
    t.string "locale"
    t.string "sku"
    t.string "image_url"
    t.string "product_title"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "business_orders", id: :serial, force: :cascade do |t|
    t.string "contact_name", null: false
    t.string "contact_email", null: false
    t.string "required_product", null: false
    t.string "quantity_required", null: false
    t.string "reason_for_purchase", null: false
    t.string "shipping_address", null: false
    t.string "desired_delivery_date", null: false
    t.string "phone_number"
    t.string "ticket_id"
    t.string "genre"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.string "shopify_domain", null: false
    t.datetime "notify2mkt_send_at"
    t.datetime "notify2customer_send_at"
    t.string "company_name"
    t.string "number_of_employees"
    t.text "additional_info"
    t.string "register_source"
  end

  create_table "carrier_names", force: :cascade do |t|
    t.string "cloud_name"
    t.string "aftership_slug"
    t.string "aftership_name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "cash_back_transactions", force: :cascade do |t|
    t.bigint "order_id"
    t.string "kind"
    t.string "status"
    t.string "gateway"
    t.decimal "amount", precision: 10, scale: 2
    t.string "currency"
    t.bigint "cloud_rma_id"
    t.bigint "cloud_refund_id"
    t.jsonb "raw_data"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "channel_recruitment", id: :serial, force: :cascade do |t|
    t.string "shopify_domain", null: false, comment: "店铺"
    t.string "tax_id", comment: "税号"
    t.string "domain_url", null: false, comment: "域名地址"
    t.string "domain_title", null: false, comment: "域名标题"
    t.string "company_name", null: false, comment: "公司名称"
    t.string "countries_businesses", null: false, comment: "您在哪些国家有业务？"
    t.string "gmv", comment: "贵公司的年总商品量（GMV）是多少？"
    t.string "media_profile", null: false, comment: "请提供您企业的社交媒体简介。"
    t.jsonb "website", comment: "你的商店或电子商务网站是什么？"
    t.string "social_profile", comment: "请提供您企业的社交媒体简介。"
    t.jsonb "industry", comment: "你从事什么行业？"
    t.jsonb "category", comment: "贵公司的主要业务类别是什么？"
    t.string "employees", null: false, comment: "你的企业有多少员工？"
    t.string "contact_name", null: false, comment: "联系人姓名"
    t.string "contact_title", null: false, comment: "联系人标题"
    t.string "contact_email", null: false, comment: "联系人电子邮件"
    t.string "contact_phone", null: false, comment: "联系人电话"
    t.jsonb "channel", comment: "你是怎么听说安克"
    t.datetime "push_email_at", comment: "推送时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
  end

  create_table "channel_recruitment_b2b", id: :serial, force: :cascade do |t|
    t.string "shopify_domain", null: false, comment: "店铺"
    t.string "url", null: false, comment: "url 页面地址"
    t.string "first_name", null: false, comment: "first_name"
    t.string "email", comment: "Work Email"
    t.string "job", comment: "Job Title"
    t.string "industry", comment: "industry"
    t.string "size", comment: "Size of Company (Number of Employees)"
    t.string "preferred", comment: "Preferred Purchase Channel"
    t.string "reason", comment: "Reason for Contacting Anker"
    t.string "register_source", comment: "register source"
    t.string "code", comment: "amz code"
    t.boolean "is_code", comment: "发送 code 邮件"
    t.string "ticket_number", comment: "ticket_number"
    t.datetime "push_manage_email_at", comment: "管理邮件"
    t.datetime "push_thank_email_at", comment: "致谢邮件"
    t.datetime "push_code_email_at", comment: "折扣code邮件"
    t.datetime "push_subscribe_at", comment: "订阅提交时间"
    t.datetime "push_ced_at", comment: "ced工单提交时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.string "product", comment: "product"
  end

  create_table "chill_box_items", force: :cascade do |t|
    t.string "market"
    t.string "email"
    t.string "order_name"
    t.integer "order_status", default: 0
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "cloud_deal_items", force: :cascade do |t|
    t.bigint "cloud_deal_id"
    t.integer "committed"
    t.string "msku"
    t.float "gross_margin"
    t.boolean "main_product"
    t.decimal "deal_price", precision: 10, scale: 2
    t.decimal "your_price", precision: 10, scale: 2
    t.string "bu"
    t.string "asin"
    t.string "currency"
    t.bigint "ext_id"
    t.bigint "ext_deal_id"
    t.string "sku"
    t.float "sale_amount"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["cloud_deal_id"], name: "index_cloud_deal_items_on_cloud_deal_id"
  end

  create_table "cloud_deals", force: :cascade do |t|
    t.datetime "deal_end_time"
    t.string "platform"
    t.string "currency_code"
    t.string "deal_title"
    t.datetime "deal_start_time"
    t.bigint "ext_id"
    t.string "outer_deal_status"
    t.string "deal_status"
    t.bigint "ext_store_id"
    t.json "ext"
    t.string "creator"
    t.string "deal_code"
    t.string "iwp_code"
    t.decimal "deal_fees", precision: 10, scale: 2
    t.string "deal_type"
    t.float "return_rate"
    t.string "time_zone"
    t.integer "version"
    t.string "sell_through_rate"
    t.integer "units_sold"
    t.float "deal_sales"
    t.string "updator"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "cloud_discounts", force: :cascade do |t|
    t.bigint "price_rule_id"
    t.string "cloud_id"
    t.string "title"
    t.integer "genre"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "cloud_deal_id", comment: "deal类型的折扣应该存储其父级cloud_id"
    t.string "asins", default: [], array: true
    t.bigint "shop_id"
    t.string "skus", array: true
    t.integer "status", default: 1
    t.string "mskus", array: true
    t.index ["price_rule_id"], name: "index_cloud_discounts_on_price_rule_id"
    t.index ["shop_id"], name: "index_cloud_discounts_on_shop_id"
  end

  create_table "cloud_fulfillment_tracks", force: :cascade do |t|
    t.bigint "cloud_fulfillment_id"
    t.jsonb "items"
    t.string "ship_method"
    t.datetime "shipped_date"
    t.string "track"
    t.string "tracking_url"
    t.datetime "upload_to_shopify_shipment_at"
    t.bigint "shopify_fulfillment_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["cloud_fulfillment_id"], name: "index_cloud_fulfillment_tracks_on_cloud_fulfillment_id"
  end

  create_table "cloud_fulfillments", force: :cascade do |t|
    t.bigint "fulfillment_order_id"
    t.string "fulfillment_order_type"
    t.bigint "cloud_id"
    t.string "state"
    t.string "warehouse"
    t.string "marketplace"
    t.jsonb "items"
    t.datetime "upload_date"
    t.datetime "upload_to_shopify_shipment_at"
    t.datetime "download_from_cloud_shipment_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["cloud_id"], name: "index_cloud_fulfillments_on_cloud_id", unique: true
    t.index ["fulfillment_order_id", "fulfillment_order_type"], name: "idx_fulfillment_order"
  end

  create_table "cloud_inventory_logs", force: :cascade do |t|
    t.bigint "shop_id"
    t.string "warehouse"
    t.bigint "variant_id"
    t.string "sku"
    t.bigint "cloud_sellable"
    t.bigint "cloud_reserved"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "cloud_ships", force: :cascade do |t|
    t.bigint "fulfillment_order_id"
    t.string "fulfillment_order_type"
    t.bigint "cloud_id"
    t.string "state"
    t.string "warehouse"
    t.jsonb "items"
    t.datetime "upload_date"
    t.datetime "upload_to_aftership_at"
    t.datetime "download_from_hzero_ship_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["cloud_id"], name: "index_cloud_ships_on_cloud_id", unique: true
    t.index ["fulfillment_order_id", "fulfillment_order_type"], name: "index_fulfillment_order"
  end

  create_table "cloud_tracks", force: :cascade do |t|
    t.bigint "cloud_ship_id"
    t.jsonb "items"
    t.string "ship_method"
    t.datetime "shipped_date"
    t.string "track"
    t.string "tracking_url"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.datetime "upload_to_aftership_at"
    t.index ["cloud_ship_id"], name: "index_cloud_tracks_on_cloud_ship_id"
  end

  create_table "companies", force: :cascade do |t|
    t.bigint "shopify_id"
    t.integer "contact_count"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.datetime "customer_since"
    t.jsonb "default_role"
    t.string "external_id"
    t.boolean "has_timeline_comment"
    t.string "lifetime_duration"
    t.integer "location_count"
    t.jsonb "main_contact"
    t.jsonb "metafields"
    t.string "name"
    t.string "note"
    t.integer "order_count"
    t.jsonb "total_spent"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "content_articles", force: :cascade do |t|
    t.bigint "shop_id", comment: "店铺ID"
    t.bigint "blog_id"
    t.bigint "shopify_id"
    t.bigint "shopify_blog_id"
    t.bigint "shopify_user_id"
    t.string "author"
    t.string "title"
    t.text "body_html"
    t.text "summary_html"
    t.string "template_suffix"
    t.string "handle"
    t.string "tags"
    t.json "image"
    t.string "path"
    t.json "relevant", default: []
    t.datetime "published_at", default: -> { "now()" }, null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["shopify_id"], name: "UQ_f2b0d3f07cd981b34d04c5aeb52", unique: true
  end

  create_table "content_blogs", force: :cascade do |t|
    t.bigint "shop_id", comment: "店铺ID"
    t.bigint "shopify_id"
    t.string "title"
    t.string "handle"
    t.string "commentable"
    t.string "feedburner"
    t.string "feedburner_location"
    t.string "template_suffix"
    t.string "tags"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["shopify_id"], name: "UQ_b059485e6e098e782e1f14545ec", unique: true
  end

  create_table "credit_orders", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.string "credit_id", null: false, comment: "平台订单ID"
    t.bigint "shop_id", comment: "店铺ID"
    t.string "shopify_domain", null: false, comment: "店铺地址"
    t.string "marketplace", null: false, comment: "市场"
    t.bigint "shopify_order_id", comment: "订单ID"
    t.string "shopify_order_name", comment: "订单名称"
    t.bigint "shopify_transactions_id", comment: "付款ID"
    t.bigint "shopify_location_id", comment: "库存ID"
    t.bigint "shopify_app_id"
    t.string "shopify_order_status_url", comment: "订单状态链接"
    t.jsonb "source_tags", comment: "渠道标签"
    t.string "email", comment: "邮箱"
    t.string "local", comment: "订单所在区域"
    t.string "first_name", comment: "名字"
    t.string "last_name", comment: "姓氏"
    t.string "currency", null: false, comment: "币种"
    t.string "financial_status", null: false, comment: "订单状态"
    t.string "fulfillment_status", comment: "发货状态"
    t.decimal "total_price", precision: 10, scale: 2, comment: "订单金额"
    t.decimal "total_tax", precision: 10, scale: 2, comment: "订单税款"
    t.decimal "total_shipping", precision: 10, scale: 2, comment: "物流费用"
    t.boolean "send_fulfillment_receipt", default: false, comment: "发送确认邮件"
    t.jsonb "billing_address", comment: "发票地址"
    t.jsonb "shipping_address", comment: "发货地址"
    t.jsonb "line_items", comment: "订单中产品项"
    t.jsonb "tax_lines", comment: "订单扣税项"
    t.jsonb "location_infos", comment: "发货仓库信息"
    t.jsonb "shipping_lines", comment: "订单产品运输项"
    t.jsonb "fulfillments", comment: "订单发货物流信息"
    t.decimal "shopify_total_price", precision: 10, scale: 2, comment: "订单金额"
    t.decimal "shopify_total_tax", precision: 10, scale: 2, comment: "订单税款"
    t.decimal "shopify_total_shipping", precision: 10, scale: 2, comment: "物流费用"
    t.jsonb "shopify_billing_address", comment: "shopify发票地址"
    t.jsonb "shopify_shipping_address", comment: "shopify发货地址"
    t.jsonb "shopify_line_items", comment: "shopify订单中产品项"
    t.jsonb "shopify_shipping_lines", comment: "shopify订单产品运输项"
    t.jsonb "shopify_fulfillments", comment: "shopify订单发货物流信息"
    t.boolean "audit_status", default: false, comment: "订单审核状态"
    t.text "desc", comment: "订单备注描述"
    t.jsonb "extend", comment: "扩展字段"
    t.jsonb "extend_log", comment: "操作日志"
    t.datetime "buy_at"
    t.datetime "pay_at"
    t.bigint "create_by"
    t.bigint "update_by"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["credit_id"], name: "IDX_7229825b88a111020a8398a900"
  end

  create_table "customer_blacklists", force: :cascade do |t|
    t.string "order_name"
    t.string "email"
    t.jsonb "billing_address"
    t.jsonb "shipping_address"
    t.integer "status"
    t.string "note"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index "((billing_address -> 'city'::text))", name: "index_customer_blacklists_on_billing_address_city"
    t.index "((billing_address -> 'country'::text))", name: "index_customer_blacklists_on_billing_address_country"
    t.index "((billing_address -> 'zip'::text))", name: "index_customer_blacklists_on_billing_address_zip"
    t.index "((shipping_address -> 'city'::text))", name: "index_customer_blacklists_on_shipping_address_city"
    t.index "((shipping_address -> 'country'::text))", name: "index_customer_blacklists_on_shipping_address_country"
    t.index "((shipping_address -> 'zip'::text))", name: "index_customer_blacklists_on_shipping_address_zip"
    t.index "lower((email)::text)", name: "index_customer_blacklists_on_lower_email"
    t.index ["order_name"], name: "index_customer_blacklists_on_order_name", unique: true
  end

  create_table "customers", force: :cascade do |t|
    t.bigint "shopify_id"
    t.string "email"
    t.boolean "accepts_marketing"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.string "first_name"
    t.string "last_name"
    t.integer "orders_count"
    t.string "state"
    t.decimal "total_spent", precision: 10, scale: 2
    t.bigint "shopify_last_order_id"
    t.string "note"
    t.boolean "verified_email"
    t.string "multipass_identifier"
    t.boolean "tax_exempt"
    t.string "phone"
    t.string "tags"
    t.string "last_order_name"
    t.string "currency"
    t.bigint "default_address_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.jsonb "email_marketing_consent"
    t.jsonb "sms_marketing_consent"
    t.jsonb "addresses"
    t.jsonb "default_address"
    t.jsonb "tax_exemptions"
    t.bigint "last_order_id"
    t.bigint "shop_id"
    t.jsonb "ext_data"
    t.index ["shop_id"], name: "index_customers_on_shop_id"
    t.index ["shopify_id"], name: "index_customers_on_shopify_id", unique: true
    t.index ["shopify_updated_at"], name: "index_customers_on_shopify_updated_at"
    t.index ["updated_at"], name: "index_customers_on_updated_at"
  end

  create_table "data_collects", id: :uuid, default: -> { "uuid_generate_v4()" }, force: :cascade do |t|
    t.string "data_type", null: false, comment: "数据类型"
    t.string "shopify_domain", comment: "店铺域名"
    t.integer "shop_id", comment: "店铺id"
    t.jsonb "data"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["data_type"], name: "IDX_bd5abe14d3ac9b23df041fd378"
    t.index ["shop_id"], name: "IDX_a6f939ada076d11b5892ddc2e0"
  end

  create_table "discount_code_batches", force: :cascade do |t|
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.integer "status"
    t.integer "codes_count"
    t.integer "imported_count"
    t.integer "failed_count"
    t.bigint "shopify_price_rule_id"
    t.bigint "shop_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["shop_id"], name: "index_discount_code_batches_on_shop_id"
  end

  create_table "discount_codes", force: :cascade do |t|
    t.bigint "shopify_id"
    t.string "code"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.integer "usage_count"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "shop_id"
    t.bigint "shopify_price_rule_id"
    t.boolean "assigned"
    t.string "assigned_email"
    t.datetime "expired_at"
    t.datetime "deleted_at"
    t.index ["code"], name: "index_discount_codes_on_code"
    t.index ["deleted_at"], name: "index_discount_codes_on_deleted_at"
    t.index ["shop_id"], name: "index_discount_codes_on_shop_id"
    t.index ["shopify_id"], name: "index_discount_codes_on_shopify_id"
    t.index ["shopify_price_rule_id"], name: "index_discount_codes_on_shopify_price_rule_id"
  end

  create_table "disputes", force: :cascade do |t|
    t.bigint "shopify_id"
    t.bigint "shopify_order_id"
    t.string "type"
    t.string "currency"
    t.decimal "amount", precision: 10, scale: 2
    t.string "reason"
    t.string "network_reason_code"
    t.string "status"
    t.datetime "evidence_due_by"
    t.datetime "evidence_sent_on"
    t.datetime "finalized_on"
    t.datetime "initiated_at"
    t.bigint "shop_id"
    t.datetime "upload_data_at"
    t.datetime "upload_result_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.jsonb "order_status"
    t.boolean "order_cancelled", default: false
    t.index ["shop_id"], name: "index_disputes_on_shop_id"
    t.index ["shopify_id"], name: "index_disputes_on_shopify_id", unique: true
  end

  create_table "drawn_prize_error_logs", id: :serial, force: :cascade do |t|
    t.string "genre", null: false, comment: "活动标识"
    t.string "shopify_domain", null: false, comment: "店铺域名"
    t.jsonb "data", null: false, comment: "表单数据"
    t.string "error_data", comment: "错误信息"
    t.datetime "error_date", comment: "本次奖品能兑现的最终截止时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
  end

  create_table "dropshipping_channel", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.string "dropshipping_shop_uuid", limit: 36, comment: "分销店铺ID"
    t.string "dropshipping_shop_domain", comment: "分销店铺地址"
    t.bigint "shop_id", comment: "店铺ID"
    t.string "shopify_domain", null: false, comment: "店铺地址"
    t.string "channel_name", comment: "渠道名称"
    t.string "parse_template", null: false, comment: "订单上传解析模板"
    t.string "channel_key", comment: "渠道唯一ID"
    t.string "channel_token", comment: "渠道授权"
    t.string "email_prefix", comment: "邮箱前缀"
    t.string "marketplace", null: false, comment: "市场"
    t.string "source_name", null: false, comment: "渠道来源"
    t.text "desc", null: false, comment: "渠道来源"
    t.boolean "auto_orders", default: false, comment: "自动订单提交"
    t.jsonb "source_tags", null: false, comment: "渠道标签"
    t.jsonb "settings", null: false, comment: "渠道配置信息"
    t.jsonb "locations", null: false, comment: "仓库配置"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.jsonb "extend", comment: "扩展字段"
    t.jsonb "extend_log", comment: "操作日志"
    t.bigint "create_by"
    t.bigint "update_by"
    t.string "cloud_upload_market", comment: "cloud市场"
    t.index ["channel_key"], name: "UQ_2835ff8d45178befc439610f056", unique: true
  end

  create_table "dropshipping_channel_sync_file", id: :serial, force: :cascade do |t|
    t.string "file_path", comment: "文件地址"
    t.string "file_name", comment: "文件名"
    t.string "file_s3_path", comment: "S3文件存储地址"
    t.integer "state", default: 0, comment: "同步状态， 1 完成"
    t.string "message", comment: "执行消息"
    t.jsonb "extend", default: {}, comment: "扩展字段"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.string "dropshipping_channel_uuid", limit: 36, comment: "渠道唯一ID"
  end

  create_table "dropshipping_feed_mappings", id: :serial, force: :cascade do |t|
    t.string "shop_domain"
    t.string "name", null: false
    t.jsonb "record", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.bigint "update_by"
    t.index ["name"], name: "UQ_83b59b11c2d9517c27ed7190ad0", unique: true
  end

  create_table "dropshipping_feed_notify_logs", id: :serial, force: :cascade do |t|
    t.integer "feed_id"
    t.string "to", null: false
    t.text "content", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
  end

  create_table "dropshipping_feed_records", id: :serial, force: :cascade do |t|
    t.string "channel_id"
    t.integer "feed_id"
    t.string "sku", null: false
    t.decimal "price"
    t.decimal "discount_price"
    t.decimal "sale_price", null: false, comment: "指定销售的价格"
    t.string "version", null: false
    t.jsonb "record", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.string "send_type", comment: "推送方式"
  end

  create_table "dropshipping_feed_v2_records", id: :serial, force: :cascade do |t|
    t.string "channel_id"
    t.integer "feed_id"
    t.string "sku", null: false
    t.decimal "price"
    t.decimal "discount_price"
    t.decimal "sale_price", null: false, comment: "指定销售的价格"
    t.string "version", null: false
    t.string "send_type", comment: "推送方式"
    t.jsonb "record", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.index ["channel_id"], name: "IDX_128e4caaacfce8112a551b875b"
    t.index ["created_at"], name: "IDX_ac5fd69fd4e37077ba3dc37df8"
    t.index ["feed_id", "version"], name: "idx_dropshipping_feed_records_feedid_version"
    t.index ["feed_id"], name: "IDX_654cb8b69e014d304ea66d9aa0"
    t.index ["version"], name: "IDX_90c8b1c5a2b5a7a524a6f314d7"
  end

  create_table "dropshipping_feed_v3_records", id: :serial, force: :cascade do |t|
    t.string "channel_id"
    t.integer "feed_id"
    t.string "sku", null: false
    t.decimal "price"
    t.decimal "discount_price"
    t.decimal "sale_price", null: false, comment: "指定销售的价格"
    t.string "version", null: false
    t.string "send_type", comment: "推送方式"
    t.jsonb "record", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.integer "inventory_quantity", default: 0, null: false
    t.index ["channel_id"], name: "IDX_53197ad57fa8a8d2ce95bdb4c6"
    t.index ["created_at"], name: "IDX_d942d72f10cef67ec70dca2ccd"
    t.index ["feed_id", "version"], name: "idx_dropshipping_feed_records_v3_feedid_version"
    t.index ["feed_id"], name: "IDX_97725e2a3c60076f53d7ea93b5"
    t.index ["version"], name: "IDX_17a3150918c0654af19c0e4cad"
  end

  create_table "dropshipping_feeds", id: :serial, force: :cascade do |t|
    t.string "name", null: false, comment: "feed名称"
    t.string "channel_id"
    t.bigint "shop_id", null: false, comment: "店铺id"
    t.string "shop_domain"
    t.jsonb "columns", default: [], null: false
    t.string "filter", default: "[]", null: false
    t.string "file_name", default: "", null: false, comment: "文件名称"
    t.string "file_type", null: false, comment: "文件格式"
    t.jsonb "csv_option", comment: "csv格式配置"
    t.string "remark", comment: "备注"
    t.bigint "create_by"
    t.bigint "update_by"
    t.bigint "deleted_by"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.string "status", default: "deactive", null: false, comment: "feed状态"
    t.datetime "last_send_at"
    t.jsonb "email_options", comment: "发送email_option配置"
    t.jsonb "ftp_options", comment: "发送ftp_option配置"
    t.jsonb "sale_price", comment: "售卖价格配置"
    t.integer "send_times", default: 0
    t.jsonb "notify_options", comment: "推送"
    t.jsonb "notify_sku", comment: "推送关注的sku"
    t.string "last_version"
    t.jsonb "filter_options"
    t.index ["name"], name: "IDX_c4dad6b11ff96aafdc58549a31"
    t.index ["shop_domain"], name: "IDX_dcf4276e3a2f9b3f60112029b3"
  end

  create_table "dropshipping_gmc", id: :serial, force: :cascade do |t|
    t.string "name", null: false, comment: "feed名称"
    t.bigint "shop_id", null: false, comment: "店铺id"
    t.string "shop_domain"
    t.jsonb "columns", default: [], null: false
    t.string "filter", default: "[]", null: false
    t.string "remark", comment: "备注"
    t.string "merchantId", null: false
    t.bigint "create_by"
    t.bigint "update_by"
    t.integer "account"
    t.bigint "deleted_by"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.string "status", default: "deactive", null: false, comment: "feed状态"
    t.datetime "last_send_at"
  end

  create_table "dropshipping_gmc_accounts", id: :serial, force: :cascade do |t|
    t.string "access_token", null: false
    t.string "refresh_token", null: false
    t.text "scope", null: false
    t.string "token_type", null: false
    t.text "id_token", null: false
    t.string "email", null: false
    t.string "name", null: false
    t.jsonb "user_info", null: false
    t.bigint "expiry_date", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["email"], name: "UQ_7e07daa483fb1ee1151a5a7252d", unique: true
  end

  create_table "dropshipping_gmc_records", id: :serial, force: :cascade do |t|
    t.integer "feed_id"
    t.string "method", null: false
    t.jsonb "records", null: false
    t.jsonb "send_result", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.jsonb "del_result"
  end

  create_table "dropshipping_history", id: :serial, force: :cascade do |t|
    t.string "uuid", limit: 36, comment: "渠道订单ID"
    t.string "action", null: false, comment: "动作"
    t.string "info", comment: "消息"
    t.jsonb "attach", comment: "分销配置信息"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
  end

  create_table "dropshipping_orders", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.bigint "shop_id", comment: "店铺ID"
    t.string "shopify_domain", null: false, comment: "店铺地址"
    t.string "dropshipping_shop_uuid", limit: 36, comment: "分销店铺ID"
    t.string "dropshipping_shop_domain", comment: "分销店铺地址"
    t.string "dropshipping_channel_uuid", limit: 36, comment: "分销店铺渠道ID"
    t.string "marketplace", null: false, comment: "市场"
    t.bigint "shopify_order_id", comment: "订单ID"
    t.bigint "shopify_transactions_id", comment: "付款ID"
    t.bigint "shopify_location_id", comment: "库存ID"
    t.bigint "shopify_app_id"
    t.string "shopify_order_status_url", comment: "订单状态链接"
    t.string "source_name", null: false, comment: "渠道来源"
    t.jsonb "source_tags", comment: "渠道标签"
    t.string "platform_order_id", null: false, comment: "平台订单ID"
    t.string "email", comment: "邮箱"
    t.string "first_name", comment: "名字"
    t.string "last_name", comment: "姓氏"
    t.string "currency", null: false, comment: "币种"
    t.string "financial_status", null: false, comment: "订单状态"
    t.string "fulfillment_status", comment: "发货状态"
    t.decimal "total_price", precision: 10, scale: 2, comment: "订单金额"
    t.decimal "total_tax", precision: 10, scale: 2, comment: "订单税款"
    t.decimal "total_shipping", precision: 10, scale: 2, comment: "物流费用"
    t.boolean "send_fulfillment_receipt", default: false, comment: "发送确认邮件"
    t.jsonb "billing_address", comment: "发票地址"
    t.jsonb "shipping_address", comment: "发货地址"
    t.jsonb "line_items", comment: "订单中产品项"
    t.jsonb "tax_lines", comment: "订单扣税项"
    t.jsonb "location_infos", comment: "发货仓库信息"
    t.jsonb "shipping_lines", comment: "订单产品运输项"
    t.jsonb "fulfillments", comment: "订单发货物流信息"
    t.decimal "shopify_total_price", precision: 10, scale: 2, comment: "订单金额"
    t.decimal "shopify_total_tax", precision: 10, scale: 2, comment: "订单税款"
    t.decimal "shopify_total_shipping", precision: 10, scale: 2, comment: "物流费用"
    t.jsonb "shopify_billing_address", comment: "shopify发票地址"
    t.jsonb "shopify_shipping_address", comment: "shopify发货地址"
    t.jsonb "shopify_line_items", comment: "shopify订单中产品项"
    t.jsonb "shopify_shipping_lines", comment: "shopify订单产品运输项"
    t.jsonb "shopify_fulfillments", comment: "shopify订单发货物流信息"
    t.boolean "audit_status", default: false, comment: "订单审核状态"
    t.text "desc", comment: "订单备注描述"
    t.datetime "buy_at"
    t.datetime "pay_at"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.string "feed_version", comment: "feed版本"
    t.jsonb "extend", comment: "扩展字段"
    t.string "shopify_order_name", comment: "订单名称"
    t.jsonb "extend_log", comment: "操作日志"
    t.bigint "create_by"
    t.bigint "update_by"
    t.index ["platform_order_id"], name: "IDX_51341436034c47878f1b7cda9d"
  end

  create_table "dropshipping_shop", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.string "shop_key", null: false, comment: "分销店铺唯一识别码"
    t.string "title", comment: "分销店铺名称"
    t.text "desc", comment: "分销店铺描述"
    t.string "dropshipping_domain", comment: "分销店铺"
    t.jsonb "settings", null: false, comment: "分销配置信息"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
  end

  create_table "dropshipping_ticket", id: :serial, force: :cascade do |t|
    t.string "dropshipping_channel_uuid", limit: 36, comment: "分销店铺渠道ID"
    t.string "order_id", null: false, comment: "订单ID"
    t.string "platform_order_id", null: false, comment: "平台订单ID"
    t.string "ticket_type"
    t.string "ticket_status"
    t.string "title", comment: "分销店铺名称"
    t.text "desc", comment: "分销店铺描述"
    t.jsonb "extend", default: {}
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["order_id"], name: "IDX_74babe5858f23b7e40a54a0fe9"
    t.index ["platform_order_id"], name: "IDX_fe5153eb5ff5e49ce374bdb75e"
  end

  create_table "dropshipping_variant_update_logs", id: :serial, force: :cascade do |t|
    t.bigint "shop_id", null: false, comment: "店铺id"
    t.string "sku", null: false
    t.string "value", null: false
    t.string "compare_value"
    t.string "variant_price4wscode"
    t.string "log_type", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.string "shopify_id"
    t.index ["created_at"], name: "IDX_400fc15b66b26793827291b72f"
    t.index ["log_type"], name: "IDX_3f835471fb367737883341ebdf"
    t.index ["sku"], name: "IDX_248a19b69a7aeeaa3faf6982ed"
  end

  create_table "earbud_cares", force: :cascade do |t|
    t.bigint "shop_id"
    t.bigint "earbud_order_id"
    t.string "earbud_order_market"
    t.string "earbud_order_name"
    t.string "earbud_order_sku"
    t.integer "earbud_order_quantity"
    t.datetime "earbud_order_date"
    t.bigint "care_order_id"
    t.datetime "care_order_date"
    t.string "care_order_index"
    t.string "care_order_sku"
    t.bigint "price_rule_id"
    t.bigint "discount_code_id"
    t.string "code"
    t.datetime "code_expired_at"
    t.bigint "redeem_order_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["care_order_id"], name: "index_earbud_cares_on_care_order_id"
    t.index ["code"], name: "index_earbud_cares_on_code"
    t.index ["earbud_order_id"], name: "index_earbud_cares_on_earbud_order_id"
    t.index ["earbud_order_name"], name: "index_earbud_cares_on_earbud_order_name"
  end

  create_table "earbud_luggage_tags", force: :cascade do |t|
    t.string "order_market"
    t.string "order_name"
    t.string "email"
    t.bigint "shop_id"
    t.jsonb "shipping_address"
    t.integer "quantity"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "ext_codes", force: :cascade do |t|
    t.string "code", null: false, comment: "折扣码|兑换码|*码"
    t.string "flag", null: false, comment: "标识符: 活动名"
    t.string "assign_to", comment: "分配对象"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["code"], name: "index_ext_codes_on_code"
  end

  create_table "fei_shu_notice_members", id: :serial, force: :cascade do |t|
    t.string "open_id", limit: 255
    t.string "user_name", limit: 255
    t.string "chat_id", limit: 255
    t.string "chat_name", limit: 255
    t.string "shopify_domain", limit: 255
    t.datetime "createdAt", null: false
    t.datetime "updatedAt", null: false
  end

  create_table "fulfillment_orders", force: :cascade do |t|
    t.bigint "order_id"
    t.bigint "shopify_id"
    t.bigint "shopify_assigned_location_id"
    t.bigint "shopify_shop_id"
    t.bigint "shopify_order_id"
    t.string "fulfillment_service_handle"
    t.string "request_status"
    t.string "status"
    t.jsonb "supported_actions"
    t.jsonb "destination"
    t.jsonb "line_items"
    t.jsonb "assigned_location"
    t.jsonb "merchant_requests"
    t.datetime "upload_to_cloud_order_at"
    t.string "cloud_order_id"
    t.datetime "download_from_cloud_shipment_at"
    t.string "cloud_shipment_status"
    t.datetime "cloud_shipped_date"
    t.string "cloud_tracking_number"
    t.string "cloud_tracking_url"
    t.datetime "upload_to_shopify_shipment_at"
    t.jsonb "cloud_order_data"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "shopify_fulfillment_id"
    t.string "cloud_ship_method"
    t.datetime "cloud_upload_date"
    t.string "split_order_status"
    t.datetime "download_from_hzero_ship_at"
    t.datetime "upload_to_aftership_ship_at"
    t.jsonb "upload_to_aftership_data"
    t.string "cloud_order_state"
    t.index ["cloud_order_id"], name: "index_fulfillment_orders_on_cloud_order_id"
    t.index ["created_at"], name: "index_fulfillment_orders_on_created_at"
    t.index ["order_id"], name: "index_fulfillment_orders_on_order_id"
    t.index ["shopify_id"], name: "index_fulfillment_orders_on_shopify_id", unique: true
  end

  create_table "fulfillment_sub_orders", force: :cascade do |t|
    t.bigint "fulfillment_order_id"
    t.datetime "upload_to_cloud_order_at"
    t.string "cloud_order_id"
    t.datetime "download_from_cloud_shipment_at"
    t.string "cloud_shipment_status"
    t.datetime "cloud_shipped_date"
    t.string "cloud_tracking_number"
    t.string "cloud_tracking_url"
    t.datetime "upload_to_shopify_shipment_at"
    t.jsonb "cloud_order_data"
    t.bigint "shopify_fulfillment_id"
    t.string "cloud_ship_method"
    t.datetime "cloud_upload_date"
    t.bigint "item_id"
    t.integer "item_no"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.datetime "download_from_hzero_ship_at"
    t.datetime "upload_to_aftership_ship_at"
    t.jsonb "upload_to_aftership_data"
    t.string "cloud_order_state"
    t.index ["cloud_order_id"], name: "index_fulfillment_sub_orders_on_cloud_order_id", unique: true
  end

  create_table "fulfillments", force: :cascade do |t|
    t.bigint "order_id"
    t.bigint "shopify_id"
    t.string "status"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.string "service"
    t.string "tracking_company"
    t.string "shipment_status"
    t.bigint "location_id"
    t.string "tracking_number"
    t.string "tracking_url"
    t.string "name"
    t.jsonb "tracking_numbers"
    t.jsonb "tracking_urls"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["order_id"], name: "index_fulfillments_on_order_id"
    t.index ["shopify_id"], name: "index_fulfillments_on_shopify_id", unique: true
  end

  create_table "gift_cards", force: :cascade do |t|
    t.bigint "shop_id"
    t.float "balance"
    t.string "code"
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.string "currency"
    t.bigint "customer_id"
    t.datetime "disabled_at"
    t.date "expires_on"
    t.float "initial_value"
    t.string "last_characters"
    t.bigint "line_item_id"
    t.string "note"
    t.bigint "order_id"
    t.string "template_suffix"
    t.bigint "user_id"
    t.bigint "api_client_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "group_buy", force: :cascade do |t|
    t.bigint "shop_id", null: false, comment: "店铺ID"
    t.string "shopify_domain", null: false, comment: "站点域名"
    t.bigint "variant_id", null: false
    t.bigint "order_id"
    t.string "genre", null: false
    t.string "source_ip", null: false, comment: "来源IP"
    t.string "nickname", null: false, comment: "昵称"
    t.string "temp_email", comment: "临时Email"
    t.string "email", comment: "订单Email"
    t.string "launch_code", null: false, comment: "发起人code"
    t.string "part_code", null: false, comment: "邀请人code"
    t.string "code", null: false, comment: "列表券code"
    t.string "register_source", null: false, comment: "站点地址"
    t.jsonb "metafields", comment: "表单数据(数组型json存储 []object)"
    t.jsonb "extend", comment: "扩展字段(json存储 object)"
    t.boolean "is_complete", default: false, null: false, comment: "是否完成团购"
    t.datetime "complete_at", comment: "完成团购时间"
    t.datetime "complete_send", comment: "团购完成通知发送时间"
    t.datetime "expired_at", null: false, comment: "团购结束时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["launch_code"], name: "IDX_8bef34875315e0a2a13304e7eb"
    t.index ["shop_id"], name: "IDX_2ecc66e4e831977a47fff7bfee"
    t.index ["variant_id"], name: "IDX_3769abfb0e7f3d2ab829d0f63a"
  end

  create_table "inventory_items", force: :cascade do |t|
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.bigint "shop_id"
    t.decimal "cost", precision: 10, scale: 2
    t.string "country_code_of_origin"
    t.jsonb "country_harmonized_system_codes"
    t.string "harmonized_system_code"
    t.string "province_code_of_origin"
    t.string "sku"
    t.boolean "tracked"
    t.boolean "requires_shipping"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["shop_id"], name: "index_inventory_items_on_shop_id"
    t.index ["shopify_id"], name: "index_inventory_items_on_shopify_id", unique: true
  end

  create_table "inventory_levels", force: :cascade do |t|
    t.datetime "shopify_updated_at"
    t.bigint "available"
    t.bigint "shopify_inventory_item_id"
    t.bigint "shopify_location_id"
    t.bigint "inventory_item_id"
    t.bigint "location_id"
    t.integer "cloud_sellable"
    t.integer "cloud_average_sale"
    t.integer "cloud_reserved"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["inventory_item_id"], name: "index_inventory_levels_on_inventory_item_id"
    t.index ["location_id"], name: "index_inventory_levels_on_location_id"
    t.index ["shopify_inventory_item_id", "shopify_location_id"], name: "uni_item_location_id", unique: true
  end

  create_table "issue_gift_card_logs", force: :cascade do |t|
    t.string "unique_key"
    t.string "attachable_type"
    t.bigint "attachable_id"
    t.string "status"
    t.bigint "gift_card_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "email_status"
    t.index ["attachable_type", "attachable_id"], name: "index_issue_gift_card_logs_on_attachable_type_and_attachable_id"
    t.index ["unique_key"], name: "index_issue_gift_card_logs_on_unique_key", unique: true
  end

  create_table "line_items", force: :cascade do |t|
    t.bigint "order_id"
    t.bigint "shopify_id"
    t.bigint "shopify_variant_id"
    t.string "title"
    t.integer "quantity"
    t.string "sku"
    t.string "variant_title"
    t.string "vendor"
    t.string "fulfillment_service"
    t.bigint "shopify_product_id"
    t.boolean "requires_shipping"
    t.boolean "taxable"
    t.boolean "gift_card"
    t.string "name"
    t.string "variant_inventory_management"
    t.boolean "product_exists"
    t.integer "fulfillable_quantity"
    t.integer "grams"
    t.decimal "price", precision: 10, scale: 2
    t.decimal "total_discount", precision: 10, scale: 2
    t.jsonb "price_set"
    t.jsonb "properties"
    t.jsonb "tax_lines"
    t.jsonb "total_discount_set"
    t.jsonb "discount_allocations"
    t.jsonb "origin_location"
    t.jsonb "duties"
    t.decimal "cost_charge_shipping", precision: 10, scale: 2, default: "0.0"
    t.decimal "cost_promo_product", precision: 10, scale: 2, default: "0.0"
    t.decimal "cost_promo_shipping", precision: 10, scale: 2, default: "0.0"
    t.decimal "cost_promo_code", precision: 10, scale: 2, default: "0.0"
    t.decimal "cost_payment_commission", precision: 10, scale: 2, default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.decimal "item_tax", precision: 10, scale: 2, default: "0.0"
    t.decimal "shipping_tax", precision: 10, scale: 2, default: "0.0"
    t.decimal "cost_shopify_commission", precision: 10, scale: 2, default: "0.0"
    t.decimal "cost_riskified_commission", precision: 10, scale: 2, default: "0.0"
    t.index ["order_id"], name: "index_line_items_on_order_id"
    t.index ["shopify_id"], name: "index_line_items_on_shopify_id", unique: true
    t.index ["sku"], name: "index_line_items_on_sku"
  end

  create_table "locations", force: :cascade do |t|
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.bigint "shop_id"
    t.boolean "active"
    t.string "address1"
    t.string "address2"
    t.string "city"
    t.string "country"
    t.string "country_code"
    t.boolean "legacy"
    t.string "name"
    t.string "phone"
    t.string "province"
    t.string "province_code"
    t.string "zip"
    t.string "localized_country_name"
    t.string "localized_province_name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["shop_id"], name: "index_locations_on_shop_id"
    t.index ["shopify_id"], name: "index_locations_on_shopify_id", unique: true
  end

  create_table "lotteries", id: :serial, force: :cascade do |t|
    t.string "email", null: false
    t.string "register_source", null: false
    t.integer "prize_id", null: false
    t.integer "prize_pool_id", null: false
    t.jsonb "prize_detail"
    t.boolean "shared", default: false, null: false, comment: "share get lottery times"
    t.jsonb "extend", comment: "扩展字段"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.string "source_ip"
    t.decimal "recaptcha_score", precision: 5, scale: 2, comment: "google验证得分"
  end

  create_table "migrations", id: :serial, force: :cascade do |t|
    t.bigint "timestamp", null: false
    t.string "name", null: false
  end

  create_table "operation_logs", force: :cascade do |t|
    t.bigint "shop_id"
    t.string "operation"
    t.string "operator"
    t.string "status"
    t.text "info"
    t.string "operand_type"
    t.bigint "operand_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.jsonb "ext_data"
    t.index ["operand_type", "operand_id"], name: "index_operation_logs_on_operand_type_and_operand_id"
    t.index ["shop_id"], name: "index_operation_logs_on_shop_id"
  end

  create_table "optometry_info", id: :serial, force: :cascade do |t|
    t.string "shopify_domain", limit: 128, null: false, comment: "店铺域名"
    t.string "name", limit: 64, comment: "订单名"
    t.bigint "order_id", null: false, comment: "订单id"
    t.bigint "line_item_shopify_id", null: false, comment: "订单行的唯一号"
    t.float "right_sphere", null: false, comment: "右眼视力"
    t.float "right_cyl", null: false, comment: "右眼散光"
    t.float "right_axis", null: false, comment: "右眼轴距"
    t.float "right_pd", null: false, comment: "右眼瞳距"
    t.float "left_sphere", null: false, comment: "左眼视力"
    t.float "left_cyl", null: false, comment: "左眼散光"
    t.float "left_axis", null: false, comment: "左眼轴距"
    t.float "left_pd", null: false, comment: "左眼瞳距"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["line_item_shopify_id", "order_id"], name: "UQ_c618f59c79bef6ea0a0f178e1f9", unique: true
    t.index ["line_item_shopify_id"], name: "IDX_1c18ddda1cc12de598e7ff7c65"
    t.index ["order_id"], name: "IDX_d6b3745f3013636b68bc1b95f3"
  end

  create_table "order_regions", force: :cascade do |t|
    t.string "region"
    t.string "name"
    t.bigint "order_id"
    t.index ["region", "order_id"], name: "index_order_regions_on_region_and_order_id", unique: true
  end

  create_table "order_risks", force: :cascade do |t|
    t.bigint "shopify_id"
    t.bigint "order_id"
    t.bigint "shopify_checkout_id"
    t.bigint "shopify_order_id"
    t.boolean "cause_cancel"
    t.boolean "display"
    t.string "merchant_message"
    t.string "message"
    t.string "recommendation"
    t.float "score"
    t.string "source"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["order_id"], name: "index_order_risks_on_order_id"
    t.index ["shopify_id"], name: "index_order_risks_on_shopify_id", unique: true
  end

  create_table "order_rmas", force: :cascade do |t|
    t.string "cloud_order_id"
    t.string "ram_item_id", null: false
    t.string "order_id"
    t.string "shopify_order_id"
    t.datetime "purchase_data"
    t.float "total_price"
    t.string "buyer_email"
    t.string "uploaded_warehouse"
    t.string "warehouse_type"
    t.string "rma_id"
    t.string "rma_type"
    t.string "rma_status"
    t.text "rma_note"
    t.string "rma_solution"
    t.string "rma_issue_category_name"
    t.string "rma_creator"
    t.datetime "rma_created_at"
    t.datetime "rma_updated_at"
    t.integer "rma_quantity"
    t.string "rma_sn"
    t.string "rma_store_name"
    t.string "rma_ticket"
    t.string "rma_combo_sku"
    t.boolean "rma_is_disabled"
    t.integer "rma_is_product_quality"
    t.string "rma_node"
    t.string "rma_number"
    t.datetime "rma_return_date"
    t.string "rma_track"
    t.string "order_status"
    t.string "order_type"
    t.jsonb "order_items"
    t.integer "order_item_quantity"
    t.jsonb "order_skus"
    t.jsonb "order_item_quantitys"
    t.integer "buyer_id"
    t.string "buyer_name"
    t.string "buyer_address"
    t.string "buyer_city"
    t.string "buyer_state"
    t.string "buyer_country"
    t.string "buyer_country_code"
    t.string "marketplace"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["ram_item_id"], name: "index_order_rmas_on_ram_item_id", unique: true
  end

  create_table "order_supply_collect", id: :serial, force: :cascade do |t|
    t.string "source_ip", comment: "扫码的客户IP"
    t.bigint "shop_id", default: 0, comment: "店铺ID"
    t.string "shopify_domain", comment: "店铺domain"
    t.string "order_name", comment: "订单名称"
    t.jsonb "skus", null: false, comment: "订单名称"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.jsonb "others", comment: "其他信息"
    t.string "email", comment: "email"
    t.index ["order_name"], name: "IDX_13c3960f85f1ad75f9d9ca5d1b"
    t.index ["shop_id"], name: "IDX_e18e9a08e05a879a36ccb2e349"
  end

  create_table "orders", force: :cascade do |t|
    t.bigint "shop_id"
    t.bigint "customer_id"
    t.bigint "shopify_app_id"
    t.bigint "shopify_id"
    t.string "email"
    t.datetime "closed_at"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.bigint "number"
    t.string "note"
    t.string "token"
    t.string "gateway"
    t.boolean "test"
    t.decimal "total_price", precision: 10, scale: 2
    t.decimal "subtotal_price", precision: 10, scale: 2
    t.float "total_weight"
    t.decimal "total_tax", precision: 10, scale: 2
    t.boolean "taxes_included"
    t.string "currency"
    t.string "financial_status"
    t.boolean "confirmed"
    t.decimal "total_discounts", precision: 10, scale: 2
    t.decimal "total_line_items_price", precision: 10, scale: 2
    t.string "cart_token"
    t.boolean "buyer_accepts_marketing"
    t.string "name"
    t.string "referring_site"
    t.string "landing_site"
    t.datetime "cancelled_at"
    t.string "cancel_reason"
    t.decimal "total_price_usd", precision: 10, scale: 2
    t.string "checkout_token"
    t.string "reference"
    t.bigint "shopify_user_id"
    t.bigint "shopify_location_id"
    t.string "source_identifier"
    t.string "source_url"
    t.datetime "processed_at"
    t.string "device_id"
    t.string "phone"
    t.string "customer_locale"
    t.string "browser_ip"
    t.string "landing_site_ref"
    t.bigint "order_number"
    t.string "processing_method"
    t.bigint "checkout_id"
    t.string "source_name"
    t.string "fulfillment_status"
    t.string "tags"
    t.string "contact_email"
    t.string "order_status_url"
    t.string "presentment_currency"
    t.string "total_tip_received"
    t.jsonb "client_details"
    t.jsonb "current_total_duties_set"
    t.jsonb "discount_applications"
    t.jsonb "discount_codes"
    t.jsonb "note_attributes"
    t.jsonb "original_total_duties_set"
    t.jsonb "payment_details"
    t.jsonb "payment_gateway_names"
    t.jsonb "refunds"
    t.jsonb "billing_address"
    t.jsonb "shipping_address"
    t.jsonb "shipping_lines"
    t.jsonb "subtotal_price_set"
    t.jsonb "tax_lines"
    t.jsonb "total_discounts_set"
    t.jsonb "total_line_items_price_set"
    t.jsonb "total_price_set"
    t.jsonb "total_tax_set"
    t.jsonb "total_shipping_price_set"
    t.boolean "has_calc_cost", default: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.datetime "klarna_preauth_at"
    t.jsonb "customer_fields", comment: "customer fields"
    t.datetime "customer_cancelled_at"
    t.datetime "klarna_check_at"
    t.integer "cancel_reason_key"
    t.text "cancel_reason_txt"
    t.jsonb "black_labels"
    t.string "aftership_order_id"
    t.integer "upload_to_aftership_status", default: 0
    t.bigint "last_aftership_order_log_id"
    t.jsonb "company", comment: "company"
    t.index "lower((email)::text)", name: "index_orders_on_lower_email"
    t.index ["checkout_id"], name: "index_orders_on_checkout_id"
    t.index ["customer_id"], name: "index_orders_on_customer_id"
    t.index ["financial_status"], name: "index_orders_on_financial_status"
    t.index ["name"], name: "index_orders_on_name"
    t.index ["shop_id"], name: "index_orders_on_shop_id"
    t.index ["shopify_id"], name: "index_orders_on_shopify_id", unique: true
  end

  create_table "orders_returned", force: :cascade do |t|
    t.bigint "shop_id", comment: "店铺ID"
    t.bigint "order_id", comment: "订单ID"
    t.string "order_name", comment: "订单名称"
    t.bigint "line_item_shopify_id"
    t.string "cloud_order_id", comment: "cloud订单ID"
    t.integer "state", default: 0, comment: "申请状态"
    t.string "email", comment: "用户邮箱"
    t.integer "quantity", comment: "退货数量"
    t.boolean "is_quality", default: false, comment: "是否是质量问题"
    t.integer "reason", comment: "退货原因分类"
    t.text "describe", comment: "退货原因详情"
    t.jsonb "materials", comment: "图片/视频"
    t.integer "solution", comment: "处理方案选择"
    t.integer "rollback", comment: "回退方式"
    t.string "contact", comment: "联系方式"
    t.string "logistics_number", comment: "物流单号"
    t.string "logistics_company", comment: "物流公司"
    t.jsonb "logistics_cert", comment: "物流凭证"
    t.string "rma_id", comment: "RMA 单号"
    t.datetime "rma_time", comment: "RMA 处理时间"
    t.string "ticket_id"
    t.datetime "ticket_time", comment: "工单处理时间"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
    t.datetime "updated_at", default: -> { "now()" }, comment: "修改时间"
    t.datetime "deleted_at", comment: "删除时间"
    t.text "reason_text"
    t.index ["email"], name: "IDX_9e36abcf0e14cb03c84c5c9a94"
    t.index ["line_item_shopify_id"], name: "IDX_74364de4bde3880dc1810daa0b"
    t.index ["order_id"], name: "IDX_02bd37db115cf73aa7413fbed4"
    t.index ["order_name"], name: "IDX_8b2046b2fecf507714bc92029e"
    t.index ["shop_id"], name: "IDX_1c985b8f389c6a1e62637be4ea"
    t.index ["state"], name: "IDX_d7b0ab111a357c8b79627c7be1"
  end

  create_table "panic_buy_config", force: :cascade do |t|
    t.string "title", null: false, comment: "活动名称"
    t.string "genre", null: false, comment: "活动标识"
    t.integer "shop_id", null: false, comment: "店铺id"
    t.string "shopify_domain", null: false, comment: "店铺域名"
    t.string "daily_start_time", null: false, comment: "闪购开始的时间"
    t.string "daily_end_time", null: false, comment: "闪购结束时间"
    t.datetime "starts_at", null: false, comment: "闪购开始的时间"
    t.datetime "ends_at", null: false, comment: "闪购结束时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.index ["genre", "shopify_domain"], name: "UQ_b6aee92e863948969cc867e8ac4", unique: true
  end

  create_table "panic_buy_variants", primary_key: ["id", "panic_buy_config_id"], force: :cascade do |t|
    t.bigserial "id", null: false
    t.bigserial "panic_buy_config_id", null: false, comment: "活动配置id"
    t.integer "daily_inventory", null: false, comment: "当日投放库存"
    t.bigint "variant_shopify_id", null: false, comment: "variant_shopify_id"
    t.integer "daily_sales_quantity", default: 0, null: false, comment: "当天卖出数量"
    t.datetime "reset_sales_date", comment: "当日清空销量的时间"
    t.datetime "update_inventory_date", comment: "当日更新库存的时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.jsonb "discount", comment: "折扣信息"
    t.integer "total_sales_quantity", default: 0, null: false, comment: "销售总数量"
    t.index ["panic_buy_config_id"], name: "IDX_b5ae767a1af5f622bf87513832"
    t.index ["variant_shopify_id"], name: "IDX_5729df915c3fa2361a713c9cf2"
  end

  create_table "paypal_disputes", force: :cascade do |t|
    t.string "paypal_dispute_id"
    t.datetime "paypal_create_time"
    t.datetime "paypal_update_time"
    t.string "paypal_status"
    t.json "raw_data"
    t.string "paypal_seller_email"
    t.string "paypal_seller_transaction_id"
    t.string "paypal_custom"
    t.bigint "order_id"
    t.bigint "shop_id"
    t.datetime "upload_data_at"
    t.datetime "upload_result_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["shop_id"], name: "index_paypal_disputes_on_shop_id"
  end

  create_table "personalize_meddle", force: :cascade do |t|
    t.string "title"
    t.bigint "shop_id", comment: "店铺ID"
    t.string "global", comment: "启用状态：active|close"
    t.string "recom_type", comment: "推荐位置：home|details|shopping"
    t.string "status", comment: "启用状态：active|disabled"
    t.datetime "starts_at", null: false, comment: "配置生效开始时间"
    t.datetime "ends_at", null: false, comment: "配置生效结束时间"
    t.jsonb "rules", comment: "管理后台配置规则元数据"
    t.jsonb "main_sku", comment: "主要产品SKU"
    t.jsonb "connect_sku", comment: "推荐插入SKU"
    t.integer "sort", comment: "排序"
    t.jsonb "metafields", comment: "扩展预留元数据"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.index ["connect_sku"], name: "IDX_babf7c6652d09236829045bd46", using: :gin
    t.index ["main_sku"], name: "IDX_0fce6337d06b6a4ada8ddd64ed", using: :gin
    t.index ["sort"], name: "IDX_ff8c46df40f25925298ff94653"
  end

  create_table "price_rules", force: :cascade do |t|
    t.bigint "shopify_id"
    t.string "allocation_method"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.string "customer_selection"
    t.datetime "ends_at"
    t.string "entitled_collection_ids", default: [], array: true
    t.string "entitled_country_ids", default: [], array: true
    t.string "entitled_product_ids", default: [], array: true
    t.string "entitled_variant_ids", default: [], array: true
    t.boolean "once_per_customer"
    t.string "prerequisite_customer_ids", default: [], array: true
    t.string "prerequisite_quantity_range"
    t.string "prerequisite_saved_search_ids", default: [], array: true
    t.jsonb "prerequisite_shipping_price_range"
    t.jsonb "prerequisite_subtotal_range"
    t.jsonb "prerequisite_to_entitlement_purchase"
    t.datetime "starts_at"
    t.string "target_selection"
    t.string "target_type"
    t.string "title"
    t.integer "usage_limit"
    t.string "prerequisite_product_ids", default: [], array: true
    t.string "prerequisite_variant_ids", default: [], array: true
    t.string "prerequisite_collection_ids", default: [], array: true
    t.decimal "value", precision: 10, scale: 2
    t.string "value_type"
    t.jsonb "prerequisite_to_entitlement_quantity_ratio"
    t.integer "allocation_limit"
    t.bigint "shop_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["shop_id"], name: "index_price_rules_on_shop_id"
    t.index ["shopify_id"], name: "index_price_rules_on_shopify_id"
    t.index ["title"], name: "index_price_rules_on_title"
  end

  create_table "prize_pools", id: :serial, force: :cascade do |t|
    t.string "name", null: false
    t.string "genre", null: false
    t.string "shopify_domain", null: false
    t.string "description", null: false
    t.datetime "start_date", null: false
    t.datetime "end_date", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.integer "total_win_count_limit", default: 0, null: false, comment: "在活动生命周期内总共抽奖次数限制"
    t.boolean "promise_repeat_wins", default: false, null: false, comment: "是否允许重复中奖"
    t.jsonb "order_limit", comment: "订单控制"
    t.bigint "shop_id"
    t.bigint "shopify_metafield_id", comment: "metaifield id"
    t.integer "daily_drawn_count", default: 0, null: false, comment: "每天抽奖次数限制"
    t.string "points_rule_id", default: "", null: false, comment: "抽奖用的积分id号"
    t.boolean "need_login", default: false, null: false, comment: "是否需要登录"
  end

  create_table "prize_share_logs", id: :serial, force: :cascade do |t|
    t.integer "prize_pool_id", null: false, comment: "prize_pool_id"
    t.string "email", null: false, comment: "分享的邮箱"
    t.datetime "shared_at", comment: "分享时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
  end

# Could not dump table "prizes" because of following StandardError
#   Unknown type 'prizes_prize_type_enum' for column 'prize_type'

  create_table "product_register", id: :serial, force: :cascade do |t|
    t.string "shopify_domain", limit: 128, null: false, comment: "店铺域名"
    t.bigint "shop_id", null: false, comment: "店铺id"
    t.string "email", null: false, comment: "邮箱"
    t.string "phone_number", null: false, comment: "电话"
    t.string "country_name", comment: "国家"
    t.string "state", comment: "地区"
    t.string "product_name", null: false, comment: "产品名称"
    t.string "purchased_from", null: false, comment: "购买来源"
    t.datetime "purchased_at", null: false, comment: "采购日期"
    t.json "extend", comment: "扩展字段(预留)"
    t.datetime "created_at", default: -> { "now()" }, null: false, comment: "创建日期"
    t.datetime "updated_at", default: -> { "now()" }, null: false, comment: "更新日期"
    t.datetime "deleted_at", comment: "删除日期"
    t.jsonb "proof_image_url", null: false, comment: "证明图片链接"
  end

  create_table "products", force: :cascade do |t|
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.bigint "shop_id"
    t.text "body_html"
    t.string "handle"
    t.jsonb "images"
    t.jsonb "options"
    t.string "product_type"
    t.datetime "published_at"
    t.string "published_scope"
    t.string "tags"
    t.string "template_suffix"
    t.string "title"
    t.string "vendor"
    t.jsonb "metafields"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "status"
    t.index ["handle"], name: "index_products_on_handle"
    t.index ["shop_id"], name: "index_products_on_shop_id"
    t.index ["shopify_id"], name: "index_products_on_shopify_id", unique: true
    t.index ["status"], name: "index_products_on_status"
  end

  create_table "qr_scan_log", id: :serial, force: :cascade do |t|
    t.string "ip", null: false, comment: "扫码的客户IP"
    t.string "country_code", comment: "扫码的国家"
    t.string "user_agent", limit: 512, comment: "user-agent"
    t.datetime "created_at", default: -> { "now()" }, null: false, comment: "扫码时间"
    t.string "query_key", comment: "扫描带的参数key值"
    t.string "redirect_url", limit: 512, comment: "redirect_url"
    t.bigint "setting_id", default: 0, comment: "扫码的客户IP"
    t.string "qrscan_link", comment: "二维码链接"
  end

  create_table "qr_scan_settings", id: :serial, force: :cascade do |t|
    t.string "qrscan_key", null: false, comment: "扫码的跳转识别"
    t.jsonb "jump_links", null: false, comment: "跳转链接列表"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.index ["qrscan_key"], name: "UQ_7287907c1d2b2dc9659411315a3", unique: true
  end

  create_table "recall_form", id: :serial, force: :cascade do |t|
    t.string "shopify_domain", null: false, comment: "店铺"
    t.string "register_source", null: false
    t.jsonb "serial_number", comment: "序列号"
    t.string "first_name", null: false
    t.string "last_name", null: false
    t.string "phone_number", null: false
    t.string "email", null: false
    t.string "mailing_address", null: false
    t.string "apt_units", null: false
    t.string "city", null: false
    t.string "state_province", null: false
    t.string "zip_code", null: false
    t.string "country", null: false
    t.integer "quantity", null: false
    t.string "product_model", null: false
    t.string "order_number"
    t.string "date_purchased", null: false
    t.string "upload_proof_of_purchase", null: false
    t.jsonb "extend", comment: "扩展JSON"
    t.string "ticket_number", comment: "ticket_number"
    t.datetime "push_ced_at", comment: "工单提交时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
  end

  create_table "referral_be_inviters", id: :uuid, default: -> { "uuid_generate_v4()" }, force: :cascade do |t|
    t.string "email", null: false
    t.string "invite_code"
    t.string "invite_note"
    t.jsonb "remind_info"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.integer "inviter_id"
    t.string "name"
    t.jsonb "coupons"
    t.string "register_source"
    t.bigint "operat_system_user_id"
    t.string "landing_site"
    t.index ["inviter_id", "email"], name: "UQ_REFERRAL_BE_INVITER", unique: true
  end

  create_table "referral_inviters", id: :serial, force: :cascade do |t|
    t.string "name", null: false
    t.string "email", null: false
    t.string "shopify_domain", null: false
    t.string "genre", null: false
    t.string "invitation_code", null: false
    t.string "invite_link", null: false
    t.string "register_source", null: false
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.datetime "last_invite_link_sent_at", comment: "最后一次邀请链接发送时间"
    t.string "landing_site"
    t.index ["genre", "email", "shopify_domain"], name: "UQ_REFERRAL_INVITER_GENRE_EMAIL", unique: true
  end

# Could not dump table "referral_rewards" because of following StandardError
#   Unknown type 'referral_rewards_status_enum' for column 'status'

  create_table "referrals", id: :serial, force: :cascade do |t|
    t.string "email", null: false
    t.string "genre", null: false
    t.string "invitation_code", null: false, comment: "邀请码"
    t.string "invite_link", null: false, comment: "邀请link"
    t.string "verify_code", null: false, comment: "验证码"
    t.boolean "is_verified", default: false, null: false, comment: "是否已经验证"
    t.string "shopify_domain", null: false, comment: "店铺名称"
    t.string "register_source", null: false
    t.string "ip", comment: "source ip"
    t.string "country_code"
    t.datetime "verify_edm_send_at", comment: "验证邮件发送时间"
    t.datetime "referral_link_edm_send_at", comment: "验证邮件发送时间"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "subscribed_at", comment: "订阅时间"
    t.boolean "single_brand_subscribed", default: true, null: false, comment: "单品牌订阅"
    t.integer "parentReferralId"
    t.boolean "is_new_subscribe", comment: "是否为新订阅用户"
    t.index ["email"], name: "IDX_5118f6d3d90044ca90cb650458"
    t.index ["genre", "email", "shopify_domain"], name: "UQ_REFERRAL_GENRE_EMAIL", unique: true
    t.index ["invitation_code"], name: "IDX_60327c04a2f06a78d5d023fe95"
    t.index ["invitation_code"], name: "UQ_60327c04a2f06a78d5d023fe95c", unique: true
    t.index ["verify_code"], name: "IDX_d5fd405bea577ea9066b7d2c5d"
    t.index ["verify_code"], name: "UQ_d5fd405bea577ea9066b7d2c5d1", unique: true
  end

  create_table "return_diff_amount_info", id: :serial, force: :cascade do |t|
    t.bigint "order_id"
    t.bigint "line_item_shopify_id"
    t.string "order_name"
    t.datetime "created_at", null: false
    t.string "shopify_domain"
    t.string "sku"
    t.bigint "shopify_variant_id"
    t.decimal "current_discount_amount", precision: 10, scale: 2
    t.decimal "order_line_amount", precision: 10, scale: 2
    t.bigint "rma_id"
    t.datetime "rma_created_at"
    t.decimal "diff_amount", precision: 10, scale: 2
    t.string "cloud_order_id"
    t.string "email"
    t.integer "order_line_quantity"
    t.index ["line_item_shopify_id", "order_id"], name: "UQ_ORDER_LINE_ITEM_IDX", unique: true
    t.index ["line_item_shopify_id"], name: "UQ_a7f44f09c2d62daeb11ee78dd71", unique: true
    t.index ["order_id"], name: "UQ_193b1edd6603cff889fdad5d6b2", unique: true
  end

  create_table "return_diff_info", id: :serial, force: :cascade do |t|
    t.bigint "order_id"
    t.bigint "line_item_shopify_id"
    t.string "order_name"
    t.datetime "created_at", null: false
    t.string "shopify_domain"
    t.string "sku"
    t.bigint "shopify_variant_id"
    t.decimal "current_discount_amount", precision: 10, scale: 2
    t.decimal "order_line_amount", precision: 10, scale: 2
    t.bigint "rma_id"
    t.datetime "rma_created_at"
    t.decimal "diff_amount", precision: 10, scale: 2
    t.string "cloud_order_id"
    t.string "email"
    t.integer "order_line_quantity"
    t.index ["line_item_shopify_id", "order_id"], name: "UQ_ORDER_LINE_ITEM_KEY", unique: true
    t.index ["line_item_shopify_id"], name: "UQ_b4499f36766ccc543f5090be35f", unique: true
    t.index ["order_id"], name: "UQ_260a5baa89f0f10b8ff6ef76d6b", unique: true
  end

  create_table "roles", force: :cascade do |t|
    t.string "name"
    t.string "resource_type"
    t.bigint "resource_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["name", "resource_type", "resource_id"], name: "index_roles_on_name_and_resource_type_and_resource_id"
    t.index ["resource_type", "resource_id"], name: "index_roles_on_resource_type_and_resource_id"
  end

  create_table "rq_scan_log", id: :serial, force: :cascade do |t|
    t.string "ip", null: false, comment: "扫码的客户IP"
    t.string "country_code", comment: "扫码的国家"
    t.string "user_agent", limit: 512, comment: "user-agent"
    t.datetime "created_at", null: false, comment: "扫码时间"
  end

  create_table "script_discounts", id: :serial, force: :cascade do |t|
    t.string "function_id", null: false, comment: "函数的key值"
    t.string "title", null: false, comment: "标题"
    t.integer "shop_id", comment: "店铺id"
    t.integer "sort", comment: "排序"
    t.string "state", null: false, comment: "活动状态"
    t.string "product_tag", null: false, comment: "活动对应的产品tag"
    t.datetime "starts_at", null: false, comment: "活动开始时间"
    t.datetime "ends_at", null: false, comment: "活动结束时间"
    t.jsonb "config", null: false, comment: "前端传过来的活动规则"
    t.jsonb "scripts_config", null: false, comment: "活动规则"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "deleted_at"
    t.boolean "is_sync", default: false, null: false, comment: "是否已经同步到app"
  end

  create_table "script_discounts_log", id: :serial, force: :cascade do |t|
    t.integer "discount_id", null: false, comment: "product_id"
    t.string "function_id", null: false, comment: "函数的key值"
    t.string "title", null: false, comment: "标题"
    t.integer "shop_id", comment: "店铺id"
    t.integer "sort", comment: "排序"
    t.string "state", null: false, comment: "活动状态"
    t.string "product_tag", null: false, comment: "活动对应的产品tag"
    t.datetime "starts_at", null: false, comment: "活动开始时间"
    t.datetime "ends_at", null: false, comment: "活动结束时间"
    t.jsonb "config", null: false, comment: "前端传过来的活动规则"
    t.jsonb "scripts_config", null: false, comment: "活动规则"
    t.datetime "created_at", null: false, comment: "活动创建时间"
    t.datetime "updated_at", null: false, comment: "更新时间"
    t.datetime "log_at", default: -> { "now()" }, null: false, comment: "日志时间"
    t.integer "operate_type", null: false, comment: "活动操作类型"
    t.bigint "user_id", comment: "user_id"
  end

  create_table "script_discounts_metafields", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.bigint "discount_id", comment: "函数的id号"
    t.bigint "target_shopify_id", null: false, comment: "target shopify id"
    t.string "target_type", null: false, comment: "目标类型 product，variant，page"
    t.bigint "metafield_shopify_id", comment: "metafields id号"
    t.boolean "is_need_delete", comment: "产品shopify id"
    t.string "metafield_type", null: false, comment: "metafields的数据类型"
    t.string "metafield_namespace", null: false, comment: "metafields的namespace"
    t.jsonb "metafield_value", null: false, comment: "metafields的值"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "start_sync_at", comment: "开始同步到shopify的时间点"
    t.datetime "sync_at", comment: "同步的时间"
    t.string "metafield_key", null: false, comment: "metafields的key值"
    t.integer "sort", comment: "排序"
  end

  create_table "script_functions", id: :serial, force: :cascade do |t|
    t.string "function_key", null: false, comment: "扫码的跳转识别"
    t.string "title", null: false, comment: "标题"
    t.string "code_type", null: false, comment: "编码类型"
    t.boolean "is_order", default: false, null: false, comment: "是否订单维度的折扣，比如满减，满赠等，这种折扣要作为最高优先级处理"
    t.integer "shop_id", comment: "店铺id"
    t.text "code", null: false, comment: "程序编码"
    t.text "details", null: false, comment: "详细描述"
    t.jsonb "relate_functions", comment: "依赖的函数"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.index ["function_key"], name: "UQ_bc2e5b048bcc0f40bb1fa63e2ba", unique: true
  end

  create_table "script_label_configs", id: :serial, force: :cascade do |t|
    t.string "function_key", null: false, comment: "扫码的跳转识别"
    t.jsonb "labels", null: false, comment: "前端文案汇总"
    t.integer "shop_id", comment: "店铺id"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.index ["function_key", "shop_id"], name: "UQ_9691fd0de5175441937d2f22bc1", unique: true
  end

  create_table "script_product_tag", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.bigint "discount_id", comment: "函数的id号"
    t.bigint "product_shopify_id", comment: "product shopify id"
    t.string "product_tag", comment: "discount product tag"
    t.boolean "is_need_delete", comment: "产品shopify id"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.datetime "start_sync_at", comment: "开始同步到shopify的时间点"
    t.datetime "sync_at", comment: "同步的时间"
    t.boolean "sync_state", default: false, null: false, comment: "同步的时间"
  end

  create_table "script_program_manages", id: :serial, force: :cascade do |t|
    t.integer "shop_id", comment: "店铺id"
    t.datetime "deploy_at", comment: "发布时间"
    t.string "deployer", comment: "部署者"
    t.integer "copty_times", default: 0, null: false, comment: "拷贝次数"
    t.datetime "created_at", default: -> { "now()" }, null: false
    t.datetime "updated_at", default: -> { "now()" }, null: false
    t.index ["shop_id"], name: "UQ_67e4440d13a988f539de2879208", unique: true
  end

  create_table "shop_data_auth", force: :cascade do |t|
    t.bigint "user_id", null: false, comment: "店铺编号"
    t.integer "shop_id", null: false, comment: "店铺编号"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
    t.index ["user_id", "shop_id"], name: "UQ_64d425c7a1acb3452c401c541bb", unique: true
  end

  create_table "shop_meta_field", id: :bigint, default: nil, force: :cascade do |t|
    t.bigint "shop_id", comment: "店铺ID"
    t.string "namespace", null: false, comment: "命名空间"
    t.string "key", null: false, comment: "key"
    t.text "value", null: false, comment: "value"
    t.text "description", null: false, comment: "描述"
    t.string "type", null: false, comment: "类型"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
    t.datetime "updated_at", default: -> { "now()" }, comment: "修改时间"
    t.index ["key"], name: "IDX_8fe449194f7e7302c6aac8729f"
    t.index ["shop_id"], name: "IDX_796dea66fa7fc5b03112cdc3a7"
  end

  create_table "shop_settings", force: :cascade do |t|
    t.string "shopify_domain"
    t.json "settings"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "shopify_inventory_up_logs", force: :cascade do |t|
    t.bigint "shop_id"
    t.bigint "variant_id"
    t.string "sku"
    t.string "warehouse"
    t.integer "cloud_reserved"
    t.integer "shpify_old_quantity"
    t.boolean "update_success"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "shopify_price_up_logs", force: :cascade do |t|
    t.bigint "shop_id"
    t.bigint "variant_id"
    t.string "sku"
    t.decimal "amazon_price", precision: 10, scale: 2
    t.decimal "shopify_old_price", precision: 10, scale: 2
    t.boolean "update_success"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "shopify_variant_update_logs", force: :cascade do |t|
    t.bigint "shop_id"
    t.bigint "variant_id"
    t.string "sku"
    t.decimal "price", precision: 10, scale: 2
    t.integer "inventory_quantity"
    t.boolean "enable_price_sync"
    t.boolean "enable_inventory_sync"
    t.datetime "shopify_updated_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "shops", force: :cascade do |t|
    t.string "shopify_domain", null: false
    t.string "shopify_token", null: false
    t.bigint "shopify_id"
    t.string "country_code"
    t.string "currency"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "iana_timezone"
    t.string "custom_domain"
    t.string "primary_locale"
    t.string "region"
  end

  create_table "system_role_apis", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.string "path", limit: 512, comment: "接口地址"
    t.string "method", limit: 32, comment: "接口注册类型"
    t.string "name", limit: 512, comment: "接口名称"
    t.string "desc", limit: 512, comment: "接口描述"
    t.string "auth_type", limit: 64, comment: "接口验证类型"
    t.jsonb "action", default: {}, comment: "接口控制器"
    t.datetime "updated_at", default: -> { "now()" }, comment: "修改时间"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
  end

  create_table "system_role_group", force: :cascade do |t|
    t.string "name", limit: 512, comment: "权限组名称"
    t.string "desc", limit: 512, comment: "权限描述"
    t.jsonb "apis", default: {}, comment: "接口控制器"
    t.jsonb "pages", default: {}, comment: "接口控制器"
    t.datetime "updated_at", default: -> { "now()" }, comment: "修改时间"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
  end

  create_table "system_role_pages", primary_key: "uuid", id: :string, limit: 36, force: :cascade do |t|
    t.string "path", limit: 512, comment: "页面地址"
    t.string "root", limit: 512, comment: "根地址"
    t.string "name", limit: 256, comment: "页面名称"
    t.string "desc", limit: 512, comment: "页面描述"
    t.jsonb "action", default: {}, comment: "页面控制器"
    t.datetime "updated_at", default: -> { "now()" }, comment: "修改时间"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
  end

  create_table "system_shop", id: :bigint, default: nil, force: :cascade do |t|
    t.string "shop", limit: 512, null: false, comment: "店铺地址"
    t.string "address1"
    t.string "address2"
    t.boolean "checkout_api_supported"
    t.string "city"
    t.string "cookie_consent_level"
    t.string "country"
    t.string "country_code"
    t.string "country_name"
    t.string "county_taxes"
    t.datetime "created_at"
    t.string "currency", comment: "商店默认货币的三字母代码"
    t.string "customer_email"
    t.string "domain"
    t.boolean "eligible_for_card_reader_giveaway"
    t.boolean "eligible_for_payments"
    t.string "email"
    t.jsonb "enabled_presentment_currencies", comment: "商店接受的启用货币列表"
    t.boolean "finances"
    t.boolean "force_ssl"
    t.string "google_apps_domain"
    t.string "google_apps_login_enabled"
    t.boolean "has_discounts"
    t.boolean "has_gift_cards"
    t.boolean "has_storefront"
    t.string "iana_timezone"
    t.float "latitude", comment: "商店位置的纬度"
    t.float "longitude", comment: "商店位置的经度"
    t.string "money_format"
    t.string "auto_configure_tax_inclusivity"
    t.string "visitor_tracking_consent_preference"
    t.string "money_in_emails_format"
    t.string "money_with_currency_format"
    t.string "money_with_currency_in_emails_format"
    t.boolean "multi_location_enabled"
    t.string "myshopify_domain"
    t.string "name"
    t.boolean "password_enabled"
    t.string "phone"
    t.string "plan_display_name"
    t.string "plan_name"
    t.boolean "pre_launch_enabled"
    t.string "primary_locale"
    t.bigint "primary_location_id"
    t.string "province"
    t.string "province_code"
    t.boolean "requires_extra_payments_agreement"
    t.boolean "setup_required"
    t.string "shop_owner"
    t.string "source"
    t.string "tax_shipping"
    t.string "taxes_included"
    t.string "timezone"
    t.boolean "transactional_sms_disabled"
    t.datetime "updated_at"
    t.string "weight_unit"
    t.string "zip"
    t.string "admin_graphql_api_id", limit: 1024, comment: "graphql id"
    t.boolean "sync_price", default: true, comment: "价钱同步"
    t.index ["shop"], name: "IDX_f825f98e0a4bb61ba1ed2544b6"
  end

  create_table "system_user", force: :cascade do |t|
    t.bigint "shopify_user_id", default: 0, comment: "shopify 用户ID"
    t.string "email", limit: 128, null: false, comment: "邮箱"
    t.string "password", limit: 64, null: false, comment: "密码"
    t.string "password_salt", limit: 32, null: false, comment: "密码遮盖码"
    t.string "nick_name", limit: 256, null: false, comment: "昵称"
    t.boolean "email_verified", default: true, comment: "用户邮箱验证状态"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
    t.datetime "updated_at", default: -> { "now()" }, comment: "修改时间"
    t.datetime "deleted_at", comment: "删除时间"
    t.bigint "role_group_id"
    t.index ["email"], name: "IDX_741d321efeff6cfdf96dce44f8"
  end

  create_table "system_user_shop", force: :cascade do |t|
    t.bigint "user_id", default: 0, comment: "用户ID"
    t.bigint "shopify_user_id", default: 0, comment: "shopify 用户ID"
    t.bigint "shopify_shop_id", default: 0, comment: "shopify 店铺ID"
    t.string "shopify_domain", limit: 256, default: "0", comment: "shopify 店铺域名"
  end

  create_table "system_user_shop_auth", force: :cascade do |t|
    t.bigint "user_id", default: 0, comment: "用户ID"
    t.bigint "shopify_user_id", default: 0, comment: "shopify 用户ID"
    t.bigint "shopify_shop_id", default: 0, comment: "shopify 店铺ID"
    t.string "shopify_domain", limit: 256, default: "0", comment: "shopify 店铺域名"
    t.string "scope", limit: 1024, comment: "接口可访问权限"
    t.string "user_scope", limit: 1024, comment: "给定用户权限"
    t.integer "auth_type", default: 1, null: false, comment: "授权方式 1 在线 2 长效授权 3 店铺授权"
    t.string "token", limit: 64, comment: "令牌, 店面令牌"
    t.datetime "expires", comment: "令牌过期时间"
    t.datetime "created_at", default: -> { "now()" }, comment: "创建时间"
    t.datetime "updated_at", default: -> { "now()" }, comment: "修改时间"
    t.datetime "deleted_at", comment: "删除时间"
  end

  create_table "transactions", force: :cascade do |t|
    t.bigint "order_id"
    t.bigint "shopify_id"
    t.string "kind"
    t.string "gateway"
    t.string "status"
    t.string "message"
    t.string "shopify_created_at"
    t.string "shopify_updated_at"
    t.boolean "test"
    t.string "authorization"
    t.bigint "shipify_user_id"
    t.bigint "shopify_parent_id"
    t.datetime "processed_at"
    t.string "error_code"
    t.string "source_name"
    t.decimal "amount", precision: 10, scale: 2
    t.string "currency"
    t.jsonb "receipt"
    t.jsonb "payment_details"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["order_id"], name: "index_transactions_on_order_id"
    t.index ["shopify_id"], name: "index_transactions_on_shopify_id", unique: true
  end

  create_table "typeorm_metadata", id: false, force: :cascade do |t|
    t.string "type", null: false
    t.string "database"
    t.string "schema"
    t.string "table"
    t.string "name"
    t.text "value"
  end

  create_table "variants", force: :cascade do |t|
    t.bigint "shopify_id"
    t.datetime "shopify_created_at"
    t.datetime "shopify_updated_at"
    t.bigint "product_id"
    t.string "title"
    t.decimal "compare_at_price", precision: 10, scale: 2
    t.string "barcode"
    t.string "fulfillment_service"
    t.integer "grams"
    t.bigint "shopify_image_id"
    t.bigint "shopify_inventory_item_id"
    t.string "inventory_management"
    t.string "inventory_policy"
    t.integer "inventory_quantity"
    t.integer "old_inventory_quantity"
    t.integer "inventory_quantity_adjustment"
    t.string "option1"
    t.string "option2"
    t.string "option3"
    t.jsonb "presentment_prices"
    t.integer "position"
    t.decimal "price", precision: 10, scale: 2
    t.bigint "shopify_product_id"
    t.boolean "requires_shipping"
    t.string "sku"
    t.boolean "taxable"
    t.string "tax_code"
    t.float "weight"
    t.string "weight_unit"
    t.boolean "enable_price_sync", default: true
    t.boolean "enable_inventory_sync", default: true
    t.decimal "amazon_price", precision: 10, scale: 2
    t.integer "cloud_sale_status"
    t.integer "shopify_sale_status"
    t.boolean "need_sync_price", default: false
    t.boolean "need_sync_inventory", default: false
    t.boolean "need_sync_status", default: false
    t.jsonb "metafields"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "upc"
    t.float "cloud_weight"
    t.jsonb "pd_payload", default: {}
    t.string "asin"
    t.bigint "last_amazon_price_log_id"
    t.index ["product_id"], name: "index_variants_on_product_id"
    t.index ["shopify_id"], name: "index_variants_on_shopify_id", unique: true
    t.index ["shopify_inventory_item_id"], name: "index_variants_on_shopify_inventory_item_id"
  end

  create_table "website_performance_data", id: false, comment: "官网性能指标数据", force: :cascade do |t|
    t.bigserial "id", null: false
    t.string "brand"
    t.string "url"
    t.date "create_time"
    t.string "total_bytes"
    t.string "fcp"
    t.string "cls"
    t.string "lcp"
    t.string "speed_index"
    t.string "tbt"
    t.string "lighthouse_performance"
    t.string "lighthouse_accessibility"
    t.string "lighthouse_bestpractices"
    t.string "lighthouse_seo"
    t.string "remark"
    t.string "fields_1"
    t.string "fields_2"
    t.string "fields_3"
  end

  add_foreign_key "cloud_deal_items", "cloud_deals"
  add_foreign_key "dropshipping_channel", "dropshipping_shop", column: "dropshipping_shop_uuid", primary_key: "uuid", name: "FK_e3993144e1474f746981b54ceeb"
  add_foreign_key "dropshipping_channel_sync_file", "dropshipping_channel", column: "dropshipping_channel_uuid", primary_key: "uuid", name: "FK_db6717f440d3d0c65a62f8d8209"
  add_foreign_key "dropshipping_feed_notify_logs", "dropshipping_feeds", column: "feed_id", name: "FK_201dbdfeef29de01ee43b80dcc8"
  add_foreign_key "dropshipping_feed_records", "dropshipping_channel", column: "channel_id", primary_key: "uuid", name: "FK_8d83e3f9736d13604cf961ae2c1"
  add_foreign_key "dropshipping_feed_records", "dropshipping_feeds", column: "feed_id", name: "FK_60ace6801dc39bdd116d21eabc8"
  add_foreign_key "dropshipping_feed_v2_records", "dropshipping_channel", column: "channel_id", primary_key: "uuid", name: "FK_128e4caaacfce8112a551b875b6"
  add_foreign_key "dropshipping_feed_v2_records", "dropshipping_feeds", column: "feed_id", name: "FK_654cb8b69e014d304ea66d9aa0a"
  add_foreign_key "dropshipping_feeds", "dropshipping_channel", column: "channel_id", primary_key: "uuid", name: "FK_dc0c79d7e3a553a6fc42a2689c4"
  add_foreign_key "dropshipping_feeds", "shops", name: "FK_1952a5855e7ff87cb0ce003e528"
  add_foreign_key "dropshipping_feeds", "system_user", column: "update_by", name: "FK_9f6a5a3fade3cf8106f9789d07e"
  add_foreign_key "dropshipping_gmc_records", "dropshipping_gmc", column: "feed_id", name: "FK_85008796bef57604fe01f3cc6c5"
  add_foreign_key "dropshipping_orders", "dropshipping_channel", column: "dropshipping_channel_uuid", primary_key: "uuid", name: "FK_2ca072aed93c89717b8ce166b99"
  add_foreign_key "dropshipping_orders", "dropshipping_shop", column: "dropshipping_shop_uuid", primary_key: "uuid", name: "FK_ebbd9d188ca55f9cf627bf538af"
  add_foreign_key "dropshipping_variant_update_logs", "shops", name: "FK_39607ed533208f129bac49d94c2"
  add_foreign_key "lotteries", "prize_pools", name: "FK_95d207e6e6b84319545cc4267e5", on_delete: :nullify
  add_foreign_key "lotteries", "prizes", name: "FK_d118177c3885e1dfc2d803496b5", on_delete: :nullify
  add_foreign_key "panic_buy_variants", "panic_buy_config", name: "FK_b5ae767a1af5f622bf875138329", on_delete: :nullify
  add_foreign_key "prize_pools", "shops", name: "FK_a109f6cac4389b31a6a244a50cf"
  add_foreign_key "prize_share_logs", "prize_pools", name: "FK_e6091e757ac0c5bd45ac5f94a48", on_delete: :cascade
  add_foreign_key "prizes", "prize_pools", name: "FK_4936e883e92739cc5f4db3e3edc", on_delete: :cascade
  add_foreign_key "referral_be_inviters", "referral_inviters", column: "inviter_id", name: "FK_f771c588ff17285da169844e15d"
  add_foreign_key "referral_be_inviters", "system_user", column: "operat_system_user_id", name: "FK_c8fc6d5169eb83ba0ac7691651b"
  add_foreign_key "referral_rewards", "orders", name: "FK_42cd0097b253b136c07d937d988"
  add_foreign_key "referral_rewards", "referral_be_inviters", column: "be_inviter_id", name: "FK_f85eaa80c8805b27af45daf4723"
  add_foreign_key "referrals", "referrals", column: "parentReferralId", name: "FK_7d6d7a918b4161421e85d04946c"
  add_foreign_key "system_user", "system_role_group", column: "role_group_id", name: "FK_ca9d1d4ebfced225e130879a556"
end
