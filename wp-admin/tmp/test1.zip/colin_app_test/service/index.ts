import express from 'express';
import * as process from 'process';
import * as dotenv from 'dotenv';
import Database from './src/database';
import '@shopify/shopify-api/adapters/node';
import { LATEST_API_VERSION, shopifyApi } from '@shopify/shopify-api';
import { RedisStorage } from './src/redis';
import { MiddlewareController } from './src/middleware/Middleware';
//import { PostgreSQLSessionStorage } from "@shopify/shopify-app-session-storage-postgresql";
import { createLogger, format, transports } from 'winston';
import { apiInit } from './src/controller/api';
import { outApiInit } from './src/controller/out';
import { JobClass } from './src/jobs';
import { restResources } from '@shopify/shopify-api/rest/admin/2023-07';
import { PostgreSQLSessionStorage } from './src/lib/session.storage';
import { WorkerClass } from './src/worker';
const logger = createLogger({
  level: 'silly',
  format: format.json(),
  defaultMeta: { service: 'user-service' },
  transports: [
    new transports.File({
      filename: './logs/error.log',
      level: 'error',
      format: format.combine(
        format.timestamp({ format: 'MMM-DD-YYYY HH:mm:ss' }),
        format.align(),
        format.printf(info => `${info.level}: ${[info.timestamp]}: ${info.message}`)
      )
    }),
    new transports.File({ filename: './logs/combined.log' })
  ]
});
// if (process.env.NODE_ENV !== 'production') {
//   logger.add(new winston.transports.Console({
//     format: winston.format.simple(),
//   }));
// }
dotenv.config({ override: true });
const PORT = parseInt(process.env.BACKEND_PORT || process.env.PORT || '3000', 10);
const isTest = process.env.NODE_ENV === 'test' || !!process.env.VITE_TEST_BUILD;
export async function createServer() {
  const app = express();
  const redis = new RedisStorage();
  // console.log('redis-length',(await redis.keys('*')).length);
  // redis.flushdb((err, result) => {
  //   if (err) {s
  //     console.error(err);
  //   } else {
  //     console.log('Redis database cleared successfully');
  //   }
  // });
  //await redis.init();
  redis.setMaxListeners(200);
  app.use(
    express.json({
      limit: '50mb',
      verify: (req: any, res, buf) => {
        if (req.url.startsWith('/api/webhook')) {
          req.rawBody = buf;
        }
      }
    })
  );
  const database = await Database.initial();
  const SHOPIFY_EXPRESS_LIBRARY_VERSION = '1.2.0';
  let userAgent = `Shopify Express Library v${SHOPIFY_EXPRESS_LIBRARY_VERSION}`;
  const api = shopifyApi({
    apiKey: process.env.SHOPIFY_API_KEY || '',
    apiSecretKey: process.env.SHOPIFY_API_SECRET || '',
    scopes: (process.env.SCOPES || 'write_products').split(','),
    hostName: (process.env.HOST || '').replace(/https?:\/\//, ''),
    hostScheme: 'https',
    apiVersion: LATEST_API_VERSION,
    isEmbeddedApp: true,
    restResources: restResources,
    userAgentPrefix: userAgent
  });

  //初始化controller shopify
  const sessionStorage = PostgreSQLSessionStorage.withCredentials(
    process.env.DATABASE_HOST || '127.0.0.1',
    process.env.DATABASE_NAME || 'discount',
    process.env.DATABASE_USERNAME || '',
    process.env.DATABASE_PASSWORD || '',
    { port: 5432 }
  );
  if (process.env.NODE_ENV == 'development' && (await redis.get('last_web_host')) !== process.env.HOST) {
    sessionStorage.deleteAllOnlineSession();
    redis.set('last_web_host', process.env.HOST);
  }
  const authRoute = express.Router();
  apiInit({
    app,
    redis,
    database,
    router: authRoute,
    api,
    logger,
    sessionStorage
  });
  //外部调用api相关控制器
  outApiInit({
    app,
    redis,
    database,
    router: authRoute,
    api,
    logger,
    sessionStorage
  });
  new JobClass({ redis, database, api, logger, sessionStorage });
  new WorkerClass({ redis, database, api, logger, sessionStorage });
  app.use(authRoute);
  //shopify api 接口校验相关中间件
  //前端校验 除了api都会走这里
  let middleHandle = new MiddlewareController({
    app,
    redis,
    router: authRoute,
    database,
    api,
    logger,
    sessionStorage
  });
  middleHandle.initial();
  app.use(authRoute);
  return { app };
}
if (!isTest) {
  createServer().then(({ app }) => app.listen(PORT));
}
