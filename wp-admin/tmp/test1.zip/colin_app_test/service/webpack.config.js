const path = require('path');
const fs = require('fs');
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
const nodeExternals = require('webpack-node-externals');

let nodeModules = {};
fs.readdirSync('./node_modules')
  .filter(x => {
    return ['.bin'].indexOf(x) === -1;
  })
  .forEach(mod => {
    nodeModules[mod] = 'commonjs ' + mod;
  });

module.exports = (env = 'production') => ({
  mode: env,
  // mode: 'development',
  entry: [path.resolve(__dirname, './index.ts')],
  output: {
    path: path.resolve(__dirname, './dist'),
    filename: 'index.js',
    publicPath: '/'
  },
  resolve: {
    extensions: ['.ts', '.js', '.json'],
    alias: {
      '@controllers': path.resolve(__dirname, './src/controllers')
    }
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        loader: 'ts-loader',
        exclude: [/node_modules/],
        options: {
          transpileOnly: true
        }
      },
      {
        test: /\.jsx?$/,
        loader: 'babel-loader',
        exclude: [/node_modules/],
        options: {
          transpileOnly: true
        }
      }
    ]
  },
  node: {
    __filename: false,
    __dirname: false,
    global: false
    // console: true,
  },
  target: 'node',
  devtool: 'source-map',
  plugins: [new ForkTsCheckerWebpackPlugin({ async: env === 'production' })],
  externalsPresets: { node: true },
  externals: [nodeExternals()]
  // externals: nodeModules,
});
