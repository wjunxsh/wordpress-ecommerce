const config = {
  test: {
    globals: true,
    exclude: ["../frontend/**", "./node_modules/**"],
  },
};

export default config;
