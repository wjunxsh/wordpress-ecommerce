import { ControllerBase, ControllerBaseInterface } from '../controller/controllerBasic';

export class ApiMiddlewareController extends ControllerBase {
  constructor(props: ControllerBaseInterface) {
    super(props);
    this.initial();
  }
  private initial() {
    this.router.use('/api/*', this.validateAuthenticatedSession());
  }
}
