import { ShopModel } from '../model/shop.model';
import { ControllerBase, ControllerBaseInterface } from '../controller/controllerBasic';
import { join } from 'path';
import { readFileSync } from 'fs';
import { Request, Response } from 'express';
import serveStatic from 'serve-static';
import { ShopEntity } from '../entity/shop.entity';
const DEV_INDEX_PATH = `${process.cwd()}/../client/`;
const PROD_INDEX_PATH = `${process.cwd()}/client/dist/`;
const STATIC_PATH = process.env.NODE_ENV === 'production' ? `${process.cwd()}/client/dist` : `${process.cwd()}/../client/`;
export class MiddlewareController extends ControllerBase {
  constructor(props: ControllerBaseInterface) {
    super(props);
  }
  whitelist = ['/privacy'];
  async initial() {
    this.app.use(/\/api.*/, this.apiNotFound());
    this.app.use(/\/out-api.*/, this.apiNotFound());
    if (process.env.NODE_ENV === 'production') {
      await this.proOtherMiddle();
    }
    this.app.get('/*', async (_req, res, next) => {
      if (this.whitelist.includes(_req.path) && !_req.query.shop) {
        return res
          .status(200)
          .set('Content-Type', 'text/html')
          .send(readFileSync(join(STATIC_PATH, 'index.html')));
      }
      next();
    });
    this.app.use(serveStatic(STATIC_PATH, { index: false }));
    this.app.use('/*', this.ensureInstalled(), async (_req, res) => {
      return res
        .status(200)
        .set('Content-Type', 'text/html')
        .send(readFileSync(join(STATIC_PATH, 'index.html')));
    });
  }
  apiNotFound() {
    return async (req: Request, res: Response) => {
      return res.json({ code: 404, msg: 'Not Found' });
    };
  }

  async proOtherMiddle() {
    const compression = await import('compression').then(({ default: fn }) => fn);
    const serveStatic = await import('serve-static').then(({ default: fn }) => fn);
    this.app.use(compression());
    this.app.use(serveStatic(PROD_INDEX_PATH, { index: false }));
  }
  frontend() {
    return async (req, res) => {
      const shop = req.query.shop;
      let shopInfo: ShopEntity;
      if (shop) {
        shopInfo = await new ShopModel(this.database).getShopByShopDomain(shop);
      }
      if ((!shopInfo || shopInfo.uninstalled_at) && shop) {
        res.redirect(`/api/auth?shop=${shop}`);
      } else {
        const fs = await import('fs');
        const fallbackFile = join(process.env.NODE_ENV === 'production' ? PROD_INDEX_PATH : DEV_INDEX_PATH, 'index.html');
        res.status(200).set('Content-Type', 'text/html').send(fs.readFileSync(fallbackFile));
      }
    };
  }
}
