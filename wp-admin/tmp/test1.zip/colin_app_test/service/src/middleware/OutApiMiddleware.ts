import { ControllerBase, ControllerBaseInterface } from '../controller/controllerBasic';
import { Request, Response, NextFunction } from 'express';
import dayjs from 'dayjs';
import md5 from 'md5';
import { OutApiAuthEntity } from '../entity/authorization.entity';
export class OutMiddlewareController extends ControllerBase {
  constructor(props: ControllerBaseInterface) {
    super(props);
    this.initial();
  }
  async initial() {
    this.router.use('/api/get-shop-token', this.validateAuthenticated());
    this.router.use('/out-api/*', this.validateAuthenticated());
  }
  validateAuthenticated() {
    return async (req: Request, res: Response, next: NextFunction) => {
      if (process.env.NODE_ENV == 'development') {
        return next();
      }
      return await this.accessAuth(req, res, next);
    };
  }
  async accessAuth(req: Request, res: Response, next: NextFunction) {
    let authToken = req.headers['token'];
    let authorization = req.headers['authorization'];
    //从数据库获取私钥
    let dcTimestamp = req.headers['dc-timestamp'];
    if (!authToken || !dcTimestamp || !authorization) {
      return res.status(403).send({ code: 403, msg: 'Authorization failed!' });
    }
    let outApiAuthRspt = this.database.getRepository(OutApiAuthEntity);
    let authInfo = await outApiAuthRspt.findOneBy({ public_token: authToken, state: true });
    if (!authInfo) {
      return res.status(403).send({ code: 403, msg: 'Authorization failed!' });
    }
    let timestamp = dayjs(dcTimestamp as string).unix() + 1000;
    if (authorization == md5(timestamp + authInfo.private_key + authInfo.public_token)) {
      return next();
    } else {
      return res.status(403).send({ code: 403, msg: 'Authorization failed!' });
    }
  }
}
