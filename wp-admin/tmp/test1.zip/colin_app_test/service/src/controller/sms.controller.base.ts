import { Redis } from "ioredis";
import { DataSource } from "typeorm";
import { Express, Router } from "express";
import { HttpResponseError, InvalidJwtError, Session, Shopify } from "@shopify/shopify-api";
import { SessionStorage } from "@shopify/shopify-app-session-storage";
import { Logger } from "winston";
import { ControllerBaseInterface } from "./controllerBasic";
export interface SmsControllerBaseInterface extends ControllerBaseInterface {
  smsDatabase: DataSource;
}

export class SmsControllerBase {
  public sessionStorage: SessionStorage;
  public app: Express;
  public redis: Redis;
  public database: DataSource;
  public router: Router;
  public api: Shopify;
  public logger:Logger
  public smsDatabase: DataSource;
  constructor(bootstrap: SmsControllerBaseInterface) {
    this.app = bootstrap.app;
    this.redis = bootstrap.redis;
    this.database = bootstrap.database;
    this.smsDatabase = bootstrap.smsDatabase;
    this.router = bootstrap.router;
    this.api = bootstrap.api;
    this.sessionStorage = bootstrap.sessionStorage;
    this.logger = bootstrap.logger;
  }
}
