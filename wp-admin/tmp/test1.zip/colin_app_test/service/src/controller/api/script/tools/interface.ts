import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';
import { ScriptDiscountMetafieldsEntity } from '../../../../entity/script/script_discount.metafields.entity';
import { ScriptProductTagEntity } from '../../../../entity/script/script_product_tag.entity';
import { ShopEntity } from '../../../../entity/shop.entity';

export interface ToolsClass {
  product_tag: string;
  makeDiscountData: (body: any) => Promise<DiscountData>;
  getVariantsIds?: (body: any) => string[];
  getProductsIds?: (body: any) => string[];
  makeScriptsData: (body: any, productObjs?: any) => any;
  makeMetafields: (body: any, variantsObj: any, shopInfo?: ShopEntity) => ScriptDiscountMetafieldsEntity[];
  createScriptsCode: (data: any) => string;
  makeProductTags: (body: any, variantsObj: any) => ScriptProductTagEntity[];
  multUpload?: (shop_id: number, data: any) => any;
  covertShopifyIdToId: (discountInfo: ScriptDiscountEntity) => Promise<ScriptDiscountEntity>;
  covertIdToShopfyId: (discountInfo: ScriptDiscountEntity) => Promise<ScriptDiscountEntity>;
}

export interface DiscountData {
  scriptData: any;
  newMetafields: ScriptDiscountMetafieldsEntity[];
  scriptProductTags: ScriptProductTagEntity[];
}
