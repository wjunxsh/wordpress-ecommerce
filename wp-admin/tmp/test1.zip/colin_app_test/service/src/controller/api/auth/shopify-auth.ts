import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { ShopModel } from '../../../model/shop.model';
import { Request, Response } from 'express';
import { InvalidOAuthError, CookieNotFound, DeliveryMethod, Session } from '@shopify/shopify-api';
import { WebhookService } from '../../../services/webhook.services';
export class ShopifyAuthController extends ControllerBase {
  private shopModel: ShopModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    this.shopModel = new ShopModel(bootstrap.database);
    this.initial();
  }
  private initial() {
    this.router.get('/api/auth/callback', this.authCallback.bind(this));
    this.router.get('/api/auth', this.auth.bind(this));
  }
  private async auth(req, res) {
    return this.redirectToAuth({ req, res });
  }

  private async authCallback(req, res) {
    req.query.shop && this.getShopifyApi(req, req.query.shop);
    try {
      const callbackResponse = await (req.api || this.api).auth.callback({
        rawRequest: req,
        rawResponse: res
      });
      await this.sessionStorage.storeSession(callbackResponse.session);
      if (callbackResponse.session.isOnline) {
        let session = callbackResponse.session;
        const host = req.query.host;
        let redirectUrl = `/bulk_code/list?shop=${session.shop}&host=${host}`;
        res.redirect(redirectUrl);
      } else {
        await this.initShopFromShopify(callbackResponse.session);
        await this.RegistryHooks();
        //注册其他的webhook信息
        new WebhookService(this.database, req.api || this.api).init(callbackResponse.session);
        await this.redirectToAuth({ req, res, isOnline: true });
        return false;
      }
    } catch (error) {
      await this.handleCallbackError(req, res, error);
    }
    return false;
  }
  async initShopFromShopify(session: Session) {
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    if (shopInfo) {
      await this.shopModel.updateShop({
        ...shopInfo,
        shopify_token: session.accessToken,
        uninstalled_at: null,
        scope: session.scope,
        state: 1
      });
    } else {
      let clients = new this.api.clients.Rest({
        session: session
      });
      let result: any = await clients.get({
        path: 'shop'
      });
      await this.shopModel.createShop({
        ...result.body.shop,
        state: 1,
        scope: session.scope,
        shopify_token: session.accessToken
      });
    }
  }
  redirectToShopifyOrAppRoot() {
    return async function (req: Request, res: Response) {
      if (res.headersSent) {
        console.log('Response headers have already been sent, skipping redirection to host');

        return;
      }

      const host = this.api.utils.sanitizeHost(req.query.host as string)!;
      const redirectUrl = this.api.config.isEmbeddedApp
        ? await this.api.auth.getEmbeddedAppUrl({
            rawRequest: req,
            rawResponse: res
          })
        : `/?shop=${res.locals.shopify.session.shop}&host=${encodeURIComponent(host)}`;

      console.log(`Redirecting to host at ${redirectUrl}`);
      res.redirect(redirectUrl);
    };
  }
  async handleCallbackError(req: Request, res: Response, error: Error) {
    switch (true) {
      case error instanceof InvalidOAuthError:
        res.status(400);
        res.send(error.message);
        break;
      case error instanceof CookieNotFound:
        await this.redirectToAuth({ req, res });
        break;
      default:
        res.status(500);
        res.send(error.message);
        break;
    }
  }
  async RegistryHooks() {
    await this.api.webhooks.addHandlers({
      CUSTOMERS_DATA_REQUEST: {
        deliveryMethod: DeliveryMethod.Http,
        callbackUrl: '/api/webhooks',
        callback: async (topic, shop, body, webhookId) => {
          const payload = JSON.parse(body);
        }
      },

      CUSTOMERS_REDACT: {
        deliveryMethod: DeliveryMethod.Http,
        callbackUrl: '/api/webhooks',
        callback: async (topic, shop, body, webhookId) => {
          const payload = JSON.parse(body);
        }
      },

      SHOP_REDACT: {
        deliveryMethod: DeliveryMethod.Http,
        callbackUrl: '/api/webhooks',
        callback: async (topic, shop, body, webhookId) => {
          const payload = JSON.parse(body);
          // Payload has the following shape:
          // {
          //   "shop_id": 954889,
          //   "shop_domain": "{shop}.myshopify.com"
          // }
        }
      }
    });
  }
  deleteAppInstallationHandler() {
    return async function (_topic: string, shop: string, _body: any, _webhookId: string) {
      console.log('uninstall --------> deleteApp Callback trigger:', _topic, shop);
      let shopModel = new ShopModel(this.database);
      await shopModel.unInstallShop(shop);
      const shopSessions = await this.sessionStorage.findSessionsByShop!(shop);

      if (shopSessions.length > 0) {
        await this.sessionStorage.deleteSessions!(shopSessions.map((session: Session) => session.id));
      }
    };
  }
  async updateShop(_topic: string, shop: string, body: any) {
    console.log(shop);
    //店铺更新的时候，从shopify重新获取店铺信息
    const payload = JSON.parse(body);
    console.log('update ---shop--', payload);
  }
}
