import dayjs from 'dayjs';
import { Request, Response } from 'express';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ScriptDiscountLogModel } from '../../../model/script-discount-log.model';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { ShopModel } from '../../../model/shop.model';
dayjs.extend(utc);
dayjs.extend(timezone);
export class ScriptDiscountLogController extends ControllerBase {
  ScriptDiscountLogService: ScriptDiscountLogModel;
  shopModel: ShopModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    this.ScriptDiscountLogService = new ScriptDiscountLogModel(this.database);
    this.shopModel = new ShopModel(bootstrap.database);
    this.router.get('/api/script/discount/log/list', this.list.bind(this));
  }
  async list(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 30;
    const title: string = request.query.title ? `${request.query.title}` : '';
    const shop_id: number = shopInfo['id'];
    const discountId: number = request.query.discount_id ? parseInt(`${request.query.discount_id}`) : 0;
    let discountList: any = await this.ScriptDiscountLogService.getDiscountList({
      shop_id,
      title,
      current_page,
      page_size,
      discountId
    });
    let count = await this.ScriptDiscountLogService.getDiscountCount({ title, shop_id, discountId });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: {
        list: discountList.map(discount => ({
          ...discount,
          user: discount.user ? discount.user.online_access_info : {},
          starts_at: dayjs(discount.starts_at).tz('Asia/ShangHai').format('YYYY-MM-DD HH:mm:ssZZ'),
          ends_at: dayjs(discount.ends_at).tz('Asia/ShangHai').format('YYYY-MM-DD HH:mm:ssZZ'),
          shop: { shopify_domain: discount.shop.shopify_domain, id: discount.shop.id }
        })),
        pagination
      }
    });
  }
}
