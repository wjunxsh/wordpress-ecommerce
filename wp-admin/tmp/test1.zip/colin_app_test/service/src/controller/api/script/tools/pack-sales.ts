import { v4 as uuidv4 } from 'uuid';
import { ToolsClass } from './interface';
import { VariantModel } from '../../../../model/variant.model';
import { VariantEntity } from '../../../../entity/variant.entity';
import { ScriptProductTagEntity } from '../../../../entity/script/script_product_tag.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';
interface DiscountRule {
  skus: { label: string; value: string }[];
  quantity: number;
  value: number;
}
export class PackSales implements ToolsClass {
  public product_tag = 'pack_sales';
  variantModel?: VariantModel;
  constructor(variantModel: VariantModel) {
    this.variantModel = variantModel;
  }

  async makeDiscountData(body: any) {
    let variantsIds = this.getVariantsIds(body);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: body.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let scriptData = this.makeScriptsData(body, variantsObj);
    let scriptProductTags = this.makeProductTags(body, variantsObj);
    //组装metafields
    let newMetafields = this.makeMetafields();

    return {
      scriptData,
      newMetafields,
      scriptProductTags
    };
  }
  async covertIdToShopfyId(data: ScriptDiscountEntity) {
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    return data;
  }
  getVariantsIds(body) {
    let discountRule: DiscountRule[] = body.config.discount_rule;
    let variantsIds = [];
    discountRule.forEach(rule => {
      rule.skus.forEach(val => {
        variantsIds.push(val.value);
      });
    });
    return variantsIds;
  }
  makeScriptsData(body, variantsObj) {
    let discountRule: DiscountRule[] = body.config.discount_rule;
    let scriptActiveRules = discountRule.map(rule => {
      return {
        skus: rule.skus.map(val => {
          if (!variantsObj[val.value]) {
            throw new Error(`Sku ${val.label} is not found!`);
          }
          return variantsObj[val.value].sku;
        }),
        quantity: rule.quantity,
        value: rule.value
      };
    });
    let returnData = {
      message: body.config.message,
      discount_type: body.config.discount_type,
      dc_mutex: body.config.dc_mutex ? true : false,
      mutex: body.config.mutex ? true : false,
      active_rules: scriptActiveRules
    };
    if (body.config.property_key) {
      returnData['property_key'] = body.config.property_key;
    }
    return returnData;
  }
  makeMetafields() {
    return [];
  }
  public makeProductTags(body, variantObjs) {
    let discountRule: DiscountRule[] = body.config.discount_rule;
    let productTags: ScriptProductTagEntity[] = [];
    discountRule.forEach(rule => {
      rule.skus.forEach(val => {
        if (!variantObjs[val['value']]) throw new Error(`Sku ${val.label} is not found!`);
        if (productTags.some(item => item.product_shopify_id == variantObjs[val['value']]['product'].shopify_id)) {
          return true;
        }
        let productTag: ScriptProductTagEntity = {
          uuid: uuidv4(),
          product_shopify_id: variantObjs[val['value']]['product'].shopify_id,
          product_tag: this.product_tag,
          discount_id: 0,
          is_need_delete: false,
          created_at: new Date(),
          updated_at: new Date(),
          start_sync_at: body.starts_at,
          sync_at: null,
          sync_state: false
        };
        productTags.push(productTag);
      });
    });
    return productTags;
  }
  public createScriptsCode(data: any): string {
    let code = `pack_sales({
  message:"${data.message}",
  discount_type:"${data.discount_type}",
  dc_mutex:${data.dc_mutex},
  product_tag:"${this.product_tag}",
  mutex:${data.mutex ?? true},
  active_rules:[\n`;
    data.active_rules.forEach(item => {
      code += `    {skus:["${item.skus.join('","')}"],quantity:${item.quantity},value:${item.value}},\n`;
    });
    code += `   ],\n`;
    if (data.property_key) {
      code += `   property_key:"${data.property_key}" \n`;
    }
    code += `})\n`;
    return code;
  }
}
