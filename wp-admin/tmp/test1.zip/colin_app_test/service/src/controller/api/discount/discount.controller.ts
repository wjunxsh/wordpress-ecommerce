import { Request, Response } from 'express';
import { ShopModel } from '../../../model/shop.model';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { ShopifyApiLib } from '../../../lib/shopify-api.lib';
import { ShopifyGraphQLLib } from '../../../lib/shopify-graphql.lib';
import { updateCodeMutation } from '../../../graphql/updateCodeMutation';
import { BulkCodeLib } from '../../../lib/bulk-code.lib';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
dayjs.extend(utc);
dayjs.extend(timezone);
import multer from 'multer';
import xlsx from 'node-xlsx';
import { DiscountImportTaskModel } from '../../../model/discount.import.task.model';
import { DiscountImportTasksEntity } from '../../../entity/discount.import.task.entity';
let upload = multer();
const SHOP_COUNTRIES_QUERY = `
  query GetShopCountries {
    shop {
      id
      countriesInShippingZones {
        countryCodes
        includeRestOfWorld
      }
    }
  }
`;
const CREATE_AUTOMATIC_MUTATION = `
  mutation CreateAutomaticDiscount($discount: DiscountAutomaticAppInput!) {
    discountCreate: discountAutomaticAppCreate(
      automaticAppDiscount: $discount
    ) {
      userErrors {
        code
        message
        field
      }
    }
  }
`;
export class DiscountController extends ControllerBase {
  public shopifyGraphQL: ShopifyGraphQLLib;
  public shopModel: ShopModel;
  public discountTaskModel: DiscountImportTaskModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    // this.router.get("/api/bulk/code/test", this.test.bind(this));
    this.shopModel = new ShopModel(bootstrap.database);
    this.discountTaskModel = new DiscountImportTaskModel(bootstrap.database, bootstrap.redis);
    this.router.post('/api/discounts/code', this.createCode.bind(this));
    this.router.post('/api/discounts/automatic', this.createAutomatic.bind(this));
    this.router.post('/api/discounts/countries', this.getCountries.bind(this));
    this.router.post('/api/discounts/customers', this.getCustomers.bind(this));
    //start_ai_generated
    this.router.post('/api/discounts/import_task', upload.single('file'), this.importTask.bind(this));
    this.router.get('/api/discounts/import_task_list', this.importTaskList.bind(this));
    this.router.get('/api/discounts/import_task_records', this.discountImportRecords.bind(this));
    //end_ai_generated
  }
  async createCode(req: Request, res: Response) {
    await this.runDiscountMutation(req, res, updateCodeMutation(req.body.id));
  }
  async createAutomatic(req: Request, res: Response) {
    await this.runDiscountMutation(req, res, CREATE_AUTOMATIC_MUTATION);
  }
  async runDiscountMutation(req, res, mutation) {
    const session = res.locals.shopify.session;
    const client = new ShopifyGraphQLLib(session, req.api);

    let queryData = { ...req.body };
    delete queryData.id;
    const data = await client.graphOnlineQL(mutation, { discount: queryData, id: req.body.id });
    res.send(data.body);
  }
  async getCountries(req, res) {
    const session = res.locals.shopify.session;
    const client = new ShopifyApiLib(session, req.api);
    const data: any = await client.apiGet('countries', {});
    return res.json({ code: 200, msg: '', data: data.body.countries });
    //await this.runDiscountMutation(req,res,SHOP_COUNTRIES_QUERY);
  }
  async getCustomers(req, res) {
    const session = res.locals.shopify.session;
    const client = new ShopifyGraphQLLib(session, req.api);
    const data = await client.graphOnlineQL(SHOP_COUNTRIES_QUERY, {});
    return res.json({ code: 200, msg: '', data: data.body });
    //await this.runDiscountMutation(req,res,SHOP_COUNTRIES_QUERY);
  }
  //start_ai_generated
  /**
   * 获取折扣任务列表
   *
   */
  async importTaskList(req: Request, res: Response) {
    let query = req.query;
    let currentPage: number = parseInt((query.current_page ?? '1') as string);
    let pageSize: number = parseInt((query.page_size ?? '50') as string);
    let search = query.search ?? '';
    let shopInfo = await new ShopModel(this.database).getShopByShopDomain(res.locals.shopify.session.shop);
    let list = await this.discountTaskModel.getList({
      currentPage,
      pageSize,
      search,
      shop_id: shopInfo['id']
    });
    let count = await this.discountTaskModel.getCount({ search, shop_id: shopInfo['id'] });
    let totalPages = Math.ceil(count / pageSize);
    //获取操作人信息
    return res.status(200).send({
      code: 200,
      msg: '',
      data: {
        shop: {
          iana_timezone: shopInfo['iana_timezone'],
          shopify_domain: shopInfo['shopify_domain'],
          id: shopInfo['id'],
          shopify_id: shopInfo['shopify_id']
        },
        list: list.map(item => ({
          ...item,
          user_email: item['user'] ? item['user']?.online_access_info.email : ''
        })),
        pagination: {
          current_page: currentPage,
          page_size: pageSize,
          total_pages: totalPages,
          total_size: count
        }
      }
    });
  }

  /**
   *
   * 获取导入任务详情
   * @param req
   * @param res
   * @returns
   */
  async discountImportRecords(req: Request, res: Response) {
    let taskId = req.query.task_id;
    let query = req.query;
    let currentPage: number = parseInt((query.current_page ?? '1') as string);
    let pageSize: number = parseInt((query.page_size ?? '50') as string);
    let list = await this.discountTaskModel.getRecordList({
      currentPage,
      pageSize,
      task_id: taskId
    });
    let count = await this.discountTaskModel.getRecordCount({
      task_id: taskId
    });
    let shopInfo = await new ShopModel(this.database).getShopByShopDomain(res.locals.shopify.session.shop);
    //获取店铺信息
    let totalPages = Math.ceil(count / pageSize);
    return res.status(200).send({
      code: 200,
      msg: '',
      data: {
        list: list.map(record => ({
          ...record,
          sync_at: record.sync_at ? dayjs(record.sync_at).tz(shopInfo['iana_timezone']).format('YYYY-MM-DD HH:mm:ss') : null
        })),
        pagination: {
          current_page: currentPage,
          page_size: pageSize,
          total_pages: totalPages,
          total_size: count
        }
      }
    });
  }

  async importTask(req, res) {
    let body = req.body;
    //初始化
    const session = res.locals.shopify.session;
    const userId = session.onlineAccessInfo.id;
    let client = new ShopifyApiLib(session, req.api);
    //获取店铺信息
    let shopifyDomain = session.shop;
    let shopInfo = await this.shopModel.getShopByShopDomain(shopifyDomain);

    let data = this.analysisExcelData(req.file.buffer);
    let bulkCodeLib = new BulkCodeLib();
    if (!data.length) {
      return res.status(200).send({
        code: 404,
        msg: 'excel是没有数据或者数据异常请检查您的excel文件'
      });
    }
    let fields = Object.keys(data[0]);
    let mustFields = ['handle', 'code', 'sku', 'value', 'value_type', 'start_date', 'end_date'];
    for (let i = 0, count = mustFields.length; i < count; i++) {
      if (!fields.includes(mustFields[i])) {
        return res.status(200).send({ code: 404, msg: `表头${mustFields[i]}未找到!` });
      }
    }
    if (body.code_type == 'import' && data.some(item => !item.code)) {
      return res.status(200).send({ code: 404, msg: `code生成方式为导入的时候，code不允许为空` });
    } else if (body['code_type'] != 'import') {
      body.code_prefix = body.code_prefix ? body.code_prefix.toUpperCase() : '';
      data.map(item => {
        let code = bulkCodeLib.randomStr(body.code_num, 'mixed');
        item.code = item.code ?? (body.code_prefix || '') + code;
      });
    }
    for (let i = 0; i < data.length; i++) {
      if (!['percentage', 'fixed_amount'].includes(data[i]['value_type'])) {
        return res.status(200).send({
          code: 500,
          msg: `The value type is incorrect, the value type is only allowed to be 'percentage' or 'fixed_amount'.`
        });
      }
      if (!/^((\d+\.\d+)|(\d+))$/.test(data[i]['value'])) {
        return res.status(200).send({ code: 500, msg: `The value can only be a number!` });
      }
      data[i]['start_date'] = dayjs(
        dayjs.tz(dayjs(data[i].start_date).format('YYYY-MM-DD HH:mm:ss'), shopInfo['iana_timezone'])
      ).format();
      data[i]['end_date'] = dayjs(
        dayjs.tz(dayjs(data[i].end_date).format('YYYY-MM-DD HH:mm:ss'), shopInfo['iana_timezone'])
      ).format();
    }
    //根据handle 和sku 获取variant_id
    let handles = data.filter(item => !!item.handle).map(item => item.handle);
    if (!handles.length) {
      return res.status(200).send({ code: 404, msg: '产品的handle必须填写' });
    }
    let productList = await this.getProductsFromShopify(client, req, res, Array.from(new Set(handles)));
    if (!productList.length) {
      return res.status(200).send({ code: 404, msg: '未查找到对应的sku,请检查数据后重新尝试' });
    }
    let notExistSkus: string[] = [];
    data.forEach(item => {
      let product = productList.find(product => product.handle === item.handle);
      let variant = product ? product['variants'].find(variant => variant.sku == item.sku) : null;
      if (!variant) {
        notExistSkus.push(item.sku);
        return false;
      }
      variant && (item.variant_id = variant.id);
    });
    if (notExistSkus.length) {
      return res.status(200).send({ code: 404, msg: `未查找到sku:${notExistSkus.join(',')}的产品,请检查数据后重新尝试` });
    }
    //将数据保存到数据库中
    let importTaskModel = new DiscountImportTaskModel(this.database, this.redis);
    let importTaskData = new DiscountImportTasksEntity();
    importTaskData = {
      ...importTaskData,
      title: body.title,
      shop_id: shopInfo.id,
      user_id: userId,
      promise_sync: true,
      combine_product_discount: body.combine_product_discount === 'true' ? true : false,
      code_generate_type: body.code_type,
      import_type: body.import_type
    };
    let taskInfo = await importTaskModel.saveDiscountImportTask(importTaskData, data);
    let taskFullData = await importTaskModel.getNotAsyncTaskInfo(taskInfo.id);
    //异步调用一次
    importTaskModel.aysncDiscountToShopify(taskFullData, this.api, this.sessionStorage);
    return res.status(200).json({ code: 200, msg: '', data: { list: data } });
  }
  //end_ai_generated
  analysisExcelData(buffer: Buffer) {
    let workbook = xlsx.parse(buffer, { cellDates: true });
    let data: any[] = [];
    let sheet = workbook[0];
    let fields = sheet['data'][0];
    sheet['data'].forEach((item, index) => {
      if (index == 0) return;
      let itemVal: any = {};
      //之所以用for 是因为如果字段为空用forEach就不会遍历到
      if (!item[0] && !item[1]) {
        return true;
      }
      for (let i = 0; i < item.length; i++) {
        itemVal[fields[i]] = item[i];
      }
      data.push({ ...itemVal, status: { code: 0 } });
    });
    return data;
  }
  async getProductsFromShopify(client: ShopifyApiLib, req: Request, res: Response, handles: string[]) {
    let result = await client.apiGet(`products`, {
      handle: handles.join(',')
    });
    return result['products'];
  }
}
