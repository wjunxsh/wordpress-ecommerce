import { v4 as uuidv4 } from 'uuid';
import { ToolsClass } from './interface';
import { VariantModel } from '../../../../model/variant.model';
import { VariantEntity } from '../../../../entity/variant.entity';
import { ScriptDiscountMetafieldsEntity } from '../../../../entity/script/script_discount.metafields.entity';
import { ScriptProductTagEntity } from '../../../../entity/script/script_product_tag.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';

export class BundleSuitesalesTools implements ToolsClass {
  public product_tag = 'bnndle_suite_sales';
  variantModel?: VariantModel;
  constructor(variantModel: VariantModel) {
    this.variantModel = variantModel;
  }

  async makeDiscountData(body: any) {
    let variantsIds = this.getVariantsIds(body);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: body.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let scriptData: any = this.makeScriptsData(body, variantsObj);
    let scriptProductTags = this.makeProductTags(body, variantsObj);
    //组装metafields
    let newMetafields = this.makeMetafields(body, variantsObj);

    return {
      scriptData,
      newMetafields,
      scriptProductTags
    };
  }
  getVariantsIds(body) {
    let bundleConfig = body.config.bundle_config;
    let variantsIds = [];
    bundleConfig.forEach(rule => {
      rule.map(item => {
        variantsIds.push(item.sku.value);
      });
    });
    return variantsIds;
  }

  getVariantsShopifyIds(data) {
    let bundleConfig = data.config.bundle_config;
    let variantsShopifyIds = [];
    bundleConfig.forEach(rule => {
      rule.map(item => {
        variantsShopifyIds.push(item.sku.value);
      });
    });
    return variantsShopifyIds;
  }

  makeScriptsData(body, variantsObj) {
    let bundleConfig = body.config.bundle_config;
    let bundleConfigs = bundleConfig.map(rule => {
      let config = {};
      rule.map(item => {
        let sku = variantsObj[item.sku.value].sku;
        if (config[sku]) {
          config[sku] = {
            qty: item.qty + config[sku].qty,
            price: item.price
          };
        } else {
          config[sku] = {
            qty: item.qty,
            price: item.price
          };
        }
      });
      return config;
    });
    let returnData = {
      message: body.config.message,
      discount_type: body.config.discount_type,
      dc_mutex: body.config.dc_mutex ?? true,
      mutex: body.config.mutex ? true : false,
      bundle_config: bundleConfigs
    };
    if (body.config.property_key) {
      returnData['property_key'] = body.config.property_key;
    }
    return returnData;
  }
  async covertIdToShopfyId(data: any) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let bundleConfig: any = data.config.bundle_config;
    bundleConfig.forEach(rule => {
      rule.forEach(item => {
        if (variantsObj[item.sku.value]) {
          item.sku.value = variantsObj[item.sku.value]['shopify_id'];
        }
      });
    });
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByShopifyIds({ shopifyIds: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['shopify_id']] = variant;
    });
    let bundleConfig: any = data.config.bundle_config;
    bundleConfig.forEach(rule => {
      rule.forEach(item => {
        if (variantsObj[item.sku.value]) {
          if (item.sku.key) {
            item.sku.key = variantsObj[item.sku.value]['id'];
          }
          item.sku.value = variantsObj[item.sku.value]['id'];
        }
      });
    });
    return data;
  }
  makeMetafields(body, variantObjs) {
    let bundleConfig = body.config.bundle_config;
    let metafields: ScriptDiscountMetafieldsEntity[] = [];
    for (let id in variantObjs) {
      let ruleList = [];
      ruleList = bundleConfig
        .filter(rule => rule.some(item => item.sku.value == id))
        .map(rule => {
          return rule.map(item => ({
            handle: variantObjs[item.sku.value]['product'].handle,
            sku: variantObjs[item.sku.value].sku,
            price: item.price,
            qty: item.qty,
            label: item.label ?? ''
          }));
        });
      let metafieldsValue = {
        list: ruleList,
        title: body.title,
        discount_type: body.config.discount_type,
        labels: body.config.text_arr || [],
        showDiscounts: body.config.dc_mutex ? false : true
      };
      let metafieldsData: ScriptDiscountMetafieldsEntity = {
        uuid: uuidv4(),
        sort: 0,
        target_shopify_id: variantObjs[id].shopify_id,
        target_type: 'variant',
        discount_id: 0,
        metafield_shopify_id: 0,
        is_need_delete: false,
        created_at: new Date(),
        updated_at: new Date(),
        metafield_type: 'json',
        start_sync_at: body.starts_at,
        sync_at: null,
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        //@ts-ignore
        metafield_value: JSON.stringify(metafieldsValue),
        metafield_namespace: 'bundle',
        metafield_key: 'bundle_suite_sales'
      };
      metafields.push(metafieldsData);
    }
    return metafields;
  }

  public makeProductTags(body, variantObjs) {
    let productTags: ScriptProductTagEntity[] = [];
    for (let id in variantObjs) {
      if (productTags.some(item => item.product_shopify_id == variantObjs[id]['product'].shopify_id)) {
        continue;
      }
      let productTag: ScriptProductTagEntity = {
        uuid: uuidv4(),
        product_shopify_id: variantObjs[id]['product'].shopify_id,
        product_tag: this.product_tag,
        discount_id: 0,
        is_need_delete: false,
        updated_at: new Date(),
        created_at: new Date(),
        start_sync_at: body.starts_at,
        sync_at: null,
        sync_state: false
      };
      productTags.push(productTag);
    }
    return productTags;
  }
  public createScriptsCode(data: any): string {
    let code = `bundle_suite_sale(`;
    code += `{
  message:"${data.message}",
  discount_type:"${data.discount_type}",
  dc_mutex:${data.dc_mutex},
  mutex:${data.mutex ?? true},
  product_tag:"${this.product_tag}",
  bundle_config:[\n`;
    for (let i = 0, count = data.bundle_config.length; i < count; i++) {
      let item = data.bundle_config[i];
      code += `   {`;
      let itemArr: string[] = [];
      for (let sku in item) {
        itemArr.push(`"${sku}"=> {:price=>${item[sku]['price']},:qty=>${item[sku]['qty']}}`);
      }
      code += `${itemArr.join(',')}},\n`;
    }
    code += ` ],
`;
    if (data.property_key) {
      code += ` property_key:"${data.property_key}" \n`;
    }
    code += `})\n`;
    return code;
  }
  async multUpload(data: any) {
    return data;
  }
}
