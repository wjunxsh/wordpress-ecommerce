export const updateCodeMutation = id => {
  const UPDATE_CODE_MUTATION = `
    mutation discountCodeAppUpdate($codeAppDiscount: DiscountCodeAppInput!, $id: ID!) {
        discountCodeAppUpdate(codeAppDiscount: $codeAppDiscount, id: ${id}) {
          codeAppDiscount {
            code
            id
          }
          userErrors {
            field
            message
          }
        }
      }
  `;
  return UPDATE_CODE_MUTATION;
};
export default {};
