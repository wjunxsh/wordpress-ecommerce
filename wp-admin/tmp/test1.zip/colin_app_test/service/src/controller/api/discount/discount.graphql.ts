export const SHOP_COUNTRIES_QUERY = `
  query GetShopCountries {
    shop {
      id
      countriesInShippingZones {
        countryCodes
        includeRestOfWorld
      }
    }
  }
`;
export const CUSTOMER_PICKER_QUERY = `
query GetCustomers($first: Int!, $searchQuery: String = "", $after: String) {
  customers(
    first: $first
    query: $searchQuery
    after: $after
    sortKey: NAME
  ) {
    edges {
      cursor
      node {
        id
        displayName
        email
      }
    }
    pageInfo {
      hasNextPage
    }
  }
}
`;
export const CREATE_AUTOMATIC_MUTATION = `
  mutation discountAutomaticAppCreate($automaticAppDiscount: DiscountAutomaticAppInput!) {
    discountAutomaticAppCreate(
      automaticAppDiscount: $automaticAppDiscount
    ) {
      userErrors {
        code
        message
        field
      }
      automaticAppDiscount {
        discountId
        title
        startsAt
        endsAt
        status
        appDiscountType {
          appKey
          functionId
        }
        combinesWith {
          orderDiscounts
          productDiscounts
          shippingDiscounts
        }
      }
    }
  }
`;

export const CREATE_CODE_MUTATION = `
mutation discountCodeAppCreate($codeAppDiscount: DiscountCodeAppInput!) {
  discountCodeAppCreate(codeAppDiscount: $codeAppDiscount) {
    codeAppDiscount {
      createdAt
      discountId
    }
    userErrors {
      field
      message
    }
  }
}
`;

export const UPDATE_CODE_MUTATION = `
mutation discountCodeAppUpdate($codeAppDiscount: DiscountCodeAppInput!, $id: ID!) {
  discountCodeAppUpdate(codeAppDiscount: $codeAppDiscount, id: $id) {
    codeAppDiscount {
      createdAt
      discountId
    }
    userErrors {
      field
      message
    }
  }
}
`;
export const UPDATE_AUTOMATIC_MUTATION = `
mutation discountAutomaticAppUpdate($automaticAppDiscount: DiscountAutomaticAppInput!, $id: ID!) {
  discountAutomaticAppUpdate(automaticAppDiscount: $automaticAppDiscount, id: $id) {
    automaticAppDiscount {
      createdAt
      discountId
    }
    userErrors {
      field
      message
    }
  }
}
`;

export const CREATE_PRICE_RULE_WITH_CODE = `
mutation priceRuleCreate($priceRule: PriceRuleInput!, $code: PriceRuleDiscountCodeInput!) {
  priceRuleCreate(priceRule: $priceRule,priceRuleDiscountCode: $code) {
    priceRule {
      id
    }
    priceRuleDiscountCode {
      code
    }
    priceRuleUserErrors {
      code
      field
      message
    }
  }
}
`;

export const UPDATE_PRICE_RULE_WITH_CODE = `
mutation priceRuleUpdate($id: ID!, $priceRule: PriceRuleInput!) {
  priceRuleUpdate(id: $id, priceRule: $priceRule) {
    priceRule {
      id
    }
    priceRuleDiscountCode {
      code
    }
    priceRuleUserErrors {
      code
      field
      message
    }
  }
}
`;

export const queryCodeMutation = (graphId: string) => {
  return `query {
    codeDiscountNode(id: "${graphId}") {
      id
      metafield (namespace: "buy_main_send_gift", key: "send-gift") {
        id
      }
    }
}`;
};
export const queryAutomationMutation = (graphId: string) => {
  return `query {
    automaticDiscountNode(id: "${graphId}") {
      id
      metafield (namespace: "buy_main_send_gift", key: "send-gift") {
        id
      }
    }
}`;
};
