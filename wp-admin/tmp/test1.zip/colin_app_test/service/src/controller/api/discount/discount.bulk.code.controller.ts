import { DataType } from '@shopify/shopify-api';
import { Request, Response } from 'express';
import { FindManyOptions, ILike, In } from 'typeorm';
import { BulkCodesSettingEntity } from '../../../entity/bulk-code-setting';
import { DiscountEntity } from '../../../entity/discount.entity';
import { DiscountBulkCodeEntity } from '../../../entity/discount-bulk-code';
import { ShopEntity } from '../../../entity/shop.entity';
import { ShopModel } from '../../../model/shop.model';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { ShopifyApiLib } from '../../../lib/shopify-api.lib';
import * as Excel from 'exceljs';
import fs from 'fs';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
dayjs.extend(utc);
dayjs.extend(timezone);
import { BulkCodeDto, PriceRuleDto } from './discount-bulk-code.dto';
import { DiscountCodeSettingModel } from '../../../model/discount.code.setting.model';
import { DiscountBulkCodeModel } from '../../../model/discount.bulk.code.model';
import { DiscountModel } from '../../../model/discount.mode';
import { ToolsLib } from '../../../lib/tools.lib';
export class DiscountBulkCodeController extends ControllerBase {
  public shopModel: ShopModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    this.shopModel = new ShopModel(bootstrap.database);
    this.router.post('/api/bulk/code', this.createRulePriceAndBulkCodes.bind(this));
    this.router.put('/api/bulk/code', this.bulkCode.bind(this));
    this.router.get('/api/price_rule', this.getPriceRule.bind(this));
    this.router.get('/api/bulk_code/list', this.getList.bind(this));
    this.router.get('/api/price_rule/simple_list', this.getSimpleRuleList.bind(this));
    this.router.get('/api/bulk_code/setting', this.getSettingInfo.bind(this));
    this.router.get('/api/bulk_code/search_code', this.searchCode.bind(this));
    this.router.get('/api/bulk_code/download', this.download.bind(this));
    this.router.delete('/api/bulk_code/delete', this.deleteDiscount.bind(this));
  }
  public async deleteDiscount(req: Request, res: Response) {
    let discountIds = req.query.id;
    if (!discountIds) {
      return res.json({ code: 404, msg: 'Not found' });
    }
    let discountRspt = this.database.getRepository(DiscountEntity);
    let list: any = await discountRspt.find({
      where: {
        id: In((discountIds as string[]).map(item => parseInt(item)))
      }
    });
    if (!list.length) {
      return res.json({ code: 404, msg: 'Not found' });
    }
    let discountModel = new DiscountModel(this.database);
    for (let info of list) {
      let client = await new ShopifyApiLib(res.locals.shopify.session, req.api);
      try {
        await client.apiDelete(`price_rules/${info['shopify_id']}`);
        //删除数据
        await discountModel.deleteDiscount(info);
      } catch (e) {
        console.log(e);
        if (e.code != 404) {
          return res.json({ msg: 'Delete failed!', code: 500 });
        }
        await discountModel.deleteDiscount(info);
      }
    }
    return res.json({ code: 200, msg: 'Delete success!' });
  }
  public async download(req: Request, res: Response) {
    let discountId = req.query.discount_id;
    let discountRspt = this.database.getRepository(DiscountEntity);
    let codeRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let info = await discountRspt.findOneBy({ id: parseInt(`${discountId}`) });
    if (!info) {
      return res.json({ code: 404, msg: 'Not Found!' });
    }
    let dirName = './files';
    let fileName = `${info.id}-${dayjs().format('YYYY-MM-DD')}.xlsx`;
    let path = dirName + '/' + fileName;
    let outFileName = `${dayjs().format('YYYY-MM-DD')}.xlsx`;
    if (!fs.existsSync(dirName)) {
      fs.mkdirSync(dirName);
    }
    let options = {
      filename: path,
      useStyles: true,
      useSharedStrings: true
    };
    let workbook = new Excel.stream.xlsx.WorkbookWriter(options);
    let worksheet = workbook.addWorksheet('My Sheet');
    worksheet.columns = [{ header: 'code', key: 'code', width: 20 }];
    let page_size = 1000;
    let current_page = 1;
    while (true) {
      let codeList = await codeRspt.find({
        where: { discount_id: parseInt(`${discountId}`) },
        take: page_size,
        skip: page_size * (current_page - 1)
      });
      if (!codeList || !codeList.length) {
        break;
      }
      current_page++;
      for (let codeInfo of codeList) {
        worksheet.addRow({
          code: codeInfo['code']
        });
      }
    }
    try {
      await workbook.commit().then(function () {});
    } catch (e) {
      return res.send(ToolsLib.formatErr('download failed!'));
    }

    let file = fs.createReadStream(path);
    const disposition = 'attachment; filename="' + outFileName + '"';

    res.setHeader('Content-Type', 'application/vnd.ms-excel');
    res.setHeader('Content-Disposition', disposition);
    file.pipe(res);
    file.on('end', () => {
      fs.unlinkSync(path);
    });
  }
  public async searchCode(req: Request, res: Response) {
    let query = req.query;
    let code = query.code as string;
    let bulkCodeRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let shopInfo = await new ShopModel(this.database).getShopByShopDomain(res.locals.shopify.session.shop);
    let info: any = await bulkCodeRspt
      .createQueryBuilder('dc')
      .leftJoinAndMapOne('dc.discount', DiscountEntity, 'd', 'd.id=dc.discount_id')
      .where({ code: code, shop_id: shopInfo.id })
      .getOne();
    if (!info) {
      return res.json({ code: 404, msg: 'Not found!' });
    }
    return res.json({ code: 200, msg: '', data: { info: info.discount } });
  }
  public async getList(req: Request, res: Response) {
    let discountRspt = this.database.getRepository(DiscountEntity);
    let bulkSettingRspt = this.database.getRepository(BulkCodesSettingEntity);
    let query = req.query;
    const session = res.locals.shopify.session;
    let currentPage: number = parseInt((query.current_page ?? '1') as string);
    let pageSize: number = parseInt((query.page_size ?? '50') as string);
    let sort_by: any = { id: 'desc' };
    if (query.sort_by) {
      let sortArr: any = (query.sort_by as string).split(':');
      sort_by = { [sortArr[0]]: sortArr[1] };
    }
    let search = query.search ?? '';
    let option: FindManyOptions<DiscountEntity> = {};
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    option.order = sort_by;
    if (search) {
      option.where = { title: ILike(`%${search}%`), shop_domain: session.shop };
    } else {
      option.where = { shop_domain: session.shop, is_bulk_discount: true };
    }
    const list = await discountRspt.find(option);
    const count = await discountRspt.count(option);
    //获取是否有setting 未处理成codes的记录
    let settingList = await bulkSettingRspt.findBy({
      is_bulk: false,
      discount_id: In(list.map(item => item.id))
    });
    if (settingList.length) {
      settingList.forEach(item => {
        list.forEach(discount => {
          if (discount['id'] === item.discount_id) {
            discount['is_loading'] = true;
          }
        });
      });
    }
    let totalPages = Math.ceil(count / pageSize);
    return res.json({
      code: 200,
      msg: '',
      data: {
        list: list.map(discount => ({
          id: discount.id,
          is_birthday: discount.is_birthday,
          title: discount.title,
          shopify_id: discount.shopify_id,
          label: discount.title,
          value: discount.id,
          code_quantity: discount['code_quantity'],
          is_loading: discount['is_loading'] ? discount['is_loading'] : false
        })),
        pagination: {
          current_page: currentPage,
          page_size: pageSize,
          total_pages: totalPages,
          total_sizes: count
        }
      }
    });
  }

  public async getSimpleRuleList(req: Request, res: Response) {
    let discountRspt = this.database.getRepository(DiscountEntity);
    let query = req.query;
    const session = res.locals.shopify.session;
    let currentPage: number = parseInt((query.current_page ?? '1') as string);
    let pageSize: number = parseInt((query.page_size ?? '50') as string);
    let sort_by: any = { id: 'desc' };
    if (query.sort_by) {
      let sortArr: any = (query.sort_by as string).split(':');
      sort_by = { [sortArr[0]]: sortArr[1] };
    }
    let search = query.search ?? '';
    let option: FindManyOptions<DiscountEntity> = {};
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    option.order = sort_by;
    if (search) {
      option.where = { title: ILike(`%${search}%`), shop_domain: session.shop };
    } else {
      option.where = { shop_domain: session.shop, is_bulk_discount: true };
    }
    const list = await discountRspt.find(option);
    const count = await discountRspt.count(option);
    let totalPages = Math.ceil(count / pageSize);
    return res.json({
      code: 200,
      msg: '',
      data: {
        list: list.map(discount => ({
          id: discount.id,
          title: discount.title,
          shopify_id: discount.shopify_id,
          label: discount.title,
          value: discount.id
        })),
        pagination: {
          current_page: currentPage,
          page_size: pageSize,
          total_pages: totalPages,
          total_sizes: count
        }
      }
    });
  }
  public async getSettingInfo(req: Request, res: Response) {
    let settingRspt = this.database.getRepository(BulkCodesSettingEntity);

    let query = req.query;
    //获取店铺信息

    let discountId: number = parseInt(query.discount_id as string);
    let info = await settingRspt.findOne({
      where: { discount_id: discountId },
      order: { id: 'desc' },
      relations: ['discount']
    });

    return res.json({
      code: 200,
      msg: '',
      data: { info: { ...info, auto_increment_code: info ? info['discount']['auto_increment_code'] : false } }
    });
  }
  private async createRulePriceAndBulkCodes(req: Request, res: Response) {
    const { body } = req;

    let msg = await ToolsLib.validateData(PriceRuleDto, {
      ...body.price_rule,
      ...body.codes_setting
    });
    if (msg !== true) {
      return res.json({ code: 500, msg: msg });
    }

    //获取店铺信息
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    //如果裂变的类型是manual 则在这里检查库中的code是否有跟传过来的code重复，如果重复则不允许保存
    if (body.codes_setting.type == 'manual') {
      let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
      let codes = body.codes_setting.codes.map(code => code.toUpperCase());
      let bulkCodes = await bulkCodesRspt.findBy({
        code: In(codes),
        shop_id: shopInfo.id
      });
      //检查code是否有重复
      if (bulkCodes.length) {
        let codesStr = bulkCodes.map(item => item.code).join(',');
        return res.status(200).json({
          code: 400,
          msg: `${codesStr.length > 200 ? codesStr.substring(0, 200) + '...' : codesStr} has exists!`
        });
      }
    }
    let priceRule: any = null;
    try {
      priceRule = await this.savePriceRuleToShopify(req, res, shopInfo);
      let discountRspt = this.database.getRepository(DiscountEntity);
      let discountData = discountRspt.create();
      discountData = {
        ...discountData,
        ...body.price_rule,
        ...priceRule,
        shopify_created_at: priceRule.created_at,
        shopify_updated_at: priceRule.updated_at,
        shop_id: shopInfo.id,
        shop_domain: session.shop,
        shopify_id: priceRule.id,
        is_bulk_discount: true,
        id: 0
      };
      let saveResult: DiscountEntity = await discountRspt.save(discountData);
      let bulkCodeSettingModel = new DiscountCodeSettingModel(this.database, this.redis);
      let bulkCodeModel = new DiscountBulkCodeModel(this.database, this.redis);
      //保存列表设置
      let codeSetting = await bulkCodeSettingModel.saveCodeSetting({
        ...body.codes_setting,
        discount_id: saveResult.id,
        shop_id: shopInfo.id,
        shopify_shop_id: shopInfo.shopify_id,
        shopify_discount_id: saveResult.shopify_id,
        shopify_domain: saveResult.shop_domain
      });
      //调用一次裂变
      bulkCodeModel.bulkCode(codeSetting['id']);
    } catch (e) {
      console.log('bulk code error======', e);
      return res.status(200).json({ code: e.code, msg: e.message });
    }
    return res.send({
      code: 200,
      msg: '',
      data: { price_rule: priceRule }
    });
  }

  private async bulkCode(req: Request, res: Response) {
    let msg = await ToolsLib.validateData(BulkCodeDto, {
      ...req.body
    });
    if (msg !== true) {
      return res.json({ code: 500, msg: msg });
    }
    let discountId = req.query.discount_id;
    if (!discountId) {
      return res.json({ code: 500, msg: 'discount id must input!' });
    }
    let discountRspt = this.database.getRepository(DiscountEntity);
    let discountInfo = await discountRspt.findOne({ where: { id: discountId }, relations: ['shop'] });
    if (!discountInfo) {
      return ToolsLib.formatErr('Not found!', 404);
    }
    let bulkCodeSettingModel = new DiscountCodeSettingModel(this.database, this.redis);
    let bulkCodeModel = new DiscountBulkCodeModel(this.database, this.redis);
    let codeSetting = await bulkCodeSettingModel.saveCodeSetting({
      ...req.body,
      discount_id: discountId,
      shop_id: discountInfo['shop_id'],
      shopify_shop_id: discountInfo.shop.shopify_id,
      shopify_discount_id: discountInfo.shopify_id
    });
    await discountRspt.save({ ...discountInfo, auto_increment_code: req.body.auto_increment_code });
    //调用一次裂变
    bulkCodeModel.bulkCode(codeSetting['id']);
    return res.send({ code: 200, msg: 'Success', data: codeSetting });
  }
  private async savePriceRuleToShopify(req: Request, res: Response, shopInfo: ShopEntity) {
    const body = req.body;
    const client = await new ShopifyApiLib(res.locals.shopify.session, req.api);
    let result: any = null;
    result = await client.apiPost({
      path: 'price_rules',
      type: DataType.JSON,
      data: {
        price_rule: {
          ...body.price_rule,
          starts_at: (dayjs as any).tz(body.price_rule.starts_at, 'UTC').tz(shopInfo['iana_timezone']).format()
        },
        ends_at: body.price_rule.ends_at ? (dayjs as any).tz(body.price_rule.ends_at, shopInfo['iana_timezone']).format() : null
      }
    });
    return result.body['price_rule'];
  }
  private async getPriceRule(req: Request, res: Response) {
    const session = res.locals.shopify.session;
    const client = new ShopifyApiLib(session, req.api);
    let result = await client.apiGet(`price_rules/${req.query.discount_id}`, {});
    return res.status(200).send(result['body']['price_rule']);
  }
}
