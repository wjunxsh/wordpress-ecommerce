import { Request, Response } from 'express';
import { Redis } from 'ioredis';
import { ShopModel } from '../../../model/shop.model';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { VariantModel } from '../../../model/variant.model';
import { ProductModel } from '../../../model/product.model';
export class BasicController extends ControllerBase {
  RedisClient: Redis;
  private shopModel: ShopModel;
  private variantModel: VariantModel;
  private productModel: ProductModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    this.shopModel = new ShopModel(this.database);
    this.variantModel = new VariantModel(this.database);
    this.productModel = new ProductModel(this.database);
    this.router.get('/api/basic/shops', this.getShops.bind(this));
    this.router.get('/api/basic/variants', this.getVariants.bind(this));
    this.router.get('/api/basic/products', this.getProducts.bind(this));
    this.router.get('/api/basic/get_product_with_variants', this.getProductsWithVariants.bind(this));
  }
  async getShops(request: Request, res: Response) {
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 100;
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const search: string = request.query.search ? `${request.query.search}` : '';
    let shopList: any = await this.shopModel.getShops({ shopify_domain: search, current_page, page_size });
    let count = await this.shopModel.getShopsCount({ shopify_domain: search });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: { list: shopList.map(item => ({ ...item, label: item.shopify_domain, value: item.id })), pagination }
    });
  }
  async getVariants(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 100;
    const search: string = request.query.search ? `${request.query.search}` : '';
    const shop_id: number = shopInfo['id'];
    let list: any = await this.variantModel.getVariants({ shop_id, search, current_page, page_size });
    let count = await this.variantModel.getVariantsCount({ shop_id, search });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: {
        list: list.map(item => ({ ...item, value: item.id, label: (item.product?.handle || '') + ':' + item.sku })),
        pagination
      }
    });
  }
  async getProducts(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 100;
    const search: string = request.query.search ? `${request.query.search}` : '';
    const shop_id: number = shopInfo['id'];
    let list: any = await this.productModel.getProducts({ shop_id, search, current_page, page_size });
    let count = await this.productModel.getProductsCount({ shop_id, search });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: { list: list.map(item => ({ title: item.title, value: item.id, label: item.handle })), pagination }
    });
  }
  async getProductsWithVariants(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 100;
    const search: string = request.query.search ? `${request.query.search}` : '';
    const shop_id: number = shopInfo['id'];
    let list: any = await this.productModel.getProductsWithVariants({ shop_id, search, current_page, page_size });
    let count = await this.productModel.getProductsWithVariantsCount({ shop_id, search });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / page_size)
    };
    return res.json({
      code: 200,
      msg: '',
      data: {
        list: list.map(product => ({
          avatar: product.images.length ? product.images[0]['src'] : '',
          title: product.title,
          id: product.shopify_id,
          handle: product.handle,
          variants: product.variants
        })),
        pagination
      }
    });
  }
}
