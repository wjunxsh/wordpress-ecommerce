import { v4 as uuidv4 } from 'uuid';
import { ToolsClass } from './interface';
import { VariantModel } from '../../../../model/variant.model';
import { ShopModel } from '../../../../model/shop.model';
import { VariantEntity } from '../../../../entity/variant.entity';
import { ShopEntity } from '../../../../entity/shop.entity';
import { ScriptDiscountMetafieldsEntity } from '../../../../entity/script/script_discount.metafields.entity';
import { ScriptProductTagEntity } from '../../../../entity/script/script_product_tag.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';

interface MultUploadItem {
  [key: string]: string;
  sku: string;
  handle: string;
}
export class QuantityLevelDiscountTools implements ToolsClass {
  public product_tag = 'quantity_level_discount';
  private shopServie: ShopModel;
  private variantModel?: VariantModel;

  constructor(shopServie: ShopModel, variantModel?: VariantModel) {
    this.shopServie = shopServie;
    this.variantModel = variantModel;
  }

  async makeDiscountData(body: any) {
    let variantsIds = this.getVariantsIds(body);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: body.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let scriptData = this.makeScriptsData(body, variantsObj);
    let scriptProductTags = this.makeProductTags(body, variantsObj);
    //组装metafields
    let shopInfo = await this.shopServie.infoByShopId(body.shop_id);
    let newMetafields = this.makeMetafields(body, variantsObj, shopInfo);

    return {
      scriptData,
      newMetafields,
      scriptProductTags
    };
  }
  getVariantsIds(body) {
    let activeRules = body.config.active_rules;
    let variantsIds = [];
    activeRules.forEach(rule => {
      rule.skus.forEach(val => {
        variantsIds.push(val.value);
      });
    });
    return variantsIds;
  }
  async covertIdToShopfyId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let activeRules = data.config.active_rules;
    activeRules.forEach(rule => {
      rule.skus.forEach(val => {
        if (variantsObj[val.value]) {
          val.value = variantsObj[val.value]['shopify_id'];
        }
      });
    });
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByShopifyIds({ shopifyIds: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['shopify_id']] = variant;
    });
    let activeRules = data.config.active_rules;
    activeRules.forEach(rule => {
      rule.skus.forEach(val => {
        if (variantsObj[val.value]) {
          if (val.key) {
            val.key = variantsObj[val.value]['id'];
          }
          val.value = variantsObj[val.value]['id'];
        }
      });
    });
    return data;
  }
  makeScriptsData(body, variantObjs) {
    let activeRules = body.config.active_rules;
    let scriptActiveRules = activeRules.map(rule => {
      return {
        skus: rule.skus.map(val => {
          try {
            return variantObjs[val.value]['sku'];
          } catch (e) {
            throw new Error(val.label + '未找到，请重新编辑');
          }
        }),
        rules: rule.rules.map(item => ({ ...item, quantity: body.config.campaign_type == 'level' ? item.quantity : 1 }))
      };
    });

    let returnData = {
      message: body.config.message,
      discount_type: body.config.discount_type,
      dc_mutex: body.config.dc_mutex ? true : false,
      mutex: body.config.mutex ? true : false,
      active_rules: scriptActiveRules
    };
    if (body.config.property_key) {
      returnData['property_key'] = body.config.property_key;
    }
    return returnData;
  }
  makeMetafields(body, variantObjs, shopInfo: ShopEntity) {
    let activeRules = body.config.active_rules;
    let metafields: ScriptDiscountMetafieldsEntity[] = [];
    let shopValues = {
      discountType: body.config.discount_type,
      labels: body.config.text_arr || [],
      products: [],
      customAttribute: body.config.property_key
    };
    activeRules.forEach(rule => {
      rule.skus.forEach(val => {
        let metafieldsValue = {
          discountType: body.config.discount_type,
          rules: rule.rules.map(item => ({
            ...item,
            quantity: body.config.campaign_type == 'level' ? item.quantity : 1
          })),
          labels: body.config.text_arr || []
        };
        shopValues['products'].push(
          rule.rules.map(item => ({
            sku: variantObjs[val['value']]['sku'],
            handle: variantObjs[val['value']]['product']['handle'],
            quantity: body.config.campaign_type == 'level' ? item.quantity : 1,
            value: body.config.discount_type == 'percentage' ? item.value / 100.0 : item.value
          }))
        );
        let metafieldsData: ScriptDiscountMetafieldsEntity = {
          uuid: uuidv4(),
          target_shopify_id: variantObjs[val['value']].shopify_id,
          target_type: 'variant',
          discount_id: 0,
          sort: 0,
          metafield_shopify_id: 0,
          is_need_delete: false,
          created_at: new Date(),
          metafield_type: 'json',
          start_sync_at: body.starts_at,
          sync_at: null,
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          //@ts-ignore
          metafield_value: JSON.stringify(metafieldsValue),
          updated_at: new Date(),
          metafield_namespace: 'qty_level',
          metafield_key: body.config.campaign_type == 'level' ? 'quantity_level_discount' : 'price_drop'
        };
        metafields.push(metafieldsData);
      });
    });
    metafields.push({
      uuid: uuidv4(),
      target_shopify_id: shopInfo['shopify_id'],
      target_type: 'shop',
      discount_id: 0,
      sort: 0,
      metafield_shopify_id: 0,
      is_need_delete: false,
      created_at: new Date(),
      metafield_type: 'json',
      start_sync_at: body.starts_at,
      sync_at: null,
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      //@ts-ignore
      metafield_value: JSON.stringify(shopValues),
      updated_at: new Date(),
      metafield_namespace: 'scriptDiscount',
      metafield_key: body.config.metafield_key ? body.config.metafield_key : 'quantity_level_discount'
    });
    return metafields;
  }
  makeProductTags(body, variantObjs) {
    let activeRules = body.config.active_rules;
    let productTags: ScriptProductTagEntity[] = [];
    activeRules.forEach(rule => {
      rule.skus.forEach(val => {
        if (productTags.some(item => item.product_shopify_id == variantObjs[val['value']]['product'].shopify_id)) {
          return true;
        }
        let productTag: ScriptProductTagEntity = {
          uuid: uuidv4(),
          product_shopify_id: variantObjs[val['value']]['product'].shopify_id,
          product_tag: this.product_tag,
          discount_id: 0,
          is_need_delete: false,
          created_at: new Date(),
          start_sync_at: body.starts_at,
          updated_at: new Date(),
          sync_at: null,
          sync_state: false
        };
        productTags.push(productTag);
      });
    });
    return productTags;
  }
  public createScriptsCode(data: any): string {
    let code = `quantity_level_discount(`;
    code += `{
  message:"${data.message}",
  discount_type:"${data.discount_type}",
  dc_mutex:${data.dc_mutex},
  mutex:${data.mutex ?? true},
  product_tag:"${this.product_tag}",
  active_rules:{\n`;
    data.active_rules.forEach(item => {
      code += `    %w[${item.skus.join(' ')}] => {${item.rules
        .map(val => `${val.quantity}=>${data.discount_type == 'percentage' ? val.value / 100 : val.value}`)
        .join(',')}},\n`;
    });
    code += `  },\n`;
    if (data.property_key) {
      code += `  property_key:"${data.property_key}" \n`;
    }
    // code += JSON.stringify(data, null, '\t');
    code += `})\n`;
    return code;
  }
  async multUpload(shop_id: number, multUploadData: MultUploadItem[]) {
    //根据handle 和 item 获取所有sku信息
    let handleSkus: { sku: string; handle: string }[] = [];
    multUploadData.forEach(item => {
      let skuArr = item.sku.split(',');
      handleSkus = handleSkus.concat(skuArr.map(sku => ({ sku, handle: item.handle })));
    });
    let variantList = await this.variantModel.getVariantsBySkuAndHandle({
      skus: handleSkus.map(item => item.sku),
      shop_id,
      handles: multUploadData.map(item => item.handle)
    });
    let notExistData = handleSkus.filter(
      item => !variantList.some(variant => variant.sku == item.sku && variant.product.handle == item.handle)
    );
    if (notExistData.length) {
      throw new Error(`the skus ${notExistData.map(item => item.sku).join(',')} don't exist!`);
    }
    let resultData: any = [];
    multUploadData.forEach(item => {
      let skuArr = item.sku.split(',');
      let skusData: { label: string; value: number }[] = [];
      skuArr.forEach(sku => {
        let variant = variantList.find(variant => variant.sku == sku && variant.product.handle == item.handle);
        skusData.push({ label: (variant.product.handle || '') + ':' + variant.sku, value: variant.id });
      });
      let keys = Object.keys(item);
      let values = keys.filter(item => item.startsWith('value'));
      let minPurchaseQty = keys.filter(item => item.startsWith('min_purchase_quantity'));
      let levelData: { quantity: string; value: string }[] = [];
      for (let i = 0, count = minPurchaseQty.length; i < count; i++) {
        if (minPurchaseQty[i] && values[i]) {
          levelData.push({ quantity: item[minPurchaseQty[i]], value: item[values[i]] });
        }
      }
      resultData.push({ skus: skusData, rules: levelData });
    });
    return resultData;
  }
}
