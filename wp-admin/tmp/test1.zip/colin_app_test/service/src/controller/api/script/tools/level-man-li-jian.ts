import { ToolsClass } from './interface';
import { VariantModel } from '../../../../model/variant.model';
import { VariantEntity } from '../../../../entity/variant.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';
import { ScriptDiscountMetafieldsEntity } from '../../../../entity/script/script_discount.metafields.entity';
import { v4 as uuidv4 } from 'uuid';
import { ShopModel } from '../../../../model/shop.model';
import { ShopEntity } from '../../../../entity/shop.entity';
interface MultUploadItem {
  sku: string;
  handle: string;
}
export class LevelMainLiJianTools implements ToolsClass {
  public product_tag = 'level_main_li_jian';
  variantModel?: VariantModel;
  private shopService: ShopModel;
  constructor(shopService: ShopModel, variantModel: VariantModel) {
    this.shopService = shopService;
    this.variantModel = variantModel;
  }
  async makeDiscountData(body: any) {
    try {
      let variantsIds = this.getVariantsIds(body);
      let variants: VariantEntity[] = [];
      if (variantsIds.length) {
        variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: body.shop_id });
      }
      let variantsObj = {};
      variants.forEach(variant => {
        variantsObj[variant['id']] = variant;
      });
      let scriptData = this.makeScriptsData(body, variantsObj);
      let shopInfo = await this.shopService.infoByShopId(body.shop_id);
      let newMetafields = this.makeMetafields(body, variantsObj, shopInfo);
      return {
        scriptData,
        newMetafields: newMetafields,
        scriptProductTags: []
      };
    } catch (e) {
      console.log(e);
    }
  }
  getVariantsIds(body) {
    let bundleConfig = body.config;
    let variantsIds = bundleConfig.exclude_skus ? bundleConfig.exclude_skus.map(item => item.value) : [];
    return variantsIds;
  }
  async covertIdToShopfyId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let bundleConfig = data.config;
    bundleConfig.exclude_skus.forEach(item => {
      if (variantsObj[item.value]) {
        item.value = variantsObj[item.value]['shopify_id'];
      }
    });
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByShopifyIds({ shopifyIds: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['shopify_id']] = variant;
    });
    let bundleConfig = data.config;
    bundleConfig.exclude_skus &&
      bundleConfig.exclude_skus.forEach(item => {
        if (variantsObj[item.value]) {
          if (item.key) {
            item.key = variantsObj[item.value]['id'];
          }
          item.value = variantsObj[item.value]['id'];
        }
      });
    return data;
  }
  makeScriptsData(body, variantsObj) {
    let bundleConfig = body.config;
    let discountRule = bundleConfig.discount_rule;
    if (discountRule.length > 1) {
      discountRule = discountRule.sort((a, b) => b.money - a.money);
    }
    let exclude_skus = bundleConfig.exclude_skus ? bundleConfig.exclude_skus.map(item => variantsObj[item.value].sku) : [];
    let returnData = {
      message: body.config.message,
      discount_type: body.config.discount_type,
      dc_mutex: body.config.dc_mutex ? true : false,
      exclude_skus,
      property_key: body.config.property_key || null,
      min_buy_qty: body.config.min_buy_qty || 1,
      limit_product_tag: bundleConfig.limit_product_tag || null,
      discount_rule: discountRule
    };
    return returnData;
  }
  makeMetafields(body: any, variantsObj: any, shopInfo: ShopEntity) {
    let bundleConfig = body.config;
    let discountRule = bundleConfig.discount_rule;
    if (discountRule.length > 1) {
      discountRule = discountRule.sort((a, b) => b.money - a.money);
    }
    if (!bundleConfig.exclude_skus?.length) {
      return [];
    }
    let exclude_skus = bundleConfig.exclude_skus ? bundleConfig.exclude_skus.map(item => variantsObj[item.value].sku) : [];
    let metafieldsData: ScriptDiscountMetafieldsEntity = {
      uuid: uuidv4(),
      sort: 0,
      target_shopify_id: shopInfo['shopify_id'],
      target_type: 'shop',
      discount_id: 0,
      metafield_shopify_id: 0,
      is_need_delete: false,
      created_at: new Date(),
      metafield_type: 'json',
      updated_at: new Date(),
      start_sync_at: body.starts_at,
      sync_at: null,
      metafield_value: JSON.stringify({
        excludeSkus: exclude_skus
      }),
      metafield_namespace: 'scriptDiscount',
      metafield_key: body.config.metafield_key ? body.config.metafield_key : 'level-man-li-jian'
    };
    return [metafieldsData];
  }
  makeProductTags() {
    return [];
  }
  public createScriptsCode(data: any): string {
    let code = `level_man_li_jian({
  message:"${data.message}",
  dc_mutex:${data.dc_mutex},
  discount_type:"${data.discount_type}",
  min_buy_qty:${data.min_buy_qty},
  limit_product_tag: ${data.limit_product_tag ? `"${data.limit_product_tag}"` : 'nil'},
  discount_rule:{${data.discount_rule.map(rule => `${rule.money} => ${rule.value}`).join(',')}},\n`;
    if (data.exclude_skus.length) {
      code += `  exclude_skus:["${data.exclude_skus.join('","')}"],\n`;
    }
    if (data.property_key) {
      code += `property_key:"${data.property_key}", \n`;
    }
    code += `})\n`;
    return code;
  }
  async multUpload(shop_id: number, multUploadData: MultUploadItem[]) {
    //根据handle 和 item 获取所有sku信息
    let variantList = await this.variantModel.getVariantsBySkuAndHandle({
      skus: multUploadData.map(item => item.sku),
      shop_id,
      handles: multUploadData.map(item => item.handle)
    });
    let notExistData = multUploadData.filter(
      item => !variantList.some(variant => variant.sku == item.sku && variant.product.handle == item.handle)
    );
    if (notExistData.length) {
      throw new Error(`the skus ${notExistData.map(item => item.sku).join(',')} don't exist!`);
    }
    return variantList
      .filter(variant => multUploadData.some(item => item.sku == variant.sku && item.handle == variant.product.handle))
      .map(item => ({ sku: item.sku, label: item.product.handle || '' + ':' + item.sku, value: item.id }));
  }
}
