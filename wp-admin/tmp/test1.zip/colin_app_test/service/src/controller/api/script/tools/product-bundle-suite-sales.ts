import { v4 as uuidv4 } from 'uuid';
import { ToolsClass } from './interface';
import { ProductModel } from '../../../../model/product.model';
import { ProductEntity } from '../../../../entity/product.entity';
import { ScriptDiscountMetafieldsEntity } from '../../../../entity/script/script_discount.metafields.entity';
import { ScriptProductTagEntity } from '../../../../entity/script/script_product_tag.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';
import { VariantEntity } from '../../../../entity/variant.entity';
import { VariantModel } from '../../../../model/variant.model';

export class ProductBundleSuitesalesTools implements ToolsClass {
  public product_tag = 'product_bnndle_suite_sales';
  private productService: ProductModel;
  private varintService: VariantModel;
  constructor(productService: ProductModel, varintService: VariantModel) {
    this.productService = productService;
    this.varintService = varintService;
  }

  async makeDiscountData(body: any) {
    let prodcutIds = this.getProductsIds(body);
    let products: ProductEntity[] = [];
    if (prodcutIds.length) {
      products = await this.productService.getPruductByIds({ ids: prodcutIds, shop_id: body.shop_id });
    }
    let productObjs = {};
    products.forEach(prodcut => {
      productObjs[prodcut['id']] = prodcut;
    });
    let scriptData: any = this.makeScriptsData(body, productObjs);
    let scriptProductTags = this.makeProductTags(body, productObjs);
    //组装metafields
    let newMetafields = this.makeMetafields(body, productObjs);

    return {
      scriptData,
      newMetafields,
      scriptProductTags
    };
  }
  getVariantsIds(body) {
    let bundleConfig = body.config.bundle_config;
    let variantIds = [];
    bundleConfig.forEach(rule => {
      rule.productList.map(item => {
        item.show_sku && variantIds.push(item.show_sku.value);
      });
    });
    return variantIds;
  }
  getProductsIds(body) {
    let bundleConfig = body.config.bundle_config;
    let productIds = [];
    bundleConfig.forEach(rule => {
      rule.productList.map(item => {
        productIds.push(item.product.value);
      });
    });
    return productIds;
  }
  async covertIdToShopfyId(data: ScriptDiscountEntity) {
    let productsIds = this.getProductsIds(data);
    let variantIds = this.getVariantsIds(data);
    let products: ProductEntity[] = [];
    let variants: VariantEntity[] = [];
    if (productsIds.length) {
      products = await this.productService.getPruductByIds({ ids: productsIds, shop_id: data.shop_id });
    }
    if (variantIds.length) {
      variants = await this.varintService.getVariantsByIds({ ids: variantIds, shop_id: data.shop_id });
    }
    let productsObj = {};
    products.forEach(product => {
      productsObj[product['id']] = product;
    });
    let variantObjs = {};
    variants.forEach(variant => {
      variantObjs[variant['id']] = variant;
    });
    let bundleConfig = data.config.bundle_config;
    bundleConfig.forEach(rule => {
      rule.productList.forEach(item => {
        if (productsObj[item.product.value]) {
          item.product.value = productsObj[item.product.value]['shopify_id'];
        }
        if (item.show_sku && variantObjs[item.show_sku.value]) {
          item.show_sku.value = variantObjs[item.show_sku.value]['shopify_id'];
        }
      });
    });
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    let productsIds = this.getProductsIds(data);
    let variantIds = this.getVariantsIds(data);
    let products: ProductEntity[] = [];
    let variants: VariantEntity[] = [];
    if (productsIds.length) {
      products = await this.productService.getListByShopifyIds(productsIds);
    }
    if (variantIds.length) {
      variants = await this.varintService.getVariantsByShopifyIds({ shopifyIds: variantIds, shop_id: data.shop_id });
    }
    let productsObj = {};
    products.forEach(product => {
      productsObj[product['shopify_id']] = product;
    });
    let variantObjs = {};
    variants.forEach(variant => {
      variantObjs[variant['shopify_id']] = variant;
    });
    let bundleConfig = data.config.bundle_config;
    bundleConfig.forEach(rule => {
      rule.productList.forEach(item => {
        if (productsObj[item.product.value]) {
          if (item.product.key) {
            item.product.key = productsObj[item.product.value]['id'];
          }
          item.product.value = productsObj[item.product.value]['id'];
        }
        if (item.show_sku && variantObjs[item.show_sku.value]) {
          if (item.show_sku.key) {
            item.show_sku.key = variantObjs[item.show_sku.value]['id'];
          }
          item.show_sku.value = variantObjs[item.show_sku.value]['id'];
        }
      });
    });
    return data;
  }

  makeScriptsData(body, productObjs) {
    let bundleConfig = body.config.bundle_config;
    let bundleConfigs = bundleConfig.map(rule => {
      let productIds = [];
      rule.productList.map(item => {
        productIds.push(productObjs[item.product.value].shopify_id);
      });
      return { price: rule.price, product: productIds };
    });
    let returnData = {
      message: body.config.message,
      discount_type: body.config.discount_type,
      dc_mutex: body.config.dc_mutex ?? true,
      bundle_config: bundleConfigs,
      labels: body.config.text_arr || []
    };
    if (body.config.property_key) {
      returnData['property_key'] = body.config.property_key;
    }
    return returnData;
  }
  makeMetafields(body, productObjs) {
    let bundleConfig = body.config.bundle_config;
    let metafields: ScriptDiscountMetafieldsEntity[] = [];
    for (let id in productObjs) {
      let ruleList: any[] = [];
      bundleConfig.forEach(rule => {
        let item = rule.productList.find(item => item.product.value == id);
        if (!item) return;
        ruleList.push({
          save: Math.round((1 - rule.price / 100) * 100) / 100.0,
          displayName: `${productObjs[id].title} ${item.display}`,
          products: rule.productList.map(item => {
            if (item.show_sku && !productObjs[item.product.value].variants.some(val => val.id == item.show_sku.value)) {
              console.log(productObjs[item.product.value].variants, item);
              throw new Error(
                `There is no  variant of ${item.show_sku.label} in product ${productObjs[item.product.value].handle} `
              );
            }
            return `${productObjs[item.product.value].handle},${
              item.show_sku
                ? productObjs[item.product.value].variants.find(val => val.id == item.show_sku.value)['sku']
                : productObjs[item.product.value].variants[0]['sku']
            },1`;
          }),
          tag: rule.tag ? rule.tag.split(',') : [],
          saveText: `${rule.price}% Off`
        });
      });
      let metafieldsValue = {
        combinations: ruleList,
        labels: body.config.text_arr || []
      };
      let metafieldsData: ScriptDiscountMetafieldsEntity = {
        uuid: uuidv4(),
        target_shopify_id: productObjs[id].shopify_id,
        target_type: 'product',
        discount_id: 0,
        sort: 0,
        metafield_shopify_id: 0,
        is_need_delete: false,
        created_at: new Date(),
        updated_at: new Date(),
        metafield_type: 'json',
        start_sync_at: body.starts_at,
        sync_at: null,
        metafield_value: JSON.stringify(metafieldsValue),
        metafield_namespace: 'product_bundle',
        metafield_key: 'product_bundle_suite_sales'
      };
      metafields.push(metafieldsData);
    }
    return metafields;
  }

  public makeProductTags(body, productObjs) {
    let productTags: ScriptProductTagEntity[] = [];
    for (let id in productObjs) {
      if (productTags.some(item => item.product_shopify_id == productObjs[id].shopify_id)) {
        continue;
      }
      let productTag: ScriptProductTagEntity = {
        uuid: uuidv4(),
        product_shopify_id: productObjs[id].shopify_id,
        product_tag: this.product_tag,
        discount_id: 0,
        is_need_delete: false,
        updated_at: new Date(),
        created_at: new Date(),
        start_sync_at: body.starts_at,
        sync_at: null,
        sync_state: false
      };
      productTags.push(productTag);
    }
    return productTags;
  }
  public createScriptsCode(data: any): string {
    console.log(data.bundle_config);
    let code = `product_bundle_sales(`;
    code += `{
  message:"${data.message}",
  discount_type:"${data.discount_type}",
  dc_mutex:${data.dc_mutex},
  product_tag:"${this.product_tag}",
  bundle_config:[\n`;
    for (let i = 0, count = data.bundle_config.length; i < count; i++) {
      let item = data.bundle_config[i];
      code += `   [${item.price},%w[${item.product.join(' ')}]],\n`;
    }
    code += ` ],
`;
    if (data.property_key) {
      code += ` property_key:"${data.property_key}" \n`;
    }
    code += `})\n`;
    return code;
  }
}
