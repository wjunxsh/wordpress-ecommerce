import { ToolsClass } from './interface';
import { VariantModel } from '../../../../model/variant.model';
import { VariantEntity } from '../../../../entity/variant.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';

export class BuyMoreThanOneDiscount implements ToolsClass {
  public product_tag = 'buy_more_than_one_discount';
  variantModel?: VariantModel;
  constructor(variantModel: VariantModel) {
    this.variantModel = variantModel;
  }
  async makeDiscountData(body: any) {
    let variantsIds = this.getVariantsIds(body);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: body.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let scriptData = this.makeScriptsData(body, variantsObj);
    return {
      scriptData,
      newMetafields: [],
      scriptProductTags: []
    };
  }
  getVariantsIds(body) {
    let bundleConfig = body.config;
    let variantsIds = bundleConfig.limit_skus ? bundleConfig.limit_skus.map(item => item.value) : [];
    return variantsIds;
  }
  async covertIdToShopfyId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let bundleConfig = data.config;
    bundleConfig.limit_skus &&
      bundleConfig.limit_skus.forEach(item => {
        if (variantsObj[item.value]) {
          item.value = variantsObj[item.value]['shopify_id'];
        }
      });
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByShopifyIds({ shopifyIds: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['shopify_id']] = variant;
    });
    let bundleConfig = data.config;
    bundleConfig.limit_skus &&
      bundleConfig.limit_skus.forEach(item => {
        if (variantsObj[item.value]) {
          if (item.key) {
            item.key = variantsObj[item.value]['id'];
          }
          item.value = variantsObj[item.value]['id'];
        }
      });
    return data;
  }
  makeScriptsData(body, variantsObj) {
    let bundleConfig = body.config;
    let limit_skus = bundleConfig.limit_skus ? bundleConfig.limit_skus.map(item => variantsObj[item.value].sku) : [];
    let returnData = {
      message: body.config.message,
      discount_type: body.config.discount_type,
      dc_mutex: body.config.dc_mutex ? true : false,
      mutex: body.config.mutex ? true : false,
      promise_repeat: body.config.promise_repeat ? true : false,
      limit_skus,
      property_key: body.config.property_key || null,
      min_buy_qty: body.config.min_buy_qty || 1,
      limit_product_tag: bundleConfig.limit_product_tag || null,
      discount_value: bundleConfig.discount_value,
      discount_amount: bundleConfig.discount_amount
    };
    return returnData;
  }
  makeMetafields() {
    return [];
  }
  makeProductTags() {
    return [];
  }
  public createScriptsCode(data: any): string {
    let code = `buy_more_than_one_discount_price({
  message:"${data.message}",
  dc_mutex:${data.dc_mutex},
  promise_repeat:${data.promise_repeat || false},
  mutex:${data.mutex ?? true},
  min_buy_qty:${data.min_buy_qty},
  limit_product_tag: ${data.limit_product_tag ? `"${data.limit_product_tag}"` : 'nil'},
  discount_value:${data.discount_value},
  discount_type:"${data.discount_type}",\n`;
    if (data.limit_skus.length) {
      code += `  limit_skus:["${data.limit_skus.join('","')}"],\n`;
    }
    if (data.property_key) {
      code += `property_key:"${data.property_key}", \n`;
    }
    code += `})\n`;
    return code;
  }
  async multUpload(data: any) {
    return data;
  }
}
