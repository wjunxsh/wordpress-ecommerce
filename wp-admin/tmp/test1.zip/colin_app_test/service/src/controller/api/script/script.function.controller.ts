import { Request, Response } from 'express';
import { ShopModel } from '../../../model/shop.model';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import dayjs from 'dayjs';
import { FunctionModel } from '../../../model/script/script-function.model';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ScriptFunctionEntity } from '../../../entity/script/script_function.entity';
dayjs.extend(utc);
dayjs.extend(timezone);
export class ScriptFunctionsController extends ControllerBase {
  shopModel: ShopModel;
  functionService: FunctionModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    // this.router.get("/api/bulk/code/test", this.test.bind(this));
    this.shopModel = new ShopModel(bootstrap.database);
    this.functionService = new FunctionModel(bootstrap.database);
    this.router.get('/api/functions/list', this.list.bind(this));
    this.router.post('/api/functions/save', this.save.bind(this));
  }

  async list(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 30;
    const title: string = request.query.title ? `${request.query.title}` : '';
    const code_type: string = request.query.code_type ? `${request.query.code_type}` : '';

    let functionList: any = await this.functionService.getFunctionList({
      shop_id: shopInfo['id'],
      code_type,
      title,
      current_page,
      page_size
    });
    let count = await this.functionService.getFunctionCount({ shop_id: shopInfo['id'], title, code_type });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: { list: functionList.map(item => ({ ...item, value: item.function_key, label: item.title })), pagination }
    });
  }
  async save(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    let body: ScriptFunctionEntity = request.body;
    if (body.code_type === 'shop_self') {
      body.shop_id = shopInfo['id'];
    }
    try {
      if (!body.id) {
        await this.functionService.create(body);
      } else {
        await this.functionService.update(body);
      }
      return res.status(200).json({ code: 200, msg: '', data: '' });
    } catch (e) {
      return res.status(200).json({ code: 404, msg: 'not Found!', data: '' });
    }
  }
}
