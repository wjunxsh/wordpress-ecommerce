import { v4 as uuidv4 } from 'uuid';
import { ToolsClass } from './interface';
import { VariantModel } from '../../../../model/variant.model';
import { VariantEntity } from '../../../../entity/variant.entity';
import { ScriptDiscountMetafieldsEntity } from '../../../../entity/script/script_discount.metafields.entity';
import { ScriptProductTagEntity } from '../../../../entity/script/script_product_tag.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';
export class BuyMainSendGift implements ToolsClass {
  public product_tag = 'buy_main_send_gift';
  variantModel?: VariantModel;
  constructor(variantModel: VariantModel) {
    this.variantModel = variantModel;
  }

  async makeDiscountData(body: any) {
    let variantsIds = this.getVariantsIds(body);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: body.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let scriptData = this.makeScriptsData(body, variantsObj);
    let scriptProductTags = this.makeProductTags(body, variantsObj);
    //组装metafields
    let newMetafields = this.makeMetafields(body, variantsObj);

    return {
      scriptData,
      newMetafields,
      scriptProductTags
    };
  }
  async covertIdToShopfyId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let activeRules = data.config.active_rules;
    activeRules.forEach(rule => {
      rule.main_sku.forEach(val => {
        if (variantsObj[val['value']]) {
          val['value'] = variantsObj[val['value']]['shopify_id'];
          if (val['key']) {
            val['key'] = variantsObj[val['value']]['shopify_id'];
          }
        }
      });
      rule.gift_rules.forEach(gift => {
        gift.sku.forEach(val => {
          if (variantsObj[val['value']]) {
            val['value'] = variantsObj[val['value']]['shopify_id'];
            if (val['key']) {
              val['key'] = variantsObj[val['value']]['shopify_id'];
            }
          }
        });
      });
    });
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByShopifyIds({ shopifyIds: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['shopify_id']] = variant;
    });
    let activeRules = data.config.active_rules;
    activeRules.forEach(rule => {
      rule.main_sku.forEach(val => {
        if (variantsObj[val['value']]) {
          if (val['key']) {
            val['key'] = variantsObj[val['value']]['id'];
          }
          val['value'] = variantsObj[val['value']]['id'];
        }
      });
      rule.gift_rules.forEach(gift => {
        gift.sku.forEach(val => {
          if (variantsObj[val['value']]) {
            if (val['key']) {
              val['key'] = variantsObj[val['value']]['id'];
            }
            val['value'] = variantsObj[val['value']]['id'];
          }
        });
      });
    });
    return data;
  }
  getVariantsIds(body) {
    let activeRules = body.config.active_rules;
    let variantsIds = [];
    activeRules.forEach(rule => {
      rule.main_sku.forEach(val => {
        variantsIds.push(val.value);
      });
      rule.gift_rules.forEach(giftRule => {
        giftRule.sku.forEach(item => {
          variantsIds.push(item.value);
        });
      });
    });
    return variantsIds;
  }
  makeScriptsData(body, variantsObj) {
    let activeRules = body.config.active_rules;
    let scriptActiveRules = activeRules.map(rule => {
      return {
        main_sku: rule.main_sku.map(val => {
          if (!variantsObj[val.value]) {
            throw new Error(`Sku ${val.label} is not found!`);
          }
          return variantsObj[val.value].sku;
        }),
        gift_rules: rule.gift_rules.map(gift => {
          return {
            qty: 1,
            discount_value: body.config.campaign_type == 'gift' ? 0 : gift.discount_value,
            sku: gift.sku.map(item => {
              if (!variantsObj[item.value]) {
                throw new Error(`Sku ${item.label} is not found!`);
              }
              return variantsObj[item.value].sku;
            })
          };
        })
      };
    });
    let returnData = {
      message: body.config.message,
      discount_type: body.config.campaign_type == 'gift' ? 'fix_amount' : body.config.discount_type,
      dc_mutex: body.config.dc_mutex ? true : false,
      mutex: body.config.mutex ? true : false,
      active_rules: scriptActiveRules,
      is_level_send: body.config.is_level_send ? true : false
    };
    if (body.config.property_key) {
      returnData['property_key'] = body.config.property_key;
    }
    return returnData;
  }
  makeMetafields(body, variantObjs) {
    let activeRules = body.config.active_rules;
    let metafields: ScriptDiscountMetafieldsEntity[] = [];
    activeRules.forEach(rule => {
      rule.main_sku.forEach(val => {
        console.log(val);
        let giftList = [];
        rule.gift_rules.forEach(gift => {
          if (body.config.campaign_type == 'gift') {
            gift['discount_value'] = 0;
          }
          gift.sku.forEach(val => {
            giftList.push({
              handle: variantObjs[val['value']]['product']['handle'],
              sku: variantObjs[val['value']].sku,
              discountValue: body.config.discount_type == 'percentage' ? gift.discount_value / 100.0 : gift.discount_value,
              label: gift.label ?? ''
            });
          });
        });
        let metafieldsValue = {
          count: body.config.is_level_send ? 1 : giftList.length,
          list: giftList,
          discountType: body.config.discount_type,
          title: body.title,
          property: body.config.property_key,
          showDiscounts: body.config.dc_mutex ? false : true,
          labels: body.config.text_arr || []
        };
        let metafieldsData: ScriptDiscountMetafieldsEntity = {
          uuid: uuidv4(),
          sort: 0,
          target_shopify_id: variantObjs[val['value']].shopify_id,
          target_type: 'variant',
          discount_id: 0,
          metafield_shopify_id: 0,
          is_need_delete: false,
          created_at: new Date(),
          metafield_type: 'json',
          updated_at: new Date(),
          start_sync_at: body.starts_at,
          sync_at: null,
          metafield_value: JSON.stringify(metafieldsValue),
          metafield_namespace: body.config.campaign_type == 'gift' ? 'free_gift' : 'scriptDiscount',
          metafield_key: body.config.campaign_type == 'gift' ? 'freeGift' : 'exchangePurchase'
        };
        metafields.push(metafieldsData);
      });
    });
    return metafields;
  }
  public makeProductTags(body, variantObjs) {
    let activeRules = body.config.active_rules;
    let productTags: ScriptProductTagEntity[] = [];
    activeRules.forEach(rule => {
      rule.main_sku.forEach(val => {
        if (productTags.some(item => item.product_shopify_id == variantObjs[val['value']]['product'].shopify_id)) {
          return true;
        }
        let productTag: ScriptProductTagEntity = {
          uuid: uuidv4(),
          product_shopify_id: variantObjs[val['value']]['product'].shopify_id,
          product_tag: this.product_tag,
          discount_id: 0,
          is_need_delete: false,
          created_at: new Date(),
          updated_at: new Date(),
          start_sync_at: body.starts_at,
          sync_at: null,
          sync_state: false
        };
        productTags.push(productTag);
      });
    });
    return productTags;
  }
  public createScriptsCode(data: any): string {
    let code = `main_mult_send_gift({
  message:"${data.message}",
  discount_type:"${data.discount_type}",
  dc_mutex:${data.dc_mutex},
  is_level_send:${data.is_level_send},
  product_tag:"${this.product_tag}",
  mutex:${data.mutex ?? true},
  active_rules:[\n`;
    data.active_rules.forEach(item => {
      code += `    {main_sku:["${item.main_sku.join('","')}"],gift_rules:[`;
      item.gift_rules.forEach(val => {
        code += `{sku:["${val.sku.join('","')}"],discount_value:${val.discount_value || 0}},`;
      });
      code += `]},\n`;
    });
    code += `   ],\n`;
    if (data.property_key) {
      code += `   property_key:"${data.property_key}" \n`;
    }
    // code += JSON.stringify(data, null, '\t');
    code += `})\n`;
    return code;
  }
}
