import { DiscountController } from './discount/discount.controller';
import { DiscountBulkCodeController } from './discount/discount.bulk.code.controller';
import { EdmToolsController } from './discount/edm.tools.controller';
import { EmailToolsController } from './discount/email.tools.controller';
import { WebhooksController } from './webhooks';
import { ScriptFunctionsController } from './script/script.function.controller';
import { ControllerBaseInterface } from '../controllerBasic';
import { ShopifyAuthController } from './auth';
import { ApiMiddlewareController } from '../../middleware/ApiMiddleware';
import { ScriptDiscountController } from './script/scripts-discount.controller';
import { BasicController } from './basic/basic.controller';
import { ScriptDiscountLogController } from './script/scripts-discount-log.controller';

export const apiInit = async (bootstrap: ControllerBaseInterface) => {
  let authControllers = [WebhooksController, ShopifyAuthController, ApiMiddlewareController];
  for (let controller of authControllers) {
    await new controller({
      ...bootstrap
    });
  }
  let apiControllers = [
    ScriptFunctionsController,
    ScriptDiscountController,
    DiscountBulkCodeController,
    DiscountController,
    EdmToolsController,
    EmailToolsController,
    BasicController,
    ScriptDiscountLogController
  ];
  for (let controller of apiControllers) {
    await new controller({
      ...bootstrap
    });
  }
};
