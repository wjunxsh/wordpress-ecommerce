import { ShopModel } from '../../../model/shop.model';
import { Request, Response } from 'express';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
dayjs.extend(utc);
dayjs.extend(timezone);
import { EdmConfigModel } from '../../../model/edm.config.model';
import { EdmConfigEntity } from '../../../entity/edm.config.entity';
import { EdmSendRecordsEntity } from '../../../entity/edm.send.records.entity';
import { ResponsysLib, TriggerEmailOptions } from '../../../lib/responsys.lib';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import multer from 'multer';
import xlsx from 'node-xlsx';
let upload = multer();
export class EdmToolsController extends ControllerBase {
  public shopModel: ShopModel;
  public edmConfigModel: EdmConfigModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    this.shopModel = new ShopModel(bootstrap.database);
    this.edmConfigModel = new EdmConfigModel(bootstrap.database, this.redis);
    this.router.get('/api/edm-config/list', this.edmConfigList.bind(this));
    this.router.post('/api/edm-config/verify', this.verifyConfig.bind(this));
    this.router.get('/api/edm-config/record_list', this.edmRecordList.bind(this));
    this.router.post('/api/edm-config/send_email', this.sendEmail.bind(this));
    this.router.post('/api/edm-config/config_save', upload.single('file'), this.edmConfigSave.bind(this));
  }
  async edmConfigList(req: Request, res: Response) {
    let query = req.query;
    let currentPage: number = parseInt((query.current_page ?? '1') as string);
    let pageSize: number = parseInt((query.page_size ?? '50') as string);
    let search = query.search ?? '';
    let shopInfo = await new ShopModel(this.database).getShopByShopDomain(res.locals.shopify.session.shop);
    let list = await this.edmConfigModel.getList({
      currentPage,
      pageSize,
      search,
      shop_id: shopInfo['id']
    });
    let count = await this.edmConfigModel.getCount({ search, shop_id: shopInfo['id'] });
    let totalPages = Math.ceil(count / pageSize);

    return res.status(200).send({
      code: 200,
      msg: '',
      data: {
        shop: {
          iana_timezone: shopInfo['iana_timezone'],
          shopify_domain: shopInfo['shopify_domain'],
          id: shopInfo['id'],
          shopify_id: shopInfo['shopify_id']
        },
        list: list.map(item => ({
          ...item,
          starts_at: dayjs(item.starts_at).tz(shopInfo['iana_timezone']).format('YYYY-MM-DD HH:mm:ss')
        })),
        pagination: {
          current_page: currentPage,
          page_size: pageSize,
          total_pages: totalPages,
          total_size: count
        }
      }
    });
  }
  async verifyConfig(req: Request, res: Response) {
    let id = req.body.id;
    let configInfo = await this.edmConfigModel.getInfoById(id);
    if (configInfo.is_verify && (configInfo.is_send_all || dayjs().isAfter(dayjs(configInfo['starts_at'])))) {
      return res.status(200).send({ code: 500, msg: `已经开始发送 或者已经发送完毕不允许弃审!` });
    }
    if (!configInfo) {
      return res.status(200).send({ code: 404, msg: `Not found` });
    }
    try {
      await this.edmConfigModel.createOrSave({
        ...configInfo,
        is_verify: !configInfo.is_verify
      });
    } catch (e) {
      console.log(e);
    }
    return res.status(200).send({ code: 200, msg: '' });
  }
  async edmRecordList(req: Request, res: Response) {
    let edmConfigId = req.query.edm_config_id;
    let query = req.query;
    let currentPage: number = parseInt((query.current_page ?? '1') as string);
    let pageSize: number = parseInt((query.page_size ?? '50') as string);
    let list = await this.edmConfigModel.getRecordList({
      currentPage,
      pageSize,
      edm_config_id: edmConfigId
    });
    let count = await this.edmConfigModel.getRecordCount({
      edm_config_id: edmConfigId
    });
    let shopInfo = await new ShopModel(this.database).getShopByShopDomain(res.locals.shopify.session.shop);
    //获取店铺信息
    let totalPages = Math.ceil(count / pageSize);
    return res.status(200).send({
      code: 200,
      msg: '',
      data: {
        list: list.map(record => ({
          ...record,
          send_time: record.send_time
            ? dayjs(record.send_time).tz(shopInfo['iana_timezone']).format('YYYY-MM-DD HH:mm:ss')
            : null
        })),
        pagination: {
          current_page: currentPage,
          page_size: pageSize,
          total_pages: totalPages,
          total_size: count
        }
      }
    });
  }
  async edmConfigSave(req: Request, res: Response) {
    let body = req.body;
    let configInfo = new EdmConfigEntity();
    let shopInfo = await new ShopModel(this.database).getShopByShopDomain(res.locals.shopify.session.shop);
    if (body.id) {
      //允许修改时间
      configInfo = await this.edmConfigModel.getInfoById(body.id);
      if (!configInfo) {
        return res.status(200).send({ code: 404, msg: `Not found` });
      }
    }
    configInfo['starts_at'] = dayjs.tz(body.starts_at, shopInfo['iana_timezone']).tz('UTC').toDate();
    configInfo['is_verify'] = false;
    configInfo['details'] = body.details;
    configInfo['title'] = body.title;
    configInfo['edm_template'] = body.edm_template;
    configInfo['is_send_all'] = false;
    configInfo['shop_id'] = shopInfo['id'];
    let edmSendRecordRspt = this.database.getRepository(EdmSendRecordsEntity);
    let records: EdmSendRecordsEntity[] = [];
    if (!body.id) {
      configInfo['price_rule_id'] = body.price_rule_id || null;
      configInfo['price_rule_title'] = body.price_rule_title;
      configInfo['is_ready'] = configInfo['price_rule_id'] ? false : true;
      let data = this.analysisExcelData(req.file.buffer);
      if (!data.length) {
        return res.status(200).send({
          code: 404,
          msg: 'excel是没有数据或者数据异常请检查您的excel文件'
        });
      }
      let fields = Object.keys(data[0]);
      let mustFields = ['email'];
      for (let i = 0, count = mustFields.length; i < count; i++) {
        if (!fields.includes(mustFields[i])) {
          return res.status(200).send({ code: 404, msg: `表头${mustFields[i]}未找到!` });
        }
      }
      for (let i = 0, count = data.length; i < count; i++) {
        let record = new EdmSendRecordsEntity();
        record['email'] = data[i]['email'].trim();
        record['is_send'] = false;
        record['edm_template'] = configInfo['edm_template'];
        if (data[i]['edm_params']) {
          record['extend'] = JSON.parse(data[i]['edm_params']) || null;
        }
        records.push(record);
      }
    }
    try {
      let info = await this.edmConfigModel.createOrSave(configInfo);
      records.forEach(item => (item.edm_config_id = info['id']));
      records.length && (await edmSendRecordRspt.save(records));
      //更新edm
      if (body.id) {
        await edmSendRecordRspt.update(
          { edm_template: body.edm_template, is_send: false, send_time: null },
          { edm_config_id: body.id }
        );
      }
      this.edmConfigModel.bindCode(info['id']);
    } catch (e) {
      console.log(e);
      return res.status(500).send({ code: 500, msg: e.message });
    }

    return res.status(200).send({ code: 200, msg: '' });
  }
  async sendEmail(req: Request, res: Response) {
    let body = req.body;
    let recordInfo = await this.edmConfigModel.getRecordInfoById(body.id);
    if (!recordInfo) {
      return res.status(200).send({ code: 404, msg: `Not found` });
    }
    let responsysLib = new ResponsysLib();
    let options: TriggerEmailOptions = [];
    if (recordInfo['code']) {
      options = [{ name: 'code_content', value: recordInfo['code'] }];
    }
    if (recordInfo['extend']) {
      options = [...options, ...recordInfo['extend']];
    }
    let edmSendRecordRspt = this.database.getRepository(EdmSendRecordsEntity);
    try {
      await responsysLib.triggerEmail(recordInfo['edm_template'], recordInfo.email, options);
      await edmSendRecordRspt.save({
        ...recordInfo,
        is_send: true,
        send_error: null,
        send_time: dayjs().toDate()
      });
    } catch (e) {
      await edmSendRecordRspt.save({ ...recordInfo, send_error: e.message });
    }
    return res.status(200).send({ code: 200, msg: `Success` });
  }
  analysisExcelData(buffer: Buffer) {
    let workbook = xlsx.parse(buffer, { cellDates: true });
    let data: any[] = [];
    let sheet = workbook[0];
    let fields = sheet['data'][0];
    sheet['data'].forEach((item, index) => {
      if (index == 0) return;
      let itemVal: any = {};
      //之所以用for 是因为如果字段为空用forEach就不会遍历到
      if (!item[0] && !item[1]) {
        return true;
      }
      for (let i = 0; i < item.length; i++) {
        itemVal[fields[i]] = item[i];
      }
      data.push({ ...itemVal });
    });
    return data;
  }
}
