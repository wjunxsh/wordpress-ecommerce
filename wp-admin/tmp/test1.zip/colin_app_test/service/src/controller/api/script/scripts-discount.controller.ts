/* eslint-disable @typescript-eslint/ban-ts-comment */
import dayjs from 'dayjs';
import { Request, Response } from 'express';
import { Redis } from 'ioredis';
import { ScriptFunctionEntity } from '../../../entity/script/script_function.entity';
import { ControllerBase, ControllerBaseInterface } from '../../controllerBasic';
import { FunctionModel } from '../../../model/script/script-function.model';
import { VariantModel } from '../../../model/variant.model';
import { ScriptDiscountModel } from '../../../model/script/script-discount.model';
import { ScriptLabelConfigModel } from '../../../model/script/script-label-config.model';
import { ScriptMetafieldsModel } from '../../../model/script/script-discount-metafields.model';
import { ScriptProductTagModel } from '../../../model/script/script-product-tag.model';
import { ProductModel } from '../../../model/product.model';
import { ScriptProgramModel } from '../../../model/script/script-program.model';
import { ShopModel } from '../../../model/shop.model';
import { DiscountData, ToolsClass } from './tools/interface';
import { BuyMainSendGift } from './tools/buy-main-send-gift';
import { BundleSuitesalesTools } from './tools/bundle-suite-sales';
import { BuyEnoughSendGiftTools } from './tools/buy-enough-send-gift';
import { QuantityLevelDiscountTools } from './tools/quantity-level-discount';
import { LevelMainLiJianTools } from './tools/level-man-li-jian';
import { ProductBundleSuitesalesTools } from './tools/product-bundle-suite-sales';
import { ScriptLabelConfigEntity } from '../../../entity/script/script_label_config.entity';
import { EveryMainLiJianTools } from './tools/every-man-li-jian';
import { BuyMoreThanOneDiscount } from './tools/buy_more_than_one_discount';
import { PackSales } from './tools/pack-sales';
import multer from 'multer';
import { ToolsLib } from '../../../lib/tools.lib';
let upload = multer();
// eslint-disable-next-line @typescript-eslint/no-var-requires
let utc = require('dayjs/plugin/utc');
// eslint-disable-next-line @typescript-eslint/no-var-requires
let timezone = require('dayjs/plugin/timezone');
dayjs.extend(utc);
dayjs.extend(timezone);

interface FunctionObj {
  [key: string]: ScriptFunctionEntity;
}
const BUY_MAIN_SEND_GIFT = 'dd5bf48a-2fc4-4db7-a17a-a9a6e672f865';
const BUNDLE_SUITE_SALES = 'f8a8fe72-7643-4b6d-9f03-7c8794e4ae2b';
const BUY_ENOUTH_SEND_GIFT = 'b4d5ebd5-936e-4795-bbf7-673c07d97947';
const QUANTITY_LEVEL_DISCOUNT = '36bf72bf-3fb6-4f05-8916-b42810f2718f';
const LEVEL_MAN_LI_JIAN = '94ee915b-038f-4015-b110-2070c8a04805';
const EVERY_MAN_LI_JIAN = '13eb1103-f68e-4639-8aa2-4f1b701cf5fb';
const PRODUCT_SUITE_SALES = '8f8da1fa-a169-4446-b635-d331e63a0c06';
const PRODUCT_PRICE_DROP = '3293e534-628d-4395-b495-63dd0e48035a';
const BUY_MORE_THAN_ONE_DISCOUNT = 'b4846a0f-4b70-4c75-bd08-f22b3bfdc7c1';
const PACK_SALES = 'd01ee379-17b5-484d-9893-315ef04bf3a8';
export class ScriptDiscountController extends ControllerBase {
  RedisClient: Redis;
  private scriptDisService: ScriptDiscountModel;
  private scriptLabelCfgService: ScriptLabelConfigModel;
  private scriptMetafieldsService: ScriptMetafieldsModel;
  private scriptProductTagService: ScriptProductTagModel;
  private variantService: VariantModel;
  private productService: ProductModel;
  private functionService: FunctionModel;
  private scriptProgramService: ScriptProgramModel;
  private shopModel: ShopModel;
  constructor(bootstrap: ControllerBaseInterface) {
    super(bootstrap);
    this.scriptDisService = new ScriptDiscountModel(this.database);
    this.scriptLabelCfgService = new ScriptLabelConfigModel(this.database);
    this.scriptMetafieldsService = new ScriptMetafieldsModel(this.database);
    this.scriptProductTagService = new ScriptProductTagModel(this.database);
    this.variantService = new VariantModel(this.database);
    this.productService = new ProductModel(this.database);
    this.functionService = new FunctionModel(this.database);
    this.scriptProgramService = new ScriptProgramModel(this.database);
    this.shopModel = new ShopModel(this.database);
    this.router.get('/api/script/discount/list', this.list.bind(this));
    this.router.get('/api/script/label_config/list', this.getLabelConfigs.bind(this));
    this.router.get('/api/script/label_config/info', this.getLabelConfigInfo.bind(this));
    this.router.get('/api/script/program/list', this.programsList.bind(this));
    this.router.post('/api/script/discount/delete', this.delete.bind(this));
    this.router.post('/api/script/discount/save', this.save.bind(this));
    this.router.post('/api/script/label_config/save', this.saveLabelConfigs.bind(this));
    this.router.post('/api/script/discount/change_state', this.changeState.bind(this));
    this.router.get('/api/script/discount/set_mark', this.mark.bind(this));
    this.router.post('/api/script/discount/sort', this.sort.bind(this));
    this.router.post('/api/script/discount/create_scripts', this.createScripts.bind(this));
    this.router.post('/api/script/discount/mult_upload', upload.single('file'), this.multUpload.bind(this));
  }
  async list(request: Request, res: Response) {
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 30;
    const title: string = request.query.title ? `${request.query.title}` : '';
    const state: string = request.query.state ? `${request.query.state}` : '';
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const shop_id: number = shopInfo['id'];
    let discountList: any = await this.scriptDisService.getDiscountList({
      shop_id,
      title,
      state,
      current_page,
      page_size
    });
    let count = await this.scriptDisService.getDiscountCount({ title, shop_id, state });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: {
        time_zone: shopInfo.iana_timezone,
        list: discountList.map(discount => ({
          ...discount,
          starts_at: this.formatShowDate(discount.starts_at, discount.shop.iana_timezone),
          ends_at: discount.ends_at,
          shop: { shopify_domain: discount.shop.shopify_domain, id: discount.shop.id }
        })),
        pagination
      }
    });
  }
  async getLabelConfigs(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 30;
    const shop_id = shopInfo['id'];
    const function_key: string = request.query.function_key ? `${request.query.function_key}` : '';

    let labelList: any = await this.scriptLabelCfgService.getList({
      shop_id,
      function_key,
      current_page,
      page_size
    });
    let count = await this.scriptLabelCfgService.getCount({ function_key, shop_id });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: {
        list: labelList.map(info => ({
          ...info,
          shop: { shopify_domain: info.shop.shopify_domain, id: info.shop.id }
        })),
        pagination
      }
    });
  }

  async getLabelConfigInfo(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const shop_id: number = shopInfo['id'];
    const function_key: string = request.query.function_key ? `${request.query.function_key}` : '';
    let list: any = await this.scriptLabelCfgService.getList({ shop_id, function_key, current_page: 1, page_size: 1 });
    return res.status(200).json({
      code: 200,
      msg: '',
      data: {
        info: list.length ? list[0] : { labels: [] }
      }
    });
  }

  async programsList(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    const current_page = request.query.current_page ? parseInt(`${request.query.current_page}`) : 1;
    const page_size = request.query.page_size ? parseInt(`${request.query.page_size}`) : 30;
    const shop_id = shopInfo['id'];
    let discountList: any = await this.scriptProgramService.getList({ shop_id, current_page, page_size });
    let count = await this.scriptProgramService.getCount({ shop_id });
    let pagination = {
      current_page: current_page,
      page_size,
      total_size: count,
      total_page: Math.ceil(count / current_page)
    };
    return res.json({
      code: 200,
      msg: '',
      data: {
        list: discountList.map(discount => ({
          ...discount,
          shop: { shopify_domain: discount.shop.shopify_domain, id: discount.shop.id }
        })),
        pagination
      }
    });
  }
  async delete(request: Request, res: Response) {
    let body = request.body;
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    let discountInfo = await this.scriptDisService.getScriptDiscountInfoById(body.id, shopInfo['id']);
    if (!discountInfo) {
      return res.status(200).json({ code: 500, msg: '未找到活动', data: '' });
    }
    try {
      await this.scriptDisService.deleteDiscount(discountInfo, session.onlineAccessInfo?.id);
    } catch (e) {
      return res.status(200).json({ code: 500, msg: e.message });
    }
    return res.status(200).json({ code: 200, msg: '' });
  }

  async save(request: Request, res: Response) {
    //处理数据
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    let body = request.body;
    let discountData: DiscountData = {
      scriptData: {},
      newMetafields: [],
      scriptProductTags: []
    };
    let toolClass: ToolsClass = null;
    try {
      switch (body.function_id) {
        case BUY_MAIN_SEND_GIFT:
          toolClass = new BuyMainSendGift(this.variantService);
          break;
        case BUNDLE_SUITE_SALES:
          toolClass = new BundleSuitesalesTools(this.variantService);
          break;
        case BUY_ENOUTH_SEND_GIFT:
          toolClass = new BuyEnoughSendGiftTools(this.variantService);
          break;
        case QUANTITY_LEVEL_DISCOUNT:
        case PRODUCT_PRICE_DROP:
          toolClass = new QuantityLevelDiscountTools(this.shopModel, this.variantService);
          break;
        case LEVEL_MAN_LI_JIAN:
          toolClass = new LevelMainLiJianTools(this.shopModel, this.variantService);
          break;
        case PRODUCT_SUITE_SALES:
          toolClass = new ProductBundleSuitesalesTools(this.productService, this.variantService);
          break;
        case EVERY_MAN_LI_JIAN:
          toolClass = new EveryMainLiJianTools(this.variantService);
          break;
        case BUY_MORE_THAN_ONE_DISCOUNT:
          toolClass = new BuyMoreThanOneDiscount(this.variantService);
          break;
        case PACK_SALES:
          toolClass = new PackSales(this.variantService);
          break;
      }
    } catch (e) {
      return res.status(200).json({ code: 500, msg: e.message, data: '' });
    }
    try {
      discountData = await toolClass.makeDiscountData({ ...body, shop_id: shopInfo['id'] });
    } catch (e) {
      return res.status(200).json({ code: 500, msg: e.message });
    }
    //如果活动存在就
    if (body.id) {
      let oldDiscountInfo = await this.scriptDisService.getScriptDiscountInfoById(body.id, shopInfo['id']);
      if (!oldDiscountInfo) {
        return res.status(200).json({ code: 500, msg: '未找到活动', data: '' });
      }
      let oldMetafields = await this.scriptMetafieldsService.getMetafieldsByDisId(body.id);
      oldMetafields.length && this.scriptMetafieldsService.compaireMetaifields(oldMetafields, discountData.newMetafields);

      let oldProductTags = await this.scriptProductTagService.getProductTagByDisId(body.id);
      oldProductTags.length && this.scriptProductTagService.compaireProductTags(oldProductTags, discountData.scriptProductTags);
    }
    //@ts-ignore
    let starts_at = dayjs.tz(body.starts_at, shopInfo['iana_timezone']).toDate();
    //@ts-ignore
    let ends_at = body.ends_at ? dayjs.tz(body.ends_at, shopInfo['iana_timezone']).toDate() : null;
    try {
      let discountInfo = await this.scriptDisService.save(
        {
          ...body,
          state: 'active',
          starts_at,
          ends_at,
          shop_id: shopInfo['id'],
          scripts_config: discountData.scriptData,
          product_tag: toolClass.product_tag
        },
        discountData.newMetafields.map(item => ({
          ...item,
          start_sync_at: starts_at
        })),
        discountData.scriptProductTags.map(item => ({
          ...item,
          start_sync_at: starts_at
        })),
        session.onlineAccessInfo.id
      );
      discountInfo = await this.scriptDisService.getDiscountInfo({ discountId: discountInfo.id, shop_id: shopInfo['id'] });
      return res.status(200).json({ code: 200, msg: '', data: { discountInfo } });
    } catch (e) {
      console.log(e);
      this.logger.error(e.message);
      return res.status(200).json({ code: 404, msg: 'Save failed!', data: '' });
    }
  }

  async saveLabelConfigs(req: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    let body: any = req.body;
    let result: ScriptLabelConfigEntity = null;
    if (!body.id) {
      let list = await this.scriptLabelCfgService.getList({
        function_key: body.function_key,
        shop_id: shopInfo['id'],
        current_page: 1,
        page_size: 1
      });
      if (list.length != 0) {
        return res.status(200).json({
          code: 400,
          msg: `店铺${list[0]['shop'].shopify_domain}的【${list[0]['function'].title}】功能对应的文案已经存在，无法重复创建!`,
          data: list[0]
        });
      }
    }
    try {
      result = await this.scriptLabelCfgService.save({ ...body, shop_id: shopInfo['id'] });
    } catch (e) {
      this.logger.error(e);
      return res.status(200).json({ code: 500, msg: 'Save failed!', data: result });
    }
    return res.status(200).json({ code: 200, msg: '', data: result });
  }

  async changeState(request: Request, res: Response) {
    let body: any = request.body;
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    //处理数据
    //如果活动存在就
    let discountData: DiscountData = null;
    let oldDiscountInfo = await this.scriptDisService.getScriptDiscountInfoById(body.id, shopInfo.id);
    if (!oldDiscountInfo) {
      return res.status(200).json({ code: 500, msg: '未找到活动', data: '' });
    }
    let oldMetafields = await this.scriptMetafieldsService.getMetafieldsByDisId(body.id);
    let oldProductTags = await this.scriptProductTagService.getProductTagByDisId(body.id);
    let toolClass: ToolsClass = null;
    if (oldDiscountInfo['state'] == 'draft') {
      switch (oldDiscountInfo.function_id) {
        case BUY_MAIN_SEND_GIFT:
          toolClass = new BuyMainSendGift(this.variantService);
          break;
        case BUNDLE_SUITE_SALES:
          toolClass = new BundleSuitesalesTools(this.variantService);
          break;
        case BUY_ENOUTH_SEND_GIFT:
          toolClass = new BuyEnoughSendGiftTools(this.variantService);
          break;
        case QUANTITY_LEVEL_DISCOUNT:
        case PRODUCT_PRICE_DROP:
          toolClass = new QuantityLevelDiscountTools(this.shopModel, this.variantService);
          break;
        case LEVEL_MAN_LI_JIAN:
          toolClass = new LevelMainLiJianTools(this.shopModel, this.variantService);
          break;
        case PRODUCT_SUITE_SALES:
          toolClass = new ProductBundleSuitesalesTools(this.productService, this.variantService);
          break;
        case EVERY_MAN_LI_JIAN:
          toolClass = new EveryMainLiJianTools(this.variantService);
          break;
        case BUY_MORE_THAN_ONE_DISCOUNT:
          toolClass = new BuyMoreThanOneDiscount(this.variantService);
          break;
        case PACK_SALES:
          toolClass = new PackSales(this.variantService);
          break;
      }
      try {
        discountData = await toolClass.makeDiscountData(oldDiscountInfo);
      } catch (e) {
        return res.status(200).json({ code: 500, msg: e.message });
      }

      oldMetafields.length && this.scriptMetafieldsService.compaireMetaifields(oldMetafields, discountData.newMetafields);
      oldProductTags.length && this.scriptProductTagService.compaireProductTags(oldProductTags, discountData.scriptProductTags);
    }
    try {
      await this.scriptDisService.save(
        { ...oldDiscountInfo, state: oldDiscountInfo.state == 'active' ? 'draft' : 'active' },
        oldDiscountInfo.state == 'draft'
          ? discountData.newMetafields
          : oldMetafields.map(item => ({ ...item, is_need_delete: true })),
        oldDiscountInfo.state == 'draft'
          ? discountData.scriptProductTags
          : oldProductTags.map(item => ({ ...item, is_need_delete: true })),
        session.onlineAccessInfo.id
      );
      return res.status(200).json({ code: 200, msg: '', data: '' });
    } catch (e) {
      console.log(e);
      return res.status(200).json({ code: 404, msg: 'Save failed!', data: '' });
    }
  }
  async mark(request: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    //获取记录
    let programInfo = await this.scriptProgramService.getInfo(shopInfo['id']);
    if (!programInfo) {
      return res.status(200).json({ code: 404, msg: 'Not found!', data: '' });
    }
    try {
      await this.scriptProgramService.update({ ...programInfo, updated_at: new Date(), deploy_at: new Date() });
      return res.status(200).json({ code: 200, msg: '', data: '' });
    } catch (e) {
      console.log(e);
      return res.status(200).json({ code: 404, msg: 'Save failed!', data: '' });
    }
  }

  async sort(request: Request, res: Response) {
    let body = request.body;
    let source_id = body.source_id;
    let target_id = body.target_id;
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    try {
      await this.scriptDisService.updateDiscountSortByIds(source_id, target_id, shopInfo['id']);
      return res.status(200).json({ code: 200, msg: '', data: '' });
    } catch (e) {
      console.log(e);
      return res.status(200).json({ code: 404, msg: 'Save failed!', data: '' });
    }
  }

  async multUpload(req: Request, res: Response) {
    let body = req.body;
    console.log(body.function_id);
    let toolClass: ToolsClass = null;
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    let data = ToolsLib.analysisExcelData(req.file.buffer);
    switch (body.function_id) {
      case BUY_MAIN_SEND_GIFT:
        toolClass = new BuyMainSendGift(this.variantService);
        break;
      case BUNDLE_SUITE_SALES:
        toolClass = new BundleSuitesalesTools(this.variantService);
        break;
      case BUY_ENOUTH_SEND_GIFT:
        toolClass = new BuyEnoughSendGiftTools(this.variantService);
        break;
      case QUANTITY_LEVEL_DISCOUNT:
      case PRODUCT_PRICE_DROP:
        toolClass = new QuantityLevelDiscountTools(this.shopModel, this.variantService);
        break;
      case LEVEL_MAN_LI_JIAN:
        toolClass = new LevelMainLiJianTools(this.shopModel, this.variantService);
        break;
      case PRODUCT_SUITE_SALES:
        toolClass = new ProductBundleSuitesalesTools(this.productService, this.variantService);
        break;
      case EVERY_MAN_LI_JIAN:
        toolClass = new EveryMainLiJianTools(this.variantService);
        break;
      case BUY_MORE_THAN_ONE_DISCOUNT:
        toolClass = new BuyMoreThanOneDiscount(this.variantService);
        break;
      case PACK_SALES:
        toolClass = new PackSales(this.variantService);
        break;
    }
    console.log(data);
    try {
      let result = (await toolClass?.multUpload(shopInfo['id'], data)) || [];
      return res.status(200).json({ code: 200, msg: '', data: result });
    } catch (e) {
      return res.status(200).json({ code: 404, msg: e.message, data: '' });
    }
  }

  async createScripts(req: Request, res: Response) {
    const session = res.locals.shopify.session;
    let shopInfo = await this.shopModel.getShopByShopDomain(session.shop);
    //获取店铺所有生效而且正在或者未来要生效的活动 test
    let discountList = await this.scriptDisService.getActiveScriptsDiscounts(shopInfo['id']);
    //获取所有的店铺相关的函数
    let functionList = await this.functionService.getShopsAllCodes(shopInfo['id']);
    if (!functionList.length) {
      return res.status(200).json({ code: 404, msg: '未找到活动', data: '' });
    }
    let functionObjs: FunctionObj = {};
    for (let func of functionList) {
      functionObjs[func['function_key']] = func;
    }

    //整理出活动依赖的函数
    let relateFunctions: FunctionObj = {};
    discountList.map(item => {
      relateFunctions[item['function_id']] = functionObjs[item['function_id']];
      relateFunctions = { ...relateFunctions, ...this.getRelateFunctions(functionObjs[item['function_id']], functionObjs) };
    });
    //将店铺自己的函数添加上去
    functionList.forEach(item => {
      if (item['code_type'] == 'shop_self') {
        relateFunctions[item['function_key']] = item;
        relateFunctions = { ...relateFunctions, ...this.getRelateFunctions(item, functionObjs) };
      }
    });
    //将所有函数和所属店铺自己的code合并
    let code = `
$has_discount = false
$sku_has_discount = Hash.new
    `;
    let shopCode = ``;
    Object.values(relateFunctions).map(item => {
      if (item['code_type'] != 'shop_self') {
        code += `
${item.code}\n`;
      }
      if (item['code_type'] == 'shop_self') {
        shopCode += `
${item.code}\n`;
      }
    });
    code += `#------------------------------调用开始-------------------------------
${shopCode}
`;
    //将活动对应的函数调用的数据传进去
    discountList.map(discount => {
      let toolClass: ToolsClass = null;
      switch (discount['function_id']) {
        case BUY_MAIN_SEND_GIFT:
          toolClass = new BuyMainSendGift(this.variantService);
          break;
        case BUNDLE_SUITE_SALES:
          toolClass = new BundleSuitesalesTools(this.variantService);
          break;
        case BUY_ENOUTH_SEND_GIFT:
          toolClass = new BuyEnoughSendGiftTools(this.variantService);
          break;
        case QUANTITY_LEVEL_DISCOUNT:
        case PRODUCT_PRICE_DROP:
          toolClass = new QuantityLevelDiscountTools(this.shopModel, this.variantService);
          break;
        case LEVEL_MAN_LI_JIAN:
          toolClass = new LevelMainLiJianTools(this.shopModel, this.variantService);
          break;
        case PRODUCT_SUITE_SALES:
          toolClass = new ProductBundleSuitesalesTools(this.productService, this.variantService);
          break;
        case EVERY_MAN_LI_JIAN:
          toolClass = new EveryMainLiJianTools(this.variantService);
          break;
        case BUY_MORE_THAN_ONE_DISCOUNT:
          toolClass = new BuyMoreThanOneDiscount(this.variantService);
          break;
        case PACK_SALES:
          toolClass = new PackSales(this.variantService);
          break;
      }
      code += toolClass.createScriptsCode(discount['scripts_config']);
    });
    code += `
#${discountList.length ? discountList[0]['shop']['shopify_domain'] : ''}
Output.cart = Input.cart
    `;
    //将json格式替换为ruby能够识别的格式
    code = code.replace(/["](\w*)["]\:/g, '$1:');
    let msg = '';
    if (code.length > 40960) {
      msg = '生成的script字节超过了shopify的限制！';
    }
    return res.status(200).json({ code: 200, msg: msg, data: { code: code } });
  }
  private getRelateFunctions(func: ScriptFunctionEntity, functionObjs: FunctionObj): FunctionObj {
    if (!func.relate_functions || !func.relate_functions.length) {
      return {};
    }
    let relateFunctions: FunctionObj = {};
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    //@ts-ignore
    func.relate_functions.map((item: string) => {
      relateFunctions[item] = functionObjs[item];
      relateFunctions = { ...relateFunctions, ...this.getRelateFunctions(functionObjs[item], functionObjs) };
    });
    return relateFunctions;
  }
  private formatShowDate(date: string, timezone: string): string {
    return dayjs(date).tz(timezone).format('YYYY-MM-DD HH:mm:ssZZ');
  }
}
