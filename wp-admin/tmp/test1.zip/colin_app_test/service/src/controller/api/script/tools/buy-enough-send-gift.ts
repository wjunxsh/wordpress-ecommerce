import { v4 as uuidv4 } from 'uuid';
import { ToolsClass } from './interface';
import { VariantModel } from '../../../../model/variant.model';
import { VariantEntity } from '../../../../entity/variant.entity';
import { ScriptProductTagEntity } from '../../../../entity/script/script_product_tag.entity';
import { ScriptDiscountEntity } from '../../../../entity/script/script_discount.entity';
export class BuyEnoughSendGiftTools implements ToolsClass {
  public product_tag = 'buy_enough_send_gift';
  variantModel?: VariantModel;
  constructor(variantModel: VariantModel) {
    this.variantModel = variantModel;
  }

  async makeDiscountData(body: any) {
    let variantsIds = this.getVariantsIds(body);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: body.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let scriptData = this.makeScriptsData(body, variantsObj);
    let scriptProductTags = this.makeProductTags(body, variantsObj);
    //组装metafields
    //let newMetafields = this.makeMetafields(body);
    return {
      scriptData,
      newMetafields: [],
      scriptProductTags
    };
  }
  getVariantsIds(body) {
    let variantsIds: string[] = [];
    let bundleConfig = body.config;
    let rules = bundleConfig.rules;
    if (rules.length == 0) {
      return [];
    }
    rules.forEach(item => {
      item.gift_skus.map(val => {
        variantsIds.push(val.value);
      });
    });
    if (bundleConfig.exclude_skus) {
      bundleConfig.exclude_skus.forEach(item => {
        variantsIds.push(item.value);
      });
    }
    return variantsIds;
  }
  async covertIdToShopfyId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByIds({ ids: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['id']] = variant;
    });
    let bundleConfig: any = data.config;
    let rules = bundleConfig.rules;
    bundleConfig.exclude_skus &&
      bundleConfig.exclude_skus.forEach(item => {
        if (variantsObj[item.value]) {
          item.value = variantsObj[item.value]['shopify_id'];
        }
      });
    rules.forEach(rule => {
      rule.gift_skus.forEach(val => {
        if (variantsObj[val.value]) {
          val['value'] = variantsObj[val.value]['shopify_id'];
        }
      });
    });
    return data;
  }
  async covertShopifyIdToId(data: ScriptDiscountEntity) {
    let variantsIds = this.getVariantsIds(data);
    let variants: VariantEntity[] = [];
    if (variantsIds.length) {
      variants = await this.variantModel.getVariantsByShopifyIds({ shopifyIds: variantsIds, shop_id: data.shop_id });
    }
    let variantsObj = {};
    variants.forEach(variant => {
      variantsObj[variant['shopify_id']] = variant;
    });
    let bundleConfig: any = data.config;
    let rules = bundleConfig.rules;
    bundleConfig.exclude_skus &&
      bundleConfig.exclude_skus.forEach(item => {
        if (variantsObj[item.value]) {
          if (item.key) {
            item.key = variantsObj[item.value]['id'];
          }
          item.value = variantsObj[item.value]['id'];
        }
      });
    rules.forEach(rule => {
      rule.gift_skus.forEach(val => {
        if (variantsObj[val.value]) {
          if (val['key']) {
            val['key'] = variantsObj[val.value]['id'];
          }
          val['value'] = variantsObj[val.value]['id'];
        }
      });
    });
    return data;
  }

  makeScriptsData(body, variantsObj) {
    let bundleConfig = body.config;
    let rules = bundleConfig.rules;
    if (rules.length > 1) {
      rules = rules.sort((a, b) => b.money - a.money);
    }
    let exclude_skus = bundleConfig.exclude_skus ? bundleConfig.exclude_skus.map(item => variantsObj[item.value].sku) : [];
    let returnData = [];
    rules.forEach(item => {
      returnData.push({
        message: body.config.message,
        discount_type: body.config.discount_type,
        dc_mutex: body.config.dc_mutex ?? true,
        mutex: body.config.mutex ? true : false,
        exclude_skus,
        limit_product_tag: bundleConfig.limit_product_tag || null,
        is_repeat: bundleConfig.is_repeat ?? false,
        is_level_send: body.config.is_level_send ?? false,
        money: item.money,
        gift_skus: item.gift_skus.map(val => variantsObj[val.value].sku)
      });
    });
    return returnData;
  }
  makeMetafields() {
    return [];
  }
  public makeProductTags(body, variantObjs) {
    let bundleConfig = body.config;
    let productTags: ScriptProductTagEntity[] = [];
    bundleConfig.rules.forEach(rule => {
      rule.gift_skus.map(val => {
        if (productTags.some(item => item.product_shopify_id == variantObjs[val['value']]['product'].shopify_id)) {
          return true;
        }
        let productTag: ScriptProductTagEntity = {
          uuid: uuidv4(),
          discount_id: 0,
          product_shopify_id: variantObjs[val['value']]['product'].shopify_id,
          is_need_delete: false,
          product_tag: this.product_tag,
          updated_at: new Date(),
          created_at: new Date(),
          sync_state: false,
          start_sync_at: body.starts_at,
          sync_at: null
        };
        productTags.push(productTag);
      });
    });
    return productTags;
  }
  public createScriptsCode(data: any): string {
    let code = ``;
    for (let rule of data) {
      code += `buy_enough_send_gift({
  message:"${rule.message}",
  is_level_send:${rule.is_level_send},
  dc_mutex:${rule.dc_mutex},
  mutex:${rule.mutex ?? true},
  money:${rule.money},
  is_repeat:${rule.is_repeat},
  product_tag:"${this.product_tag}",
  limit_product_tag: ${rule.limit_product_tag ? `"${rule.limit_product_tag}"` : 'nil'},
  gift_skus:["${rule.gift_skus.join('","')}"],
  `;
      if (rule.exclude_skus) {
        code += `exclude_skus:["${rule.exclude_skus.join('","')}"]\n`;
      }
      code += `})\n`;
    }

    return code;
  }
  async multUpload(data: any) {
    return data;
  }
}
