import { IsArray, IsNotEmpty, IsString, Max, Min, ValidateIf } from 'class-validator';
export class BulkCodeDto {
  @IsString()
  @IsNotEmpty()
  type: string;

  @ValidateIf(o => o.type === 'auto')
  @Max(10)
  @Min(4)
  @IsNotEmpty()
  random_length: number;

  @ValidateIf(o => o.type === 'auto')
  @Max(100000)
  @Min(1)
  @IsNotEmpty()
  counts: number;

  @ValidateIf(o => o.type === 'auto')
  @IsNotEmpty()
  character_type: string;

  @ValidateIf(o => o.type === 'menual')
  @IsNotEmpty()
  @IsArray()
  codes: string[];
}

export class PriceRuleDto extends BulkCodeDto {
  @IsString()
  title: string;
}
