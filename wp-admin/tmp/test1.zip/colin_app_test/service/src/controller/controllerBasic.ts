import { Redis } from 'ioredis';
import { DataSource } from 'typeorm';
import { Express, Router } from 'express';
import { RequestHandler } from 'express';
import * as crypto from 'crypto';
import { HttpResponseError, InvalidJwtError, LATEST_API_VERSION, Session, Shopify, shopifyApi } from '@shopify/shopify-api';
import { Request, Response, NextFunction } from 'express';
import { Logger } from 'winston';
import { PostgreSQLSessionStorage } from '../lib/session.storage';
import { restResources } from '@shopify/shopify-api/rest/admin/2023-07';
const AUTH_PATH = '/api/auth';
const CALLBACK_PATH = '/api/auth/callback';
const EXITIFRAMEPATH = 'exitiframe';
const TEST_GRAPHQL_QUERY = `
{
  shop {
    name
  }
}`;
enum WebhookHeader {
  Hmac = 'X-Shopify-Hmac-Sha256',
  Topic = 'X-Shopify-Topic',
  Domain = 'X-Shopify-Shop-Domain'
}
export interface ControllerBaseInterface {
  app: Express;
  redis: Redis;
  database: DataSource;
  router: Router;
  api: Shopify;
  logger: Logger;
  sessionStorage: PostgreSQLSessionStorage;
}

export class ControllerBase {
  public sessionStorage: PostgreSQLSessionStorage;
  public app: Express;
  public redis: Redis;
  public database: DataSource;
  public router: Router;
  public api: Shopify;
  public logger: Logger;
  constructor(bootstrap: ControllerBaseInterface) {
    this.app = bootstrap.app;
    this.redis = bootstrap.redis;
    this.database = bootstrap.database;
    this.router = bootstrap.router;
    this.api = bootstrap.api;
    this.sessionStorage = bootstrap.sessionStorage;
    this.logger = bootstrap.logger;
  }
  public verifyhook(): RequestHandler {
    return async (req: any, res, next?: any) => {
      const resData = {};
      if (req.headers['x-shopify-shop-domain']) {
        resData['shop'] = req.headers['x-shopify-shop-domain'];
      }
      req.authData = resData;
      if (
        !(
          crypto.createHmac('SHA256', process.env.API_SECRET_KEY).update(req.rawBody, 'utf8').digest('base64') ===
          (req.headers[WebhookHeader.Hmac] ?? req.headers[WebhookHeader.Hmac.toLowerCase()])
        )
      ) {
        res.status(401).json({
          status: 401,
          message: 'forbidden'
        });
        return;
      } else {
        next();
      }
    };
  }
  async redirectToAuth({ req, res, isOnline = false }) {
    const shop = this.api.utils.sanitizeShop(req.query.shop as string);
    if (shop) {
      this.getShopifyApi(req, shop);
      if (req.query.embedded === '1') {
        await this.clientSideRedirect(shop, req, res);
      } else {
        await this.serverSideRedirect(shop, req, res, isOnline);
      }
    } else {
      console.log('No shop provided to redirect to auth');

      res.status(500);
      return res.send('No shop provided');
    }
  }
  validateAuthenticatedSession() {
    return async (req: Request, res: Response, next: NextFunction) => {
      let sessionId: string | undefined;
      let shop = req.query.shop;
      shop && this.getShopifyApi(req, shop);
      try {
        sessionId = await (req.api || this.api).session.getCurrentId({
          isOnline: true,
          rawRequest: req,
          rawResponse: res
        });
      } catch (error) {
        await this.handleSessionError(req, res, error);
        return undefined;
      }

      let session: Session | undefined;
      if (sessionId) {
        try {
          session = await this.sessionStorage.loadSession(sessionId);
        } catch (error) {
          res.status(500);
          res.send(error.message);
          return undefined;
        }
      }

      shop = req.query.shop || session?.shop;
      if (session && shop && session.shop !== shop) {
        return this.redirectToAuth({ req, res });
      }
      shop && this.getShopifyApi(req, shop);
      if (session) {
        if (session?.isActive(this.api.config.scopes)) {
          if (await this.hasValidAccessToken(req.api || this.api, session)) {
            res.locals.shopify = {
              ...res.locals.shopify,
              session
            };
            return next();
          }
        }
      }

      const bearerPresent = req.headers.authorization?.match(/Bearer (.*)/);
      if (bearerPresent) {
        if (!shop) {
          shop = await this.setShopFromSessionOrToken(req.api || this.api, session, bearerPresent[1]);
        }
      }
      const redirectUrl = `${AUTH_PATH}?shop=${shop}`;
      return this.returnTopLevelRedirection({
        res,
        bearerPresent: Boolean(req.headers.authorization?.match(/Bearer (.*)/)),
        redirectUrl
      });
    };
  }
  async setShopFromSessionOrToken(api: Shopify, session: Session | undefined, token: string): Promise<string | undefined> {
    let shop: string | undefined;

    if (session) {
      shop = session.shop;
    } else if (api.config.isEmbeddedApp) {
      const payload = await api.session.decodeSessionToken(token);
      shop = payload.dest.replace('https://', '');
    }
    return shop;
  }
  async returnTopLevelRedirection({ res, bearerPresent, redirectUrl }: any): Promise<void> {
    // If the request has a bearer token, the app is currently embedded, and must break out of the iframe to
    // re-authenticate
    if (bearerPresent) {
      res.status(403);
      res.header('X-Shopify-API-Request-Failure-Reauthorize', '1');
      res.header('X-Shopify-API-Request-Failure-Reauthorize-Url', redirectUrl);
      res.end();
    } else {
      res.redirect(redirectUrl);
    }
  }
  ensureInstalled() {
    return async (req: Request, res: Response, next: NextFunction) => {
      if (!this.api.config.isEmbeddedApp) {
        return this.validateAuthenticatedSession()(req, res, next);
      }

      const shop = this.getRequestShop(req, res);
      if (!shop) {
        return undefined;
      }
      const sessionId = this.api.session.getOfflineId(shop);
      const session = await this.sessionStorage.loadSession(sessionId);

      const exitIframeRE = new RegExp(`^${EXITIFRAMEPATH}`, 'i');
      if (!session && !req.originalUrl.match(exitIframeRE)) {
        return this.redirectToAuth({ req, res });
      }
      if (this.api.config.isEmbeddedApp && req.query.embedded !== '1') {
        if (await this.sessionHasValidAccessToken(session)) {
          await this.embedAppIntoShopify(req, res);
          return undefined;
        } else {
          return this.redirectToAuth({ req, res });
        }
      }

      this.addCSPHeader(req, res);
      return next();
    };
  }
  async embedAppIntoShopify(req: Request, res: Response): Promise<void> {
    const embeddedUrl = await this.api.auth.getEmbeddedAppUrl({
      rawRequest: req,
      rawResponse: res
    });
    res.redirect(embeddedUrl + req.path);
  }
  getRequestShop(req: Request, res: Response): string | undefined {
    if (typeof req.query.shop !== 'string') {
      res.status(422);
      res.send('No shop provided1');
      return undefined;
    }
    const shop = this.api.utils.sanitizeShop(req.query.shop);
    if (!shop) {
      res.status(422);
      res.send('Invalid shop provided');
      return undefined;
    }

    return shop;
  }
  addCSPHeader(req: Request, res: Response) {
    const shop = this.api.utils.sanitizeShop(req.query.shop as string);
    if (this.api.config.isEmbeddedApp && shop) {
      res.setHeader(
        'Content-Security-Policy',
        `frame-ancestors https://${encodeURIComponent(shop)} https://admin.shopify.com;`
      );
    } else {
      res.setHeader('Content-Security-Policy', `frame-ancestors 'none';`);
    }
  }

  async sessionHasValidAccessToken(session: Session | undefined): Promise<boolean> {
    if (!session) {
      return false;
    }

    try {
      return session.isActive(this.api.config.scopes) && (await this.hasValidAccessToken(this.api, session));
    } catch (error) {
      return false;
    }
  }

  async clientSideRedirect(shop: string, req: Request, res: Response): Promise<void> {
    const host = (req.api || this.api).utils.sanitizeHost(req.query.host as string);
    if (!host) {
      res.status(500);
      res.send('No host provided');
      return;
    }

    const redirectUriParams = new URLSearchParams({ shop, host }).toString();

    const appHost = `${(req.api || this.api).config.hostScheme}://${(req.api || this.api).config.hostName}`;
    const queryParams = new URLSearchParams({
      ...req.query,
      shop,
      redirectUri: `${appHost}${AUTH_PATH}?${redirectUriParams}`
    }).toString();
    res.redirect(`${EXITIFRAMEPATH}?${queryParams}`);
  }
  async hasValidAccessToken(api: Shopify, session: Session): Promise<boolean> {
    try {
      const client = new api.clients.Graphql({ session });
      await client.query({ data: TEST_GRAPHQL_QUERY });
      return true;
    } catch (error) {
      if (error instanceof HttpResponseError && error.response.code === 401) {
        // Re-authenticate if we get a 401 response
        return false;
      } else {
        throw error;
      }
    }
  }

  async serverSideRedirect(shop: string, req: Request, res: Response, isOnline: boolean): Promise<void> {
    req.query.shop && this.getShopifyApi(req, req.query.shop);
    await (req.api || this.api).auth.begin({
      callbackPath: CALLBACK_PATH,
      shop,
      isOnline,
      rawRequest: req,
      rawResponse: res
    });
  }
  async getCurrentShopifyName(req: Request, res: Response) {
    let sessionId = await this.api.session.getCurrentId({
      isOnline: true,
      rawRequest: req,
      rawResponse: res
    });
    const session = await this.sessionStorage.loadSession!(sessionId);
    return session.shop;
  }
  async handleSessionError(_req: Request, res: Response, error: Error) {
    switch (true) {
      case error instanceof InvalidJwtError:
        res.status(401);
        res.send(error.message);
        break;
      default:
        res.status(500);
        res.send(error.message);
        break;
    }
  }
  getShopifyApi(req: Request, shop: string) {
    const SHOPIFY_EXPRESS_LIBRARY_VERSION = '1.2.0';
    let userAgent = `Shopify Express Library v${SHOPIFY_EXPRESS_LIBRARY_VERSION}`;
    const shopifyConfig = {
      'beta-mach-us.myshopify.com': {
        shopify_api_key: '2246e91171a38397559f502000563c2b',
        shopify_secret_key: '4b807df57e5f26bb357bdff67447cf53'
      },
      'beta-mach-de.myshopify.com': {
        shopify_api_key: 'd17cfb7b08daa5f536557c204a5a483c',
        shopify_secret_key: 'df917ef57d54069c0460d576798e3c9e'
      }
    };
    if (shopifyConfig[shop]) {
      req.api = shopifyApi({
        apiKey: shopifyConfig[shop]['shopify_api_key'],
        apiSecretKey: shopifyConfig[shop]['shopify_secret_key'],
        scopes: (process.env.SCOPES || 'write_products').split(','),
        hostName: (process.env.HOST || '').replace(/https?:\/\//, ''),
        hostScheme: 'https',
        apiVersion: LATEST_API_VERSION,
        isEmbeddedApp: true,
        restResources: restResources,
        userAgentPrefix: userAgent
      });
    } else {
      req.api = shopifyApi({
        apiKey: process.env.SHOPIFY_API_KEY || '',
        apiSecretKey: process.env.SHOPIFY_API_SECRET || '',
        scopes: (process.env.SCOPES || 'write_products').split(','),
        hostName: (process.env.HOST || '').replace(/https?:\/\//, ''),
        hostScheme: 'https',
        apiVersion: LATEST_API_VERSION,
        isEmbeddedApp: true,
        restResources: restResources,
        userAgentPrefix: userAgent
      });
    }
  }
}
