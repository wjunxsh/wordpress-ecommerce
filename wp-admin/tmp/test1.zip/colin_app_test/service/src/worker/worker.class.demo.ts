import { WorkerBasis } from './wooker-basis';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { WorkerInterface } from './interface';
import { Job } from 'bullmq';
dayjs.extend(utc);
dayjs.extend(timezone);
export class DemoWorker extends WorkerBasis {
  constructor(bootstrap: WorkerInterface) {
    super(bootstrap);
  }
  /**
   * @brief process 函数必须提供，在消费job的时候需要用到
   * @param job
   * @returns
   */
  async process(job: Job<any, any, string>) {
    switch (job.name) {
      case 'job name的值':
        return await this.consumerFunc(job.data);
      default:
        return true;
    }
  }
  /**
   * 根据job的key值分发处理函数
   * @param data
   * @returns
   */
  async consumerFunc(data: any) {
    return data;
  }
}
