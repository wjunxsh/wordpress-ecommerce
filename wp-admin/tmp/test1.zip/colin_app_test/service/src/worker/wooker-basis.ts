import { DataSource } from 'typeorm';
import { Redis } from 'ioredis';
import { Shopify } from '@shopify/shopify-api';
import { Logger } from 'winston';
import { WorkerInterface } from './interface';
import { PostgreSQLSessionStorage } from '../lib/session.storage';
export class WorkerBasis {
  redis: Redis;
  database: DataSource;
  api: Shopify;
  logger: Logger;
  sessionStorage: PostgreSQLSessionStorage;
  constructor(bootstrap: WorkerInterface) {
    this.database = bootstrap.database;
    this.redis = bootstrap.redis;
    this.logger = bootstrap.logger;
    this.api = bootstrap.api;
    this.sessionStorage = bootstrap.sessionStorage;
  }
}
