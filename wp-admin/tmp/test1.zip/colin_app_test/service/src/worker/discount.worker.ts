import { WorkerBasis } from './wooker-basis';
import {
  APP_COMMON_NAMESPACE,
  CREATE_DISCOUNT_EVENT_JOB,
  DELETE_DISCOUNT_JOB_NAME,
  DISCOUNT_PRODUCT_TAG,
  REDIS_CACHE_KEY_PREFIX,
  SYNC_ALL_DISCOUNT_FROM_SHOPIFY,
  SYNC_DISCOUNT_VARIANT_METAFIELDS,
  SYNC_OTHER_DISCOUNT_FROM_SHOPIFY,
  UPDATE_DISCOUNT_EVENT_JOB,
  WAIT_SYNC_DISCOUNT_LIST
} from '../lib/variable';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { WorkerInterface } from './interface';
import { Job } from 'bullmq';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { DiscountVariantModel } from '../model/discount.variant.model';
import { ToolsLib } from '../lib/tools.lib';
import { DiscountVariantEntity } from '../entity/discount.variant.entity';
import { DataType, Session } from '@shopify/shopify-api';
import { ShopifyGraphQLLib } from '../lib/shopify-graphql.lib';
import { metafieldStorefrontVisibilityCreate } from '../graphql/metafields.graphql';
import { In, IsNull } from 'typeorm';
import { DiscountModel } from '../model/discount.mode';
import { ShopEntity } from '../entity/shop.entity';
import { DiscountEntity } from '../entity/discount.entity';
import { ProductModel } from '../model/product.model';
import { DiscountVariantLogModel } from '../model/discount.variant.log.model';
import { DiscountVariantLogEntity } from '../entity/discount.variant.log.entity';
dayjs.extend(utc);
dayjs.extend(timezone);
export class DiscountWorker extends WorkerBasis {
  constructor(bootstrap: WorkerInterface) {
    super(bootstrap);
  }
  async process(job: Job<any, any, string>) {
    switch (job.name) {
      case SYNC_DISCOUNT_VARIANT_METAFIELDS:
        return await this.asyncDiscountVariantMetafields(job.data);
      case DELETE_DISCOUNT_JOB_NAME:
        return await this.deleteDiscount(job.data);
      case SYNC_OTHER_DISCOUNT_FROM_SHOPIFY:
        return await this.getDiscountsFromShopify({ ...job.data }, false, SYNC_OTHER_DISCOUNT_FROM_SHOPIFY);
      //全量同步折扣信息
      case SYNC_ALL_DISCOUNT_FROM_SHOPIFY:
        return await this.getDiscountsFromShopify({ ...job.data }, true, SYNC_ALL_DISCOUNT_FROM_SHOPIFY);
      case CREATE_DISCOUNT_EVENT_JOB:
        return await this.createDiscountEvent({ ...job.data });
      case UPDATE_DISCOUNT_EVENT_JOB:
        return await this.updateDiscountEvent({ ...job.data });
      case WAIT_SYNC_DISCOUNT_LIST:
        return await this.getDiscountFromShopifyById({ ...job.data });

      default:
        return true;
    }
  }
  async getDiscountsFromShopify(jobData: { shopify_shop_id: number }, is_all_sync: boolean = false, redisKey: string) {
    let shopRspt = this.database.getRepository(ShopEntity);
    let discountRspt = this.database.getRepository(DiscountEntity);
    let shopInfo = await shopRspt.findOneBy({
      shopify_id: jobData.shopify_shop_id
    });
    //从缓存中获取当前店铺的折扣的上一次更新时间的缓存
    let lastSyncTime: string = null;
    if (!is_all_sync) {
      lastSyncTime = await this.redis.get(`${shopInfo['id']}-` + redisKey);
      //获取最近一次更新的其他活动时间,实测过程中发现shopify的折扣更新后，不一定能够及时获取可能跟shopify的数据策略有关系，所以最好是增加一个
      //获取最近的一条更新记录的shopify_created_at时间，取两者最小值作为本次更新时间的开始时间
      let discountInfo = await discountRspt.findOne({
        where: { shop_id: shopInfo['id'] },
        order: { shopify_updated_at: 'DESC' }
      });
      if (discountInfo) {
        lastSyncTime =
          !lastSyncTime || dayjs(discountInfo.shopify_updated_at).isBefore(dayjs(lastSyncTime))
            ? dayjs(discountInfo.shopify_updated_at).tz('UTC').format()
            : lastSyncTime;
      }
    }

    if (shopInfo && shopInfo['shopify_token']) {
      const offlineSessionId = this.api.session.getOfflineId(shopInfo.shopify_domain);
      let session = await this.sessionStorage.loadSession(offlineSessionId);
      let shopifyApi = new ShopifyApiLib(session, this.api);

      try {
        let sinceId = 0;
        while (true) {
          let params = {};
          params['since_id'] = sinceId;
          if (lastSyncTime) {
            params['updated_at_min'] = lastSyncTime;
          }

          let result = await shopifyApi.apiGet('price_rules', params);
          if (!result.price_rules.length) {
            break;
          }
          //记录开始获取数据的时间,作为下一个任务的开始时间
          !is_all_sync &&
            (await this.redis.set(`${shopInfo['id']}-` + redisKey, dayjs().tz('UTC').format(), 'EX', 2 * 24 * 60 * 60));
          let addPriceRules = result.price_rules;
          let addData = [];
          let updateData = [];
          //从数据库中查询已经存在的discount记录
          let discountList = await discountRspt.findBy({ shopify_id: In(addPriceRules.map(item => item.id)) });
          if (discountList.length) {
            addPriceRules.forEach(item =>
              discountList.forEach(discount => {
                if (discount.shopify_id == item.id) {
                  updateData.push({
                    ...discount,
                    ...item,
                    id: discount.id,
                    shopify_id: item.id,
                    shopify_created_at: item.created_at,
                    shopify_updated_at: item.updated_at
                  });
                }
              })
            );
            addPriceRules = addPriceRules.filter(item => !discountList.some(discount => discount.shopify_id == item.id));
          }

          for (let priceRule of addPriceRules) {
            let discount = new DiscountEntity();
            discount = {
              ...discount,
              ...priceRule,
              id: undefined,
              created_at: undefined,
              updated_at: undefined,
              sync_time: null,
              shopify_id: priceRule.id,
              shopify_created_at: priceRule.created_at,
              shopify_updated_at: priceRule.updated_at,
              shop_id: shopInfo['id'],
              shop_domain: shopInfo['shopify_domain'],
              is_bulk_discount: false,
              set_discount_variant: false
            };
            addData.push(discount);
          }
          //增加事务处理
          await discountRspt.save(addData);
          await discountRspt.save(updateData);
          sinceId = result.price_rules[result.price_rules.length - 1]['id'];
        }
      } catch (e) {
        console.log(e);
      }
    }
    await ToolsLib.unLock(this.redis, `${shopInfo['shopify_id']}-` + redisKey);
    return true;
  }

  async deleteDiscount(shop: ShopEntity) {
    const offlineSessionId = this.api.session.getOfflineId(shop.shopify_domain);
    let session = await this.sessionStorage.loadSession(offlineSessionId);
    if (!session) {
      return;
    }
    let discountModel = new DiscountModel(this.database);
    let client = new ShopifyApiLib(session, this.api);
    let lastDiscountDelEventTime =
      (await this.redis.get('last-get-discount-del-event-time' + shop['shopify_id'])) || dayjs().subtract(2, 'day').format();
    try {
      while (true) {
        let result = await client.apiGet('/events', {
          limit: 250,
          created_at_min: lastDiscountDelEventTime,
          verb: 'destroy',
          filter: 'PriceRule'
        });
        const events = result.events;
        for (let event of events) {
          let discountInfo = await discountModel.getDiscountInfo({ shopify_id: event.subject_id });
          discountInfo && (await discountModel.deleteDiscount(discountInfo));
        }
        if (events.length > 0) {
          await this.redis.set(
            'last-get-discount-del-event-time' + shop['shopify_id'],
            dayjs(events[events.length - 1].created_at)
              .add(1, 'second')
              .format(),
            'EX',
            2 * 24 * 60 * 60
          );
          lastDiscountDelEventTime = dayjs(events[events.length - 1].created_at)
            .add(1, 'second')
            .format();
        }
        if (events.length < 250) break;
      }
    } catch (e) {
      console.log(e);
    }

    await ToolsLib.unLock(this.redis, 'DELETE_DISCOUNT_FREQUENCE_LIMIT_KEY' + shop['shopify_id']);
    return true;
  }
  async createDiscountEvent(shop: ShopEntity) {
    const offlineSessionId = this.api.session.getOfflineId(shop.shopify_domain);
    let session = await this.sessionStorage.loadSession(offlineSessionId);
    if (!session) {
      return;
    }
    let client = new ShopifyApiLib(session, this.api);
    let lastDiscountDelEventTime =
      (await this.redis.get(CREATE_DISCOUNT_EVENT_JOB + '_time' + shop['shopify_id'])) || dayjs().subtract(2, 'day').format();
    try {
      while (true) {
        let result = await client.apiGet('/events', {
          limit: 250,
          created_at_min: lastDiscountDelEventTime,
          verb: 'create',
          filter: 'PriceRule'
        });
        const events = result.events;
        for (let event of events) {
          await this.redis.lpush(WAIT_SYNC_DISCOUNT_LIST + shop['shopify_id'], event.subject_id);
        }
        if (events.length > 0) {
          await this.redis.set(
            CREATE_DISCOUNT_EVENT_JOB + '_time' + shop['shopify_id'],
            dayjs(events[events.length - 1].created_at)
              .add(1, 'second')
              .format(),
            'EX',
            2 * 24 * 60 * 60
          );
          lastDiscountDelEventTime = dayjs(events[events.length - 1].created_at)
            .add(1, 'second')
            .format();
        }
        if (events.length < 250) break;
      }
    } catch (e) {
      console.log(e);
    }
    await ToolsLib.unLock(this.redis, CREATE_DISCOUNT_EVENT_JOB + shop['shopify_id']);
    return true;
  }
  async updateDiscountEvent(shop: ShopEntity) {
    const offlineSessionId = this.api.session.getOfflineId(shop.shopify_domain);
    let session = await this.sessionStorage.loadSession(offlineSessionId);
    if (!session) {
      return;
    }
    let client = new ShopifyApiLib(session, this.api);
    let lastDiscountDelEventTime =
      (await this.redis.get(UPDATE_DISCOUNT_EVENT_JOB + '_time' + shop['shopify_id'])) || dayjs().subtract(2, 'day').format();
    try {
      while (true) {
        let result = await client.apiGet('/events', {
          limit: 250,
          created_at_min: lastDiscountDelEventTime,
          verb: 'update',
          filter: 'PriceRule'
        });
        const events = result.events;
        for (let event of events) {
          //和create公用一个就可以了,不管是创建还是更新，都需要判断数据库存不存在，而且异步拉取也是一样的接口
          await this.redis.lpush(WAIT_SYNC_DISCOUNT_LIST + shop['shopify_id'], event.subject_id);
        }
        if (events.length > 0) {
          await this.redis.set(
            UPDATE_DISCOUNT_EVENT_JOB + '_time' + shop['shopify_id'],
            dayjs(events[events.length - 1].created_at)
              .add(1, 'second')
              .format(),
            'EX',
            2 * 24 * 60 * 60
          );
          lastDiscountDelEventTime = dayjs(events[events.length - 1].created_at)
            .add(1, 'second')
            .format();
        }
        if (events.length < 250) break;
      }
    } catch (e) {
      console.log(e);
    }
    await ToolsLib.unLock(this.redis, UPDATE_DISCOUNT_EVENT_JOB + shop['shopify_id']);
    return true;
  }
  async getDiscountFromShopifyById(jobData: { shopify_shop_id: number; discount_shopify_id }) {
    let shopRspt = this.database.getRepository(ShopEntity);
    let discountRspt = this.database.getRepository(DiscountEntity);
    let shopInfo = await shopRspt.findOneBy({
      shopify_id: jobData.shopify_shop_id
    });

    if (shopInfo && shopInfo['shopify_token']) {
      const offlineSessionId = this.api.session.getOfflineId(shopInfo.shopify_domain);
      let session = await this.sessionStorage.loadSession(offlineSessionId);
      let shopifyApi = new ShopifyApiLib(session, this.api);
      try {
        let result = await shopifyApi.apiGet('price_rules/' + jobData.discount_shopify_id, {});
        let priceRule = result.price_rule;
        if (!priceRule) {
          return true;
        }
        let discountInfo = await discountRspt.findOne({
          where: { shopify_id: priceRule.id }
        });
        let saveData: DiscountEntity = null;
        //从数据库中查询已经存在的discount记录
        if (discountInfo) {
          saveData = {
            ...discountInfo,
            ...priceRule,
            id: discountInfo.id,
            shopify_id: priceRule.id,
            shopify_created_at: priceRule.created_at,
            shopify_updated_at: priceRule.updated_at
          };
        } else {
          saveData = new DiscountEntity();
          saveData = {
            ...saveData,
            ...priceRule,
            id: undefined,
            created_at: undefined,
            updated_at: undefined,
            sync_time: null,
            shopify_id: priceRule.id,
            shopify_created_at: priceRule.created_at,
            shopify_updated_at: priceRule.updated_at,
            shop_id: shopInfo['id'],
            shop_domain: shopInfo['shopify_domain'],
            is_bulk_discount: false,
            set_discount_variant: false
          };
        }
        //增加事务处理
        await discountRspt.save(saveData);
      } catch (e) {
        console.log(e);
      }
    }
    return true;
  }
  async asyncDiscountVariantMetafields(shopInfo: ShopEntity) {
    const METAFIELD_KEY = 'ws-discount-info';
    let discountVariantModel = new DiscountVariantModel(this.database);
    let discountVariantLogModel = new DiscountVariantLogModel(this.database);
    let productModel = new ProductModel(this.database);
    const offlineSessionId = this.api.session.getOfflineId(shopInfo['shopify_domain']);
    let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
    let shopifyGraphql = new ShopifyGraphQLLib(session, this.api);
    let shopifyApi = new ShopifyApiLib(session, this.api);
    //获取所有未写入metafield的shopify_variant_id
    let shopifyVariantIds = await discountVariantModel.getNotWriteMetaifieldVariantShopifyIds(shopInfo['id']);
    if (!shopifyVariantIds.length) {
      await ToolsLib.unLock(this.redis, REDIS_CACHE_KEY_PREFIX + shopInfo['shopify_id']);
    }
    //根据variant id 查询所有记录
    let discountVariants = await discountVariantModel.getListVariantShopifyIds(shopifyVariantIds);
    //获取所有产品列表
    let productList = await productModel.getListByShopifyIds(discountVariants.map(item => item.shopify_product_id));
    let discountVariantObjs: { [shopifyVariantId: number]: DiscountVariantEntity[] } = {};
    for (let discountVariant of discountVariants) {
      let shopifyVariantId = discountVariant['shopify_variant_id'];
      if (discountVariantObjs[shopifyVariantId]) {
        discountVariantObjs[shopifyVariantId].push(discountVariant);
      } else {
        discountVariantObjs[shopifyVariantId] = [discountVariant];
      }
    }
    for (let shopifyVariantId in discountVariantObjs) {
      let discountVariants = discountVariantObjs[shopifyVariantId];
      //随机获取其中没有超过最大折扣的记录，作为初始计算的值
      let maxDiscountVariant = discountVariants.find(
        item =>
          parseFloat(`${item.percentage_sort_key}`) < parseFloat(`${shopInfo['extend']?.shop_discount_threshold_value || 50}`)
      );
      let date = new Date();
      //如果没有找到
      if (!maxDiscountVariant) {
        //找不到的时候则将所有的都设置为已经同步并且都设置为不是最大值
        //如果有设置了最大值的则要删除对应的metafields
        let delDiscountVariant = discountVariants.find(item => item.is_max_discount && item.metafield_shopify_id);
        if (delDiscountVariant) {
          let productInfo = productList.find(item => item.shopify_id == delDiscountVariant['shopify_product_id']);
          await shopifyApi.apiDelete(
            `variants/${delDiscountVariant.shopify_variant_id}/metafields/${delDiscountVariant.metafield_shopify_id}`
          );
          let tags = productInfo ? (productInfo.tags || '').split(',') : [];
          let index = tags.findIndex(item => item == DISCOUNT_PRODUCT_TAG);
          if (index !== -1) {
            tags.splice(index, 1);
            await shopifyApi.apiPut({
              path: `products/${productInfo['shopify_id']}`,
              type: DataType.JSON,
              data: {
                product: {
                  id: productInfo['shopify_id'],
                  tags: tags.length ? tags.join(',') : ''
                }
              }
            });
          }
        }
        await discountVariantModel.discountVariantRspt.update(
          { id: In(discountVariants.map(item => item.id)) },
          { metafield_shopify_id: null, is_max_discount: false, async_time: date }
        );
        continue;
      }
      maxDiscountVariant = discountVariants.reduce((max, val) => {
        if (
          parseFloat(`${val.fixed_value}`) > parseFloat(`${max.fixed_value}`) &&
          parseFloat(`${val.percentage_sort_key}`) < parseFloat(`${shopInfo['extend']?.shop_discount_threshold_value || 50}`)
        ) {
          console.log('val', val.fixed_value);
          return val;
        } else {
          console.log('max', val.fixed_value, max.fixed_value);
          return max;
        }
      }, maxDiscountVariant);
      if (maxDiscountVariant['is_max_discount']) {
        discountVariantModel.discountVariantRspt.update(
          { id: In(discountVariants.map(item => item.id)), async_time: IsNull() },
          { async_time: new Date() }
        );
        continue;
      }
      //将最大值写入到variant metafield中

      let product = productList.find(product => product.shopify_id == maxDiscountVariant['shopify_product_id']);
      let tags = product['tags'] ? product['tags'].split(',') : [];
      let minorDiscountVariants = discountVariants.filter(item => item.id != maxDiscountVariant.id);
      try {
        let path = `variants/${maxDiscountVariant.shopify_variant_id}/metafields`;
        let metafieldValue = JSON.stringify({
          variant_shopify_id: maxDiscountVariant.shopify_variant_id,
          variant_price: maxDiscountVariant.variant_price,
          product_shopify_id: maxDiscountVariant.shopify_product_id,
          title: maxDiscountVariant.title,
          starts_at: dayjs(maxDiscountVariant.starts_at).tz(shopInfo['iana_timezone']).format(),
          ends_at: maxDiscountVariant.ends_at ? dayjs(maxDiscountVariant.ends_at).tz(shopInfo['iana_timezone']).format() : null,
          value_type: maxDiscountVariant.value_style,
          value: maxDiscountVariant.value,
          shopify_domain: maxDiscountVariant.discount.shop_domain,
          currency: shopInfo.currency,
          shop_discount_threshold_value: shopInfo.extend?.['shop_discount_threshold_value'] || 50,
          fixed_value: maxDiscountVariant.fixed_value,
          value_style: maxDiscountVariant.value_style,
          variant_price4wscode: maxDiscountVariant.variant_price4wscode,
          currency_symbol: maxDiscountVariant.currency_symbol,
          fixed_amount_sort_key: maxDiscountVariant.fixed_amount_sort_key,
          percentage_sort_key: maxDiscountVariant.percentage_sort_key,
          timezone: shopInfo.iana_timezone,
          starts_at_with_timezone: dayjs.tz(maxDiscountVariant.starts_at, shopInfo.iana_timezone).format(),
          ends_at_with_timezone: maxDiscountVariant.ends_at
            ? dayjs.tz(maxDiscountVariant.ends_at, shopInfo.iana_timezone).format()
            : null
        });
        let result = await shopifyApi.apiPost({
          path: path,
          type: DataType.JSON,
          data: {
            metafield: {
              namespace: APP_COMMON_NAMESPACE,
              key: METAFIELD_KEY,
              type: 'json',
              value: metafieldValue
            }
          }
        });

        if (!tags.includes(DISCOUNT_PRODUCT_TAG)) {
          tags.push(DISCOUNT_PRODUCT_TAG);
          await shopifyApi.apiPut({
            path: `products/${product['shopify_id']}`,
            type: DataType.JSON,
            data: {
              product: {
                id: product['shopify_id'],
                tags: tags.length ? tags.join(',') : ''
              }
            }
          });
        }

        let metafield = result.body.metafield;
        await shopifyGraphql.graphOfflineQL(metafieldStorefrontVisibilityCreate, {
          input: {
            ownerType: 'PRODUCTVARIANT',
            key: METAFIELD_KEY,
            namespace: APP_COMMON_NAMESPACE
          }
        });
        //更改最大的数据
        await discountVariantModel.discountVariantRspt.update(
          { id: maxDiscountVariant['id'] },
          { metafield_shopify_id: metafield.id, is_max_discount: true, async_time: date }
        );

        //保存日志方便后续追查
        await discountVariantLogModel.discountVariantLogRspt.save({
          ...new DiscountVariantLogEntity(),
          ...maxDiscountVariant,
          operate_type: 'create'
        });

        minorDiscountVariants.length &&
          (await discountVariantModel.discountVariantRspt.update(
            { id: In(minorDiscountVariants.map(item => item.id)) },
            { metafield_shopify_id: null, is_max_discount: false, async_time: date }
          ));
      } catch (e) {
        console.log('set product metafield-------------' + maxDiscountVariant.id, e);
        if (e.code && e.code == 404) {
          await discountVariantModel.discountVariantRspt.update(
            { id: maxDiscountVariant['id'] },
            { is_max_discount: true, async_time: date, extend: { sync_error: e.message || 'sync error!' } }
          );
          minorDiscountVariants.length &&
            (await discountVariantModel.discountVariantRspt.update(
              { id: In(minorDiscountVariants.map(item => item.id)) },
              {
                metafield_shopify_id: null,
                is_max_discount: false,
                async_time: date,
                extend: { sync_error: e.message || 'sync error!' }
              }
            ));
        }
      }
    }
    await ToolsLib.unLock(this.redis, REDIS_CACHE_KEY_PREFIX + shopInfo['shopify_id']);
    return true;
  }
}
