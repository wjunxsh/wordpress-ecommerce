import { BulkCodeWorker } from './bulk-code.worker';
import { ProductWorker } from './product.worker';
import { BULK_CODE_QUEUE_SUFFIX } from '../lib/variable';
import { Job } from 'bullmq';
import { WorkerQueueBasis } from './wooker-queue-basic';
import { WorkerInterface } from './interface';
import { DiscountWorker } from './discount.worker';
const workerList = [ProductWorker, BulkCodeWorker, DiscountWorker];
export class WorkerClass extends WorkerQueueBasis {
  constructor(bootstrap: WorkerInterface) {
    super(bootstrap, BULK_CODE_QUEUE_SUFFIX);
    this.initial();
  }

  async initial() {
    this.initialize(this.process.bind(this));
  }
  async process(job: Job<any, any, string>) {
    for (let worker of workerList) {
      new worker({
        redis: this.redis,
        database: this.database,
        api: this.api,
        logger: this.logger,
        sessionStorage: this.sessionStorage
      }).process(job);
    }
    return true;
  }
}
