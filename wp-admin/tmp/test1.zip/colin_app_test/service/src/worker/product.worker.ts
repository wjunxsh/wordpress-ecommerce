import { WorkerBasis } from './wooker-basis';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ShopModel } from '../model/shop.model';
import { DataType, Session } from '@shopify/shopify-api';
import { ProductEntity } from '../entity/product.entity';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { ProductModel } from '../model/product.model';
import { VariantModel } from '../model/variant.model';
import { VariantEntity } from '../entity/variant.entity';
import { ProductTagLogModel } from '../model/product.tag.log.model';
import { DiscountProductTagLogEntity } from '../entity/product.discount.tag.log.entity';
import { DiscountProductTagEntity } from '../entity/product.discount.tag.entity';
import { ProductTagModel } from '../model/product.tag.model';
import { Not } from 'typeorm';
import { WorkerInterface } from './interface';
import { Job } from 'bullmq';
import { DEL_PRODUCT_DISCOUNT_TAG, SYNC_PRODUCT_KEY, UPDATE_PRODUCT_DISCOUNT_TAG } from '../lib/variable';
import { DiscountVariantModel } from '../model/discount.variant.model';
import { ToolsLib } from '../lib/tools.lib';
import { ShopEntity } from '../entity/shop.entity';
dayjs.extend(utc);
dayjs.extend(timezone);
export class ProductWorker extends WorkerBasis {
  shopModel: ShopModel;
  productModel: ProductModel;
  variantModel: VariantModel;
  constructor(bootstrap: WorkerInterface) {
    super(bootstrap);
    this.shopModel = new ShopModel(this.database);
    this.productModel = new ProductModel(this.database);
    this.variantModel = new VariantModel(this.database);
  }
  async process(job: Job<any, any, string>) {
    switch (job.name) {
      case SYNC_PRODUCT_KEY:
        return await this.getProductFromShopify(job.data);
      case UPDATE_PRODUCT_DISCOUNT_TAG:
        return await this.setProductDiscountTag(job.data);
      case DEL_PRODUCT_DISCOUNT_TAG:
        return await this.delProductDiscountTag(job.data);
      default:
        return true;
    }
  }
  async getProductFromShopify(shopInfo: ShopEntity) {
    const offlineSessionId = this.api.session.getOfflineId(shopInfo['shopify_domain']);
    let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
    if (!session) {
      console.log('session is null', session, shopInfo);
      return true;
    }
    let apiClient = new ShopifyApiLib(session, this.api);
    let discountVariantModel = new DiscountVariantModel(this.database);
    let sinceId: number = 0;
    try {
      // let result: { data: ProductEntity[] } = await this.api.rest.Product.all({ session, since_id: sinceId, limit: 5 });
      //获取所有产品
      while (true) {
        let result = await apiClient.apiGet(`products`, {
          since_id: sinceId,
          limit: 100
        });
        let products: ProductEntity[] = result.products;

        if (!products?.length) {
          break;
        }
        sinceId = products[products.length - 1]['id'];
        let shopifyProductIds = products.map(item => item.id);
        let productList = await this.productModel.getListByShopifyIdsWidthDeleted(shopifyProductIds);
        let addProducts: ProductEntity[] = products;
        let updateProducts: ProductEntity[] = [];
        if (productList.length) {
          addProducts = products.filter(product => !productList.some(item => item.shopify_id == product.id));
          updateProducts = products.filter(product =>
            productList.some(
              item => item.shopify_id == product.id && dayjs(item.shopify_updated_at).unix() != dayjs(product.updated_at).unix()
            )
          );
        }
        if (addProducts.length) {
          for (let product of addProducts) {
            let variants = product.variants;
            let productInfo = await this.productModel.save({
              ...product,
              id: 0,
              shopify_id: product.id,
              shop_id: shopInfo['id'],
              shopify_created_at: product.created_at,
              shopify_updated_at: product.updated_at
            });
            await this.variantModel.multSave(
              variants.map(variant => {
                let variantData = new VariantEntity();
                return {
                  ...variantData,
                  ...variant,
                  id: 0,
                  product_id: productInfo.id,
                  shopify_product_id: productInfo.shopify_id,
                  shop_id: shopInfo['id'],
                  shopify_id: variant.id,
                  shopify_created_at: product.created_at,
                  shopify_updated_at: product.updated_at
                };
              })
            );
          }
        }
        if (updateProducts.length) {
          for (let product of updateProducts) {
            let productInfo = productList.find(item => item.shopify_id == product.id);
            await this.productModel.save({
              ...product,
              id: productInfo.id,
              shopify_id: product.id,
              deleted_at: null,
              shop_id: shopInfo['id'],
              shopify_created_at: product.created_at,
              shopify_updated_at: product.updated_at
            });
            let variants = product.variants;
            if (variants && variants.length) {
              //获取当前已经存在的variant
              let variantList = productInfo.variants;
              //如果variant已经被删除，则也物理删除
              let variantShopifyIds = variants.map(variant => variant.id);
              variantList = variantList.filter(variant => !variantShopifyIds.includes(parseInt(`${variant['shopify_id']}`)));
              if (variantList.length) {
                await this.variantModel.multDeleteByIds(variantList.map(item => item.id));
              }
              await this.variantModel.insertOrUpdate(
                variants.map(variant => {
                  let variantData = new VariantEntity();
                  return {
                    ...variantData,
                    ...variant,
                    id: 0,
                    shopify_id: variant.id,
                    product_id: productInfo.id,
                    shopify_product_id: productInfo.shopify_id,
                    shop_id: shopInfo['id'],
                    shopify_created_at: variant.created_at,
                    shopify_updated_at: variant.updated_at
                  };
                })
              );
              discountVariantModel.updateDiscountVariantByProductId(product.id);
            }
          }
        }
      }
    } catch (e) {
      console.log(e);
    }
    await ToolsLib.unLock(this.redis, 'sync-products-limit' + shopInfo['shopify_id']);
    return true;
  }

  async setProductDiscountTag({
    shopify_domain,
    shopify_product_ids,
    product_tag,
    discount_id
  }: {
    shop_id: number;
    shop_shopify_id: number;
    shopify_product_ids: number[];
    product_tag: string;
    shopify_domain: string;
    discount_id: number;
  }) {
    //或产品判断产品是否包含某个tag
    let productTagLogModel = new ProductTagLogModel(this.database);
    let productTagModel = new ProductTagModel(this.database);
    let productList = await this.productModel.getListByShopifyIds(shopify_product_ids);
    const offlineSessionId = this.api.session.getOfflineId(shopify_domain);
    let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
    let apiClient = new ShopifyApiLib(session, this.api);
    for (let product of productList) {
      //防止产品有变更，部分产品删除，则对应的tag也要删掉
      let tags = product['tags'] ? product['tags'].split(',') : [];
      try {
        if (!tags.includes(product_tag)) {
          tags.push(product_tag);
          await apiClient.apiPut({
            path: `products/${product['shopify_id']}`,
            type: DataType.JSON,
            data: {
              product: {
                id: product['shopify_id'],
                tags: tags.length ? tags.join(',') : ''
              }
            }
          });
        }
        let logData = new DiscountProductTagLogEntity();
        logData = {
          ...logData,
          shop_id: product['shop_id'],
          product_id: product['id'],
          change_tag: product_tag,
          discount_id: discount_id,
          tags: tags.join(','),
          product_shopify_id: product['shopify_id'],
          operate_type: 'add'
        };
        let tagData = new DiscountProductTagEntity();
        tagData = {
          ...tagData,
          shop_id: product['shop_id'],
          product_id: product['id'],
          change_tag: product_tag,
          discount_id: discount_id,
          tags: tags.join(','),
          product_shopify_id: product['shopify_id']
        };
        await productTagLogModel.productTagLogRspt.save(logData);
        await productTagModel.productTagRspt
          .createQueryBuilder()
          .insert()
          .into(DiscountProductTagEntity)
          .values([logData])
          .orUpdate(
            ['shop_id', 'product_id', 'change_tag', 'discount_id', 'tags', 'product_shopify_id'],
            ['product_id', 'discount_id', 'change_tag']
          )
          .execute();

        //将产品tag的更新日志保存到数据库中，方便后期排查问题
      } catch (e) {
        console.log(e);
      }
    }
    await this.unLock('set-product-discount-tag' + discount_id);
    return true;
  }

  async delProductDiscountTag({
    shopify_domain,
    product_tag,
    discount_id
  }: {
    shop_id: number;
    shop_shopify_id: number;
    product_tag: string;
    shopify_domain: string;
    discount_id: number;
  }) {
    //或产品判断产品是否包含某个tag
    let productTagLogModel = new ProductTagLogModel(this.database);
    let productTagModel = new ProductTagModel(this.database);
    let tagList = await productTagModel.productTagRspt.find({
      where: { discount_id: discount_id, change_tag: product_tag }
    });
    if (!tagList.length) {
      await this.unLock('del-product-discount-tag' + discount_id);
      return;
    }
    let productList = await this.productModel.getListByShopifyIds(tagList.map(item => item.product_shopify_id));
    const offlineSessionId = this.api.session.getOfflineId(shopify_domain);
    let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
    let apiClient = new ShopifyApiLib(session, this.api);
    for (let product of productList) {
      let tags = product['tags'] ? product['tags'].split(',') : [];
      //判断是否还有其他活动存在此tag
      let tagList = await productTagModel.productTagRspt.find({
        where: { discount_id: Not(discount_id), product_id: product['id'], change_tag: product_tag }
      });
      if (!tagList.length) {
        try {
          let index = tags.findIndex(item => item == product_tag);
          if (index !== -1) {
            tags.splice(index, 1);
            await apiClient.apiPut({
              path: `products/${product['shopify_id']}`,
              type: DataType.JSON,
              data: {
                product: {
                  id: product['shopify_id'],
                  tags: tags.length ? tags.join(',') : ''
                }
              }
            });
          }
          let logData = new DiscountProductTagLogEntity();
          logData = {
            ...logData,
            shop_id: product['shop_id'],
            product_id: product['id'],
            change_tag: product_tag,
            discount_id: discount_id,
            tags: tags.join(','),
            product_shopify_id: product['shopify_id'],
            operate_type: 'del'
          };
          await productTagModel.productTagRspt.delete({
            discount_id: discount_id,
            product_id: product['id'],
            change_tag: product_tag
          });
          await productTagLogModel.productTagLogRspt.save(logData);
          //将产品tag的更新日志保存到数据库中，方便后期排查问题
        } catch (e) {
          console.log(e);
        }
      }
    }
    await this.unLock('del-product-discount-tag' + discount_id);
    return true;
  }
  async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  async unLock(key) {
    if (this.redis.get(`setnx-${key}`)) {
      this.redis.del(`setnx-${key}`);
    }
  }
}
