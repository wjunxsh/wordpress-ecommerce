import * as cron from 'node-cron';
import { Job, Worker, WorkerOptions } from 'bullmq';
import { ShopEntity } from '../entity/shop.entity';
import { WorkerBasis } from './wooker-basis';
import { WorkerInterface } from './interface';
import { MoreThan } from 'typeorm';
export class WorkerQueueBasis extends WorkerBasis {
  public workerList: { shop_id: number; handle: Worker }[] = [];
  public queueSufix: string;
  constructor(bootstrap: WorkerInterface, queueSufix: string) {
    super(bootstrap);
    this.queueSufix = queueSufix;
    this.database = bootstrap.database;
    this.redis = bootstrap.redis;
    this.logger = bootstrap.logger;
    this.api = bootstrap.api;
    this.sessionStorage = bootstrap.sessionStorage;
  }
  async initialize(callback: (job: Job<any, any, string>) => Promise<Boolean>) {
    await this.createShopWorker(callback);
    cron.schedule('*/20 * * * * *', () => {
      this.createShopWorker(callback, true);
    });
    cron.schedule('*/20 * * * * *', () => {
      this.deleteUnvisibleWorker();
    });
  }
  async createShopWorker(callback: (job: Job<any, any, string>) => Promise<Boolean>, isAdded: boolean = false) {
    //获取有效的所有店铺
    let shopRspt = this.database.getRepository(ShopEntity);
    let date = new Date(new Date().getTime() - 60 * 10 * 1000);
    let where = { state: 1 };
    if (isAdded) {
      where['updated_at'] = MoreThan(date);
    }
    let shopList: ShopEntity[] = [];

    shopList = await shopRspt.find({ where });
    if (shopList.length) {
      for (let shop of shopList) {
        console.log(shop.id);
        this.createWorker(`${shop.shopify_id}-${this.queueSufix}`, callback, shop.id, {});
      }
    }
  }

  public async deleteUnvisibleWorker() {
    //获取有效的所有店铺
    let shopRspt = this.database.getRepository(ShopEntity);
    let date = new Date(new Date().getTime() - 60 * 10 * 1000);
    let shopList = await shopRspt.find({
      where: { state: 0, updated_at: MoreThan(date) }
    });
    if (shopList.length) {
      for (let shop of shopList) {
        this.deleteWorker(shop.id);
      }
    }
  }
  public async createWorker(
    keyName: string,
    callback: (job: Job<any, any, string>) => {},
    shopId: number,
    workOptions: WorkerOptions
  ) {
    for (let worker of this.workerList) {
      if (worker.shop_id === shopId) {
        return true;
      }
    }
    let worker = new Worker(
      keyName,
      async (job: Job<any, any, string>) => {
        callback(job);
      },
      {
        concurrency: process.env.MODE === 'DEV' ? 4 : 2,
        limiter: {
          max: 2,
          duration: 1000
        },
        connection: this.redis,
        ...workOptions
      }
    );
    this.workerList.push({
      shop_id: shopId,
      handle: worker
    });
    //成功后将job直接删除掉
    this.workerList[this.workerList.length - 1].handle.on('completed', this.succCallback.bind(this));
    this.workerList[this.workerList.length - 1].handle.on('failed', this.failedCallback.bind(this));
  }
  async deleteWorker(shopId: number) {
    if (!this.workerList.length) {
      return false;
    }
    let deleteIndex = -1;
    for (let i = 0, count = this.workerList.length; i < count; i++) {
      let worker = this.workerList[i];
      if (worker.shop_id == shopId) {
        deleteIndex = i;
        break;
      }
    }
    if (deleteIndex !== -1) {
      await this.workerList[deleteIndex].handle.close();
      this.workerList.splice(deleteIndex, 1);
    }
  }
  async failedCallback(job: Job<any, any, string>) {
    await job.remove();
  }
  async succCallback(job: Job<any, any, string>) {
    await job.remove();
  }
}
