import { WorkerBasis } from './wooker-basis';
import { BulkCodesSettingEntity } from '../entity/bulk-code-setting';
import { ShopEntity } from '../entity/shop.entity';
import { BulkCodeLib } from '../lib/bulk-code.lib';
import { DataType } from '@shopify/shopify-api';
import { DiscountBulkCodeEntity } from '../entity/discount-bulk-code';
import { In, IsNull } from 'typeorm';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { DiscountEntity } from '../entity/discount.entity';
import {
  SYNC_CODE_FROM_SHOPIFY,
  SYNC_CODE_TO_SHOPIFY,
  SYNC_DISCOUNT_CODE_FROM_SHOPIFY,
  UPDATE_DISCOUNT
} from '../lib/variable';
import { DiscountModel } from '../model/discount.mode';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { WorkerInterface } from './interface';
import { Job } from 'bullmq';
dayjs.extend(utc);
dayjs.extend(timezone);
export class BulkCodeWorker extends WorkerBasis {
  constructor(bootstrap: WorkerInterface) {
    super(bootstrap);
  }
  async process(job: Job<any, any, string>) {
    switch (job.name) {
      case SYNC_CODE_TO_SHOPIFY:
        return await this.syncBulkCodeToShopify(job.data);
      case SYNC_CODE_FROM_SHOPIFY:
        console.log('========sync code fom shopify=======');
        return await this.syncCodeFromShopify(job.data);
      case SYNC_DISCOUNT_CODE_FROM_SHOPIFY:
        return await this.syncDiscountCodeFromShopify(job.data);
      default:
        return true;
    }
  }

  /**
   * @deprecated The method should not be used，此方法已经通过直接删除接口替代
   */
  async syncUpdateDiscountFromShopify(data: DiscountEntity) {
    //从shopify获取
    let shop = data.shop;
    if (!shop || !shop.shopify_token) {
      return true;
    }
    const offlineSessionId = this.api.session.getOfflineId(shop.shopify_domain);
    let session = await this.sessionStorage.loadSession(offlineSessionId);
    let discountRspt = this.database.getRepository(DiscountEntity);
    let discountModel = new DiscountModel(this.database);
    let client = new ShopifyApiLib(session, this.api);
    try {
      let result = await client.apiGet(`price_rules/${data.shopify_id}`, {});
      let saveData = {
        ...data,
        ...result.price_rule
      };
      //如果活动有更新，则设置参数set_discount_variant，重新计算最大的活动写入meitafield
      if (result.price_rule.updated_at == data.shopify_updated_at) {
        saveData.set_discount_variant = false;
      }

      saveData.id = data.id;
      delete saveData.shop;
      result = await discountRspt.save(saveData);
    } catch (e) {
      if (e.code == 404) {
        await discountModel.deleteDiscount(data);
        //将所有的code进行物理删除，有时候业务建单建错了，重新建立的时候发现建立不了，主要原因是由于code，被占用
        //物理删除前将code 备份到备份表中
      }
    }
    await this.unLock(`${data['shopify_id']}-${UPDATE_DISCOUNT}`);
    return true;
  }
  //根据discount id 将code 同步到shopify
  async syncBulkCodeToShopify(data: any) {
    //通过discount 将code 同步到数据库
    let discountRspt = this.database.getRepository(DiscountEntity);
    let shopRspt = this.database.getRepository(ShopEntity);
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let shopInfo = await shopRspt.findOneBy({
      shopify_id: data.shopify_shop_id
    });
    if (!shopInfo || !shopInfo.shopify_token) {
      return true;
    }
    let discountInfo = await discountRspt.findOneBy({ id: data.discount_id });
    //获取所有未同步到shopify的数据
    let codeList = await bulkCodesRspt.find({
      where: {
        discount_id: data.discount_id,
        sync_at: IsNull(),
        shopify_id: IsNull()
      },
      take: 10000
    });
    if (codeList.length === 0 || !discountInfo) {
      await this.unLock(`${data.discount_id}-${SYNC_CODE_TO_SHOPIFY}`);
      return true;
    }
    const offlineSessionId = this.api.session.getOfflineId(shopInfo.shopify_domain);
    let session = await this.sessionStorage.loadSession(offlineSessionId);
    let syncCodes: DiscountBulkCodeEntity[] = [];
    let shopifyApi = new ShopifyApiLib(session, this.api);
    while (codeList.length) {
      if (codeList.length > 100) {
        syncCodes = codeList.splice(0, 100);
      } else {
        syncCodes = codeList;
        codeList = [];
      }
      try {
        let result = await shopifyApi.apiPost({
          path: `price_rules/${discountInfo['shopify_id']}/batch`,
          type: DataType.JSON,
          data: {
            discount_codes: syncCodes.map(item => ({
              code: item.code
            }))
          }
        });
        let batch_id = result.body.discount_code_creation.id;
        let date = result.body.discount_code_creation.created_at;
        syncCodes.forEach(item => {
          item.sync_at = date;
          item.batch_id = batch_id;
        });
        await bulkCodesRspt.update({ id: In(syncCodes.map(item => item.id)) }, { sync_at: date, batch_id: batch_id });
      } catch (e) {
        console.log(e);
        if (e.code == 422 && e.message && e.message.discount_codes && e.message.discount_codes.length == 0) {
          continue;
        }
        //await discountRspt.softRemove(discountInfo);

        break;
      }
    }
    await this.unLock(`${data.discount_id}-${SYNC_CODE_TO_SHOPIFY}`);
    return true;
  }
  async syncCodeFromShopify(jobData: any) {
    let shopRspt = this.database.getRepository(ShopEntity);
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let discountRspt = this.database.getRepository(DiscountEntity);
    if (!jobData.shopify_shop_id) {
      return true;
    }
    let shopInfo = await shopRspt.findOneBy({
      shopify_id: jobData.shopify_shop_id
    });
    let redisKey = `${shopInfo['shopify_id']}-${SYNC_CODE_FROM_SHOPIFY}`;
    if (!shopInfo || !shopInfo.shopify_token) {
      await this.unLock(redisKey);
      return true;
    }
    //根据店铺id 获取所有discountInfo
    let discountList = await bulkCodesRspt
      .createQueryBuilder('bc')
      .groupBy('discount_id,discount_shopify_id,shop_id')
      .select('discount_id as id,discount_shopify_id as shopify_id,shop_id')
      .where({
        shopify_id: IsNull(),
        shop_id: shopInfo['id']
      })
      .andWhere('batch_id is not null and batch_id != 0')
      .andWhere({ sync_error: IsNull() })
      .execute();
    //({where:{shop_id: shopInfo['id'], shopify_id: IsNull()},take:5000,skip:0});
    if (discountList.length == 0) {
      await this.unLock(redisKey);
      return true;
    }
    const offlineSessionId = this.api.session.getOfflineId(shopInfo.shopify_domain);
    let session = await this.sessionStorage.loadSession(offlineSessionId);
    let apiClient = new ShopifyApiLib(session, this.api);
    for (let discountInfo of discountList) {
      let params: { limit: number; page_info?: string } = { limit: 250 };
      while (true) {
        let result = await apiClient.apiGetAllRes(`price_rules/${discountInfo['shopify_id']}/discount_codes`, params);

        if (result.body.discount_codes.length > 0) {
          let allCodes = result.body.discount_codes;
          //优化，如果discount的 sync_time 不为空，则 只保存近两天新增的code
          if (allCodes.length > 0) {
            await this.saveCodesFromShopify({ ...discountInfo, shop: { id: discountInfo['shop_id'] } }, allCodes, false);
          } else {
            console.log('have async before so refused ====');
          }
        }
        if (result?.pageInfo?.nextPage) {
          params = result?.pageInfo.nextPage.query;
        } else {
          break;
        }
      }
      //更新discount的 code_quantity 信息
      let count = await bulkCodesRspt.count({ where: { discount_id: discountInfo['id'] } });
      await discountRspt.update({ id: discountInfo['id'] }, { code_quantity: count });
    }
    await this.unLock(redisKey);
    return true;
  }

  async syncDiscountCodeFromShopify(jobData: { discount_shopify_id: number }) {
    //获取所有code
    let discountRspt = this.database.getRepository(DiscountEntity);
    let discountCodeRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let discountInfo = await discountRspt.findOne({
      where: {
        shopify_id: jobData['discount_shopify_id']
      },
      relations: ['shop']
    });
    if (discountInfo?.shop.shopify_token) {
      //获取code
      //生成对应的

      try {
        const offlineSessionId = this.api.session.getOfflineId(discountInfo['shop'].shopify_domain);
        let session = await this.sessionStorage.loadSession(offlineSessionId);
        if (!session) {
          throw new Error('session is null');
        }
        let shopifyApi = new ShopifyApiLib(session, this.api);
        let params: { limit: number; page_info?: string } = { limit: 250 };
        let isBulkDiscount = false;
        while (true) {
          let result = await shopifyApi.apiGetAllRes(`price_rules/${discountInfo['shopify_id']}/discount_codes`, params);

          if (result.body.discount_codes.length > 0) {
            if (result.body.discount_codes.length > 1) {
              isBulkDiscount = true;
            }
            let allCodes = result.body.discount_codes;
            //优化，如果discount的 sync_time 不为空，则 只保存近两天新增的code
            if (
              discountInfo['sync_time'] &&
              dayjs(discountInfo['shopify_updated_at']).unix() < dayjs().subtract(2, 'day').unix()
            ) {
              allCodes = allCodes.filter(item => dayjs(item.created_at).unix() > dayjs().subtract(2, 'day').unix());
            }
            if (allCodes.length > 0) {
              await this.saveCodesFromShopify(discountInfo, allCodes);
            } else {
              console.log('have async before so refused ====');
            }
          }
          if (result?.pageInfo?.nextPage) {
            params = result?.pageInfo.nextPage.query;
          } else {
            await discountRspt.save({
              ...discountInfo,
              sync_time: new Date(),
              is_bulk_discount: isBulkDiscount,
              last_page_info: params.page_info || null
            });
            break;
          }
        }
        //更新discount的 code_quantity 信息
        let count = await discountCodeRspt.count({ where: { discount_id: discountInfo['id'] } });
        await discountRspt.update({ id: discountInfo['id'] }, { code_quantity: count });
      } catch (e) {
        console.log('sync code from shopify failed:================', discountInfo['shopify_id']);
        console.log(e);
      }
    }
    await this.unLock(`${jobData['discount_shopify_id']}-${SYNC_DISCOUNT_CODE_FROM_SHOPIFY}`);
    return true;
  }
  async saveCodesFromShopify(discountInfo: DiscountEntity, allCodes: DiscountBulkCodeEntity[], is_skip_exists: boolean = true) {
    let date = new Date();
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let codes: string[] = [];
    if (is_skip_exists) {
      let codeList = await bulkCodesRspt.find({
        where: {
          shop_id: discountInfo['shop_id'],
          code: In(allCodes.map(codeItem => codeItem['code']))
        }
      });
      codes = codeList.map(item => item.code);
    }
    let codesSaveData = allCodes
      .filter(item => !codes.includes(item.code))
      .map(item => {
        let codeData = {
          discount_id: discountInfo['id'],
          discount_shopify_id: discountInfo['shopify_id'],
          shopify_id: item.id,
          usage_count: 0,
          shopify_created_at: item.created_at,
          shopify_updated_at: item.updated_at,
          shop_id: discountInfo['shop']['id'],
          sync_at: date,
          batch_id: 0,
          code: item.code
        };
        return codeData;
      });
    if (codesSaveData.length) {
      await bulkCodesRspt.save(codesSaveData);
    } else {
      console.log('----------------------------------++++++++', discountInfo['shopify_id'], discountInfo['shop_id']);
      console.log('exists! not save======');
    }
  }

  async bulkCodes(settingInfo: BulkCodesSettingEntity): Promise<string[]> {
    let codes: string[] = [];
    let { prefix, suffix, random_length, counts, character_type } = settingInfo;
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let bulkCodeLib = new BulkCodeLib();
    codes = bulkCodeLib.createCodes(
      {
        prefix,
        suffix,
        random_length,
        quantity: counts,
        character_type: character_type
      },
      []
    );
    //将所有codes带入数据库中查询，如果有已经存在了则删除
    let addCodes: string[] = codes;
    while (true) {
      let codeList = await bulkCodesRspt.find({
        where: { shop_id: settingInfo.shop_id, code: In(addCodes) }
      });
      if (!codeList.length) {
        break;
      }
      let oldCodes = codeList.map(item => item.code);
      codes = codes.filter(x => !oldCodes.includes(x));
      addCodes = bulkCodeLib.createCodes(
        {
          prefix,
          suffix,
          random_length,
          quantity: oldCodes.length,
          character_type: character_type
        },
        []
      );
      codes = [...codes, ...addCodes];
    }
    return codes;
  }

  unLock(key) {
    if (this.redis.get(`setnx-${key}`)) {
      this.redis.del(`setnx-${key}`);
    }
  }
}
