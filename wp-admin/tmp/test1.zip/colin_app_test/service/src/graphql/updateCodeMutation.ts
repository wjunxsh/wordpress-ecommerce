

export const updateCodeMutation = (id) => {
    const UPDATE_CODE_MUTATION = `
    mutation discountCodeAppUpdate($codeAppDiscount: DiscountCodeAppInput!, $id: ID!) {
        discountCodeAppUpdate(codeAppDiscount: $codeAppDiscount, id: ${id}) {
          codeAppDiscount {
            title
          }
          userErrors {
            field
            message
          }
        }
      }
  `;
  return UPDATE_CODE_MUTATION;
}
export default {}
