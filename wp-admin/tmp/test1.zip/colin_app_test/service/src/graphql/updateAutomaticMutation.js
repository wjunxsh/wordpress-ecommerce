// export const updateAutomaticMutation = (id) => {
//     console.log("sdafadsfasfd");
//     const UPDATE_AUTOMATIC_MUTATION = `
//     mutation UpdateAutomaticDiscount($discount: DiscountAutomaticAppInput!,id:$id) {
//         discountUpdate: discountAutomaticAppUpdate(
//           automaticAppDiscount: $discount,id:${id}
//         ) {
//           userErrors {
//             code
//             message
//             field
//           }
//         }
//       }
//   `;
//   return UPDATE_AUTOMATIC_MUTATION
// }
export const updateAutomaticMutation = (id) => {
  const UPDATE_AUTOMATIC_MUTATION = `
    mutation discountAutomaticAppUpdate($discount: DiscountAutomaticAppInput!, $id: ID!) {
        discountAutomaticAppUpdate(automaticAppDiscount: $discount, id: $id) {
          automaticAppDiscount {
            title
          }
          userErrors {
            field
            message
          }
        }
      }
  `;
  return UPDATE_AUTOMATIC_MUTATION;
};

export default {};
