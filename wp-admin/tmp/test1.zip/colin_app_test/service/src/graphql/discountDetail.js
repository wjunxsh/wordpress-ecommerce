export function graphQLDetails(id) {
  let graphql = `
      {
          discountNode(id:"gid://shopify/DiscountCodeNode/${id}") {
              id
              discount {
                  ... on DiscountCodeApp {
                      createdAt
                      appliesOncePerCustomer
                      asyncUsageCount
                      codeCount
                      combinesWith {
                          orderDiscounts
                          productDiscounts
                          shippingDiscounts
                      }
                      discountClass
                      discountId
                      endsAt
                      hasTimelineComment
                      recurringCycleLimit
                      startsAt
                      status
                      title
                      codes(first:3) {
                          edges {
                              node {
                                  code
                              }
                          }
                          pageInfo {
                              hasPreviousPage
                              startCursor
                          }
                      }
                      totalSales {
                          amount
                          currencyCode
                      }
                      usageLimit
                  }
                  ... on DiscountAutomaticApp {
                      startsAt
                      combinesWith {
                          orderDiscounts
                          productDiscounts
                          shippingDiscounts
                      }
                      discountClass
                      discountId
                      endsAt
                      startsAt
                      status
                      title
                  }
              }
              metafield (namespace:"volume",key:"volume-config"){
                  namespace
                  id
                  value
                  key
              }
          }
      }
  `;
  return graphql;
}

export default {};
