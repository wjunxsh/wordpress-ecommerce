export const metafieldDefinitionCreate = `
mutation CreateMetafieldDefinition($definition: MetafieldDefinitionInput!) {
  metafieldDefinitionCreate(definition: $definition) {
    createdDefinition {
      id
      name
    }
    userErrors {
      field
      message
      code
    }
  }
}
`;
export const metafieldStorefrontVisibilityCreate = `
mutation CreateMetafieldStorefrontVisibility($input: MetafieldStorefrontVisibilityInput!) {
  metafieldStorefrontVisibilityCreate(input: $input) {
    metafieldStorefrontVisibility {
      namespace
      key
    }
    userErrors {
      field
      message
    }
  }
}
`;
