export const discountRedeemCodeBulkAddGraphQl = `
    mutation discountRedeemCodeBulkAdd($codes: [DiscountRedeemCodeInput!]!, $discountId: ID!) {
        discountRedeemCodeBulkAdd(codes: $codes, discountId: $discountId) {
          bulkCreation {
            codesCount
            createdAt
          }
          userErrors {
            field
            message
          }
        }
      }
  `;

//id,gid://shopify/DiscountCodeNode/996486054026
