// export const priceRules = `
// query {
//   priceRules(first: 20) {
//     nodes {
//       id
//       title
//       status
//     }
//   }
// }
// `;
// export const priceRules = `
// query {
//   discountNodes(first: 20) {
//     edges {
//       node {
//         id
//         discount {
//           ... on DiscountCodeBasic {
//             title
//             status
//           }
//           ... on DiscountAutomaticBasic {
//             title
//           }
//         }
//       }
//     }
//   }
// }
// `;
export const codeDiscountNodes = `
query getCodeDiscountNodes($after:String,$query: String) {
  codeDiscountNodes(first: 3,after:$after,query: $query) {
    edges {
      cursor
    }
    nodes {
      id
      codeDiscount {
        ... on DiscountCodeBasic {
          title
          status
          
        }
        ... on DiscountCodeBxgy {
          title
          status
        }
      }
    }
    pageInfo {
      startCursor
      endCursor
      hasNextPage
    }
  }
}
`;
export const priceRule = `
query getPriceRule($query:PriceRuleConnection!)
{
priceRule(after:$after,) {
  title
  createdAt
  discountClass
  discountCodesCount
  startsAt
  endsAt
  status
  features
  oncePerCustomer
  summary
  target
  totalSales {
      amount
      currencyCode
  }
  usageCount
  usageLimit
  hasTimelineComment
  id
  oncePerCustomer
  validityPeriod {
      end
      start
  }
  valueV2
  discountCodes(first:100) {
    edges {
      node {
         code
        usageCount
        id
        app {
          id
          description
          apiKey
        }
      }

    }
  }
}
`;
