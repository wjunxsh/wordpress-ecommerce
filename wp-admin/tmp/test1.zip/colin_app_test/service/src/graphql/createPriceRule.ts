export const createPriceRule = `
    mutation priceRuleCreate($priceRule: ) {
        priceRuleCreate(priceRule: $priceRule) {
            priceRule {
                title
            }
            priceRuleDiscountCode {
                code
            }
            priceRuleUserErrors {
                field
                message
            }
        }
    }
`;
