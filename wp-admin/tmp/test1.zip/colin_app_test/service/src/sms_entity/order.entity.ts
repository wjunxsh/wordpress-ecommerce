import { Column, Entity, Index, PrimaryGeneratedColumn, ManyToOne, OneToMany, JoinColumn } from 'typeorm';
import { SmsShopEntity } from './shop.entity';

type discount_code = {
  code: string;
  type: string;
  amount: string;
};

@Entity('orders', { schema: 'public', synchronize: false })
export class SmsOrderEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: number;

  @Column('bigint', { name: 'shop_id', nullable: true })
  shop_id: number | null;

  @Column('bigint', { name: 'customer_id', nullable: true })
  customer_id: number | null;

  @Column('bigint', { name: 'shopify_app_id', nullable: true })
  shopify_app_id: number | null;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopify_id: number | null;

  @Column('character varying', { name: 'email', nullable: true })
  email: string | null;

  @Column('timestamp without time zone', {
    name: 'closed_at',
    nullable: true,
  })
  closed_at: Date | null;

  @Column('timestamp without time zone', {
    name: 'shopify_created_at',
    nullable: true,
  })
  shopify_created_at: Date | null;

  @Column('timestamp without time zone', {
    name: 'shopify_updated_at',
    nullable: true,
  })
  shopify_updated_at: Date | null;

  @Column('bigint', { name: 'number', nullable: true })
  number: number | null;

  @Column('character varying', { name: 'note', nullable: true })
  note: string | null;

  @Column('character varying', { name: 'token', nullable: true })
  token: string | null;

  @Column('character varying', { name: 'gateway', nullable: true })
  gateway: string | null;

  @Column('boolean', { name: 'test', nullable: true })
  test: boolean | null;

  @Column('numeric', {
    name: 'total_price',
    nullable: true,
    precision: 10,
    scale: 2,
  })
  total_price: string | null;

  @Column('numeric', {
    name: 'subtotal_price',
    nullable: true,
    precision: 10,
    scale: 2,
  })
  subtotal_price: string | null;

  @Column('double precision', {
    name: 'total_weight',
    nullable: true,
    precision: 53,
  })
  total_weight: number | null;

  @Column('numeric', {
    name: 'total_tax',
    nullable: true,
    precision: 10,
    scale: 2,
  })
  total_tax: string | null;

  @Column('boolean', { name: 'taxes_included', nullable: true })
  taxes_included: boolean | null;

  @Column('character varying', { name: 'currency', nullable: true })
  currency: string | null;

  @Column('character varying', { name: 'financial_status', nullable: true })
  financial_status: string | null;

  @Column('boolean', { name: 'confirmed', nullable: true })
  confirmed: boolean | null;

  @Column('numeric', {
    name: 'total_discounts',
    nullable: true,
    precision: 10,
    scale: 2,
  })
  total_discounts: string | null;

  @Column('numeric', {
    name: 'total_line_items_price',
    nullable: true,
    precision: 10,
    scale: 2,
  })
  total_line_items_price: string | null;

  @Column('character varying', { name: 'cart_token', nullable: true })
  cart_token: string | null;

  @Column('boolean', { name: 'buyer_accepts_marketing', nullable: true })
  buyer_accepts_marketing: boolean | null;

  @Column('character varying', { name: 'name', nullable: true })
  name: string | null;

  @Column('character varying', { name: 'referring_site', nullable: true })
  referring_site: string | null;

  @Column('character varying', { name: 'landing_site', nullable: true })
  landing_site: string | null;

  @Column('timestamp without time zone', {
    name: 'cancelled_at',
    nullable: true,
  })
  cancelled_at: Date | null;

  @Column('character varying', { name: 'cancel_reason', nullable: true })
  cancel_reason: string | null;

  @Column('numeric', {
    name: 'total_price_usd',
    nullable: true,
    precision: 10,
    scale: 2,
  })
  total_price_usd: string | null;

  @Column('character varying', { name: 'checkout_token', nullable: true })
  checkout_token: string | null;

  @Column('character varying', { name: 'reference', nullable: true })
  reference: string | null;

  @Column('bigint', { name: 'shopify_user_id', nullable: true })
  shopify_user_id: number | null;

  @Column('bigint', { name: 'shopify_location_id', nullable: true })
  shopify_location_id: number | null;

  @Column('character varying', { name: 'source_identifier', nullable: true })
  source_identifier: string | null;

  @Column('character varying', { name: 'source_url', nullable: true })
  source_url: string | null;

  @Column('timestamp without time zone', {
    name: 'processed_at',
    nullable: true,
  })
  processed_at: Date | null;

  @Column('character varying', { name: 'device_id', nullable: true })
  device_id: string | null;

  @Column('character varying', { name: 'phone', nullable: true })
  phone: string | null;

  @Column('character varying', { name: 'customer_locale', nullable: true })
  customer_locale: string | null;

  @Column('character varying', { name: 'browser_ip', nullable: true })
  browser_ip: string | null;

  @Column('character varying', { name: 'landing_site_ref', nullable: true })
  landing_site_ref: string | null;

  @Column('bigint', { name: 'order_number', nullable: true })
  order_number: number | null;

  @Column('character varying', { name: 'processing_method', nullable: true })
  processing_method: string | null;

  @Column('bigint', { name: 'checkout_id', nullable: true })
  checkout_id: number | null;

  @Column('character varying', { name: 'source_name', nullable: true })
  source_name: string | null;

  @Column('character varying', { name: 'fulfillment_status', nullable: true })
  fulfillment_status: string | null;

  @Column('character varying', { name: 'tags', nullable: true })
  tags: string | null;

  @Column('character varying', { name: 'contact_email', nullable: true })
  contact_email: string | null;

  @Column('character varying', { name: 'order_status_url', nullable: true })
  order_status_url: string | null;

  @Column('character varying', {
    name: 'presentment_currency',
    nullable: true,
  })
  presentment_currency: string | null;

  @Column('character varying', { name: 'total_tip_received', nullable: true })
  total_tip_received: string | null;

  @Column('jsonb', { name: 'client_details', nullable: true })
  client_details: object | null;

  @Column('jsonb', { name: 'current_total_duties_set', nullable: true })
  current_total_duties_set: object | null;

  @Column('jsonb', { name: 'discount_applications', nullable: true })
  discount_applications: object | null;

  @Column('jsonb', { name: 'discount_codes', nullable: true })
  discount_codes: discount_code[] | null;

  @Column('jsonb', { name: 'note_attributes', nullable: true })
  note_attributes: object | null;

  @Column('jsonb', { name: 'original_total_duties_set', nullable: true })
  original_total_duties_set: object | null;

  @Column('jsonb', { name: 'payment_details', nullable: true })
  payment_details: object | null;

  @Column('jsonb', { name: 'payment_gateway_names', nullable: true })
  payment_gateway_names: object | null;

  @Column('jsonb', { name: 'refunds', nullable: true, array: true })
  refunds: object[] | null;

  @Column('jsonb', { name: 'billing_address', nullable: true })
  billing_address: object | null;

  @Column('jsonb', { name: 'shipping_address', nullable: true })
  shipping_address: object | null;

  @Column('jsonb', { name: 'shipping_lines', nullable: true })
  shipping_lines: object | null;

  @Column('jsonb', { name: 'subtotal_price_set', nullable: true })
  subtotal_price_set: object | null;

  @Column('jsonb', { name: 'tax_lines', nullable: true })
  tax_lines: object | null;

  @Column('jsonb', { name: 'total_discounts_set', nullable: true })
  total_discounts_set: object | null;

  @Column('jsonb', { name: 'total_line_items_price_set', nullable: true })
  total_line_items_price_set: object | null;

  @Column('jsonb', { name: 'total_price_set', nullable: true })
  total_price_set: object | null;

  @Column('jsonb', { name: 'total_tax_set', nullable: true })
  total_tax_set: object | null;

  @Column('jsonb', { name: 'total_shipping_price_set', nullable: true })
  total_shipping_price_set: object | null;

  @Column('boolean', {
    name: 'has_calc_cost',
    nullable: true,
    default: () => 'false',
  })
  has_calc_cost: boolean | null;

  @Column('timestamp without time zone', { name: 'created_at' })
  created_at: Date;

  @Column('timestamp without time zone', { name: 'updated_at' })
  updated_at: Date;

  @Column('timestamp without time zone', {
    name: 'klarna_preauth_at',
    nullable: true,
  })
  klarna_preauth_at: Date | null;

  @Column('jsonb', { name: 'customer_fields', nullable: true })
  customer_fields: object | null;

  @Column('timestamp without time zone', {
    name: 'customer_cancelled_at',
    nullable: true,
  })
  customer_cancelled_at: Date | null;

  @Column('timestamp without time zone', {
    name: 'klarna_check_at',
    nullable: true,
  })
  klarna_check_at: Date | null;

  @Column('integer', { name: 'cancel_reason_key', nullable: true })
  cancel_reason_key: number | null;

  @Column('text', { name: 'cancel_reason_txt', nullable: true })
  cancel_reason_txt: string | null;

  @ManyToOne(type => SmsShopEntity, shop => shop.orders)
  @JoinColumn({ name: 'shop_id' })
  shop: SmsShopEntity | null;
}
