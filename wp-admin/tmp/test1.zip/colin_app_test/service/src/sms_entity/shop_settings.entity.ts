import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('shop_settings_pkey', ['id'], { unique: true })
@Entity('shop_settings', { schema: 'public' })
export class ShopSettingsEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: string;

  @Column('character varying', { name: 'shopify_domain', nullable: true })
  shopify_domain: string | null;

  @Column('json', { name: 'settings', nullable: true })
  settings: object | null;

  @Column('timestamp without time zone', { name: 'created_at' })
  created_at: Date;

  @Column('timestamp without time zone', { name: 'updated_at' })
  updated_at: Date;
}
