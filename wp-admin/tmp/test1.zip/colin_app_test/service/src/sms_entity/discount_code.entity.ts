import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { SmsPriceRulesEntity } from './price_rules.entity';

@Index('index_discount_codes_on_code', ['code'], {})
@Index('discount_codes_pkey', ['id'], { unique: true })
@Index('index_discount_codes_on_shop_id', ['shopId'], {})
@Index('index_discount_codes_on_shopify_id', ['shopifyId'], {})
@Index('index_discount_codes_on_shopify_price_rule_id', ['shopifyPriceRuleId'], {})
@Entity('discount_codes', { schema: 'public' })
export class SmsDiscountCode {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: string;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopifyId: number | null;

  @Column('character varying', { name: 'code', nullable: true })
  code: string | null;

  @Column('timestamp without time zone', {
    name: 'shopify_created_at',
    nullable: true,
  })
  shopifyCreatedAt: Date | null;

  @Column('timestamp without time zone', {
    name: 'shopify_updated_at',
    nullable: true,
  })
  shopifyUpdatedAt: Date | null;

  @Column('integer', { name: 'usage_count', nullable: true })
  usageCount: number | null;

  @Column('timestamp without time zone', { name: 'created_at' })
  createdAt: Date;

  @Column('timestamp without time zone', { name: 'updated_at' })
  updatedAt: Date;

  @Column('bigint', { name: 'shop_id', nullable: true })
  shopId: string | null;

  @Column('bigint', { name: 'shopify_price_rule_id' })
  shopifyPriceRuleId: number;

  @Column('boolean', { name: 'assigned', nullable: true })
  assigned: boolean | null;

  @Column('character varying', { name: 'assigned_email', nullable: true })
  assignedEmail: string | null;

  @Column('timestamp without time zone', { name: 'expired_at', nullable: true })
  expiredAt: Date | null;

  @Column('timestamp without time zone', { name: 'deleted_at', nullable: true })
  deletedAt: Date | null;

  @ManyToOne(() => SmsPriceRulesEntity, priceRule => priceRule.discountCodes, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'shopify_price_rule_id' })
  priceRule: SmsPriceRulesEntity;
}
