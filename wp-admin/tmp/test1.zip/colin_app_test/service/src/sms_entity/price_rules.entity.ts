import { Column, Entity, PrimaryGeneratedColumn, ManyToOne, OneToMany, JoinColumn } from 'typeorm';
import { SmsDiscountCode } from './discount_code.entity';

@Entity('price_rules', { schema: 'public', synchronize: false })
export class SmsPriceRulesEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: number;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopify_id: number | null;

  @Column('bigint', { name: 'shop_id', nullable: true })
  shop_id: number | null;

  @Column('integer', { name: 'usage_limit', nullable: true })
  usage_limit: number | null;

  @Column('integer', { name: 'allocation_limit', nullable: true })
  allocation_limit: number | null;

  @Column('numeric', { name: 'value', nullable: true, precision: 10, scale: 2 })
  value: string | null;

  @Column('boolean', { name: 'once_per_customer', nullable: true })
  once_per_customer: boolean | null;

  @Column('character varying', { name: 'allocation_method', nullable: true })
  allocation_method: string | null;

  @Column('character varying', {
    name: 'prerequisite_quantity_range',
    nullable: true,
  })
  prerequisite_quantity_range: string | null;

  @Column('character varying', { name: 'target_selection', nullable: true })
  target_selection: string | null;

  @Column('character varying', { name: 'target_type', nullable: true })
  target_type: string | null;

  @Column('character varying', { name: 'title', nullable: true })
  title: string | null;

  @Column('character varying', { name: 'value_type', nullable: true })
  value_type: string | null;

  @Column('character varying', { name: 'customer_selection', nullable: true })
  customer_selection: string | null;

  // --------
  @Column('character varying', {
    name: 'entitled_collection_ids',
    nullable: true,
  })
  entitled_collection_ids: string | null;

  @Column('character varying', { name: 'entitled_country_ids', nullable: true })
  entitled_country_ids: string | null;

  @Column('character varying', { name: 'entitled_product_ids', nullable: true })
  entitled_product_ids: string | null;

  @Column('character varying', { name: 'entitled_variant_ids', nullable: true })
  entitled_variant_ids: string | null;

  @Column('character varying', {
    name: 'prerequisite_product_ids',
    nullable: true,
  })
  prerequisite_product_ids: string | null;

  @Column('character varying', {
    name: 'prerequisite_variant_ids',
    nullable: true,
  })
  prerequisite_variant_ids: string | null;

  @Column('character varying', {
    name: 'prerequisite_collection_ids',
    nullable: true,
  })
  prerequisite_collection_ids: string | null;

  @Column('character varying', {
    name: 'prerequisite_saved_search_ids',
    nullable: true,
  })
  prerequisite_saved_search_ids: string | null;

  @Column('character varying', {
    name: 'prerequisite_customer_ids',
    nullable: true,
  })
  prerequisite_customer_ids: string | null;
  // -------

  @Column('jsonb', {
    name: 'prerequisite_shipping_price_range',
    nullable: true,
  })
  prerequisite_shipping_price_range: object | null;

  @Column('jsonb', { name: 'prerequisite_subtotal_range', nullable: true })
  prerequisite_subtotal_range: object | null;

  @Column('jsonb', {
    name: 'prerequisite_to_entitlement_purchase',
    nullable: true,
  })
  prerequisite_to_entitlement_purchase: object | null;

  @Column('jsonb', {
    name: 'prerequisite_to_entitlement_quantity_ratio',
    nullable: true,
  })
  prerequisite_to_entitlement_quantity_ratio: object | null;

  @Column('timestamp without time zone', { name: 'starts_at' })
  starts_at: Date;

  @Column('timestamp without time zone', { name: 'shopify_created_at' })
  shopify_created_at: Date;

  @Column('timestamp without time zone', { name: 'shopify_updated_at' })
  shopify_updated_at: Date;

  @Column('timestamp without time zone', { name: 'ends_at' })
  ends_at: Date;

  @Column('timestamp without time zone', { name: 'created_at' })
  created_at: Date;

  @Column('timestamp without time zone', { name: 'updated_at' })
  updated_at: Date;
  @OneToMany(() => SmsDiscountCode, discountCode => discountCode.priceRule)
  discountCodes: SmsDiscountCode[];
}
