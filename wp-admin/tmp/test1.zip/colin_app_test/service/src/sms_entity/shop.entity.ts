import { Column, Entity, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { SmsOrderEntity } from './order.entity';

@Entity('shops', { schema: 'public', synchronize: false })
export class SmsShopEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: number;

  @Column('character varying', { name: 'shopify_domain' })
  shopify_domain: string;

  @Column('character varying', { name: 'shopify_token' })
  shopify_token: string;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopify_id: number | null;

  @Column('character varying', { name: 'country_code', nullable: true })
  country_code: string | null;

  @Column('character varying', { name: 'currency', nullable: true })
  currency: string | null;

  @Column('timestamp without time zone', { name: 'created_at' })
  created_at: Date;

  @Column('timestamp without time zone', { name: 'updated_at' })
  updated_at: Date;

  @Column('character varying', { name: 'iana_timezone', nullable: true })
  iana_timezone: string | null;

  @Column('character varying', { name: 'custom_domain', nullable: true })
  custom_domain: string | null;

  @Column('character varying', { name: 'primary_locale', nullable: true })
  primary_locale: string | null;

  @OneToMany(() => SmsOrderEntity, order => order.shop)
  orders: SmsOrderEntity[] | null;

  public get brand(): string {
    const domain = this.shopify_domain.toLowerCase();
    if (domain.includes('costco')) {
      return 'costco';
    } else if (domain.includes('ankerwork')) {
      return 'ankerwork';
    } else if (domain.includes('ankermake')) {
      return 'ankermake';
    } else if (domain.includes('soundcore')) {
      return 'soundcore';
    } else if (domain.includes('anker')) {
      return 'anker';
    } else if (domain.includes('eufy')) {
      return 'eufy';
    } else if (domain.includes('security')) {
      return 'eufy';
    } else if (domain.includes('nebula')) {
      return 'nebula';
    }
    return 'unknown brand';
  }

  public get headless(): boolean {
    return ['anker', 'ankermake'].includes(this.brand);
  }

  /**
   * 获取官网的真实域名
   */
  public get websiteDomain(): string {
    if (this.headless) {
      return (
        {
          'ankerca.myshopify.com': 'www.anker.com/ca',
          'ankerde.myshopify.com': 'www.anker.com/eu-de',
          'ankereu.myshopify.com': 'www.anker.com/eu-en',
          'ankeruk.myshopify.com': 'www.anker.com/uk',
          'ankerus.myshopify.com': 'www.anker.com',
        }[this.shopify_domain] || this.shopify_domain
      );
    }
    return this.custom_domain;
  }
}
