import { DataSource, In, MoreThan, Repository } from 'typeorm';
import { ApiErrorLogEntity, ApiType } from '../entity/api.error.log.entity';
import dayjs from 'dayjs';
export class ApiErrorLogModel {
  logRspt: Repository<ApiErrorLogEntity>;
  database: DataSource;
  constructor(database: DataSource) {
    this.logRspt = database.getRepository(ApiErrorLogEntity);
    this.database = database;
  }

  async createLog(path: string, method: string, api_type: ApiType, data: any, error_data: any) {
    let logData = new ApiErrorLogEntity();
    logData = {
      ...logData,
      path,
      method,
      api_type,
      data,
      error_data
    };
    await this.logRspt.save(logData);
  }
  async getLogListPastDay() {
    return await this.logRspt.find({
      where: { created_at: MoreThan(dayjs().subtract(1, 'day').toDate()), path: In(['/out-api/code', '/out-api/codes']) },
      take: 50,
      order: { created_at: 'DESC' }
    });
  }
}
