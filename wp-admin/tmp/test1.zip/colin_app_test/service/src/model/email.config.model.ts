import { DataSource, FindManyOptions, ILike, IsNull, LessThanOrEqual, Repository } from 'typeorm';
import { EmailConfigEntity } from '../entity/email.config.entity';
import { EmailSendRecordsEntity } from '../entity/email.send.records.entity';
import { DiscountBulkCodeModel } from './discount.bulk.code.model';
import { Redis } from 'ioredis';
import { DiscountModel } from './discount.mode';
import tinyliquid from 'tinyliquid';
import { DiscountEntity } from '../entity/discount.entity';
export class EmailConfigModel {
  emailConfigRspt: Repository<EmailConfigEntity>;
  emailRecordRspt: Repository<EmailSendRecordsEntity>;
  database: DataSource;
  private emailBindCodeKey = 'email_bind_code_key';
  redis: Redis;
  constructor(database: DataSource, redis: Redis) {
    this.emailConfigRspt = database.getRepository(EmailConfigEntity);
    this.emailRecordRspt = database.getRepository(EmailSendRecordsEntity);
    this.database = database;
    this.redis = redis;
  }
  async getList(params: { currentPage: number; pageSize: number; search: string; shop_id: number }) {
    const { currentPage, pageSize, search, shop_id } = params;
    let option: FindManyOptions<EmailConfigEntity> = { where: { shop_id } };
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    if (search) {
      option['where'] = { title: ILike(`%${search}%`) };
    }
    option['order'] = { id: 'desc' };
    const list = await this.emailConfigRspt.find(option);
    return list;
  }
  async getVerifyedList(id?: number) {
    let option: FindManyOptions<EmailConfigEntity> = {
      where: {
        is_verify: true,
        is_send_all: false,
        is_ready: true,
        starts_at: LessThanOrEqual(new Date())
      }
    };
    if (id) {
      option['where']['id'] = id;
    }
    return await this.emailConfigRspt.find({
      where: {
        is_verify: true,
        is_send_all: false,
        starts_at: LessThanOrEqual(new Date())
      }
    });
  }
  async getRecordList(params: { is_send?: boolean | null; currentPage: number; pageSize: number; email_config_id: number }) {
    const { is_send, currentPage, pageSize, email_config_id } = params;
    let option: FindManyOptions<EmailSendRecordsEntity> = {};
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    if (email_config_id) {
      option['where'] = { email_config_id: email_config_id };
    }
    option['order'] = { id: 'desc' };
    if (is_send === false) {
      option['where']['is_send'] = false;
    } else if (is_send === true) {
      option['where']['is_send'] = true;
    }
    const list = await this.emailRecordRspt.find(option);
    return list;
  }
  async getInfoById(id: number) {
    return await this.emailConfigRspt.findOneBy({ id });
  }
  async getRecordInfoById(id: number) {
    return await this.emailRecordRspt.findOneBy({ id });
  }
  async getConfigInfoById(id: number) {
    return await this.emailConfigRspt.findOneBy({ id });
  }
  async getCount(params: { search: string; shop_id: number }) {
    const { search, shop_id } = params;
    let option: FindManyOptions<EmailConfigEntity> = { where: { shop_id } };
    if (search) {
      option['where'] = { title: ILike(`%${search}%`) };
    }
    const count = await this.emailConfigRspt.count(option);
    return count;
  }
  async getRecordCount(params: { email_config_id: number }) {
    const { email_config_id } = params;
    let option: FindManyOptions<EmailSendRecordsEntity> = {};
    if (email_config_id) {
      option['where'] = { email_config_id: email_config_id };
    }
    const count = await this.emailRecordRspt.count(option);
    return count;
  }
  async createOrSave(emailConfigInfo: EmailConfigEntity) {
    return await this.emailConfigRspt.save(emailConfigInfo);
  }
  async bindParams(id: number = 0) {
    let where: FindManyOptions<EmailConfigEntity>['where'] = {
      is_ready: false
    };
    if (id) {
      where['id'] = id;
    }
    let emailConfiglist = await this.emailConfigRspt.find({ where });
    console.log(emailConfiglist);
    if (!emailConfiglist.length) return;
    let bulkCodeModel = new DiscountBulkCodeModel(this.database, this.redis);
    let discountModel = new DiscountModel(this.database);
    for (let emailConfigInfo of emailConfiglist) {
      let discountInfo: DiscountEntity = null;
      let records: EmailSendRecordsEntity[] = [];
      if (!emailConfigInfo.price_rule_id) {
        records = await this.emailRecordRspt.find({
          where: {
            email_config_id: emailConfigInfo.id,
            html_details: IsNull()
          }
        });
      } else {
        discountInfo = await discountModel.getDiscountInfoById(emailConfigInfo.price_rule_id);
        if (!discountInfo) {
          continue;
        }
        records = await this.emailRecordRspt.find({
          where: {
            email_config_id: emailConfigInfo.id,
            html_details: IsNull()
          }
        });
      }
      if (!records.length) {
        await this.emailConfigRspt.save({
          ...emailConfigInfo,
          is_ready: true
        });
        continue;
      }
      if (!(await this.lock(`${emailConfigInfo['id']}-${this.emailBindCodeKey}`, 30 * 60))) {
        continue;
      }
      for (let record of records) {
        let params: { [key: string]: string } = record['extend'] || {};
        try {
          if (discountInfo) {
            let codeInfo = await bulkCodeModel.getNotUseCode(
              {
                discountShopifyId: discountInfo['shopify_id'],
                email: record['email'],
                expired_at: null,
                onlyOnceEveryEmail: true
              },
              discountInfo
            );
            record['code'] = codeInfo['code'];
            params['code'] = codeInfo['code'];
          }
          let html = await this.getHtml(emailConfigInfo['html_template'], params);
          await this.emailRecordRspt.save({ ...record, html_details: html });
        } catch (e) {
          console.log(e);
        }
      }
      await this.emailConfigRspt.save({ ...emailConfigInfo, is_ready: true });
      await this.unLock(`${emailConfigInfo['id']}-${this.emailBindCodeKey}`);
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
  async getHtml(htmlSource: string, params): Promise<string> {
    let render = tinyliquid.compile(htmlSource);
    let context = tinyliquid.newContext({ locals: { ...params } });
    return new Promise((resolve, reject) => {
      render(context, function (err, output) {
        if (err) {
          reject(err);
        } else {
          resolve(output);
        }
      });
    });
  }
}
