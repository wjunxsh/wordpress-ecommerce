import { DataSource, Repository } from 'typeorm';
import { DiscountProductTagLogEntity } from '../entity/product.discount.tag.log.entity';

export class ProductTagLogModel {
  productTagLogRspt: Repository<DiscountProductTagLogEntity>;
  constructor(database: DataSource) {
    this.productTagLogRspt = database.getRepository(DiscountProductTagLogEntity);
  }
}
