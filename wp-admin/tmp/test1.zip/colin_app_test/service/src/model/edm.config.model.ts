import { DataSource, FindManyOptions, ILike, IsNull, LessThanOrEqual, Repository } from 'typeorm';
import { EdmConfigEntity } from '../entity/edm.config.entity';
import { EdmSendRecordsEntity } from '../entity/edm.send.records.entity';
import { DiscountBulkCodeModel } from './discount.bulk.code.model';
import { Redis } from 'ioredis';
import { DiscountModel } from './discount.mode';
export class EdmConfigModel {
  edmConfigRspt: Repository<EdmConfigEntity>;
  edmRecordRspt: Repository<EdmSendRecordsEntity>;
  database: DataSource;
  private edmBindCodeKey = 'edm_bind_code_key';
  redis: Redis;
  constructor(database: DataSource, redis: Redis) {
    this.edmConfigRspt = database.getRepository(EdmConfigEntity);
    this.edmRecordRspt = database.getRepository(EdmSendRecordsEntity);
    this.database = database;
    this.redis = redis;
  }
  async getList(params: { currentPage: number; pageSize: number; search: string; shop_id: number }) {
    const { currentPage, pageSize, search, shop_id } = params;
    let option: FindManyOptions<EdmConfigEntity> = { where: { shop_id } };
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    if (search) {
      option['where'] = { title: ILike(`%${search}%`) };
    }
    option['order'] = { id: 'desc' };
    const list = await this.edmConfigRspt.find(option);
    return list;
  }
  async getVerifyedList(id?: number) {
    let option: FindManyOptions<EdmConfigEntity> = {
      where: {
        is_verify: true,
        is_send_all: false,
        is_ready: true,
        starts_at: LessThanOrEqual(new Date())
      }
    };
    if (id) {
      option['where']['id'] = id;
    }
    return await this.edmConfigRspt.find({
      where: {
        is_verify: true,
        is_send_all: false,
        starts_at: LessThanOrEqual(new Date())
      }
    });
  }
  async getRecordList(params: { is_send?: boolean; currentPage: number; pageSize: number; edm_config_id: number }) {
    const { is_send, currentPage, pageSize, edm_config_id } = params;
    let option: FindManyOptions<EdmSendRecordsEntity> = {};
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    if (edm_config_id) {
      option['where'] = { edm_config_id: edm_config_id };
    }
    option['where']['send_error'] = IsNull();
    if (is_send === false) {
      option['where']['is_send'] = false;
    } else if (is_send === true) {
      option['where']['is_send'] = true;
    }
    option['order'] = { id: 'desc' };
    const list = await this.edmRecordRspt.find(option);
    return list;
  }
  async getInfoById(id: number) {
    return await this.edmConfigRspt.findOneBy({ id });
  }
  async getRecordInfoById(id: number) {
    return await this.edmRecordRspt.findOneBy({ id });
  }
  async getCount(params: { search: string; shop_id: number }) {
    const { search, shop_id } = params;
    let option: FindManyOptions<EdmConfigEntity> = { where: { shop_id } };
    if (search) {
      option['where'] = { title: ILike(`%${search}%`) };
    }
    const count = await this.edmConfigRspt.count(option);
    return count;
  }
  async getRecordCount(params: { edm_config_id: number }) {
    const { edm_config_id } = params;
    let option: FindManyOptions<EdmSendRecordsEntity> = {};
    if (edm_config_id) {
      option['where'] = { edm_config_id: edm_config_id };
    }
    const count = await this.edmRecordRspt.count(option);
    return count;
  }
  async createOrSave(edmConfigInfo: EdmConfigEntity) {
    return await this.edmConfigRspt.save(edmConfigInfo);
  }
  async bindCode(id: number = 0) {
    let where: FindManyOptions<EdmConfigEntity>['where'] = { is_ready: false };
    if (id) {
      where['id'] = id;
    }
    let edmConfiglist = await this.edmConfigRspt.find({ where });
    console.log('edmConfiglist', edmConfiglist);
    if (!edmConfiglist.length) return;
    let bulkCodeModel = new DiscountBulkCodeModel(this.database, this.redis);
    let discountModel = new DiscountModel(this.database);
    for (let edmConfigInfo of edmConfiglist) {
      if (!edmConfigInfo.price_rule_id) {
        await this.edmConfigRspt.save({ ...edmConfigInfo, is_ready: true });
        continue;
      }
      let records = await this.edmRecordRspt.find({ where: { edm_config_id: edmConfigInfo.id, code: IsNull() } });

      if (!records.length) {
        await this.edmConfigRspt.save({ ...edmConfigInfo, is_ready: true });
        continue;
      }
      let discountInfo = await discountModel.getDiscountInfoById(edmConfigInfo.price_rule_id);
      if (!discountInfo) {
        continue;
      }
      if (!(await this.lock(`${edmConfigInfo['id']}-${this.edmBindCodeKey}`, 30 * 60))) {
        continue;
      }
      for (let record of records) {
        try {
          let codeInfo = await bulkCodeModel.getNotUseCode(
            {
              discountShopifyId: discountInfo['shopify_id'],
              email: record['email'],
              expired_at: null,
              onlyOnceEveryEmail: true
            },
            discountInfo
          );
          record['code'] = codeInfo['code'];
          await this.edmRecordRspt.save(record);
        } catch (e) {
          console.log(e);
        }
      }
      await this.edmConfigRspt.save({ ...edmConfigInfo, is_ready: true });
      await this.unLock(`${edmConfigInfo['id']}-${this.edmBindCodeKey}`);
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
}
