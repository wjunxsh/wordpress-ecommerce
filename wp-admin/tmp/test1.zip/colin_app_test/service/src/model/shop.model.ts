import { DataSource, FindOptionsWhere, In, Like, Repository } from 'typeorm';
import { ShopEntity } from '../entity/shop.entity';
import { Session } from '@shopify/shopify-api';
export class ShopModel {
  shopRspt: Repository<ShopEntity>;
  constructor(database: DataSource) {
    this.shopRspt = database.getRepository(ShopEntity);
  }
  async getAllShops() {
    return await this.shopRspt.find();
  }
  async getActiveShops() {
    return await this.shopRspt.find({ where: { state: 1 } });
  }
  async getShopByShopDomain(shopDomain: string) {
    return await this.shopRspt.findOneBy({ shopify_domain: shopDomain });
  }
  async getShopByShopDomains(shopDomains: string[]) {
    return await this.shopRspt.findBy({ shopify_domain: In(shopDomains) });
  }
  async getShopByShopifyIds(shopifyIds: number[]) {
    return await this.shopRspt.findBy({ shopify_id: In(shopifyIds) });
  }
  async unInstallShop(shopDomain: string) {
    //获取店铺信息
    let shopInfo = await this.shopRspt.findOneBy({
      shopify_domain: shopDomain
    });
    shopInfo['uninstalled_at'] = new Date();
    shopInfo['state'] = 0;
    shopInfo.shopify_token = null;
    shopInfo.uninstalled_at = new Date();
    return await this.shopRspt.save(shopInfo);
  }
  async InstallShop(session: Session) {
    try {
      let shopInfo = await this.getShopByShopDomain(session.shop);
      shopInfo.shopify_token = session.accessToken;
      shopInfo.scope = session.scope;
      shopInfo.updated_at = new Date();
      shopInfo.uninstalled_at = null;
      shopInfo.state = 1;
      return await this.shopRspt.save(shopInfo);
    } catch (e) {
      //添加错误日志
    }
  }
  async updateShop(data: ShopEntity) {
    await this.shopRspt.save(data);
  }
  async createShop(shopifyShopInfo: ShopEntity) {
    let shopInfo = await this.shopRspt.create();
    shopInfo = this.assembleShopObj(shopInfo, shopifyShopInfo);
    await this.shopRspt.upsert(shopInfo, ['shopify_id']);
  }
  assembleShopObj(shopInfo: ShopEntity, shopifyShopInfo: any) {
    return {
      ...shopInfo,
      ...{
        name: shopifyShopInfo.name,
        shopify_domain: shopifyShopInfo.myshopify_domain,
        shopify_id: shopifyShopInfo.id,
        currency: shopifyShopInfo.currency,
        country_code: shopifyShopInfo.country_code,
        created_at: shopifyShopInfo.created_at,
        updated_at: shopifyShopInfo.created_at,
        scope: shopifyShopInfo.scope,
        shopify_token: shopifyShopInfo.shopify_token,
        state: shopifyShopInfo.state,
        iana_timezone: shopifyShopInfo.iana_timezone,
        custom_domain: shopifyShopInfo.domain
      }
    };
  }
  async infoByShopId(shopId: number) {
    return await this.shopRspt.findOne({ where: { id: shopId } });
  }
  async getListByShopifyIds(shopifyIds: number[]) {
    return await this.shopRspt.find({ where: { shopify_id: In(shopifyIds) } });
  }
  async getShops(params: { auth_shop_ids?: string[]; shopify_domain: string; current_page: number; page_size: number }) {
    const { auth_shop_ids, shopify_domain, current_page, page_size } = params;
    let where: FindOptionsWhere<ShopEntity> = { shopify_domain: Like(`%${shopify_domain}%`) };
    if (auth_shop_ids && auth_shop_ids.length > 0) {
      where['id'] = In(auth_shop_ids);
    }
    return await this.shopRspt.find({
      order: { created_at: 'DESC' },
      where,
      take: page_size,
      skip: page_size * (current_page - 1)
    });
  }
  async getShopsCount(params: { auth_shop_ids?: string[]; shopify_domain: string }) {
    const { auth_shop_ids, shopify_domain } = params;
    let where: FindOptionsWhere<ShopEntity> = { shopify_domain: Like(`%${shopify_domain}%`) };
    if (auth_shop_ids && auth_shop_ids.length > 0) {
      where['id'] = In(auth_shop_ids);
    }
    return await this.shopRspt.count({
      where
    });
  }
}
