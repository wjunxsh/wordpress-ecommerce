import { Repository, DataSource, SelectQueryBuilder } from 'typeorm';
import { ScriptProgramManageEntity } from '../../entity/script/script_program_manage.entity';
import { ShopEntity } from '../../entity/shop.entity';
export class ScriptProgramModel {
  RedisClient: any;
  ReferralKeyNamePrefix: string;
  dataSource: DataSource;
  private scriptProgramRspt: Repository<ScriptProgramManageEntity>;
  constructor(dataSource: DataSource) {
    this.dataSource = dataSource;
    this.scriptProgramRspt = this.dataSource.getRepository(ScriptProgramManageEntity);
  }
  async update(data: ScriptProgramManageEntity) {
    return await this.scriptProgramRspt.save(data);
  }
  async getInfo(shop_id: number) {
    return await this.scriptProgramRspt.findOneBy({ shop_id });
  }
  async getList(params: { shop_id: number; current_page: number; page_size: number }) {
    const { shop_id, current_page, page_size } = params;
    let handle = this.scriptProgramRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .orderBy('d.created_at', 'DESC')
      .take(page_size)
      .skip(page_size * (current_page - 1))
      .where('1=1');
    this.getWhere({ shop_id }, handle);
    return await handle.getMany();
  }
  async getCount(params: { shop_id: number }) {
    const { shop_id } = params;
    let handle = this.scriptProgramRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .orderBy('d.created_at', 'DESC')
      .where('1=1');
    this.getWhere({ shop_id }, handle);
    return await handle.getCount();
  }

  private getWhere(params: { shop_id: number }, handle: SelectQueryBuilder<ScriptProgramManageEntity>) {
    const { shop_id } = params;
    handle.andWhere(`d.shop_id = '${shop_id}'`);
  }
}
