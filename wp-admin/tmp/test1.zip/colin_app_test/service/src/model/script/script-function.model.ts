import { DataSource, In, Repository } from 'typeorm';
import { ScriptFunctionEntity } from '../../entity/script/script_function.entity';
export class FunctionModel {
  scriptFuncRspt: Repository<ScriptFunctionEntity>;
  constructor(database: DataSource) {
    this.scriptFuncRspt = database.getRepository(ScriptFunctionEntity);
  }
  async create(data: ScriptFunctionEntity) {
    let info = this.scriptFuncRspt.create();
    info.code = data.code;
    info.code_type = data.code_type;
    info.title = data.title;
    info.shop_id = data.shop_id || null;
    info.function_key = data.function_key;
    info.details = data.details;
    (info.is_order = data.is_order ?? false), (info.relate_functions = data.relate_functions ?? []);
    info.created_at = new Date();
    info.updated_at = new Date();
    await this.scriptFuncRspt.save(info);
    return true;
  }
  async update(data: ScriptFunctionEntity) {
    let functionInfo = await this.scriptFuncRspt.findOne({ where: { id: data.id } });
    if (!functionInfo) {
      throw new Error('没有找到对应的配置!');
    } else {
      await this.scriptFuncRspt.save(data);
    }
    return true;
  }
  async getFunctionList(params: {
    shop_id: number;
    code_type: string;
    title: string;
    current_page: number;
    page_size: number;
  }) {
    const { title, current_page, page_size, code_type } = params;
    let handle = this.scriptFuncRspt.createQueryBuilder();
    handle.where('(shop_id is null or shop_id=:shop_id)', { shop_id: params.shop_id });
    if (title) {
      handle.andWhere(`title ilike('%${title}%')`);
    }
    if (code_type) {
      handle.andWhere(`code_type =:code_type`, { code_type });
    }

    return await handle
      .take(page_size)
      .skip(page_size * (current_page - 1))
      .orderBy('created_at', 'DESC')
      .getMany();
  }
  async getFunctionCount(params: { shop_id: number; title: string; code_type: string }) {
    const { title, code_type } = params;
    let handle = this.scriptFuncRspt.createQueryBuilder();
    handle.where('(shop_id is null or shop_id=:shop_id)', { shop_id: params.shop_id });
    if (title) {
      handle.andWhere(`title ilike('%${title}%')`);
    }
    if (code_type) {
      handle.andWhere(`code_type =:code_type`, { code_type });
    }
    return await handle.getCount();
  }
  async getShopsAllCodes(shop_id: number) {
    return await this.scriptFuncRspt.find({
      order: { created_at: 'DESC' },
      where: [{ shop_id }, { code_type: In(['common', 'util_common']) }]
    });
  }
}
