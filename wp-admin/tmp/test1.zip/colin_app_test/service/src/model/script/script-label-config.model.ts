import { Repository, DataSource, SelectQueryBuilder } from 'typeorm';
import { ScriptLabelConfigEntity } from '../../entity/script/script_label_config.entity';
import { ShopEntity } from '../../entity/shop.entity';
import { ScriptFunctionEntity } from '../../entity/script/script_function.entity';
export class ScriptLabelConfigModel {
  private scriptLabelConfigRspt: Repository<ScriptLabelConfigEntity>;
  dataSource: DataSource;
  constructor(dataSource: DataSource) {
    this.dataSource = dataSource;
    this.scriptLabelConfigRspt = this.dataSource.getRepository(ScriptLabelConfigEntity);
  }
  async save(data: ScriptLabelConfigEntity) {
    if (data.id) {
      let info = await this.scriptLabelConfigRspt.findOneBy({ id: data.id });
      if (info) {
        data = { ...info, ...data };
      }
    } else {
      data.created_at = new Date();
    }
    return await this.scriptLabelConfigRspt.save({ ...data });
  }
  async getList(params: { shop_id: number; function_key: string; current_page: number; page_size: number }) {
    const { current_page, page_size } = params;
    let handle = this.scriptLabelConfigRspt
      .createQueryBuilder('sl')
      .leftJoinAndMapOne('sl.shop', ShopEntity, 's', 's.id=sl.shop_id')
      .leftJoinAndMapOne('sl.function', ScriptFunctionEntity, 'sc', 'sc.function_key=sl.function_key')
      .take(page_size)
      .skip(page_size * (current_page - 1))
      .where('1=1');
    this.getWhere(params, handle);
    return await handle.getMany();
  }
  async getCount(params: { shop_id: number; function_key: string }) {
    const { function_key, shop_id } = params;
    let handle = this.scriptLabelConfigRspt
      .createQueryBuilder('sl')
      .leftJoinAndMapOne('sl.shop', ShopEntity, 's', 's.id=sl.shop_id')
      .where('1=1');
    this.getWhere({ shop_id, function_key }, handle);
    return await handle.getCount();
  }
  private getWhere(params: { shop_id: number; function_key?: string }, handle: SelectQueryBuilder<ScriptLabelConfigEntity>) {
    const { function_key = null, shop_id = null } = params;
    if (function_key) {
      handle.andWhere(`sl.function_key = '${function_key}'`);
    }
    handle.andWhere(`sl.shop_id = '${shop_id}'`);
  }
}
