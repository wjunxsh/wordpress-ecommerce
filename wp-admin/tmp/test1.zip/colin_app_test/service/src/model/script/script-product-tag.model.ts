import { Repository, Not, DataSource } from 'typeorm';
import dayjs from 'dayjs';
import { ScriptDiscountEntity } from '../../entity/script/script_discount.entity';
import { ShopEntity } from '../../entity/shop.entity';
import { ScriptProductTagEntity } from '../../entity/script/script_product_tag.entity';
export class ScriptProductTagModel {
  scriptProductTagRspt: Repository<ScriptProductTagEntity>;
  constructor(dataSource: DataSource) {
    this.scriptProductTagRspt = dataSource.getRepository(ScriptProductTagEntity);
  }
  async getProductTagByDisId(discountId) {
    return await this.scriptProductTagRspt.findBy({ discount_id: discountId });
  }

  async getNotSyncScriptsProductTag() {
    return await this.scriptProductTagRspt
      .createQueryBuilder('sm')
      .leftJoinAndMapOne('sm.discount', ScriptDiscountEntity, 'd', 'sm.discount_id=d.id')
      .leftJoinAndMapOne('sm.shop', ShopEntity, 's', 'd.shop_id=s.id')
      .where(
        `sm.start_sync_at <= '${(dayjs as any)()
          .second(+60)
          .tz('Etc/UTC')
          .format('YYYY-MM-DD HH:mm:ss')}' and sync_at is null and sm.is_need_delete=false`
      )
      .getMany();
  }
  async getNotDeleteProductTag() {
    return await this.scriptProductTagRspt
      .createQueryBuilder('sm')
      .withDeleted()
      .leftJoinAndMapOne('sm.discount', ScriptDiscountEntity, 'd', 'sm.discount_id=d.id')
      .leftJoinAndMapOne('sm.shop', ShopEntity, 's', 'd.shop_id=s.id')
      .where(`sm.is_need_delete=true`)
      .orWhere(`d.ends_at < '${(dayjs as any)().second(+60).tz('Etc/UTC').format('YYYY-MM-DD HH:mm:ss')}'`)
      .getMany();
  }
  async getChangeButNotDeleteProductTags() {
    return await this.scriptProductTagRspt
      .createQueryBuilder('sm')
      .leftJoinAndMapOne('sm.discount', ScriptDiscountEntity, 'd', 'sm.discount_id=d.id')
      .leftJoinAndMapOne('sm.shop', ShopEntity, 's', 'd.shop_id=s.id')
      .where(
        `sm.start_sync_at > '${(dayjs as any)()
          .second(+60)
          .tz('Etc/UTC')
          .format('YYYY-MM-DD HH:mm:ss')}' and sync_at is null and sync_state = true and sm.is_need_delete=false`
      )
      .getMany();
  }
  async updateProductTag(productTag: ScriptProductTagEntity) {
    return await this.scriptProductTagRspt.save(productTag);
  }
  async deleteProductTag(productTag: ScriptProductTagEntity) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    //@ts-ignore
    return await this.scriptProductTagRspt.delete({ uuid: productTag.uuid });
  }

  async isTagExistOtherDiscount(productTag: ScriptProductTagEntity) {
    let { product_tag, product_shopify_id, uuid } = productTag;
    let list = await this.scriptProductTagRspt.find({
      where: {
        uuid: Not(uuid),
        product_shopify_id: product_shopify_id,
        product_tag
      }
    });
    return list.length ? true : false;
  }
  compaireProductTags(oldProductTags: ScriptProductTagEntity[], newProductTags: ScriptProductTagEntity[]) {
    //将id插入更新的列中

    newProductTags.forEach((item: ScriptProductTagEntity) => {
      oldProductTags.forEach(val => {
        if (item.product_shopify_id == val.product_shopify_id) {
          item.uuid = val.uuid;
          item.sync_state = val.sync_state;
          return false;
        }
      });
    });
    //获取要删除的数据
    oldProductTags.forEach(item => {
      let isDelete = true;
      newProductTags.forEach(val => {
        if (item.product_shopify_id == val.product_shopify_id) {
          isDelete = false;
        }
      });
      if (isDelete) {
        newProductTags.push({ ...item, is_need_delete: true });
      }
    });
  }
}
