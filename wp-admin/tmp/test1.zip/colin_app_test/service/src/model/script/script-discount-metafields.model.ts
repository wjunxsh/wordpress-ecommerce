import { DataSource, Repository } from 'typeorm';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ScriptDiscountMetafieldsEntity } from '../../entity/script/script_discount.metafields.entity';
import { ScriptDiscountEntity } from '../../entity/script/script_discount.entity';
import { ShopEntity } from '../../entity/shop.entity';
dayjs.extend(utc);
dayjs.extend(timezone);
export class ScriptMetafieldsModel {
  scriptMetaifeldsRspt: Repository<ScriptDiscountMetafieldsEntity>;
  dataSource: DataSource;
  constructor(dataSource: DataSource) {
    this.dataSource = dataSource;
    this.scriptMetaifeldsRspt = this.dataSource.getRepository(ScriptDiscountMetafieldsEntity);
  }

  async getMetafieldsByDisId(discountId) {
    return await this.scriptMetaifeldsRspt.findBy({ discount_id: discountId });
  }
  async getNotSyncScriptsMetafields() {
    return await this.scriptMetaifeldsRspt
      .createQueryBuilder('sm')
      .leftJoinAndMapOne('sm.discount', ScriptDiscountEntity, 'd', 'sm.discount_id=d.id')
      .leftJoinAndMapOne('sm.shop', ShopEntity, 's', 'd.shop_id=s.id')
      .where(
        `sm.start_sync_at <= '${(dayjs as any)()
          .second(+60)
          .tz('Etc/UTC')
          .format('YYYY-MM-DD HH:mm:ss')}' and sync_at is null and sm.is_need_delete=false`
      )
      .orderBy('sm.sort', 'ASC')
      .getMany();
  }
  async getNotDeleteScriptsMetafields() {
    return await this.scriptMetaifeldsRspt
      .createQueryBuilder('sm')
      .withDeleted()
      .leftJoinAndMapOne('sm.discount', ScriptDiscountEntity, 'd', 'sm.discount_id=d.id')
      .leftJoinAndMapOne('sm.shop', ShopEntity, 's', 'd.shop_id=s.id')
      .where(`sm.is_need_delete=true`)
      .orWhere(`d.ends_at <:date`, { date: dayjs().second(+60) })
      .getMany();
  }
  async getOthersNotExpiredMetafields(metafield: ScriptDiscountMetafieldsEntity) {
    return await this.scriptMetaifeldsRspt
      .createQueryBuilder('sm')
      .withDeleted()
      .leftJoinAndMapOne('sm.discount', ScriptDiscountEntity, 'd', 'sm.discount_id=d.id')
      .leftJoinAndMapOne('sm.shop', ShopEntity, 's', 'd.shop_id=s.id')
      .where(
        `sm.is_need_delete=false and sm.discount_id!=${metafield['discount_id']} 
        and d.shop_id=${metafield['shop']['id']} and metafield_namespace='${metafield['metafield_namespace']}' 
        and metafield_key='${metafield['metafield_key']}' and sm.target_shopify_id=${metafield['target_shopify_id']}`
      )
      .orderBy('sm.sort', 'ASC')
      .getMany();
  }

  async getChangeButNotDeleteMetafields() {
    return await this.scriptMetaifeldsRspt
      .createQueryBuilder('sm')
      .leftJoinAndMapOne('sm.discount', ScriptDiscountEntity, 'd', 'sm.discount_id=d.id')
      .leftJoinAndMapOne('sm.shop', ShopEntity, 's', 'd.shop_id=s.id')
      .where(
        `sm.start_sync_at > '${(dayjs as any)()
          .second(+60)
          .tz('Etc/UTC')
          .format('YYYY-MM-DD HH:mm:ss')}' and sync_at is null and metafield_shopify_id is not null and sm.is_need_delete=false`
      )
      .getMany();
  }
  async updateMetafield(metafield: ScriptDiscountMetafieldsEntity) {
    return await this.scriptMetaifeldsRspt.save(metafield);
  }
  async deleteMetafield(metafield: ScriptDiscountMetafieldsEntity) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    //@ts-ignore
    return await this.scriptMetaifeldsRspt.delete({ uuid: metafield.uuid });
  }
  compaireMetaifields(oldMetafields: ScriptDiscountMetafieldsEntity[], newMetafields: ScriptDiscountMetafieldsEntity[]) {
    //将id插入更新的列中
    newMetafields.forEach((item: ScriptDiscountMetafieldsEntity) => {
      oldMetafields.forEach(val => {
        if (
          item.target_shopify_id == val.target_shopify_id &&
          item.metafield_namespace == val.metafield_namespace &&
          item.metafield_key == val.metafield_key
        ) {
          item.metafield_shopify_id = val.metafield_shopify_id;
          item.uuid = val.uuid;
          return false;
        }
      });
    });
    //获取要删除的数据
    oldMetafields.forEach(item => {
      let isDelete = true;
      newMetafields.forEach(val => {
        if (
          item.target_shopify_id == val.target_shopify_id &&
          item.metafield_namespace == val.metafield_namespace &&
          item.metafield_key == val.metafield_key
        ) {
          isDelete = false;
        }
      });
      if (isDelete) {
        newMetafields.push({ ...item, is_need_delete: true });
      }
    });
  }
}
