import { DataSource, Repository, SelectQueryBuilder } from 'typeorm';
import dayjs from 'dayjs';
import { ScriptProductTagEntity } from '../../entity/script/script_product_tag.entity';
import { ScriptDiscountEntity } from '../../entity/script/script_discount.entity';
import { ScriptDiscountMetafieldsEntity } from '../../entity/script/script_discount.metafields.entity';
import { ScriptProgramManageEntity } from '../../entity/script/script_program_manage.entity';
import { ScriptDiscountLogEntity } from '../../entity/script/script_discount_log.entity';
import { ShopEntity } from '../../entity/shop.entity';
import { ScriptFunctionEntity } from '../../entity/script/script_function.entity';
const OPERATE_TYPE_UPDATE = 2;
const OPERATE_TYPE_CREATE = 1;
const OPERATE_TYPE_DELETE = 3;

export class ScriptDiscountModel {
  RedisClient: any;
  ReferralKeyNamePrefix: string;
  public scriptDiscountRspt: Repository<ScriptDiscountEntity>;
  private scriptMetaifeldsRspt: Repository<ScriptDiscountMetafieldsEntity>;
  private dataSource: DataSource;
  constructor(dataSource: DataSource) {
    this.dataSource = dataSource;
    this.scriptDiscountRspt = this.dataSource.getRepository(ScriptDiscountEntity);
    this.scriptMetaifeldsRspt = this.dataSource.getRepository(ScriptDiscountMetafieldsEntity);
  }
  async save(
    data: ScriptDiscountEntity,
    metafields: ScriptDiscountMetafieldsEntity[],
    productTags: ScriptProductTagEntity[],
    user_id: number
  ) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    let operate_type = OPERATE_TYPE_CREATE;
    try {
      if (data.id) {
        operate_type = OPERATE_TYPE_UPDATE;
        data.updated_at = new Date();
      } else {
        data.created_at = new Date();
        data.updated_at = new Date();
      }
      let id = data.id;

      let discountInfo = await queryRunner.manager.save(ScriptDiscountEntity, data);

      if (!id) {
        //排序值插入
        discountInfo.sort = discountInfo.id;
        discountInfo = await queryRunner.manager.save(ScriptDiscountEntity, discountInfo);
      }
      discountInfo = await queryRunner.manager.findOne(ScriptDiscountEntity, { where: { id: discountInfo.id } });
      metafields.forEach(item => {
        item.discount_id = discountInfo.id;
        item.sort = discountInfo.sort;
      });
      productTags.forEach(item => {
        item.discount_id = discountInfo.id;
      });
      if (metafields.length) {
        await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(ScriptDiscountMetafieldsEntity)
          .values(metafields)
          .orUpdate(['is_need_delete', 'metafield_value', 'start_sync_at', 'sync_at', 'metafield_key'], ['uuid'])
          .execute();
      }
      if (productTags.length) {
        await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(ScriptProductTagEntity)
          .values(productTags.map(item => ({ ...item })))
          .orUpdate(['is_need_delete', 'sync_state', 'product_tag', 'start_sync_at', 'sync_at'], ['uuid'])
          .execute();
      }
      await queryRunner.manager
        .createQueryBuilder()
        .insert()
        .into(ScriptProgramManageEntity)
        .values({ shop_id: discountInfo.shop_id, deploy_at: null, updated_at: new Date(), copty_times: 0 })
        .orUpdate(['deploy_at', 'updated_at', 'copty_times'], ['shop_id'])
        .execute();

      user_id &&
        (await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(ScriptDiscountLogEntity)
          .values({ ...discountInfo, user_id: user_id, discount_id: discountInfo.id, id: 0, log_at: new Date(), operate_type })
          .execute());
      await queryRunner.commitTransaction();
      return discountInfo;
    } catch (e) {
      await queryRunner.rollbackTransaction();
      throw e;
    } finally {
      await queryRunner.release();
    }
  }
  async deleteDiscount(discountInfo: ScriptDiscountEntity, userId: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.getRepository(ScriptDiscountEntity).softRemove(discountInfo);
      await queryRunner.manager
        .createQueryBuilder()
        .update(ScriptDiscountMetafieldsEntity)
        .set({ is_need_delete: true })
        .where({ discount_id: discountInfo.id })
        .execute();

      await queryRunner.manager
        .createQueryBuilder()
        .update(ScriptProductTagEntity)
        .set({ is_need_delete: true })
        .where({ discount_id: discountInfo.id })
        .execute();
      userId &&
        (await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(ScriptDiscountLogEntity)
          .values({
            ...discountInfo,
            discount_id: discountInfo.id,
            id: 0,
            user_id: userId,
            log_at: new Date(),
            operate_type: OPERATE_TYPE_DELETE
          })
          .execute());
      await queryRunner.commitTransaction();
    } catch (e) {
      console.log('sdfsfa=======delete failed');
      await queryRunner.rollbackTransaction();
      throw e;
    } finally {
      await queryRunner.release();
    }
  }

  async getDiscountList(params: {
    discountId?: number;
    shop_id: number;
    title: string;
    current_page: number;
    page_size: number;
    state: string;
  }) {
    const { title, shop_id, current_page, page_size, discountId, state } = params;
    let handle = this.scriptDiscountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .leftJoinAndMapOne('d.function', ScriptFunctionEntity, 'sc', 'sc.function_key=d.function_id')
      .orderBy('d.sort', 'ASC')
      .addOrderBy('d.created_at', 'ASC')
      .take(page_size)
      .skip(page_size * (current_page - 1))
      .where('1=1');
    this.getWhere({ shop_id, title, discountId, state }, handle);
    return await handle.getMany();
  }
  async getComingToEndDiscountList() {
    let date = dayjs().subtract(1, 'day').toDate();
    let currDate = dayjs().toDate();
    let list = this.scriptDiscountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .orderBy('d.sort', 'ASC')
      .addOrderBy('d.created_at', 'ASC')
      .where(`ends_at>=:date and ends_at<=:currDate and state='active'`, { date, currDate })
      .getMany();
    return list;
  }

  async getDiscountInfo(params: { discountId?: number; shop_id?: number; title?: string }) {
    const { title, shop_id, discountId } = params;
    let handle = this.scriptDiscountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .leftJoinAndMapOne('d.function', ScriptFunctionEntity, 'sc', 'sc.function_key=d.function_id')
      .orderBy('d.sort', 'ASC')
      .addOrderBy('d.created_at', 'ASC')
      .where('1=1');
    this.getWhere({ shop_id, title, discountId }, handle);
    return await handle.getOne();
  }
  async getDiscountCount(params: { state: string; discountId?: number; shop_id: number; title: string }) {
    const { title, shop_id, discountId, state } = params;
    let handle = this.scriptDiscountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .where('1=1');
    this.getWhere({ shop_id, title, discountId, state }, handle);
    return await handle.getCount();
  }
  async getScriptDiscountInfoById(id, shop_id: number): Promise<ScriptDiscountEntity> {
    return await this.scriptDiscountRspt.findOneBy({
      id: id,
      shop_id
    });
  }
  async getScriptDiscountInfoByOldId(old_id: number, shop_id: number): Promise<ScriptDiscountEntity> {
    return await this.scriptDiscountRspt.findOneBy({
      old_id,
      shop_id
    });
  }
  async getMetafieldsByDisId(discountId) {
    return await this.scriptMetaifeldsRspt.findBy({ discount_id: discountId });
  }
  private getWhere(
    params: { state?: string; shop_id: number; title?: string; discountId?: number },
    handle: SelectQueryBuilder<ScriptDiscountEntity>
  ) {
    const { discountId = 0, title = null, shop_id = null, state = null } = params;
    if (title) {
      handle.andWhere(`d.title like '%${title}%'`);
    }
    if (discountId) {
      handle.andWhere(`d.id = ${discountId}`);
    }
    handle.andWhere(`d.shop_id = '${shop_id}'`);
    if (state == 'draft') {
      handle.andWhere(`d.state = '${state}'`);
    }
    if (state == 'active') {
      handle.andWhere(`d.state = '${state}' and d.starts_at <:date and (d.ends_at >:date or d.ends_at is null)`, {
        date: dayjs().toDate()
      });
    } else if (state == 'scheduled') {
      handle.andWhere(`d.starts_at >:date`, { date: dayjs().toDate() });
    } else if (state == 'expired') {
      handle.andWhere(`d.ends_at <:date`, { date: dayjs().toDate() });
    }
  }
  async updateDiscountSortByIds(sourceId: number, targetId: number, shop_id: number) {
    let targetDiscountInfo = await this.scriptDiscountRspt.findOneBy({ id: targetId });
    let sourceDiscountInfo = await this.scriptDiscountRspt.findOneBy({ id: sourceId });
    if (sourceDiscountInfo['sort'] > targetDiscountInfo['sort']) {
      //sort >= ${targetDiscountInfo["sort"]} and sort < ${sourceDiscountInfo["sort"]}
      await this.scriptDiscountRspt
        .createQueryBuilder()
        .where(`shop_id=${shop_id} and sort >= ${targetDiscountInfo['sort']} and sort < ${sourceDiscountInfo['sort']}`)
        .update({ sort: () => 'sort + 1' })
        .execute();
    } else {
      await this.scriptDiscountRspt
        .createQueryBuilder()
        .where(`shop_id=${shop_id} and sort > ${sourceDiscountInfo['sort']} and sort <= ${targetDiscountInfo['sort']}`)
        .update({ sort: () => 'sort - 1' })
        .execute();
    }
    await this.scriptDiscountRspt.save({ ...sourceDiscountInfo, sort: targetDiscountInfo.sort });
    await this.scriptDiscountRspt.query(`UPDATE script_discounts_metafields as a
    SET sort=d.sort
    FROM script_discounts as d
    WHERE d.id=a.discount_id and d.shop_id=${shop_id}`);
    await this.scriptMetaifeldsRspt.update(
      { discount_id: sourceDiscountInfo['id'] },
      { sync_at: null, metafield_shopify_id: null }
    );
  }
  async updateDiscount(updateData: ScriptDiscountEntity) {
    return await this.scriptDiscountRspt.save(updateData);
  }
  async getActiveScriptsDiscounts(shop_id: number) {
    let handle = this.scriptDiscountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .leftJoinAndMapOne('d.function', ScriptFunctionEntity, 'sc', 'sc.function_key=d.function_id')
      .where('1=1');
    handle.andWhere({ shop_id: shop_id, state: 'active' });
    handle
      .andWhere(`(d.ends_at is null or d.ends_at >='${dayjs().format('YYYY-MM-DD HH:mm:ss')}')`)
      .orderBy('sc.is_order', 'DESC')
      .addOrderBy('d.sort', 'ASC')
      .addOrderBy('d.created_at', 'ASC');
    return await handle.getMany();
  }
}
