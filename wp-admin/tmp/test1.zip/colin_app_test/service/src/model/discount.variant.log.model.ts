import { DataSource, Repository } from 'typeorm';
import { DiscountVariantLogEntity } from '../entity/discount.variant.log.entity';
export class DiscountVariantLogModel {
  discountVariantLogRspt: Repository<DiscountVariantLogEntity>;
  database: DataSource;
  constructor(database: DataSource) {
    this.discountVariantLogRspt = database.getRepository(DiscountVariantLogEntity);
    this.database = database;
  }
}
