import { DataSource, Repository } from 'typeorm';
import { DiscountProductTagEntity } from '../entity/product.discount.tag.entity';

export class ProductTagModel {
  productTagRspt: Repository<DiscountProductTagEntity>;
  constructor(database: DataSource) {
    this.productTagRspt = database.getRepository(DiscountProductTagEntity);
  }
}
