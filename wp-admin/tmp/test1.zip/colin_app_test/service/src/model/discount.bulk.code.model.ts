import { DataSource, FindOneOptions, In, LessThanOrEqual, Repository } from 'typeorm';
import { DiscountEntity } from '../entity/discount.entity';
import { BulkCodesSettingEntity } from '../entity/bulk-code-setting';
import { ShopEntity } from '../entity/shop.entity';
import { Redis } from 'ioredis';
import { BulkCodeLib } from '../lib/bulk-code.lib';
import { DiscountBulkCodeEntity } from '../entity/discount-bulk-code';
import dayjs from 'dayjs';
import { DISCOUNT_UNSIGNED_PREFIX } from '../lib/variable';
import { ToolsLib } from '../lib/tools.lib';
import { DiscountCodeSettingModel } from './discount.code.setting.model';
import { DiscountCodeAutoIncreamentLogEntity } from '../entity/discount-code-auto-increment-log.entity';
export class DiscountBulkCodeModel {
  discountRspt: Repository<DiscountEntity>;
  discountCodeRspt: Repository<DiscountBulkCodeEntity>;
  shopRspt: Repository<ShopEntity>;
  autoAddCodeLogRspt: Repository<DiscountCodeAutoIncreamentLogEntity>;
  database: DataSource;
  redis: Redis;
  constructor(database: DataSource, redis: Redis) {
    this.discountRspt = database.getRepository(DiscountEntity);
    this.shopRspt = database.getRepository(ShopEntity);
    this.autoAddCodeLogRspt = database.getRepository(DiscountCodeAutoIncreamentLogEntity);
    this.discountCodeRspt = database.getRepository(DiscountBulkCodeEntity);
    this.database = database;
    this.redis = redis;
  }
  async bulkCode(settingId?: number) {
    let bulkSettingRspt = this.database.getRepository(BulkCodesSettingEntity);
    let date = new Date();
    let handle = bulkSettingRspt
      .createQueryBuilder('s')
      .leftJoinAndMapOne('s.discount', DiscountEntity, 'd', 'd.id=s.discount_id')
      .leftJoinAndMapOne('s.shop_info', ShopEntity, 'sh', 'sh.id=s.shop_id')
      .where({ is_bulk: false })
      .andWhere('d.deleted_at is null');
    if (settingId) {
      handle.andWhere({ id: settingId });
    } else {
      //异步拉取，则裂变5分钟之前的，防止出现并发情况
      handle.andWhere({
        created_at: LessThanOrEqual(dayjs().subtract(5, 'minute').toDate())
      });
    }
    let settingList = await handle.select().getMany();
    if (settingList.length == 0) {
      return false;
    }
    for (let settingInfo of settingList) {
      //如果discount不存在,则删除setting 可能discount被删除了了

      if (!settingInfo.discount) {
        await bulkSettingRspt.softRemove(settingInfo);
        //添加日志
      }
      //获取店铺信息
      let shopInfo: ShopEntity = settingInfo['shop_info'];
      //获取裂变的详细信息
      let limitKey = `${settingInfo['shop_info']['shopify_id']}_create_code_limit_key`;
      //当前店铺如果有活动正在裂变，则将店铺锁定20分钟，防止并发裂变导致code店铺内冲突
      if (!(await this.lock(limitKey, 5 * 60)) && !settingId) {
        continue;
      }
      let codes: string[] = [];
      if (settingInfo.type != 'auto') {
        codes = [...settingInfo.codes];
        await this.saveCodes(settingInfo, date, codes, shopInfo);
      } else {
        await this.createCodesFromSetting(settingInfo);
      }
      await bulkSettingRspt
        .createQueryBuilder()
        .update(BulkCodesSettingEntity)
        .set({ is_bulk: true, bulk_at: date })
        .where({ id: settingInfo.id })
        .execute();
      //更新discount的 code_quantity 信息
      let count = await this.discountCodeRspt.count({ where: { discount_id: settingInfo['discount_id'] } });
      //start_ai_generated
      if (settingInfo.discount.auto_increment_code) {
        await this.getAndSetNotUsedCodesCountsByDiscountId(settingInfo['discount_shopify_id'], true);
      }
      //end_ai_generated
      await this.discountRspt.update({ id: settingInfo['discount_id'] }, { code_quantity: count });
      await this.bakupCodes(settingInfo.id);
      !settingId && (await this.unLock(limitKey));
    }
  }
  async incrementBulkCode(settingInfo: BulkCodesSettingEntity, bulkCodeCounts: number) {
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let date = new Date();
    //获取店铺信息
    let shopInfo: ShopEntity = settingInfo['shop'];
    let bulkCodeLib = new BulkCodeLib();
    //将所有codes带入数据库中查询，如果有已经存在了则删除
    while (true) {
      if (bulkCodeCounts <= 0) {
        break;
      }
      //如果不传递shop_id 则 全部店铺不重复;
      let addCodes = bulkCodeLib.createCodes(
        {
          prefix: settingInfo['prefix'],
          suffix: settingInfo['suffix'],
          random_length: settingInfo['random_length'],
          quantity: bulkCodeCounts > 5000 ? 5000 : bulkCodeCounts,
          character_type: settingInfo['character_type']
        },
        []
      );
      let codeList = await bulkCodesRspt.find({
        withDeleted: true,
        where: { shop_id: settingInfo.shop_id, code: In(addCodes) }
      });
      if (!codeList.length) {
        await this.saveCodes(settingInfo, date, addCodes, shopInfo, true);
        bulkCodeCounts -= addCodes.length;
        continue;
      }
      let oldCodes = codeList.map(item => item.code);
      addCodes = addCodes.filter(x => !oldCodes.includes(x));
      if (addCodes.length == 0) continue;
      await this.saveCodes(settingInfo, date, addCodes, shopInfo, true);
      bulkCodeCounts -= addCodes.length;
    }
    let count = await this.discountCodeRspt.count({ where: { discount_id: settingInfo['discount_id'] } });
    await this.discountRspt.update({ id: settingInfo['discount_id'] }, { code_quantity: count });
    await this.bakupCodes(settingInfo.id);
  }
  async bulkBirthdayCode(email: string, birsthdayDiscounts: DiscountEntity[], expired_at: Date) {
    let bulkCodeCounts = 1;
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let date = new Date();
    let prefix = 'WSBD';
    let randomLength = 6;
    let suffix = '';
    let bulkCodeLib = new BulkCodeLib();
    let code: string = '';
    while (true) {
      code = bulkCodeLib.createCodes(
        {
          prefix: prefix,
          suffix: suffix,
          random_length: randomLength,
          quantity: bulkCodeCounts,
          character_type: 'mix'
        },
        []
      )[0];
      //如果code已经被任何一个店铺占用则继续裂变新的code
      let codeList = await bulkCodesRspt.find({
        withDeleted: true,
        where: {
          code: code
        }
      });
      if (codeList.length > 0) continue;
      let saveData: DiscountBulkCodeEntity[] = birsthdayDiscounts.map(discountInfo => {
        let data = new DiscountBulkCodeEntity();
        if (!expired_at && discountInfo['code_effective_days'] && discountInfo['code_effective_days'] != 0) {
          expired_at = dayjs().add(discountInfo['code_effective_days'], 'day').toDate();
        }
        return {
          ...data,
          setting_id: 0,
          code,
          shop_id: discountInfo['shop_id'],
          assigned_email: email,
          assigned: true,
          assigned_at: new Date(),
          discount_id: discountInfo.id,
          discount_shopify_id: discountInfo.shopify_id,
          created_at: date,
          expired_at: expired_at,
          auto_increment_code: false
        };
      });
      await bulkCodesRspt.save(saveData);
      break;
    }
    return code;
  }
  async createBirthdayCode(email: string, birsthdayDiscounts: DiscountEntity[], expired_at: Date, code: string) {
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    let date = new Date();
    let saveData: DiscountBulkCodeEntity[] = birsthdayDiscounts.map(discountInfo => {
      let data = new DiscountBulkCodeEntity();
      if (!expired_at && discountInfo['code_effective_days'] && discountInfo['code_effective_days'] != 0) {
        expired_at = dayjs().add(discountInfo['code_effective_days'], 'day').toDate();
      }
      return {
        ...data,
        setting_id: 0,
        code,
        assigned_email: email,
        assigned: true,
        shop_id: discountInfo['shop_id'],
        expired_at: expired_at,
        assigned_at: new Date(),
        discount_id: discountInfo.id,
        discount_shopify_id: discountInfo.shopify_id,
        created_at: date,
        auto_increment_code: false
      };
    });
    console.log('test==========birthday:', saveData);
    await bulkCodesRspt.save(saveData);
  }
  async saveCodes(settingInfo, date, addCodes, shopInfo, auto_increment_code: boolean = false) {
    console.log(addCodes);
    let queryRunner = this.database.createQueryRunner();
    let codes = [...addCodes];
    while (codes.length !== 0) {
      let splitCodes = [];
      if (codes.length > 500) {
        splitCodes = codes.splice(0, 500);
      } else {
        splitCodes = codes;
        codes = [];
      }
      let saveCodes: DiscountBulkCodeEntity[] = [
        ...splitCodes.map(code => ({
          ...new DiscountBulkCodeEntity(),
          code,
          setting_id: settingInfo.id,
          shop_id: shopInfo.id,
          created_at: date,
          discount_id: settingInfo.discount_id,
          discount_shopify_id: settingInfo.discount_shopify_id,
          is_auto_increment: auto_increment_code || false
        }))
      ];
      let saveRst = await queryRunner.manager
        .createQueryBuilder()
        .insert()
        .into(DiscountBulkCodeEntity)
        .values(saveCodes)
        .execute();
      if (!saveRst) {
        //添加保存失败的日志
        return false;
      }
    }
    await queryRunner.manager.release();
    return true;
  }
  async createCodesFromSetting(settingInfo: BulkCodesSettingEntity) {
    let date = new Date();
    let { prefix, suffix, random_length, counts, character_type } = settingInfo;
    let bulkCodesRspt = this.database.getRepository(DiscountBulkCodeEntity);
    //获取本次裂变配置已经裂变的数量
    let haveExistCounts: number = await bulkCodesRspt.count({
      where: { setting_id: settingInfo.id }
    });
    let bulkCodeLib = new BulkCodeLib();
    let bulkCodeCounts = counts - haveExistCounts;
    //将所有codes带入数据库中查询，如果有已经存在了则删除
    while (true) {
      if (bulkCodeCounts <= 0) {
        break;
      }
      //如果不传递shop_id 则 全部店铺不重复
      let addCodes = bulkCodeLib.createCodes(
        {
          prefix,
          suffix,
          random_length,
          quantity: bulkCodeCounts > 5000 ? 5000 : bulkCodeCounts,
          character_type
        },
        []
      );
      let codeList = await bulkCodesRspt.find({
        where: { shop_id: settingInfo.shop_id, code: In(addCodes) }
      });
      if (!codeList.length) {
        await this.saveCodes(settingInfo, date, addCodes, settingInfo['shop_info']);
        bulkCodeCounts -= addCodes.length;
        continue;
      }
      let oldCodes = codeList.map(item => item.code);
      addCodes = addCodes.filter(x => !oldCodes.includes(x));
      if (addCodes.length <= 0) {
        continue;
      }
      await this.saveCodes(settingInfo, date, addCodes, settingInfo['shop_info']);
      bulkCodeCounts -= addCodes.length;
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
  async getBirthdayCodes(discountIds: number[], code: string, email: string) {
    //获取生日券发放未超过一年的code
    return await this.discountCodeRspt.find({
      withDeleted: true,
      where: {
        discount_id: In(discountIds),
        code,
        assigned_email: email
      }
    });
  }
  async bakupCodes(setting_id?: number) {
    try {
      if (setting_id) {
        let codeRspt = this.database.getRepository(DiscountBulkCodeEntity);
        await codeRspt.query(`insert into discount_bulk_code_bak
          select * from discount_bulk_code where setting_id=${setting_id} ON conflict (id) DO UPDATE SET
          code=EXCLUDED.code,
          updated_at=EXCLUDED.updated_at,
          deleted_at=EXCLUDED.deleted_at,
          sync_at=EXCLUDED.sync_at,
          batch_id=EXCLUDED.batch_id,
          discount_shopify_id=EXCLUDED.discount_shopify_id,
          shopify_id=EXCLUDED.shopify_id,
          expired_at=EXCLUDED.expired_at,
          assigned_email=EXCLUDED.assigned_email,
          assigned=EXCLUDED.assigned,
          assigned_at=EXCLUDED.assigned_at
        `);
      } else {
        let maxDate = dayjs().subtract(1, 'day').format('YYYY-MM-DD HH:mm:ss');
        let codeRspt = this.database.getRepository(DiscountBulkCodeEntity);
        await codeRspt.query(`insert into discount_bulk_code_bak
          select * from discount_bulk_code where updated_at > '${maxDate}'  ON conflict (id) DO UPDATE SET
          code=EXCLUDED.code,
          updated_at=EXCLUDED.updated_at,
          deleted_at=EXCLUDED.deleted_at,
          sync_at=EXCLUDED.sync_at,
          batch_id=EXCLUDED.batch_id,
          discount_shopify_id=EXCLUDED.discount_shopify_id,
          shopify_id=EXCLUDED.shopify_id,
          expired_at=EXCLUDED.expired_at,
          assigned_email=EXCLUDED.assigned_email,
          assigned=EXCLUDED.assigned,
          assigned_at=EXCLUDED.assigned_at
          `);
      }
    } catch (e) {
      console.log(e);
    }
  }
  async getNotUseCode(
    {
      discountShopifyId,
      email,
      expired_at,
      onlyOnceEveryEmail = true
    }: {
      discountShopifyId: number;
      email: string;
      expired_at: Date | null;
      onlyOnceEveryEmail?: boolean | string;
    },
    discountInfo: DiscountEntity,
    times: number = 0
  ) {
    const codeCacheKeyPrefix = 'code-cache-key-';
    if (onlyOnceEveryEmail !== 'false' && onlyOnceEveryEmail !== false) {
      //获取店铺信息
      let options: FindOneOptions<DiscountBulkCodeEntity> = {
        where: { assigned_email: email, discount_shopify_id: discountShopifyId }
      };
      let codeInfo = await this.discountCodeRspt.findOne(options);
      if (codeInfo) return codeInfo;
    }
    //start_ai_generated
    if (discountInfo.auto_increment_code) {
      let unassignedCount = await this.getAndSetNotUsedCodesCountsByDiscountId(discountShopifyId, false);
      if (!unassignedCount) {
        throw new Error('No more discount codes');
      }
    }

    let where: FindOneOptions<DiscountBulkCodeEntity>['where'] = { assigned: false };
    where['discount_shopify_id'] = discountShopifyId;

    //end_ai_generated
    let codeInfo = await this.discountCodeRspt.findOneBy(where);
    if (!codeInfo) {
      throw new Error('No more discount codes');
    }
    //将code信息在redis中锁定三秒，防止并发,最好是后期更改为队列这样就能够减少多个email获取一个email的并发情况
    if (!(await this.redis.set(`${codeCacheKeyPrefix}${codeInfo.id}`, 1, 'EX', 3, 'NX'))) {
      if (times > 2) {
        //获取code失败,code已经被锁定
        throw new Error('the code is locked,please try again!');
      }
      //如果锁定则等待2秒后重新获取
      await ToolsLib.sleep(2000);
      return await this.getNotUseCode({ discountShopifyId, email, expired_at, onlyOnceEveryEmail }, discountInfo, ++times);
    }
    //将email 和过期时间存入进去
    codeInfo['assigned_email'] = email;
    codeInfo['assigned'] = true;
    codeInfo['assigned_at'] = new Date();
    if (expired_at) {
      codeInfo['expired_at'] = expired_at;
    }
    //start_ai_generated
    //将redis中的数据减少一个
    await this.redis.decr(`${DISCOUNT_UNSIGNED_PREFIX}${discountShopifyId}`);
    //end_ai_generated
    await this.discountCodeRspt.save(codeInfo);
    delete codeInfo['discount'];
    //异步调用自增增加code
    if (discountInfo.auto_increment_code) {
      this.autoIncrementCode(discountInfo);
    }
    //删除redis中的锁
    await this.redis.del(`${codeCacheKeyPrefix}${codeInfo.id}`);
    return codeInfo;
  }
  //start_ai_generated
  async getAndSetNotUsedCodesCountsByDiscountId(discountShopifyId: number, fromDb: boolean = false) {
    //从redis中获取未分配的折扣数量
    let unassignedCount: number = null;
    if (fromDb) {
      //获取未分配的折扣数量
      unassignedCount = await this.discountCodeRspt.count({
        where: { discount_shopify_id: discountShopifyId, assigned: false }
      });
      //将数据存储到redis中
      await this.redis.set(`${DISCOUNT_UNSIGNED_PREFIX}${discountShopifyId}`, unassignedCount);
    } else {
      let unassignedCountString = await this.redis.get(`${DISCOUNT_UNSIGNED_PREFIX}${discountShopifyId}`);
      unassignedCount = unassignedCountString ? parseInt(`${unassignedCountString}`) : null;
      if (unassignedCount === null) {
        //从数据库中查询
        //获取未分配的折扣数量
        let unassignedCount = await this.discountCodeRspt.count({
          where: { discount_shopify_id: discountShopifyId, assigned: false }
        });
        //将数据存储到redis中
        await this.redis.set(`${DISCOUNT_UNSIGNED_PREFIX}${discountShopifyId}`, unassignedCount);
      }
    }
    //将值的超时时间设置为10天
    await this.redis.expire(`${DISCOUNT_UNSIGNED_PREFIX}${discountShopifyId}`, 10 * 24 * 60 * 60);
    return unassignedCount;
  }
  //自动增加1000个code
  async autoIncrementCode(discountInfo: DiscountEntity) {
    const autoCreateQuantity = 200;
    //获取code，计算平均code的
    //锁定增加的数量，防止重复裂变
    let lockKey = `auto_increment_code_lock_${discountInfo.shopify_id}`;
    if (!(await this.lock(lockKey, 60 * 60))) {
      return;
    }
    let unUserdCounts = await this.getAndSetNotUsedCodesCountsByDiscountId(discountInfo['shopify_id']);
    if (unUserdCounts >= autoCreateQuantity) {
      await this.unLock(lockKey);
      return;
    }
    const settingModel = new DiscountCodeSettingModel(this.database, this.redis);
    //获取最后一次裂变的setting
    let settingInfo = await settingModel.getLastInfoByDiscountId(discountInfo['id']);
    if (!settingInfo) {
      await this.unLock(lockKey);
      return;
    }
    await this.incrementBulkCode(settingInfo, autoCreateQuantity);
    //分配完成后将数量记录到redis中
    await this.getAndSetNotUsedCodesCountsByDiscountId(discountInfo['shopify_id'], true);
    //记录增加的节点日志
    await this.autoAddCodeLogRspt.save({
      discount_shopify_id: discountInfo.shopify_id,
      discount_id: discountInfo.id,
      shopify_domain: discountInfo.shop_domain,
      left_code_quantity: unUserdCounts,
      add_code_quantity: autoCreateQuantity,
      shop_id: discountInfo.shop_id
    });
    await this.unLock(lockKey);
  }
  //end_ai_generated
  async getExpiredCodes() {
    let date = dayjs().toDate();
    let list = await this.shopRspt
      .createQueryBuilder('s')
      .leftJoinAndMapMany('s.codes', DiscountBulkCodeEntity, 'dc', 'dc.shop_id=s.id')
      .where('dc.assigned=true and dc.expired_at < :date and dc.shopify_id is not null and dc.usage_count =0', { date })
      .getMany();
    return list;
  }
  async softRemoveCode(codeInfo: DiscountBulkCodeEntity) {
    return await this.discountCodeRspt.softRemove(codeInfo);
  }
  async updteCodeUsageCount(shopifyId: number, usageCount: number) {
    return await this.discountCodeRspt.update({ shopify_id: shopifyId }, { usage_count: usageCount });
  }

  async getDailyUsedCountByDiscountId(discountId: number) {
    return await this.discountCodeRspt
      .createQueryBuilder('dc')
      .select(`to_char(dc.assigned_at, 'YYYY-MM-DD') as date,count(*) as counts`)
      .where({ discount_id: discountId })
      .groupBy(`to_char(dc.assigned_at, 'YYYY-MM-DD')`)
      .execute();
  }
}
