import { DataSource, FindOptionsWhere, In, Like, Repository } from 'typeorm';
import { DiscountEntity } from '../entity/discount.entity';
import { DiscountMetafieldsEntity } from '../entity/discount.metafields.entity';
import { BulkCodesSettingEntity } from '../entity/bulk-code-setting';
import { ShopEntity } from '../entity/shop.entity';
import { Redis } from 'ioredis';
import { BulkCodeLib } from '../lib/bulk-code.lib';
import { DiscountBulkCodeEntity } from '../entity/discount-bulk-code';

export class DiscountCodeSettingModel {
  discountRspt: Repository<DiscountEntity>;
  database: DataSource;
  settingRsty: Repository<BulkCodesSettingEntity>;
  redis: Redis;
  constructor(database: DataSource, redis: Redis) {
    this.discountRspt = database.getRepository(DiscountEntity);
    this.settingRsty = database.getRepository(BulkCodesSettingEntity);
    this.database = database;
    this.redis = redis;
  }
  async saveCodeSetting(codes_setting: any) {
    let { codes, type, counts, prefix, suffix, random_length, discount_id, shop_id, shopify_discount_id, character_type } =
      codes_setting;
    //将裂变的设置保存到数据库中
    let settingRsty = this.database.getRepository(BulkCodesSettingEntity);
    let settingData = settingRsty.create();
    settingData.discount_shopify_id = shopify_discount_id;
    settingData.discount_id = discount_id;
    settingData.codes = codes.map(code => code.toUpperCase());
    settingData.type = type;
    settingData.shop_id = shop_id;
    settingData.counts = parseInt(counts);
    settingData.prefix = prefix;
    settingData.suffix = suffix;
    settingData.is_bulk = false;
    settingData.character_type = character_type;
    settingData.random_length = random_length;
    return await settingRsty.save(settingData);
  }

  async save(data: BulkCodesSettingEntity) {
    //将裂变的设置保存到数据库中
    let settingRsty = this.database.getRepository(BulkCodesSettingEntity);

    return await settingRsty.save(data);
  }
  async getLastInfoByDiscountId(discountId: number) {
    let settingInfo = await this.settingRsty.findOne({
      where: { discount_id: discountId },
      relations: ['shop'],
      order: { id: 'desc' }
    });
    return settingInfo;
  }
}
