import { DataSource, FindManyOptions, ILike, Repository } from 'typeorm';
import { Redis } from 'ioredis';
import { DiscountImportTasksEntity } from '../entity/discount.import.task.entity';
import { DisocuntImportRecordsEntity } from '../entity/discount.import.records.entity';
import { Shopify, ShopifyRestResources } from '@shopify/shopify-api';
import { SessionStorage } from '@shopify/shopify-app-session-storage';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { ShopifyGraphQLLib } from '../lib/shopify-graphql.lib';
import { CREATE_PRICE_RULE_WITH_CODE, UPDATE_PRICE_RULE_WITH_CODE } from '../controller/api/discount/discount.graphql';
import { ToolsLib } from '../lib/tools.lib';
import { ShopifySessionsEntity } from '../entity/script/shopify_sessions.entity';
export class DiscountImportTaskModel {
  imortTaskRspt: Repository<DiscountImportTasksEntity>;
  importRecordRspt: Repository<DisocuntImportRecordsEntity>;
  database: DataSource;
  redis: Redis;
  constructor(database: DataSource, redis: Redis) {
    this.imortTaskRspt = database.getRepository(DiscountImportTasksEntity);
    this.importRecordRspt = database.getRepository(DisocuntImportRecordsEntity);
    this.database = database;
    this.redis = redis;
  }
  async getList(params: { currentPage: number; pageSize: number; search: string; shop_id: number }) {
    const { currentPage, pageSize, search, shop_id } = params;
    let option: FindManyOptions<DiscountImportTasksEntity> = { where: { shop_id } };
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    if (search) {
      option['where'] = { title: ILike(`%${search}%`) };
    }
    option['order'] = { id: 'desc' };
    //.leftJoinAndMapOne('d.user', ShopifySessionsEntity, 'ss', `(online_access_info->>'id')::bigint=d.user_id`)
    const handle = this.imortTaskRspt
      .createQueryBuilder('tk')
      .leftJoinAndMapOne('tk.user', ShopifySessionsEntity, 'ss', `(online_access_info->>'id')::bigint=tk.user_id`)
      .skip(pageSize * (currentPage - 1))
      .take(pageSize);
    if (search) {
      handle.where({ title: ILike(`%${search}%`) });
    }
    handle.andWhere({ shop_id });
    return await handle.orderBy('tk.id', 'DESC').getMany();
  }
  async getPromisedList(id?: number) {
    let option: FindManyOptions<DiscountImportTasksEntity> = {
      where: {
        promise_sync: true,
        is_send_all: false
      }
    };
    if (id) {
      option['where']['id'] = id;
    }
    return await this.imortTaskRspt.find({
      where: {
        promise_sync: true,
        is_send_all: false
      }
    });
  }
  async getRecordList(params: { currentPage: number; pageSize: number; task_id: number }) {
    const { currentPage, pageSize, task_id } = params;
    let option: FindManyOptions<DisocuntImportRecordsEntity> = {};
    option.take = pageSize;
    option.skip = pageSize * (currentPage - 1);
    if (task_id) {
      option['where'] = { import_task_id: task_id };
    }
    option['order'] = { id: 'desc' };
    const list = await this.importRecordRspt.find(option);
    return list;
  }
  async getInfoById(id: number) {
    return await this.imortTaskRspt.findOneBy({ id });
  }
  async getRecordInfoById(id: number) {
    return await this.importRecordRspt.findOneBy({ id });
  }
  async getCount(params: { search: string; shop_id: number }) {
    const { search, shop_id } = params;
    let option: FindManyOptions<DiscountImportTasksEntity> = { where: { shop_id } };
    if (search) {
      option['where'] = { title: ILike(`%${search}%`) };
    }
    const count = await this.imortTaskRspt.count(option);
    return count;
  }
  async getRecordCount(params: { task_id: number }) {
    const { task_id } = params;
    let option: FindManyOptions<DisocuntImportRecordsEntity> = {};
    if (task_id) {
      option['where'] = { import_task_id: task_id };
    }
    const count = await this.importRecordRspt.count(option);
    return count;
  }
  async saveDiscountImportTask(info: DiscountImportTasksEntity, records: DisocuntImportRecordsEntity[]) {
    const queryRunner = this.database.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    let taskInfo: DiscountImportTasksEntity;
    try {
      taskInfo = await queryRunner.manager.save(DiscountImportTasksEntity, info);
      await queryRunner.manager.save(
        DisocuntImportRecordsEntity,
        records.map(item => ({ ...item, import_task_id: taskInfo.id }))
      );
      await queryRunner.commitTransaction();
    } catch (err) {
      console.log('error', err);
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
    }
    return taskInfo;
  }
  //start_ai_generated
  async getNotAsyncTask() {
    return await this.imortTaskRspt
      .createQueryBuilder('tk')
      .leftJoinAndMapMany('tk.records', DisocuntImportRecordsEntity, 'rc', 'rc.import_task_id = tk.id')
      .leftJoinAndMapOne('tk.shop', 'shops', 'shop', 'shop.id = tk.shop_id')
      .where('tk.promise_sync = :promise_sync', { promise_sync: true })
      .andWhere('tk.is_send_all = :is_send_all', { is_send_all: false })
      .andWhere('rc.sync_at is null')
      .getMany();
  }
  async getNotAsyncTaskInfo(id: number) {
    return await this.imortTaskRspt
      .createQueryBuilder('tk')
      .leftJoinAndMapMany('tk.records', DisocuntImportRecordsEntity, 'rc', 'rc.import_task_id = tk.id')
      .leftJoinAndMapOne('tk.shop', 'shops', 'shop', 'shop.id = tk.shop_id')
      .where('tk.promise_sync = :promise_sync', { promise_sync: true })
      .andWhere('tk.is_send_all = :is_send_all', { is_send_all: false })
      .andWhere('rc.sync_at is null')
      .andWhere('tk.id = :id', { id })
      .getOne();
  }
  async updateDiscountImportTask(info: DiscountImportTasksEntity) {
    return await this.imortTaskRspt.save(info);
  }
  async updateDiscountImportRecords(list: DisocuntImportRecordsEntity[]) {
    return await this.importRecordRspt.save(list);
  }

  async aysncDiscountToShopify(
    importTask: DiscountImportTasksEntity,
    api: Shopify<ShopifyRestResources>,
    sessionStorage: SessionStorage
  ) {
    if (!(await ToolsLib.lock(this.redis, `sync-import-discount_${importTask.id}`, 3 * 60 * 60))) return;
    let shopInfo = importTask['shop'];
    let records = importTask['records'];
    if (records.length == 0) {
      //将记录设置为已经发送完成
      importTask.is_send_all = true;
      await this.updateDiscountImportTask(importTask);
      return true;
    }
    //将data 按照code进行分组
    let importData: { [code: string]: any[] } = {};
    for (let i = 0; i < records.length; i++) {
      if (!importData[records[i].code]) importData[records[i].code] = [];
      importData[records[i].code].push(records[i]);
    }
    const offlineSessionId = api.session.getOfflineId(shopInfo.shopify_domain);
    let session = await sessionStorage.loadSession(offlineSessionId);
    if (!session) {
      return;
    }
    records = [];
    for (let code in importData) {
      let client = new ShopifyApiLib(session, api);
      let graphClient = new ShopifyGraphQLLib(session, api);
      let discountResult = await this.isCodeExist(client, code);
      if (importTask.import_type == 'create' && discountResult) {
        importData[code].map(item => {
          item.sync_at = new Date();
          (!item.status || !item.status.code) &&
            (item['extend'] = {
              code: 1001,
              msg: 'code已经存在',
              data: discountResult.discount_code
            });
          records.push(item);
        });
        continue;
      } else if (importTask.import_type == 'update' && !discountResult) {
        importData[code].map(item => {
          item.sync_at = new Date();
          (!item.status || !item.status.code) &&
            (item['extend'] = {
              code: 1001,
              msg: 'coe不存在',
              data: discountResult.discount_code
            });
          records.push(item);
        });
        continue;
      }

      //let priceRule = this.createDiscount(importData[code]);
      let priceRule = this.createGraphqlDiscount(importData[code]);
      if (importTask.combine_product_discount && !importData[code][0].combine_product_discount) {
        priceRule.combinesWith = {
          productDiscounts: true,
          orderDiscounts: false,
          shippingDiscounts: false
        };
      }
      if (!priceRule) {
        continue;
      }
      try {
        if (importTask.import_type == 'update') {
          let result: any = await graphClient.graphOnlineQL(UPDATE_PRICE_RULE_WITH_CODE, {
            priceRule: priceRule,
            id: 'gid://shopify/PriceRule/' + discountResult['discount_code'].price_rule_id
          });
          let priceRuleUpdate = result.body.data.priceRuleUpdate;
          importData[code].map(item => {
            item.sync_at = new Date();
            item['extend'] = {
              code: priceRuleUpdate?.priceRule?.id ? 200 : 1002,
              msg: priceRuleUpdate?.priceRule?.id ? '保存成功' : '保存失败',
              data: {
                discount: priceRuleUpdate?.priceRule?.id ? priceRuleUpdate.priceRule : priceRuleUpdate.priceRuleUserErrors
              }
            };
            records.push(item);
          });
        } else {
          let result: any = await graphClient.graphOnlineQL(CREATE_PRICE_RULE_WITH_CODE, {
            priceRule: priceRule,
            code: { code }
          });
          let data = result.body.data.priceRuleCreate;
          importData[code].map(item => {
            item.sync_at = new Date();
            item['extend'] = {
              code: data?.priceRule?.id ? 200 : 1002,
              msg: data?.priceRule?.id ? '保存成功' : '保存失败',
              data: {
                discount: data?.priceRule?.id ? data.priceRule : data.priceRuleUserErrors
              }
            };
            records.push(item);
          });
        }
      } catch (e) {
        importData[code].map(item => {
          item.sync_at = new Date();
          item['extend'] = {
            code: 1002,
            msg: e.message || '保存失败'
          };
          records.push(item);
        });
      }
    }
    //end_ai_generated
    //更新记录
    await this.updateDiscountImportRecords(records);
    //将记录设置为已经发送完成
    importTask.is_send_all = true;
    await this.updateDiscountImportTask(importTask);
    //解锁
    ToolsLib.unLock(this.redis, `sync-import-discount_${importTask.id}`);
  }
  async isCodeExist(client: ShopifyApiLib, code) {
    try {
      let result = await client.apiGet('discount_codes/lookup', { code: code });
      return result;
    } catch (e) {
      if (e.code == 404) {
        return false;
      }
      throw new Error(e);
    }
  }
  createGraphqlDiscount(data) {
    if (!data.filter(item => !item.status || item.status != 404).length) {
      return null;
    }
    let priceRule = {
      title: data[0].code,
      target: 'LINE_ITEM',
      combinesWith: {
        orderDiscounts: false,
        productDiscounts: false,
        shippingDiscounts: false
      },
      //allocationLimit: 1,
      allocationMethod:
        data[0].allocation_method && ['ACROSS', 'EACH'].includes(data[0].allocation_method)
          ? data[0].allocation_method
          : 'ACROSS',
      customerSelection: {
        forAllCustomers: true
      },
      validityPeriod: {
        start: data[0].start_date,
        end: data[0].end_date
      },
      itemEntitlements: {
        collectionIds: [],
        productIds: [],
        productVariantIds: data
          .filter(item => !item.status || item.status != 404)
          .map(item => 'gid://shopify/ProductVariant/' + item.variant_id),
        targetAllLineItems: false
      },
      oncePerCustomer: data[0].once_per_customer && data[0].once_per_customer == 'Y' ? true : false,
      usageLimit: data[0].usage_limit && data[0].usage_limit > 0 ? parseInt(`${data[0].usage_limit}`) : null,
      itemPrerequisites: {
        collectionIds: [],
        productIds: [],
        productVariantIds: []
      },
      prerequisiteQuantityRange: {},
      prerequisiteShippingPriceRange: {},
      prerequisiteSubtotalRange: {},
      prerequisiteToEntitlementQuantityRatio: {}
    };
    priceRule['value'] =
      data[0].value_type !== 'percentage'
        ? { fixedAmountValue: `-${Math.abs(parseFloat(data[0].value))}` }
        : { percentageValue: -Math.abs(parseInt(data[0].value)) };
    if (data[0].combine_product_discount == 'Y') {
      priceRule.combinesWith = {
        productDiscounts: true,
        orderDiscounts: false,
        shippingDiscounts: false
      };
    }
    return priceRule;
  }
}
