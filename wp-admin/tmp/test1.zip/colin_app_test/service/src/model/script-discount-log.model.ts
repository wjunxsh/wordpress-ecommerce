import { DataSource, In, Repository, SelectQueryBuilder } from 'typeorm';
import { ScriptDiscountLogEntity } from '../entity/script/script_discount_log.entity';
import { ShopEntity } from '../entity/shop.entity';
import { ScriptFunctionEntity } from '../entity/script/script_function.entity';
import { ShopifySessionsEntity } from '../entity/script/shopify_sessions.entity';
export class ScriptDiscountLogModel {
  RedisClient: any;
  ReferralKeyNamePrefix: string;
  private scriptDiscountRspt: Repository<ScriptDiscountLogEntity>;
  private shopifySessionRspt: Repository<ShopifySessionsEntity>;
  private database: DataSource;
  constructor(database: DataSource) {
    this.database = database;
    this.scriptDiscountRspt = this.database.getRepository(ScriptDiscountLogEntity);
    this.shopifySessionRspt = this.database.getRepository(ShopifySessionsEntity);
  }
  async getDiscountList(params: {
    discountId?: number;
    shop_id: number;
    title: string;
    current_page: number;
    page_size: number;
    auth_shop_ids?: string[];
  }) {
    const { title, shop_id, current_page, page_size, discountId, auth_shop_ids } = params;
    let handle = this.scriptDiscountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .leftJoinAndMapOne('d.function', ScriptFunctionEntity, 'sc', 'sc.function_key=d.function_id')
      .leftJoinAndMapOne('d.user', ShopifySessionsEntity, 'ss', `(online_access_info->>'id')::bigint=d.user_id`)
      .orderBy('d.sort', 'ASC')
      .addOrderBy('d.created_at', 'ASC')
      .take(page_size)
      .skip(page_size * (current_page - 1))
      .where('1=1');
    this.getWhere({ shop_id, title, discountId, auth_shop_ids }, handle);
    let list = await handle.getMany();
    return list;
  }
  async getEmailFromDiscountLogs(discountIds: number[]) {
    let list = await this.scriptDiscountRspt
      .createQueryBuilder('d')
      .where({ discount_id: In(discountIds) })
      .andWhere('u.email is not null')
      .andWhere(`u.email != 'admin@anker-in.com'`)
      .select(['d.discount_id', 'u.email'])
      .groupBy('discount_id,email')
      .getRawMany();
    return list.map(item => ({
      discount_id: item.d_discount_id,
      email: item.u_email
    }));
  }
  async getDiscountCount(params: { discountId?: number; shop_id: number; title: string }) {
    const { title, shop_id, discountId } = params;
    let handle = this.scriptDiscountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .where('1=1');
    this.getWhere({ shop_id, title, discountId }, handle);
    return await handle.getCount();
  }
  private getWhere(
    params: { auth_shop_ids?: string[]; state?: string; shop_id?: number; title?: string; discountId?: number },
    handle: SelectQueryBuilder<ScriptDiscountLogEntity>
  ) {
    const { auth_shop_ids, discountId = 0, title = null, shop_id = null, state = null } = params;
    if (title) {
      handle.andWhere(`d.title like '%${title}%'`);
    }
    if (auth_shop_ids && auth_shop_ids.length) {
      handle.andWhere(`d.shop_id in (${auth_shop_ids.join(',')})`);
    } else if (auth_shop_ids && auth_shop_ids.length == 0) {
      handle.andWhere(`d.shop_id = -1`);
    }
    if (discountId) {
      handle.andWhere(`d.discount_id = ${discountId}`);
    }

    if (shop_id) {
      handle.andWhere(`d.shop_id = '${shop_id}'`);
    }
    if (state) {
      handle.andWhere(`d.state = '${state}'`);
    }
  }
}
