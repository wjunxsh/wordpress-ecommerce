import { DataSource, In, IsNull, LessThan, Repository } from 'typeorm';
import { DiscountVariantEntity } from '../entity/discount.variant.entity';
import { DiscountEntity } from '../entity/discount.entity';
import { ProductModel } from './product.model';
import dayjs from 'dayjs';
export class DiscountVariantModel {
  discountVariantRspt: Repository<DiscountVariantEntity>;
  productModel: ProductModel;
  database: DataSource;
  discountRspt: Repository<DiscountEntity>;
  constructor(database: DataSource) {
    this.discountVariantRspt = database.getRepository(DiscountVariantEntity);
    this.database = database;
    this.discountRspt = database.getRepository(DiscountEntity);
    this.productModel = new ProductModel(database);
  }
  async getNotWriteMetaifieldVariantShopifyIds(shop_id: number) {
    let variants = await this.discountVariantRspt
      .createQueryBuilder('dv')
      .where({ starts_at: LessThan(new Date()), shop_id, async_time: IsNull() })
      .andWhere(`(dv.ends_at is null or dv.ends_at >:date)`, { date: dayjs().toISOString() })
      .getMany();
    return variants.map(item => item.shopify_variant_id);
  }
  async getListVariantShopifyIds(shopifyVariantIds: number[]) {
    return await this.discountVariantRspt.find({
      where: { shopify_variant_id: In(shopifyVariantIds) },
      relations: ['discount']
    });
  }
  async getNeedDeleteList() {
    return await this.discountVariantRspt
      .createQueryBuilder('dv')
      .where(`(dv.need_delete= true or dv.ends_at<=:date)`, {
        date: dayjs().toISOString()
      })
      .andWhere(`(dv.extend is null or dv.extend->> 'delete_error' is null)`)
      .limit(1000)
      .getMany();
  }
  async saveData(
    discountInfo: DiscountEntity,
    addDiscountVariants: DiscountVariantEntity[],
    delDiscountVariants: DiscountVariantEntity[]
  ) {
    const queryRunner = this.database.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.update(DiscountEntity, { id: discountInfo['id'] }, { set_discount_variant: true });
      addDiscountVariants.length &&
        (await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(DiscountVariantEntity)
          .values(addDiscountVariants)
          .orUpdate(
            [
              'title',
              'variant_price',
              'value_type',
              'value',
              'fixed_value',
              'value_style',
              'variant_price4wscode',
              'currency_symbol',
              'fixed_amount_sort_key',
              'percentage_sort_key',
              'async_time',
              'starts_at',
              'ends_at',
              'need_delete'
            ],
            ['discount_id', 'shopify_variant_id']
          )
          .execute());

      delDiscountVariants.length &&
        (await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(DiscountVariantEntity)
          .values(delDiscountVariants)
          .orUpdate(['need_delete'], ['discount_id', 'shopify_variant_id'])
          .execute());
      await queryRunner.commitTransaction();
    } catch (e) {
      await queryRunner.rollbackTransaction();
      throw e;
    } finally {
      await queryRunner.release();
    }
  }
  async updateDiscountVariantByProductId(productShopifyId: number) {
    //获取产品对应的所有discount
    let discountList = await this.discountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapMany('d.discountVariants', DiscountVariantEntity, 'dv', 'dv.discount_id=d.id')
      .where('(d.ends_at is null or d.ends_at >=:date)', { date: dayjs().toISOString() })
      .andWhere(`dv.shopify_product_id =:productShopifyId`, { productShopifyId })
      .getMany();
    if (!discountList.length) return;
    //更新折扣字段
    await this.discountRspt.update({ id: In(discountList.map(item => item.id)) }, { set_discount_variant: false });
  }
}
