import { DataSource, Repository } from 'typeorm';
import { ShopEntity } from '../entity/shop.entity';
import { BirthdayCodeEntity } from '../entity/birthday-code.entity';
export class BirthdayCodeModel {
  birthdayCodeRspt: Repository<BirthdayCodeEntity>;
  shopRspt: Repository<ShopEntity>;
  database: DataSource;
  constructor(database: DataSource) {
    this.shopRspt = database.getRepository(ShopEntity);
    this.birthdayCodeRspt = database.getRepository(BirthdayCodeEntity);
    this.database = database;
  }
  async getBirthdayCode(email: string, birthday: string) {
    let info = await this.birthdayCodeRspt.findOneBy({
      email,
      birthday
    });
    return info?.code || null;
  }
  async saveBirthdayCode(code: string, email: string, birthday: string) {
    let saveData = new BirthdayCodeEntity();
    saveData = {
      ...saveData,
      email,
      birthday,
      code
    };
    let info = await this.birthdayCodeRspt.save(saveData);
    return info?.code || null;
  }
}
