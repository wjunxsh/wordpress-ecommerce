import { DataSource, FindOptionsWhere, ILike, In, LessThanOrEqual, Repository } from 'typeorm';
import { DiscountEntity } from '../entity/discount.entity';
import { DiscountMetafieldsEntity } from '../entity/discount.metafields.entity';
import { ShopEntity } from '../entity/shop.entity';
import { DiscountBulkCodeEntity } from '../entity/discount-bulk-code';
import { DiscountBulkCodeBakEntity } from '../entity/discount-bulk-code-bak.entity';
import dayjs from 'dayjs';
import { DiscountVariantEntity } from '../entity/discount.variant.entity';
interface PriceRuleParam {
  shopShopifyId?: number;
  shopifyDomain?: string;
  shopifyId?: number;
  title?: string;
  search?: string;
}
export class DiscountModel {
  discountRspt: Repository<DiscountEntity>;
  codeRspt: Repository<DiscountBulkCodeEntity>;
  bakCodeRspt: Repository<DiscountBulkCodeBakEntity>;
  discountVariantRspt: Repository<DiscountVariantEntity>;
  database: DataSource;
  constructor(database: DataSource) {
    this.discountRspt = database.getRepository(DiscountEntity);
    this.bakCodeRspt = database.getRepository(DiscountBulkCodeBakEntity);
    this.codeRspt = database.getRepository(DiscountBulkCodeEntity);
    this.discountVariantRspt = database.getRepository(DiscountVariantEntity);
    this.database = database;
  }
  async getPriceRulesByShop(params: PriceRuleParam) {
    let where: FindOptionsWhere<DiscountEntity> = {};

    if (params.shopShopifyId) {
      where['shop'] = { shopify_id: params.shopShopifyId };
    }
    if (params.shopifyId) {
      where['shopify_id'] = params.shopifyId;
    }
    if (params.shopifyDomain) {
      where['shop_domain'] = params.shopifyDomain;
    }
    if (params.title) {
      where['title'] = params.title;
    }
    if (params.search) {
      where.title = ILike(`%${params.search}%`);
    }
    return await this.discountRspt.find({ where, take: 100, order: { shopify_created_at: 'desc' } });
  }
  async saveDiscount(data: DiscountEntity, metafields: DiscountMetafieldsEntity[]) {
    const queryRunner = this.database.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      if (data.id) {
        data.updated_at = new Date();
      } else {
        data.created_at = new Date();
        data.updated_at = new Date();
      }
      let discountInfo = await queryRunner.manager.save(DiscountEntity, data);
      metafields.forEach(item => {
        item.discount_id = discountInfo.id;
      });
      if (metafields.length) {
        await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(DiscountMetafieldsEntity)
          .values(metafields)
          .orUpdate(['is_need_delete', 'metafield_value', 'start_sync_at', 'sync_at'], ['id'])
          .execute();
      }
      await queryRunner.commitTransaction();
      return discountInfo;
    } catch (e) {
      await queryRunner.rollbackTransaction();
      throw e;
    } finally {
      await queryRunner.release();
    }
  }
  async getDiscountInfo(where: FindOptionsWhere<DiscountEntity>) {
    return await this.discountRspt.findOneBy(where);
  }
  async getDiscountList(where: FindOptionsWhere<DiscountEntity>) {
    return await this.discountRspt.findBy(where);
  }
  async getDiscountInfoById(id: number) {
    return await this.discountRspt.findOneBy({ id });
  }
  async getNotSyncToShopifyDiscounts() {
    return await this.discountRspt
      .createQueryBuilder('d')
      .leftJoinAndSelect(ShopEntity, 's', 's.id=d.shop_id')
      .leftJoinAndSelect(DiscountBulkCodeEntity, 'b', 'd.id=b.discount_id')
      .select('d.id as discount_id,s.shopify_id as shopify_shop_id')
      .where('b.sync_at is null and b.id is not null and b.shopify_id is null and d.is_bulk_discount=true')
      .groupBy('d.id,s.shopify_id')
      .execute();
  }
  async getDiscountsThatNotDeleteCodes() {
    return await this.discountRspt
      .createQueryBuilder('d')
      .withDeleted()
      .leftJoinAndSelect(ShopEntity, 's', 's.id=d.shop_id')
      .leftJoinAndSelect(DiscountBulkCodeEntity, 'b', 'd.id=b.discount_id')
      .select('d.id,s.shopify_id as shopify_shop_id')
      .where('d.deleted_at is not null and b.discount_id is not null')
      .groupBy('d.id,s.shopify_id')
      .execute();
  }
  async deleteDiscount(discountInfo: DiscountEntity) {
    try {
      await this.discountRspt.softRemove(discountInfo);
      await this.bakCodeRspt.update({ discount_id: discountInfo['id'] }, { deleted_at: new Date() });
      await this.codeRspt.delete({ discount_id: discountInfo.id });
      await this.discountVariantRspt.update({ discount_id: discountInfo.id }, { need_delete: true });
    } catch (e) {
      console.log(e);
    }
  }
  async getBirsthdayDiscountsByShopIds(shopIds: number[]) {
    return await this.discountRspt.find({
      where: {
        shop_id: In(shopIds),
        is_birthday: true,
        is_bulk_discount: true
      }
    });
  }
  async getNotExpiredList() {
    return await this.discountRspt
      .createQueryBuilder('d')
      .where('(ends_at is null or ends_at >=:date)', { date: dayjs().format('YYYY-MM-DD HH:mm:ss') })
      .andWhere({ auto_increment_code: true })
      .andWhere({ starts_at: LessThanOrEqual(new Date()) })
      .getMany();
  }
}
