import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { SmsShopEntity } from '../sms_entity/shop.entity';
import { SmsDiscountCode } from '../sms_entity/discount_code.entity';
import { SmsPriceRulesEntity } from '../sms_entity/price_rules.entity';
import { SmsOrderEntity } from '../sms_entity/order.entity';
import { ShopSettingsEntity } from '../sms_entity/shop_settings.entity';
class SmsDatabase extends DataSource {
  public static async initial() {
    let database = new SmsDatabase();
    await database.initialize();
    return database;
  }
  constructor() {
    super({
      type: 'postgres',
      host: process.env.SMS_DATABASE_HOST || '127.0.0.1',
      port: parseInt(process.env.SMS_DATABASE_PORT || '5432'),
      username: process.env.SMS_DATABASE_USERNAME || '',
      password: process.env.SMS_DATABASE_PASSWORD || '123456',
      database: process.env.SMS_DATABASE_NAME || 'discount-app',
      synchronize: false, //要设置为false，不自动去更新库信息
      migrationsRun: false,
      //ssl:true,
      logging: false,
      migrations: ['dist/migrations/**/*.{js,ts}'],
      entities: [SmsShopEntity, SmsDiscountCode, SmsPriceRulesEntity, SmsOrderEntity, ShopSettingsEntity],
      subscribers: []
    });
  }
}

export default SmsDatabase;
