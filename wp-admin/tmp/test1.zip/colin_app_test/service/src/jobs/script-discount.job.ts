import * as cron from 'node-cron';
import dayjs from 'dayjs';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ScriptMetafieldsModel } from '../model/script/script-discount-metafields.model';
import { DataType, Session } from '@shopify/shopify-api';
import { ShopifyGraphQLLib } from '../lib/shopify-graphql.lib';
import { metafieldStorefrontVisibilityCreate } from '../graphql/metafields.graphql';
import { ShopEntity } from '../entity/shop.entity';
import { ScriptProductTagModel } from '../model/script/script-product-tag.model';
import { In } from 'typeorm';
import { JobInterface } from './interface';
import { JobBasis } from './job-base';
const shopifyMetafieldsTypes = {
  variant: 'variants',
  product: 'products',
  shop: ''
};
const shopifyMetafieldsVisibleTypes = {
  variant: 'PRODUCTVARIANT',
  product: 'PRODUCT',
  shop: 'SHOP'
};
dayjs.extend(utc);
dayjs.extend(timezone);
const catchKeys = {
  DELETE_SHOPIFY: 'delete_code_key',
  AUTO_INCREMENT_CODE: 'auto_increment_code'
};
export interface ShopAuthObject {
  shopify_id: number;
  shopify_domain: string;
  shopifyApi: ShopifyApiLib;
  shopifyGraphql: ShopifyGraphQLLib;
}
export interface ShopAuth {
  [shopify_id: number]: ShopAuthObject;
}
export class ScriptDiscountJob extends JobBasis {
  private shopifyApis: ShopAuth = {};
  scriptMetafieldService: ScriptMetafieldsModel;
  scriptProductTagService: ScriptProductTagModel;
  constructor(bootstrap: JobInterface) {
    super(bootstrap);
    this.scriptMetafieldService = new ScriptMetafieldsModel(bootstrap.database);
    this.scriptProductTagService = new ScriptProductTagModel(bootstrap.database);
    this.shopifyApis = {};
  }
  initial() {
    //获取店铺信息
    this.clearCatche();
    cron.schedule(
      process.env.NODE_ENV === 'development' ? '10,20,40,30,50,0 * * * * *' : '50 */3 * * * *',
      this.syncDiscountMetafields.bind(this)
    );
    cron.schedule('50 */3 * * * *', this.syncDiscountProµductTags.bind(this));
    cron.schedule('50 */3 * * * *', this.deleteDiscountMetafields.bind(this));
    cron.schedule('50 */3 * * * *', this.deleteProductTag.bind(this));
    cron.schedule('50 */3 * * * *', this.deleteMetafieldsFromShopify.bind(this));
    cron.schedule('50 */3 * * * *', this.deleteProductTagFromShopify.bind(this));

    return this;
  }
  async clearCatche() {
    let keys = Object.values(catchKeys);
    for (let key of keys) {
      await this.unLock(key);
    }
  }
  async syncDiscountMetafields() {
    if (process.env.STOP_CRON === 'true') {
      return;
    }
    //获取即将开始的所有活动
    let metafieldList = await this.scriptMetafieldService.getNotSyncScriptsMetafields();
    let shopList = metafieldList.map((item: any) => item.shop);
    await this.getShopsToken(shopList);
    //获取所有店铺的信息
    if (metafieldList.length == 0) {
      return false;
    }
    for (let metafield of metafieldList) {
      let shop_shopify_id = metafield['shop']['shopify_id'];
      if (!this.isExistToken(metafield['shop'])) {
        continue;
      }
      //获取除了本次活动的其他活动对应的相同namespace，相同target_shopify_id的metafield
      let otherMetafields = await this.scriptMetafieldService.getOthersNotExpiredMetafields(metafield);
      if (otherMetafields.length) {
        //如果有其他的排序优先级高于本次设置，则直接更新值，并返回
        if (metafield['sort'] > otherMetafields[0]['sort']) {
          await this.scriptMetafieldService.updateMetafield({
            ...metafield,
            metafield_shopify_id: otherMetafields[0].metafield_shopify_id,
            sync_at: otherMetafields[0].sync_at
          });
          continue;
        }
      }
      //判断获取的优先级是否大于
      let shopifyApi = this.shopifyApis[shop_shopify_id]['shopifyApi'];
      let shopifyGraphql = this.shopifyApis[shop_shopify_id]['shopifyGraphql'];
      let metafieldResult: any = null;
      let path = `${shopifyMetafieldsTypes[metafield['target_type']]}/${metafield.target_shopify_id}/metafields`;
      if (metafield['target_type'] == 'shop') {
        path = `metafields`;
      }
      try {
        console.log(path, {
          namespace: metafield.metafield_namespace,
          key: metafield.metafield_key,
          type: metafield.metafield_type,
          value: metafield.metafield_value
        });
        metafieldResult = await shopifyApi.apiPost({
          path: path,
          type: DataType.JSON,
          data: {
            metafield: {
              namespace: metafield.metafield_namespace,
              key: metafield.metafield_key,
              type: metafield.metafield_type,
              value: metafield.metafield_value
            }
          }
        });
        //console.log(metafieldResult);
        //更新metafields是否可见
        await shopifyGraphql.graphOfflineQL(metafieldStorefrontVisibilityCreate, {
          input: {
            ownerType: shopifyMetafieldsVisibleTypes[metafield['target_type']],
            key: metafield.metafield_key,
            namespace: metafield.metafield_namespace
          }
        });
        await this.scriptMetafieldService.updateMetafield({
          ...metafield,
          metafield_shopify_id: metafieldResult.body.metafield.id,
          sync_at: metafieldResult.body.metafield.created_at
        });
      } catch (e) {
        console.log('sync metafields to shopify:');
        console.log(e);
      }
    }
  }
  async syncDiscountProµductTags() {
    //获取即将开始的所有活动
    let productTags = await this.scriptProductTagService.getNotSyncScriptsProductTag();
    //获取所有店铺的信息
    if (productTags.length == 0) {
      return false;
    }
    let shopList = productTags.map((item: any) => item.shop);
    await this.getShopsToken(shopList);
    for (let productTag of productTags) {
      //调用shopify接口将metafields
      try {
        let shop_shopify_id = productTag['shop']['shopify_id'];
        if (!this.isExistToken(productTag['shop'])) {
          continue;
        }
        let shopifyApi = this.shopifyApis[shop_shopify_id]['shopifyApi'];
        let productResult = await shopifyApi.apiGet(`products/${productTag.product_shopify_id}`, {});
        let product = productResult.product;
        let tags: string[] = product.tags.split(',');
        if (!tags.includes(productTag.product_tag)) {
          await this.updateProductTags(shopifyApi, productTag.product_shopify_id, [...tags, productTag.product_tag]);
        }
        await this.scriptProductTagService.updateProductTag({
          ...productTag,
          sync_at: new Date(),
          sync_state: true
        });
      } catch (e) {
        if (e?.code == 404) {
          await this.scriptProductTagService.deleteProductTag(productTag);
        }
        console.log(e);
      }
    }
  }

  async deleteDiscountMetafields() {
    if (process.env.STOP_CRON === 'true') {
      return;
    }
    //获取即将开始的所有活动
    let metafieldList = await this.scriptMetafieldService.getNotDeleteScriptsMetafields();
    //获取所有店铺的信息
    if (metafieldList.length == 0) {
      return false;
    }
    //从discount app 获取 店铺的auth token
    let shopList = metafieldList.map((item: any) => item.shop);
    await this.getShopsToken(shopList);
    //调用shopify接口将metafields
    for (let metafield of metafieldList) {
      try {
        let shop_shopify_id = metafield['shop']['shopify_id'];
        if (!this.isExistToken(metafield['shop'])) {
          continue;
        }
        if (metafield.target_shopify_id) {
          let shopifyApi = this.shopifyApis[shop_shopify_id]['shopifyApi'];
          try {
            await shopifyApi.apiDelete(
              `${metafield.target_type == 'variant' ? 'variants' : 'products'}/${metafield.target_shopify_id}/metafields/${
                metafield.metafield_shopify_id
              }`
            );
          } catch (e) {
            if (e.code != 404) {
              throw e;
            }
          }
        }
        await this.scriptMetafieldService.deleteMetafield(metafield);
        //获取是否具有相同目标的 和类型的 metafield
        let otherMetafields = await this.scriptMetafieldService.getOthersNotExpiredMetafields(metafield);
        if (otherMetafields.length) {
          await this.scriptMetafieldService.scriptMetaifeldsRspt.update(
            { uuid: In((await otherMetafields).map(item => item.uuid)) },
            { metafield_shopify_id: null, sync_at: null }
          );
        }
      } catch (e) {
        console.log(e);
      }
    }
  }

  async deleteProductTag() {
    if (process.env.STOP_CRON === 'true') {
      return;
    }
    let productTags = await this.scriptProductTagService.getNotDeleteProductTag();
    //获取即将开始的所有活动
    try {
      productTags = await this.scriptProductTagService.getNotDeleteProductTag();
    } catch (e) {
      console.log(e);
    }
    //获取所有店铺的信息
    if (productTags.length == 0) {
      return false;
    }
    //从discount app 获取 店铺的auth token
    let shopList = productTags.map((item: any) => item.shop);
    await this.getShopsToken(shopList);
    //调用shopify接口将metafields
    for (let productTag of productTags) {
      try {
        let shop_shopify_id = productTag['shop']['shopify_id'];
        if (!this.isExistToken(productTag['shop'])) {
          continue;
        }
        let shopifyApi = this.shopifyApis[shop_shopify_id].shopifyApi;
        //修改shopify 产品的product tag
        //根据product_shopify_id 和 product_tag  获取是否还有其他的活动在进行
        let productResult = await shopifyApi.apiGet(`products/${productTag.product_shopify_id}`, {});
        let product = productResult.product;
        let tags: string[] = product.tags.split(',');
        tags = tags.map(item => item.trim());
        if (!this.scriptProductTagService.isTagExistOtherDiscount(productTag) || tags.includes(productTag.product_tag)) {
          tags = tags.filter(tag => tag != productTag.product_tag);
          await this.updateProductTags(shopifyApi, productTag.product_shopify_id, tags);
        }
        await this.scriptProductTagService.deleteProductTag(productTag);
      } catch (e) {
        if (e?.code == 404) {
          await this.scriptProductTagService.updateProductTag({
            ...productTag,
            sync_at: new Date(),
            sync_state: false
          });
        }
        console.log(e);
      }
    }
  }

  /**
   * 删除活动已经自动过期的metafield
   * @returns
   */
  async deleteMetafieldsFromShopify() {
    if (process.env.STOP_CRON === 'true') {
      return;
    }
    //获取修改了活动时间，使得活动还未生效的已经同步到shopify的metafields
    let metafieldList = await this.scriptMetafieldService.getChangeButNotDeleteMetafields();
    //获取所有店铺的信息
    if (metafieldList.length == 0) {
      return false;
    }
    //从discount app 获取 店铺的auth token
    let shopList = metafieldList.map((item: any) => item.shop);
    await this.getShopsToken(shopList);
    //调用shopify接口将metafields
    try {
      for (let metafield of metafieldList) {
        let shop_shopify_id = metafield['shop']['shopify_id'];
        if (!this.isExistToken(metafield['shop'])) {
          continue;
        }
        if (metafield.target_shopify_id) {
          let shopifyApiLib = this.shopifyApis[shop_shopify_id].shopifyApi;
          try {
            await shopifyApiLib.apiDelete(
              `${metafield.target_type == 'variant' ? 'variants' : 'products'}/${metafield.target_shopify_id}/metafields/${
                metafield.metafield_shopify_id
              }`
            );
          } catch (e) {
            if (e.code != 404) {
              throw e;
            }
          }
        }
        await this.scriptMetafieldService.updateMetafield({
          ...metafield,
          updated_at: new Date(),
          metafield_shopify_id: null
        });
        let otherMetafields = await this.scriptMetafieldService.getOthersNotExpiredMetafields(metafield);
        if (otherMetafields.length) {
          await this.scriptMetafieldService.scriptMetaifeldsRspt.update(
            { uuid: In((await otherMetafields).map(item => item.uuid)) },
            { metafield_shopify_id: null, sync_at: null }
          );
        }
      }
    } catch (e) {
      console.log(e);
    }
  }

  async deleteProductTagFromShopify() {
    if (process.env.STOP_CRON === 'true') {
      return;
    }
    //获取即将开始的所有活动
    let productTagList = await this.scriptProductTagService.getChangeButNotDeleteProductTags();
    //获取所有店铺的信息
    if (productTagList.length == 0) {
      return false;
    }
    //从discount app 获取 店铺的auth token
    let shopList = productTagList.map((item: any) => item.shop);
    await this.getShopsToken(shopList);
    //调用shopify接口将metafields
    try {
      for (let productTag of productTagList) {
        let shop_shopify_id = productTag['shop']['shopify_id'];
        if (!this.isExistToken(productTag['shop'])) {
          continue;
        }
        let shopifyApiLib = this.shopifyApis[shop_shopify_id].shopifyApi;
        //根据product_shopify_id 和 product_tag  获取是否还有其他的活动在进行
        let productResult = await shopifyApiLib.apiGet(`products/${productTag.product_shopify_id}`, {});
        let product = productResult.product;
        let tags: string[] = product.tags.split(',');
        tags = tags.map(item => item.trim());
        if (!this.scriptProductTagService.isTagExistOtherDiscount(productTag) || tags.includes(productTag.product_tag)) {
          tags = tags.filter(tag => tag != productTag.product_tag);
          await this.updateProductTags(shopifyApiLib, productTag.product_shopify_id, tags);
        }
        await this.scriptProductTagService.updateProductTag({ ...productTag, sync_state: false });
      }
    } catch (e) {
      console.log(e);
    }
  }

  private async updateProductTags(shopifyApiLib: ShopifyApiLib, product_shopify_id: number, tags: string[]) {
    return await shopifyApiLib.apiPut({
      path: `products/${product_shopify_id}`,
      type: DataType.JSON,
      data: {
        product: {
          id: product_shopify_id,
          tags: tags.length ? tags.join(',') : ''
        }
      }
    });
  }
  private isExistToken(shopInfo: ShopEntity) {
    let shop_shopify_id = shopInfo['shopify_id'];
    if (!this.shopifyApis[shop_shopify_id]) {
      return false;
    }
    return true;
  }
  async getShopsToken(shopList: { shopify_domain: string; shopify_id: number }[]) {
    shopList.filter(shopInfo => !this.shopifyApis[shopInfo['shopify_id']]);
    if (shopList.length) {
      for (let shopInfo of shopList) {
        const offlineSessionId = this.api.session.getOfflineId(shopInfo['shopify_domain']);
        let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
        let shopifyApi = new ShopifyApiLib(session, this.api);
        let shopifyGraphql = new ShopifyGraphQLLib(session, this.api);
        this.shopifyApis[shopInfo['shopify_id']] = {
          ...shopInfo,
          shopifyGraphql: shopifyGraphql,
          shopifyApi: shopifyApi
        };
      }
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
}
