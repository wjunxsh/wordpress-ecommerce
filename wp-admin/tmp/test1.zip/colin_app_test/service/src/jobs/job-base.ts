import { DataSource } from 'typeorm';
import { Redis } from 'ioredis';
import { Shopify } from '@shopify/shopify-api';
import { SessionStorage } from '@shopify/shopify-app-session-storage';
import { Logger } from 'winston';
import { JobInterface } from './interface';

export class JobBasis {
  public database: DataSource;
  public redis: Redis;
  public api: Shopify;
  public logger: Logger;
  public sessionStorage: SessionStorage;
  constructor(bootstrap: JobInterface) {
    this.database = bootstrap.database;
    this.redis = bootstrap.redis;
    this.logger = bootstrap.logger;
    this.api = bootstrap.api;
    this.sessionStorage = bootstrap.sessionStorage;
  }
}
