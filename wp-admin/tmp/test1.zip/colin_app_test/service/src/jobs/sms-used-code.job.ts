import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { DataSource, In, MoreThanOrEqual } from 'typeorm';
import { SmsDiscountCode } from '../sms_entity/discount_code.entity';
import { SmsShopEntity } from '../sms_entity/shop.entity';
import { ShopModel } from '../model/shop.model';
import { ShopEntity } from '../entity/shop.entity';
import { DiscountBulkCodeEntity } from '../entity/discount-bulk-code';
import { DiscountModel } from '../model/discount.mode';
import { ShopSettingsEntity } from '../sms_entity/shop_settings.entity';
import * as yaml from 'js-yaml';
import { BulkCodesSettingEntity } from '../entity/bulk-code-setting';
import { DiscountEntity } from '../entity/discount.entity';
import { DiscountCodeSettingModel } from '../model/discount.code.setting.model';
import { JobBasis } from './job-base';
import { SmsJobInterface } from './interface';
dayjs.extend(utc);
dayjs.extend(timezone);
/**
 * 直连sms库，暂不启用，因为一样无法解决rainbow的主从库的问题
 */
export interface PriceRuleSetting {
  prefix: string;
  suffix?: string;
  amount?: number;
  validity_days?: number;
}
export class SmsUsedCodeJob extends JobBasis {
  private redisCacheKey = 'used_codes_last_updated_at_new';
  private redisSettingCacheKey = 'used_codes_last_updated_at_setting';
  private smsDatabase: DataSource;
  constructor(bootstrap: SmsJobInterface) {
    super(bootstrap);
    this.smsDatabase = bootstrap.smsDatabase;
  }
  initial() {
    this.clearCache();
    //cron.schedule('2 * * * * *', this.getUsedCodes.bind(this));
    //cron.schedule('2 */5 * * * *', this.syncSmsPriceRuleSetting.bind(this));
  }
  async clearCache() {
    let keys = await this.redis.keys(`setnx-*${this.redisCacheKey}`);
    if (keys.length > 0) {
      for (let key of keys) {
        await this.redis.del(key);
      }
    }
    keys = await this.redis.keys(`setnx-*${this.redisSettingCacheKey}`);
    if (keys.length > 0) {
      for (let key of keys) {
        await this.redis.del(key);
      }
    }
  }

  async getDiscountUsedCodes(lastUpdatesAt: Date, shopId: string, skip: number = 0) {
    let smsDiscountCodeRspt = this.smsDatabase.getRepository(SmsDiscountCode);
    let usedCodesList: any = await smsDiscountCodeRspt
      .createQueryBuilder('dc')
      .where({ assigned: true, shopId, updatedAt: MoreThanOrEqual(lastUpdatesAt) })
      .select([
        'dc.id',
        'dc.shopifyId',
        'dc.assigned',
        'dc.assignedEmail',
        'dc.code',
        'dc.shopifyPriceRuleId',
        'dc.updatedAt',
        'dc.expiredAt',
        'dc.deletedAt'
      ])
      .take(500)
      .skip(skip)
      .orderBy('dc.updatedAt', 'ASC')
      .getMany();
    return usedCodesList;
  }

  //@Cron('*/50 */2 * * * *')1
  async getUsedCodes() {
    let shopModel = new ShopModel(this.database);
    console.log('-----getUsedCodes---');
    //获取店铺信息
    try {
      let shopList = await shopModel.getActiveShops();
      for (let shopInfo of shopList) {
        this.sendUsedCodesToDiscountApp(shopInfo);
      }
    } catch (e) {
      console.log(e);
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
  async sendUsedCodesToDiscountApp(shop: ShopEntity) {
    let shopRspt = this.smsDatabase.getRepository(SmsShopEntity);

    let shopInfo = await shopRspt.findOne({ where: { shopify_id: shop['shopify_id'] } });
    if (!shopInfo) {
      return;
    }
    if (!(await this.lock(`${shopInfo.shopify_id}-${this.redisCacheKey}`, 2 * 60 * 60))) return;
    let minUpdatedAt = await this.redis.get(shopInfo['shopify_id'] + this.redisCacheKey);
    console.log('sync used 1codes---', minUpdatedAt, shopInfo['shopify_id']);
    let updatedAt = minUpdatedAt ? minUpdatedAt : dayjs().subtract(3, 'year').format();
    let skip = 0;
    while (true) {
      let codeList = await this.getDiscountUsedCodes(dayjs(updatedAt).toDate(), `${shopInfo['id']}`, skip);
      if (!codeList.length) {
        skip != 0 &&
          (await this.redis.set(
            shopInfo['shopify_id'] + this.redisCacheKey,
            dayjs(updatedAt).add(60, 'second').format(),
            'EX',
            10 * 24 * 60 * 60
          ));
        break;
      }
      await this.updateUsedCodes(
        codeList.map(item => ({ ...item, shopifyShopId: shop.shopify_id })),
        shop
      );
      await this.redis.set(
        shopInfo['shopify_id'] + this.redisCacheKey,
        dayjs(codeList[codeList.length - 1]['updatedAt']).format(),
        'EX',
        10 * 24 * 60 * 60
      );
      if (updatedAt == dayjs(codeList[codeList.length - 1]['updatedAt']).format()) {
        skip++;
      } else {
        updatedAt = dayjs(codeList[codeList.length - 1]['updatedAt']).format();
      }
    }
    if (!(await this.unLock(`${shopInfo['shopify_id']}-${this.redisCacheKey}`))) return;
  }
  async updateUsedCodes(codeList: SmsDiscountCode[], shopInfo: ShopEntity) {
    let codeRspt = this.database.getRepository(DiscountBulkCodeEntity);
    //将codeList 按照 discount 拆分
    let codeArr: { [key: number]: SmsDiscountCode[] } = {};

    if (codeList.length == 0) return false;
    let discountCodes = await codeRspt.find({ where: { code: In(codeList.map(item => item.code)), assigned: true } });
    let codes = discountCodes.map(item => item.code);
    codeList = codeList.filter(item => !codes.includes(item.code));
    if (codeList.length == 0) {
      console.log('assign code all exists=====');
      return true;
    }
    //获取店铺信息
    let discountModel = new DiscountModel(this.database);
    for (let code of codeList) {
      codeArr[code['shopifyPriceRuleId']] = codeArr[code['shopifyPriceRuleId']] ?? [];
      codeArr[code['shopifyPriceRuleId']].push(code);
    }
    let saveCodes: DiscountBulkCodeEntity[] = [];
    for (let shopifyDiscountId in codeArr) {
      //获取discountInfo
      let discountInfo = await discountModel.getDiscountInfo({ shopify_id: parseInt(shopifyDiscountId) });
      if (!discountInfo) {
        console.log('discount not exist-----', shopifyDiscountId);
        return false;
      }

      for (let code of codeArr[shopifyDiscountId]) {
        let codeInfo = new DiscountBulkCodeEntity();
        codeInfo = {
          ...codeInfo,
          assigned: true,
          shopify_id: code['shopifyId'],
          assigned_at: dayjs(code['updatedAt']).toDate(),
          expired_at: code['expiredAt'] ? dayjs(code['expiredAt']).toDate() : null,
          assigned_email: code['assignedEmail'],
          shop_id: shopInfo['id'],
          discount_shopify_id: code['shopifyPriceRuleId'],
          is_auto_increment: false,
          code: code['code'],
          sync_at: new Date(),
          batch_id: 0,
          discount_id: discountInfo['id'],
          deleted_at: code['deletedAt'] ? dayjs(code['deletedAt']).toDate() : undefined
        };
        saveCodes.push(codeInfo);
      }
    }
    try {
      console.log('start save ---------');
      await codeRspt
        .createQueryBuilder()
        .insert()
        .into(DiscountBulkCodeEntity)
        .values(saveCodes)
        .orUpdate(['assigned_at', 'assigned', 'expired_at', 'assigned_email', 'deleted_at'], ['code', 'shop_id'])
        .execute();
    } catch (e) {
      false;
    }

    return true;
  }
  //将sms设置的price-rule的规则拉到app中，为自动增长做准备
  async syncSmsPriceRuleSetting() {
    let discountRspt = this.database.getRepository(DiscountEntity);
    let discountModel = new DiscountModel(this.database);
    let discountCodeSettingModel = new DiscountCodeSettingModel(this.database, this.redis);
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    for (let shop of shopList) {
      let smsShopRspt = this.smsDatabase.getRepository(SmsShopEntity);
      let smsShopInfo = await smsShopRspt.findOne({ where: { shopify_id: shop['shopify_id'] } });
      if (!smsShopInfo) {
        continue;
      }
      if (!(await this.lock(`${shop.shopify_id}-${this.redisSettingCacheKey}`, 2 * 60 * 60))) return;
      let priceRuleObjs = await this.getPriceRuleSettingBy(shop['shopify_domain']);
      if (!priceRuleObjs) continue;
      for (let title in priceRuleObjs) {
        //获取discount 信息
        let discountInfo = await discountModel.getDiscountInfo({
          is_bulk_discount: true,
          title,
          shop_domain: shop['shopify_domain']
        });
        if (!discountInfo) {
          continue;
        }
        let settingInfo = await discountCodeSettingModel.getLastInfoByDiscountId(discountInfo['id']);
        if (settingInfo) {
          continue;
        }
        //将规则整理成discount setting保存到数据库中，并将discount 设置为自增code形式
        let bulkCodesSetting = new BulkCodesSettingEntity();
        bulkCodesSetting = {
          ...bulkCodesSetting,
          random_length: 6,
          prefix: priceRuleObjs[title].prefix || null,
          suffix: priceRuleObjs[title].suffix || null,
          type: 'auto',
          discount_shopify_id: discountInfo['shopify_id'],
          discount_id: discountInfo['id'],
          shop_id: discountInfo['shop_id'],
          counts: priceRuleObjs[title].amount || 0,
          is_bulk: true,
          bulk_at: new Date(),
          character_type: 'mix'
        };
        try {
          await discountCodeSettingModel.save(bulkCodesSetting);
          await discountRspt.save({
            ...discountInfo,
            auto_increment_code: true,
            code_effective_days: priceRuleObjs[title].validity_days || 0
          });
        } catch (e) {
          console.log(e);
        }
      }
      this.unLock(`${shop.shopify_id}-${this.redisSettingCacheKey}`);
    }
  }
  async getPriceRuleSettingBy(shopifyDomain: string): Promise<{ [key: string]: PriceRuleSetting }> {
    const shopSetting = await this.getShopSettingBy(shopifyDomain);
    let config: { [key: string]: PriceRuleSetting } = null;
    try {
      config = yaml.load(shopSetting.settings['price_rules']) || {};
    } catch (e) {
      return null;
    }
    return config;
  }
  async getShopSettingBy(shopifyDomain: string): Promise<ShopSettingsEntity> {
    let shopSettingRspt = this.smsDatabase.getRepository(ShopSettingsEntity);
    const shopSetting = shopSettingRspt.findOne({ where: { shopify_domain: shopifyDomain } });
    if (shopSetting === undefined) throw new Error('Shop Not Found');
    return shopSetting;
  }
}
