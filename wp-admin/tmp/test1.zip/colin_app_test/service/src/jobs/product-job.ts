import * as cron from 'node-cron';
import dayjs from 'dayjs';
import { SYNC_PRODUCT_KEY } from '../lib/variable';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ShopModel } from '../model/shop.model';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { ProductModel } from '../model/product.model';
import { JobBasis } from './job-base';
import { JobInterface, Queues } from './interface';
import { ToolsLib } from '../lib/tools.lib';
import { DiscountVariantEntity } from '../entity/discount.variant.entity';
import { ShopEntity } from '../entity/shop.entity';
import { DataType, Session } from '@shopify/shopify-api';
dayjs.extend(utc);
dayjs.extend(timezone);
const DISCOUNT_PRODUCT_TAG = 'akr_product_discount_tag';
export class ProductJob extends JobBasis {
  private queues: Queues = {};
  constructor(bootstrap: JobInterface, queues: Queues) {
    super(bootstrap);
    this.queues = queues;
  }
  initial() {
    // this.getOrder();
    //异步删除活动已经软删除的对应code，也基本上用不到，防止服务器异常导致code没有及时删除的操作

    cron.schedule(process.env.NODE_ENV == 'development' ? '1 * * * * *' : '1 1 6 * * *', this.getProductFromShopify.bind(this));
    // process.env.NODE_ENV !== 'development' &&
    //   cron.schedule(process.env.NODE_ENV !== 'development' ? '1 * * * * *' : '1 * * * * *', this.repairProductTag.bind(this));

    return this;
  }
  async getProductFromShopify() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    for (let shopInfo of shopList) {
      let shopifyShopId = shopInfo['shopify_id'];
      if (!(await ToolsLib.lock(this.redis, 'sync-products-limit' + shopInfo['shopify_id'], 12 * 60 * 60))) continue;
      if (!this.queues[shopifyShopId]) {
        return false;
      }
      this.queues[shopifyShopId].add(SYNC_PRODUCT_KEY, shopInfo);
    }
  }
  async repairProductTag() {
    let productModel = new ProductModel(this.database);
    let productList = await productModel.productRspt
      .createQueryBuilder('p')
      .leftJoinAndMapMany('p.variants', DiscountVariantEntity, 'dv', 'dv.shopify_product_id =p.shopify_id')
      .leftJoinAndMapOne('p.shop', ShopEntity, 's', 's.id=p.shop_id')
      .where(`p.tags like '%akr_product_discount_tag%'  and dv.id is null`)
      .getMany();
    for (let productInfo of productList) {
      let shopInfo = productInfo.shop;
      let offlineSessionId = this.api.session.getOfflineId(shopInfo['shopify_domain']);
      let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
      let shopifyApiLib = new ShopifyApiLib(session, this.api);
      try {
        let tags = productInfo['tags'] ? productInfo['tags'].split(',') : [];
        let index = tags.findIndex(item => item == DISCOUNT_PRODUCT_TAG || item == ' ' + DISCOUNT_PRODUCT_TAG);
        if (index !== -1) {
          tags.splice(index, 1);
          await shopifyApiLib.apiPut({
            path: `products/${productInfo['shopify_id']}`,
            type: DataType.JSON,
            data: {
              product: {
                id: productInfo['shopify_id'],
                tags: tags.length ? tags.join(',') : ''
              }
            }
          });
        }
      } catch (e) {
        console.log('repair product====error====', productInfo.shopify_id, e);
      }
    }
  }
}
