import { BulkCodeJob } from './bulk-code.job';
import { EdmJob } from './edm-job';
import { EmailJob } from './email-job';
import { ProductJob } from './product-job';
import { ScriptDiscountJob } from './script-discount.job';
import { DiscountJob } from './discount.job';
import { ShopQueueBasis } from './queue-basis';
import { BULK_CODE_QUEUE_SUFFIX } from '../lib/variable';
import { JobInterface } from './interface';
import { DIscountCodeJob } from './discount-code.job';

export class JobClass extends ShopQueueBasis {
  constructor(bootstrap: JobInterface) {
    super(bootstrap, BULK_CODE_QUEUE_SUFFIX);
    process.env.IS_WORKER_TASK == 'true' && this.initial(bootstrap);
    process.env.NODE_ENV == 'development' && this.testInitial(bootstrap);
  }
  initial(bootstrap: JobInterface) {
    const queueJobList = [ProductJob, BulkCodeJob, DiscountJob];
    this.initialize();
    queueJobList.forEach(JobClass => {
      new JobClass(
        {
          ...bootstrap
        },
        this.queues
      ).initial();
    });
    const simpleJobList = [EdmJob, EmailJob, ScriptDiscountJob, DIscountCodeJob];
    simpleJobList.forEach(JobClass => {
      new JobClass({
        ...bootstrap
      }).initial();
    });
  }
  testInitial(bootstrap: JobInterface) {
    const queueJobList = [BulkCodeJob, DiscountJob];
    this.initialize();
    queueJobList.forEach(JobClass => {
      new JobClass(
        {
          ...bootstrap
        },
        this.queues
      ).initial();
    });
  }
}
