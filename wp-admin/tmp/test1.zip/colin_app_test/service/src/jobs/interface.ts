import { Shopify } from '@shopify/shopify-api';
import { SessionStorage } from '@shopify/shopify-app-session-storage';
import { Queue } from 'bullmq';
import { Redis } from 'ioredis';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';

export interface JobInterface {
  database: DataSource;
  redis: Redis;
  api: Shopify;
  sessionStorage: SessionStorage;
  logger: Logger;
}

export interface SmsJobInterface extends JobInterface {
  smsDatabase: DataSource;
}
export interface Queues {
  [key: string]: Queue;
}
