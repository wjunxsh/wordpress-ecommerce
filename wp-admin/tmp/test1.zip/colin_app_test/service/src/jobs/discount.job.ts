import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { JobInterface, Queues } from './interface';
import { JobBasis } from './job-base';
import { ShopModel } from '../model/shop.model';
import { DiscountModel } from '../model/discount.mode';
import { VariantModel } from '../model/variant.model';
import { ProductEntity } from '../entity/product.entity';
import { DiscountEntity } from '../entity/discount.entity';
import { DiscountVariantEntity } from '../entity/discount.variant.entity';
import { VariantEntity } from '../entity/variant.entity';
import getSymbolFromCurrency from 'currency-symbol-map';
import { ShopEntity } from '../entity/shop.entity';
import * as cron from 'node-cron';
import { DiscountVariantModel } from '../model/discount.variant.model';
import { Brackets, In, IsNull, Not } from 'typeorm';
import { ToolsLib } from '../lib/tools.lib';
import NP from 'number-precision';
import {
  CREATE_DISCOUNT_EVENT_JOB,
  DELETE_DISCOUNT_JOB_NAME,
  DISCOUNT_PRODUCT_TAG,
  REDIS_CACHE_KEY_PREFIX,
  SYNC_ALL_DISCOUNT_FROM_SHOPIFY,
  SYNC_DISCOUNT_VARIANT_METAFIELDS,
  SYNC_OTHER_DISCOUNT_FROM_SHOPIFY,
  UPDATE_DISCOUNT_EVENT_JOB,
  WAIT_SYNC_DISCOUNT_LIST
} from '../lib/variable';
import { DataType, Session } from '@shopify/shopify-api';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { ProductModel } from '../model/product.model';
import { DiscountVariantLogEntity } from '../entity/discount.variant.log.entity';
import { DiscountVariantLogModel } from '../model/discount.variant.log.model';
import { DiscountImportTaskModel } from '../model/discount.import.task.model';
dayjs.extend(utc);
dayjs.extend(timezone);
export class DiscountJob extends JobBasis {
  private queues: Queues = {};
  constructor(bootstrap: JobInterface, queues: Queues) {
    super(bootstrap);
    this.queues = queues;
  }
  public initial() {
    // this.getOrder();
    //异步删除活动已经软删除的对应code，也基本上用不到，防止服务器异常导致code没有及时删除的操作
    // cron.schedule('35 * * * * *', this.discountGraphQlTest.bind(this));
    // cron.schedule(
    //   process.env.NODE_ENV == 'development' ? '*/10 * * * * *' : '*/10 * * * * *',
    //   this.setDiscountVariant.bind(this)
    // );
    // cron.schedule(
    //   process.env.NODE_ENV == 'development' ? '*/10 * * * * *' : '*/10 * * * * *',
    //   this.setProductMetaifields.bind(this)
    // );
    // cron.schedule(
    //   process.env.NODE_ENV == 'development' ? '*/10 * * * * *' : '*/10 * * * * *',
    //   this.deleteProductMetafields.bind(this)
    // );
    //将导入的折扣同步到shopify
    cron.schedule('1 */10 * * * *', this.syncImportDiscountToShopify.bind(this));
    //删除shopify已经删除的折扣
    cron.schedule(process.env.NODE_ENV !== 'development' ? '*/30 * * * * *' : '*/10 * * * * *', this.deleteDiscount.bind(this));

    //同步更新的discount
    cron.schedule(
      process.env.NODE_ENV !== 'development' ? '*/30 * * * * *' : '*/10 * * * * *',
      this.updateEventDiscount.bind(this)
    );

    //同步创建的discount
    cron.schedule(
      process.env.NODE_ENV !== 'development' ? '*/30 * * * * *' : '*/10 * * * * *',
      this.createEventDiscount.bind(this)
    );

    //通过shopify的事件同步创建和更新的discount
    cron.schedule(
      process.env.NODE_ENV !== 'development' ? '*/10 * * * * *' : '*/10 * * * * *',
      this.createAndUpdateDiscount.bind(this)
    );

    //根据最后更新时间，来同步discout活动
    //cron.schedule('45,15 * * * * *', this.incrementSyncDiscountsFromShopify.bind(this));

    //每个店铺的数据量不多，每天全量同步一次
    cron.schedule('45,15 9 * * * *', this.allSyncDiscountsFromShopify.bind(this));
    return this;
  }

  //同步店铺的其他的折扣信息
  async incrementSyncDiscountsFromShopify() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();

    if (!shopList.length) return;
    for (let shopInfo of shopList) {
      let shopifyShopId = shopInfo['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        return false;
      }
      if (!(await this.lock(`${shopInfo['shopify_id']}-${SYNC_OTHER_DISCOUNT_FROM_SHOPIFY}`, 5 * 60))) {
        continue;
      }
      this.queues[shopifyShopId].add(SYNC_OTHER_DISCOUNT_FROM_SHOPIFY, {
        shopify_shop_id: shopInfo['shopify_id']
      });
    }
  }

  //同步店铺的其他的折扣信息
  async allSyncDiscountsFromShopify() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();

    if (!shopList.length) return;
    for (let shopInfo of shopList) {
      let shopifyShopId = shopInfo['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        return false;
      }
      if (!(await this.lock(`${shopInfo['shopify_id']}-${SYNC_ALL_DISCOUNT_FROM_SHOPIFY}`, 5 * 60))) {
        continue;
      }
      this.queues[shopifyShopId].add(SYNC_ALL_DISCOUNT_FROM_SHOPIFY, {
        shopify_shop_id: shopInfo['shopify_id']
      });
    }
  }

  async deleteDiscount() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    for (let shopInfo of shopList) {
      if (!(await this.lock('DELETE_DISCOUNT_FREQUENCE_LIMIT_KEY' + shopInfo['shopify_id'], 5 * 60))) continue;
      let shopifyShopId = shopInfo['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        continue;
      }
      this.queues[shopifyShopId].add(DELETE_DISCOUNT_JOB_NAME, shopInfo);
    }
  }
  async createAndUpdateDiscount() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    for (let shopInfo of shopList) {
      let shopifyShopId = shopInfo['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        continue;
      }
      if (!(await this.lock(WAIT_SYNC_DISCOUNT_LIST + `-${shopInfo['shopify_id']}`, 5 * 60))) continue;
      while (true) {
        let discountShopifyId = await this.redis.lpop(WAIT_SYNC_DISCOUNT_LIST + shopInfo['shopify_id']);
        if (!discountShopifyId) {
          break;
        }
        this.queues[shopifyShopId].add(WAIT_SYNC_DISCOUNT_LIST, {
          shopify_shop_id: shopInfo['shopify_id'],
          discount_shopify_id: discountShopifyId
        });
      }
      await this.unLock(WAIT_SYNC_DISCOUNT_LIST + `-${shopInfo['shopify_id']}`);
    }
  }
  async createEventDiscount() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    for (let shopInfo of shopList) {
      if (!(await this.lock(CREATE_DISCOUNT_EVENT_JOB + shopInfo['shopify_id'], 5 * 60))) continue;
      let shopifyShopId = shopInfo['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        continue;
      }
      this.queues[shopifyShopId].add(CREATE_DISCOUNT_EVENT_JOB, shopInfo);
    }
  }

  async updateEventDiscount() {
    let shopModel = new ShopModel(this.database);
    let shopList = await shopModel.getActiveShops();
    for (let shopInfo of shopList) {
      if (!(await this.lock(UPDATE_DISCOUNT_EVENT_JOB + shopInfo['shopify_id'], 5 * 60))) continue;
      let shopifyShopId = shopInfo['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        continue;
      }
      this.queues[shopifyShopId].add(UPDATE_DISCOUNT_EVENT_JOB, shopInfo);
    }
  }

  //start_ai_generated
  /**
   * 异步将导入的折扣同步到shopify
   * @returns
   */
  async syncImportDiscountToShopify() {
    //获取所有未发送的记录
    if (!(await this.lock(`sync-import-discount`, 3 * 60 * 60))) return;
    let importDiscountModel = new DiscountImportTaskModel(this.database, this.redis);
    let importTaskList = await importDiscountModel.getNotAsyncTask();
    if (!importTaskList.length) {
      await this.unLock(`sync-import-discount`);
      return;
    }
    for (let importTask of importTaskList) {
      await importDiscountModel.aysncDiscountToShopify(importTask, this.api, this.sessionStorage);
    }
    //解除锁定
    await this.unLock(`sync-import-discount`);
  }
  //end_ai_generated
  async deleteProductMetafields() {
    const DELETE_VARIANT_METAFIELD_KEY = 'del-d-variant-metafield-key';
    if (!(await ToolsLib.lock(this.redis, DELETE_VARIANT_METAFIELD_KEY, 10 * 60))) return;
    let discountVariantModel = new DiscountVariantModel(this.database);
    let variantModel = new VariantModel(this.database);
    let productModel = new ProductModel(this.database);
    let discountVariantLogModel = new DiscountVariantLogModel(this.database);
    let shopModel = new ShopModel(this.database);
    let discountVariantList = await discountVariantModel.getNeedDeleteList();
    if (!discountVariantList.length) {
      await ToolsLib.unLock(this.redis, DELETE_VARIANT_METAFIELD_KEY);
      return;
    }
    let shopifyApis: { [key: string]: ShopifyApiLib } = {};
    let shopList = await shopModel.shopRspt.find({ where: { id: In(discountVariantList.map(item => item.shop_id)) } });
    for (let shopInfo of shopList) {
      const offlineSessionId = this.api.session.getOfflineId(shopInfo['shopify_domain']);
      let session: Session = await this.sessionStorage.loadSession(offlineSessionId);
      shopifyApis[shopInfo['id']] = new ShopifyApiLib(session, this.api);
    }
    //获取所有variant_id
    let variantList = await variantModel.variantRspt.findBy({
      shopify_id: In(discountVariantList.map(item => item.shopify_variant_id))
    });
    let productList = await productModel.getListByShopifyIds(discountVariantList.map(item => item.shopify_product_id));
    for (let discountVariant of discountVariantList) {
      let shopifyApiLib = shopifyApis[discountVariant['shop_id']] || null;
      let variant = variantList.find(item => item.shopify_id == discountVariant.shopify_variant_id);
      let product = productList.find(product => (product.shopify_id = discountVariant.shopify_product_id));
      try {
        if (variant && shopifyApiLib && discountVariant.metafield_shopify_id) {
          await shopifyApiLib.apiDelete(
            `variants/${discountVariant.shopify_variant_id}/metafields/${discountVariant.metafield_shopify_id}`
          );
          await discountVariantModel.discountVariantRspt.update(
            { shopify_variant_id: Not(discountVariant.shopify_discount_id) },
            { async_time: null }
          );
        }
        if (product) {
          let tags = product['tags'] ? product['tags'].split(',') : [];
          let index = tags.findIndex(item => item == DISCOUNT_PRODUCT_TAG);
          if (index !== -1) {
            tags.splice(index, 1);
            await shopifyApiLib.apiPut({
              path: `products/${product['shopify_id']}`,
              type: DataType.JSON,
              data: {
                product: {
                  id: product['shopify_id'],
                  tags: tags.length ? tags.join(',') : ''
                }
              }
            });
          }
        }
        await discountVariantModel.discountVariantRspt.delete({ id: discountVariant.id });
        //保存日志方便后续追查
        await discountVariantLogModel.discountVariantLogRspt.save({
          ...new DiscountVariantLogEntity(),
          ...discountVariant,
          operate_type: 'delete'
        });
      } catch (e) {
        if (e.code == 404) {
          await discountVariantModel.discountVariantRspt.delete({ id: discountVariant.id });
        } else {
          let extend = { ...discountVariant.extend, delete_error: e.message || 'delete error' };
          await discountVariantModel.discountVariantRspt.update({ id: discountVariant.id }, { extend });
        }
      }
    }
    await ToolsLib.unLock(this.redis, DELETE_VARIANT_METAFIELD_KEY);
  }
  async setProductMetaifields() {
    let shopList = await new ShopModel(this.database).getActiveShops();
    for (let shopInfo of shopList) {
      if (!(await ToolsLib.lock(this.redis, REDIS_CACHE_KEY_PREFIX + shopInfo['shopify_id'], 5 * 60))) {
        continue;
      }
      if (!this.queues[shopInfo['shopify_id']]) {
        continue;
      }
      this.queues[shopInfo['shopify_id']].add(SYNC_DISCOUNT_VARIANT_METAFIELDS, shopInfo);
    }
  }
  /** 发布的时候一定要将线上的活动value重新刷一遍 */
  async setDiscountVariant() {
    let shopModel = new ShopModel(this.database);
    let discountModel = new DiscountModel(this.database);
    let variantModel = new VariantModel(this.database);
    let discountVarianatModel = new DiscountVariantModel(this.database);
    let shopList = await shopModel.getActiveShops();
    if (!(await this.lock('set-discount-variant', 10 * 60))) {
      return;
    }
    try {
      for (let shopInfo of shopList) {
        let discountList: DiscountEntity[] = await discountModel.discountRspt
          .createQueryBuilder('d')
          .leftJoinAndMapMany('d.variants', DiscountVariantEntity, 'v', 'v.discount_id=d.id')
          .where({ shop_id: shopInfo['id'], set_discount_variant: false })
          .andWhere(
            `(d.title like 'WS24%' or d.title like 'WSCP%' or d.title like 'WS7D%' or d.title like 'WSCH%' or d.title like 'WSTD%')`
          )
          .orderBy('shopify_updated_at', 'ASC')
          .getMany();
        if (!discountList.length) continue;
        for (let discountInfo of discountList) {
          //获取活动存在的产品信息
          if (!discountInfo.entitled_product_ids.length && !discountInfo.entitled_variant_ids.length) {
            await discountModel.discountRspt.update({ id: discountInfo['id'] }, { set_discount_variant: true });
            continue;
          }
          let handle = variantModel.variantRspt
            .createQueryBuilder('v')
            .leftJoinAndMapOne('v.product', ProductEntity, 'p', 'p.id=v.product_id')
            .where({ shopify_id: Not(IsNull()), shopify_product_id: Not(IsNull()) });
          if (discountInfo['entitled_product_ids'].length || discountInfo['entitled_variant_ids'].length) {
            handle.andWhere(
              new Brackets(qb => {
                if (discountInfo['entitled_product_ids'].length) {
                  qb.where(`p.shopify_id in(${discountInfo.entitled_product_ids.join(',')})`);
                }
                if (discountInfo['entitled_variant_ids'].length) {
                  qb.orWhere(`v.shopify_id in(${discountInfo.entitled_variant_ids.join(',')})`);
                }
              })
            );
          }

          let variantList: VariantEntity[] = await handle.getMany();
          if (!variantList.length) {
            await discountModel.discountRspt.update({ id: discountInfo['id'] }, { set_discount_variant: true });
            continue;
          }
          let discountVariantList: DiscountVariantEntity[] = discountInfo['variants'];
          //如果discountVariantList为空，并且discount已经过期则跳过
          if (discountVariantList.length == 0 && !this.isActive(discountInfo)) {
            await discountModel.discountRspt.update({ id: discountInfo['id'] }, { set_discount_variant: true });
            continue;
          }
          //对比关键数据是否正确，如果都正确则不进行存储更新，
          let saveDiscountVariants: DiscountVariantEntity[] = [];
          let { addVariants, delVariants, updateVariants } = await this.compaireVariant(
            discountInfo,
            variantList,
            discountVariantList
          );
          if (addVariants.length) {
            for (let variant of addVariants) {
              saveDiscountVariants.push(this.createDiscountVariant(discountInfo, variant, shopInfo));
            }
          }

          if (updateVariants.length) {
            for (let variant of updateVariants) {
              saveDiscountVariants.push({ ...this.createDiscountVariant(discountInfo, variant, shopInfo) });
            }
          }
          try {
            //将数据放在同一个事务中
            //console.log(discountInfo, variantList, saveDiscountVariants, delVariants);
            await discountVarianatModel.saveData(
              discountInfo,
              saveDiscountVariants,
              delVariants.map(item => ({ ...item, need_delete: true }))
            );
          } catch (e) {
            console.log('save failed:', e);
          }
          //保存到数据库;
        }
      }
    } catch (e) {
      console.log(e);
    }
    await this.unLock('set-discount-variant');
  }
  isDiscountEdit(discount: DiscountEntity, discountVariant: DiscountVariantEntity) {
    if (discount.value != discountVariant.value) {
      return false;
    }
    if (discount.value_type != discountVariant.value_type) {
      return false;
    }
    if (dayjs(discount.starts_at).unix() != dayjs(discountVariant.starts_at).unix()) {
      return false;
    }
    if (
      (discount.ends_at && !discountVariant.ends_at) ||
      (!discount.ends_at && discountVariant.ends_at) ||
      (discount.ends_at && discountVariant.ends_at && dayjs(discount.ends_at).unix() != dayjs(discountVariant.ends_at).unix())
    ) {
      return false;
    }
    return true;
  }
  isVariantEdit(variant: VariantEntity, discountVariant: DiscountVariantEntity) {
    if (variant['price'] != discountVariant['variant_price']) {
      return false;
    }
    return true;
  }

  createDiscountVariant(discount: DiscountEntity, variant: VariantEntity, shopInfo: ShopEntity) {
    let discountVariant = new DiscountVariantEntity();
    discountVariant['value_type'] = discount['value_type'];
    discountVariant['metafield_shopify_id'] = null;
    discountVariant['title'] = discount['title'];
    discountVariant['discount_id'] = discount['id'];
    discountVariant['need_delete'] = false;
    discountVariant['shopify_discount_id'] = discount['shopify_id'];
    discountVariant['shopify_product_id'] = variant['shopify_product_id'];
    discountVariant['shopify_variant_id'] = variant['shopify_id'];
    discountVariant['shop_domain'] = discount['shop_domain'];
    discountVariant['shop_id'] = discount['shop_id'];
    discountVariant['variant_price'] = variant['price'];
    discountVariant['value'] = discount.value;
    discountVariant['fixed_value'] = this.wsc_fixed_value(discount, variant);
    discountVariant['fixed_amount_sort_key'] = discountVariant['fixed_value'];
    discountVariant['percentage_sort_key'] =
      discount.value_type == 'percentage'
        ? Math.abs(discount.value)
        : Math.floor(Math.abs((parseFloat(`${discount['value']}`) / variant['price']) * 100.0));
    discountVariant['value_style'] = (getSymbolFromCurrency(shopInfo.currency) || '$') + discountVariant['fixed_value'];
    discountVariant['currency_symbol'] = getSymbolFromCurrency(shopInfo.currency) || '$';
    discountVariant['is_max_discount'] = false;
    discountVariant['async_time'] = null;
    discountVariant['starts_at'] = discount['starts_at'];
    discountVariant['ends_at'] = discount['ends_at'];
    let amount = NP.minus(
      variant['price'],
      discount['value_type'] == 'fixed_amount'
        ? Math.abs(discount['value'])
        : NP.divide(Math.floor(NP.times(variant['price'], Math.abs(discount['value']))), 100)
    );
    discountVariant['variant_price4wscode'] = Math.round(NP.times(amount, 100)) / 100;
    return discountVariant;
  }

  wsc_fixed_value(discount: DiscountEntity, variant: VariantEntity) {
    return discount['value_type'] == 'fixed_amount'
      ? Math.abs(discount['value'])
      : NP.divide(Math.floor(NP.times(variant['price'], Math.abs(discount['value']))), 100);
  }
  isExcludeSetMetafield(variant: VariantEntity) {
    return variant.metafields?.some(item => item.key == 'limit-discount-write' && item.value);
  }
  isActive(discount: DiscountEntity) {
    return (
      dayjs(discount['starts_at']).isBefore(new Date()) &&
      (!discount['ends_at'] || dayjs(discount['ends_at']).isAfter(new Date()))
    );
  }
  async compaireVariant(discount: DiscountEntity, variantList: VariantEntity[], discountVariantList: DiscountVariantEntity[]) {
    let addVariants: VariantEntity[] = [];
    let delVariants: DiscountVariantEntity[] = [];
    let updateVariants: VariantEntity[] = [];
    for (let variant of variantList) {
      //如果variant 设置了metafield的 global limit-discount-write 的值为true则不设置最大code
      let discountVariant = discountVariantList.find(item => item.shopify_variant_id == variant.shopify_id);
      if (!discountVariant) {
        !this.isExcludeSetMetafield(variant) && this.isActive(discount) && addVariants.push(variant);
        continue;
      }
      if (!this.isDiscountEdit(discount, discountVariant) || !this.isVariantEdit(variant, discountVariant)) {
        !this.isExcludeSetMetafield(variant) && this.isActive(discount) && updateVariants.push(variant);
      }
    }
    for (let discountVariant of discountVariantList) {
      let variant = variantList.find(item => item.shopify_id == discountVariant.shopify_variant_id);
      if (!this.isActive(discount) || !variant || this.isExcludeSetMetafield(variant)) delVariants.push(discountVariant);
    }
    return { addVariants, delVariants, updateVariants };
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
}
