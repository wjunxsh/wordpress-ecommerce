import { Queue, QueueOptions } from 'bullmq';
import { ShopEntity } from '../entity/shop.entity';
import * as cron from 'node-cron';
import { MoreThan } from 'typeorm';
import { JobBasis } from './job-base';
import { JobInterface } from './interface';

export class ShopQueueBasis extends JobBasis {
  public queues: { [key: string]: Queue } = {};
  public queueSuffix: string;
  constructor(bootstrap: JobInterface, queueSuffix: string) {
    super(bootstrap);
    this.queueSuffix = queueSuffix;
  }
  async initialize(queueOption?: QueueOptions) {
    this.initShopQueue(queueOption);
    cron.schedule('*/10 * * * * *', () => {
      this.initShopQueue(queueOption, true);
    });
    cron.schedule('*/10 * * * * *', () => {
      this.deleteShopQueue();
    });
  }
  async initShopQueue(queueOption?: QueueOptions, isAdded: boolean = false) {
    let shopRspt = this.database.getRepository(ShopEntity);
    let date = new Date(new Date().getTime() - 60 * 10 * 1000);
    let where = { state: 1 };
    if (isAdded) {
      where['updated_at'] = MoreThan(date);
    }
    let shopList = await shopRspt.find({ where: where });
    if (shopList.length) {
      for (let shop of shopList) {
        this.createQueue(shop['shopify_id'], queueOption);
      }
    }
  }
  async deleteShopQueue() {
    let shopRspt = this.database.getRepository(ShopEntity);
    //获取十分钟内更改了状态的店铺
    let date = new Date(new Date().getTime() - 60 * 10 * 1000);
    let shopList = await shopRspt.find({
      where: { state: 0, updated_at: MoreThan(date) }
    });
    if (shopList.length) {
      for (let shop of shopList) {
        this.deleteQueue(shop['shopify_id']);
      }
    }
  }
  public createQueue = (shopifyId: number, queueOption?: QueueOptions) => {
    if (!this.queues[shopifyId]) {
      this.queues[shopifyId] = new Queue(`${shopifyId}-${this.queueSuffix}`, {
        connection: this.redis,
        ...(queueOption ?? {})
      });
    }
  };
  public deleteQueue = (shopifyId: number) => {
    if (this.queues[shopifyId]) {
      this.queues[shopifyId].close();
      delete this.queues[shopifyId];
    }
  };
}
