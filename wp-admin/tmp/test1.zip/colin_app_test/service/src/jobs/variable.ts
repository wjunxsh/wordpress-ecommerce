export const PRODUCT_QUEUE = 'sync_products';
export const DISCOUNT_QUEUE_SUFFIX = 'sync_discount_queue_suffix';
export const NAMESPACE = 'update-discount';
