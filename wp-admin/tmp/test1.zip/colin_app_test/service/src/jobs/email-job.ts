import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import * as cron from 'node-cron';
import { EdmConfigModel } from '../model/edm.config.model';
import { NodeMailerLib } from '../lib/nodemailer.lib';
import { EmailConfigModel } from '../model/email.config.model';
import { EmailSendRecordsEntity } from '../entity/email.send.records.entity';
import { EmailSendRecordsLogsEntity } from '../entity/email.send.records.logs.entity';
import { JobBasis } from './job-base';
import { JobInterface } from './interface';
dayjs.extend(utc);
dayjs.extend(timezone);
/**
 * 直连sms库，暂不启用，因为一样无法解决rainbow的主从库的问题
 */
export class EmailJob extends JobBasis {
  private redisCacheKey = 'email_send_cache';
  private edmBindCodeKey = 'email_bind_code_key';
  public edmConfigModel: EdmConfigModel;
  public emailConfigModel: EmailConfigModel;
  constructor(bootstrap: JobInterface) {
    super(bootstrap);
    this.edmConfigModel = new EdmConfigModel(this.database, this.redis);
    this.emailConfigModel = new EmailConfigModel(this.database, this.redis);
  }
  initial() {
    this.clearCache();
    cron.schedule('30 */5 * * * *', this.sendVerifyEmailTask.bind(this));
    cron.schedule('50 */5 * * * *', this.emailBindCode.bind(this));
  }
  async clearCache() {
    let keys = await this.redis.keys(`setnx-*${this.redisCacheKey}`);
    if (keys.length > 0) {
      for (let key of keys) {
        await this.redis.del(key);
      }
    }
    keys = await this.redis.keys(`setnx-*${this.edmBindCodeKey}`);
    if (keys.length > 0) {
      for (let key of keys) {
        await this.redis.del(key);
      }
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
  async sendVerifyEmailTask() {
    //获取未完全发送的所有任务
    let nodeMailerLib = new NodeMailerLib();
    let emailSendRecordRspt = this.database.getRepository(EmailSendRecordsEntity);
    let emailConfigList = await this.emailConfigModel.getVerifyedList();
    if (!emailConfigList.length) return;
    for (let emailConfig of emailConfigList) {
      let records = await this.emailConfigModel.getRecordList({
        currentPage: 1,
        pageSize: 1000,
        is_send: false,
        email_config_id: emailConfig['id']
      });
      if (records.length == 0) {
        await this.emailConfigModel.createOrSave({
          ...emailConfig,
          is_send_all: true
        });
        continue;
      }
      if (!(await this.lock(`${emailConfig['id']}-${this.redisCacheKey}`, 3 * 60 * 60))) continue;
      let emailSendRecordLogRspt = this.database.getRepository(EmailSendRecordsLogsEntity);

      for (let recordInfo of records) {
        let emailSendRecordlog = new EmailSendRecordsLogsEntity();
        emailSendRecordlog = {
          ...emailSendRecordlog,
          from: emailConfig['from'] + emailConfig['from_email'],
          email: recordInfo['email'],
          subject: emailConfig['from'],
          html_details: recordInfo['html_details'],
          send_time: dayjs().toDate(),
          code: recordInfo['code'],
          is_send: true,
          record_id: recordInfo['id'],
          extend: recordInfo['extend'],
          email_config_id: recordInfo['email_config_id']
        };
        try {
          let info = await nodeMailerLib.sendEmail({
            from: emailConfig['from'] + emailConfig['from_email'],
            to: recordInfo['email'],
            subject: emailConfig['subject'],
            html: recordInfo['html_details'],
            text: null
          });

          await emailSendRecordRspt.save({
            ...recordInfo,
            is_send: true,
            send_time: dayjs().toDate()
          });
          emailSendRecordlog['send_result'] = info;
          await emailSendRecordLogRspt.save(emailSendRecordlog);
        } catch (e) {
          await emailSendRecordRspt.save({
            ...recordInfo,
            send_error: e.message,
            send_time: dayjs().toDate()
          });
          emailSendRecordlog['send_result'] = e.message;
          await emailSendRecordLogRspt.save(emailSendRecordlog);
        }
      }
      await this.unLock(`${emailConfig['id']}-${this.redisCacheKey}`);
    }
  }

  async emailBindCode() {
    await this.emailConfigModel.bindParams();
  }
}
