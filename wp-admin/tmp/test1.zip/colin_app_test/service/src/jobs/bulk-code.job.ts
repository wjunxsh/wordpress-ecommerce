import * as cron from 'node-cron';
import { DiscountBulkCodeEntity } from '../entity/discount-bulk-code';
import { ShopEntity } from '../entity/shop.entity';
import { DiscountEntity } from '../entity/discount.entity';
import dayjs from 'dayjs';
import {
  SYNC_CODE_FROM_SHOPIFY,
  SYNC_CODE_TO_SHOPIFY,
  SYNC_DISCOUNT_CODE_FROM_SHOPIFY,
  UPDATE_DISCOUNT
} from '../lib/variable';
import { DiscountBulkCodeModel } from '../model/discount.bulk.code.model';
import { DiscountModel } from '../model/discount.mode';
import { ShopifyApiLib } from '../lib/shopify-api.lib';
import { IsNull, LessThan } from 'typeorm';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { JobBasis } from './job-base';
import { JobInterface, Queues } from './interface';
dayjs.extend(utc);
dayjs.extend(timezone);
const catchKeys = {
  DELETE_SHOPIFY: 'delete_code_key',
  AUTO_INCREMENT_CODE: 'auto_increment_code'
};
export class BulkCodeJob extends JobBasis {
  private queues: Queues = {};
  constructor(bootstrap: JobInterface, queues: Queues) {
    super(bootstrap);
    this.queues = queues;
  }
  initial() {
    //获取店铺信息
    this.clearCatche();
    // this.getOrder();
    //异步删除活动已经软删除的对应code，也基本上用不到，防止服务器异常导致code没有及时删除的操作
    cron.schedule('35 * * * * *', this.deleteBulkCode.bind(this));
    //异步裂变code操作，基本上用不到，主要是防止服务器异常，导致同步裂变没完成的操作
    cron.schedule('20,50 * * * * *', this.createBulkCode.bind(this));
    //备份裂变的code,
    cron.schedule('1 50 14,20 * * *', this.bakupCodes.bind(this));
    //将没有shpify_id的code 同步过来
    cron.schedule('*/18 * * * * *', this.syncCodesFromShopify.bind(this));
    //软删除超过期限的code
    cron.schedule('42 35 */2 * * *', this.deleteExpiredCode.bind(this));
    //计算自动增长的discount，每天消耗的code，以及自动裂变当天的code
    cron.schedule('55 */10 * * * *', this.calculateAverageDiscount.bind(this));
    //首次同步discount对应的code
    cron.schedule(
      process.env.NODE_ENV !== 'development' ? '20 2 * * * *' : '20 */2 * * * *',
      this.getDiscountFirstCodeFromShopify.bind(this)
    );
    // cron.schedule("20 * * * * *", this.getDiscountFirstCodeFromShopifyRangeShop.bind(this));
    //每天全量跑一次同步code
    cron.schedule(
      process.env.NODE_ENV !== 'development' ? '15 55 10 * * *' : '15 */5 * * * *',
      this.getDiscountCodeFromShopify.bind(this)
    );
    return this;
  }
  async clearCatche() {
    let keys = Object.values(catchKeys);
    for (let key of keys) {
      await this.unLock(key);
    }
  }

  /**
   * @deprecated The method should not be used
   */
  async updateDiscountFromShopify() {
    let discountRspt = this.database.getRepository(DiscountEntity);
    //获取所有discount
    let discountList = await discountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      //.where({ is_bulk_discount: true })
      .getMany();
    for (let discount of discountList) {
      let shopifyShopId = discount['shop'].shopify_id;
      if (!this.queues[shopifyShopId]) {
        continue;
      }
      if (!(await this.lock(`${discount['shopify_id']}-${UPDATE_DISCOUNT}`, 60 * 60))) {
        continue;
      }
      this.queues[shopifyShopId].add(UPDATE_DISCOUNT, discount);
    }
  }
  async syncCodesToShopfify() {
    //查询所有未同步到shopify的优惠券信息
    let discountModel = new DiscountModel(this.database);
    let discountList = await discountModel.getNotSyncToShopifyDiscounts();
    if (!discountList.length) {
      console.log('no discount need to sync to shopify');
      return true;
    }
    for (let discount of discountList) {
      let shopifyShopId = discount['shopify_shop_id'];
      if (!this.queues[shopifyShopId]) {
        console.log('shopify shop is not exist====', discount['discount_id']);
        return false;
      }
      //按照店铺维度加锁
      let isLock = await this.lock(`${discount['discount_id']}-${SYNC_CODE_TO_SHOPIFY}`, 30 * 60);
      if (!isLock) {
        console.log('shop is locked====', discount['discount_id']);
        continue;
      }
      console.log('sync codes to shopify======', discount);
      this.queues[shopifyShopId].add(SYNC_CODE_TO_SHOPIFY, {
        ...discount
      });
    }
  }
  private async syncCodesFromShopify() {
    //查询所有未同步的bulk code的数据
    let discountRspt = this.database.getRepository(DiscountEntity);
    let discountList: any = [];
    try {
      discountList = await discountRspt
        .createQueryBuilder('d')
        .groupBy('s.shopify_id')
        .leftJoinAndSelect(ShopEntity, 's', 's.id=d.shop_id')
        .leftJoinAndSelect(DiscountBulkCodeEntity, 'db', 'db.discount_id=d.id')
        .select(['s.shopify_id as shopify_shop_id'])
        .where(
          'db.shopify_id is null and d.is_bulk_discount=true and db.batch_id!=0 and db.batch_id is not null and db.sync_error is null and db.created_at <=:date',
          { date: dayjs().subtract(20, 'minute').toDate() }
        )
        .execute();
    } catch (e) {
      console.log(e);
    }

    if (!discountList?.length) {
      return false;
    }
    for (let discount of discountList) {
      let shopifyShopId = discount['shopify_shop_id'];
      if (!this.queues[shopifyShopId]) {
        continue;
      }
      if (!(await this.lock(`${discount['shopify_shop_id']}-${SYNC_CODE_FROM_SHOPIFY}`, 30 * 60))) {
        continue;
      }
      console.log('sync code from shopify==========', discount);
      await this.queues[shopifyShopId].add(SYNC_CODE_FROM_SHOPIFY, {
        ...discount
      });
    }
  }
  async createBulkCode() {
    console.log('create bulk code ===');
    try {
      let bulkCodeModel = await new DiscountBulkCodeModel(this.database, this.redis);
      await bulkCodeModel.bulkCode();
      console.log('sync code to shopify ===');
      await this.syncCodesToShopfify();
    } catch (e) {
      console.log(e);
    }
  }

  public async deleteBulkCode() {
    //查询所有未同步的bulk code的数据
    let discountModel = new DiscountModel(this.database);
    let discountList = await discountModel.getDiscountsThatNotDeleteCodes();
    for (let discount of discountList) {
      await discountModel.deleteDiscount(discount);
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
  async bakupCodes() {
    let bulkCodeModel = new DiscountBulkCodeModel(this.database, this.redis);
    try {
      await bulkCodeModel.bakupCodes();
    } catch (e) {
      console.log('bakup code failed===');
      console.log(e);
    }
  }
  //删除过期的code
  async deleteExpiredCode() {
    //获取所有已经过期的code并将其逻辑删除
    if (!(await this.lock(catchKeys.DELETE_SHOPIFY, 2 * 60 * 60))) {
      return false;
    }
    let discountCodeModel = new DiscountBulkCodeModel(this.database, this.redis);
    let shopWithCodeList = await discountCodeModel.getExpiredCodes();
    //将code 从 shopify中删除
    for (let shopInfo of shopWithCodeList) {
      let codeList = shopInfo['codes'];

      if (codeList.length == 0) continue;
      const offlineSessionId = this.api.session.getOfflineId(shopInfo.shopify_domain);
      let session = await this.sessionStorage.loadSession(offlineSessionId);
      if (!session) continue;
      let apiClient = new ShopifyApiLib(session, this.api);

      for (let code of codeList) {
        try {
          //从shopify获取是否使用过
          let result = await apiClient.apiGet(
            `price_rules/${code['discount_shopify_id']}/discount_codes/${code['shopify_id']}`,
            {}
          );
          if (result['discount_code']['usage_count'] != 0) {
            await discountCodeModel.updteCodeUsageCount(code['shopify_id'], result['discount_code']['usage_count']);
          } else {
            await apiClient.apiDelete(`price_rules/${code['discount_shopify_id']}/discount_codes/${code['shopify_id']}`);
            await discountCodeModel.softRemoveCode(code);
          }
        } catch (e) {
          console.log(e);
          if (e.code == 404) {
            await discountCodeModel.softRemoveCode(code);
          }
          console.log('delete code error:', e, code);
          continue;
        }
      }
    }
    await this.unLock(catchKeys.DELETE_SHOPIFY);
  }
  //计算平均使用情况
  async calculateAverageDiscount() {
    //获取未过期的 并且设置了自动增加code的所有discount
    if (!(await this.lock(catchKeys.AUTO_INCREMENT_CODE, 2 * 60 * 60))) {
      return false;
    }
    let discountModel = new DiscountModel(this.database);
    let discountBulkModel = new DiscountBulkCodeModel(this.database, this.redis);
    let discountList = await discountModel.getNotExpiredList();
    if (discountList.length == 0) {
      await this.unLock(catchKeys.AUTO_INCREMENT_CODE);
      return;
    }
    for (let discount of discountList) {
      await discountBulkModel.autoIncrementCode(discount);
    }
    await this.unLock(catchKeys.AUTO_INCREMENT_CODE);
  }
  //同步未完成的
  async getDiscountFirstCodeFromShopify() {
    let discountRspt = this.database.getRepository(DiscountEntity);
    //获取所有未同步code的discount
    let discountList = await discountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .where({
        shopify_created_at: LessThan(dayjs().subtract(20, 'minute').toDate()),
        sync_time: IsNull()
      })
      .andWhere(`(d.ends_at is null or d.ends_at >='${dayjs().format('YYYY-MM-DD HH:mm:ss')}')`)
      .getMany();
    if (!discountList.length) return;
    for (let discountInfo of discountList) {
      let shopifyShopId = discountInfo['shop']['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        return false;
      }
      if (!(await this.lock(`${discountInfo['shopify_id']}-${SYNC_DISCOUNT_CODE_FROM_SHOPIFY}`, 12 * 60 * 60))) {
        continue;
      }
      this.queues[shopifyShopId].add(SYNC_DISCOUNT_CODE_FROM_SHOPIFY, {
        discount_shopify_id: discountInfo['shopify_id']
      });
    }
  }
  //同步未完成的dimension

  async getDiscountCodeFromShopify() {
    let discountRspt = this.database.getRepository(DiscountEntity);
    //获取所有未同步code的discount
    let discountList = await discountRspt
      .createQueryBuilder('d')
      .leftJoinAndMapOne('d.shop', ShopEntity, 's', 's.id=d.shop_id')
      .where({
        shopify_created_at: LessThan(dayjs().subtract(20, 'minute').toDate())
      })
      .andWhere(`(d.ends_at is null or d.ends_at >='${dayjs().format('YYYY-MM-DD HH:mm:ss')}')`)
      .getMany();
    if (!discountList.length) return;
    for (let discountInfo of discountList) {
      let shopifyShopId = discountInfo['shop']['shopify_id'];
      if (!this.queues[shopifyShopId]) {
        return false;
      }
      if (!(await this.lock(`${discountInfo['shopify_id']}-${SYNC_DISCOUNT_CODE_FROM_SHOPIFY}`, 2 * 60 * 60))) {
        continue;
      }
      this.queues[shopifyShopId].add(SYNC_DISCOUNT_CODE_FROM_SHOPIFY, {
        discount_shopify_id: discountInfo['shopify_id']
      });
    }
  }
}
