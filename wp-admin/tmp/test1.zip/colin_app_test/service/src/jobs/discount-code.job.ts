import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import * as cron from 'node-cron';
import { JobBasis } from './job-base';
import { JobInterface } from './interface';
import { ApiErrorLogModel } from '../model/api.error.log.model';
import { NodeMailerLib } from '../lib/nodemailer.lib';
dayjs.extend(utc);
dayjs.extend(timezone);
/**
 * 直连sms库，暂不启用，因为一样无法解决rainbow的主从库的问题
 */
export class DIscountCodeJob extends JobBasis {
  constructor(bootstrap: JobInterface) {
    super(bootstrap);
  }
  initial() {
    cron.schedule(
      process.env.NODE_ENV == 'development' ? '40 * * * * *' : '40 15 3,9,15,21 * * *',
      this.codeApiEarlyWarning.bind(this)
    );
  }

  async codeApiEarlyWarning() {
    let apiErrLogModel = new ApiErrorLogModel(this.database);
    let errList = await apiErrLogModel.getLogListPastDay();
    let nodeMailerLib = new NodeMailerLib();
    if (!(await this.lock('codeApiEarlyWarning', 30 * 60))) {
      return;
    }
    if (errList.length > 0) {
      let html = `<div>
      <h3>请注意get code api 接口正在报错 请留意!</3>
      <Table cellspacing="0" cellpadding="0" style="width:800px">
          <tr style="background:#43b391">
              <td style="color:#ffffff;padding:4px;border:1px solid #dedede;width:120px;padding:4px;">path</td>
              <td style="color:#ffffff;padding:4px;border:1px solid #dedede;width:300px;padding:4px;">data</td>
              <td style="color:#ffffff;padding:4px;border:1px solid #dedede;width:300px;padding:4px;">error</td>
              <td style="color:#ffffff;padding:4px;border:1px solid #dedede;width:120px;padding:4px;">Create date</td>
              </tr>
      `;
      for (let errInfo of errList) {
        html += `
        <tr>
        <td style="border:1px solid #dedede;padding:4px;">${errInfo.path}</td>
        <td style="border:1px solid #dedede;padding:4px;word-break:break-all; ">${JSON.stringify(errInfo.data)}</td>
        <td style="border:1px solid #dedede;padding:4px;word-break:break-all; ">${JSON.stringify(errInfo.error_data)}</td>
        <td style="border:1px solid #dedede;padding:4px;">${errInfo.created_at}</td>
        </tr>
        `;
      }
      html += `</Table></div>`;
      try {
        await nodeMailerLib.sendEmail({
          from: 'Anker ' + '<noreply-service@anker.com>',
          to: 'colin.wu@anker-in.com',
          subject: '折扣接口报错预警-Discount Interface Error Alert',
          html: html,
          text: null
        });
      } catch (e) {
        console.log('send email error');
      }
    }
    await this.unLock('codeApiEarlyWarning');
  }

  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
}
