import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import * as cron from 'node-cron';
import { EdmConfigModel } from '../model/edm.config.model';
import { ResponsysLib, TriggerEmailOptions } from '../lib/responsys.lib';
import { EdmSendRecordsEntity } from '../entity/edm.send.records.entity';
import tinyliquid from 'tinyliquid';
import { EmailConfigModel } from '../model/email.config.model';
import { JobBasis } from './job-base';
import { JobInterface } from './interface';
dayjs.extend(utc);
dayjs.extend(timezone);
/**
 * 直连sms库，暂不启用，因为一样无法解决rainbow的主从库的问题
 */
export class EdmJob extends JobBasis {
  private redisCacheKey = 'emd_send_cache';
  private edmBindCodeKey = 'edm_bind_code_key';
  public edmConfigModel: EdmConfigModel;
  public emailConfigModel: EmailConfigModel;
  constructor(bootstrap: JobInterface) {
    super(bootstrap);
    this.edmConfigModel = new EdmConfigModel(this.database, this.redis);
    this.emailConfigModel = new EmailConfigModel(this.database, this.redis);
  }
  initial() {
    this.clearCache();
    cron.schedule('40 */5 * * * *', this.sendVerifyEdmTask.bind(this));
    cron.schedule('40 */5 * * * *', this.emdBindCode.bind(this));
  }
  async clearCache() {
    let keys = await this.redis.keys(`setnx-*${this.redisCacheKey}`);
    if (keys.length > 0) {
      await this.redis.del(keys);
    }
    keys = await this.redis.keys(`setnx-*${this.edmBindCodeKey}`);
    if (keys.length > 0) {
      await this.redis.del(keys);
    }
  }
  public async lock(lockKey, seconds: number = 20 * 60) {
    return await this.redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  public async unLock(lockKey) {
    if (await this.redis.get('setnx-' + lockKey)) {
      await this.redis.del('setnx-' + lockKey);
    }
    return true;
  }
  async sendVerifyEdmTask() {
    //获取未完全发送的所有任务
    let responsysLib = new ResponsysLib();
    let edmSendRecordRspt = this.database.getRepository(EdmSendRecordsEntity);
    let edmConfigList = await this.edmConfigModel.getVerifyedList();
    if (!edmConfigList.length) return;
    for (let edmConfig of edmConfigList) {
      let records = await this.edmConfigModel.getRecordList({
        is_send: false,
        currentPage: 1,
        pageSize: 1000,
        edm_config_id: edmConfig['id']
      });
      if (records.length == 0) {
        await this.edmConfigModel.createOrSave({ ...edmConfig, is_send_all: true });
        continue;
      }
      if (!(await this.lock(`${edmConfig['id']}-${this.redisCacheKey}`, 3 * 60 * 60))) continue;
      for (let recordInfo of records) {
        let options: TriggerEmailOptions = [];
        if (recordInfo['code']) {
          options = [{ name: 'code_content', value: recordInfo['code'] }];
        }
        if (recordInfo['extend']) {
          options = [...options, ...recordInfo['extend']];
        }
        try {
          await responsysLib.triggerEmail(recordInfo['edm_template'], recordInfo.email, options);
          await edmSendRecordRspt.save({ ...recordInfo, is_send: true, send_time: dayjs().toDate() });
        } catch (e) {
          await edmSendRecordRspt.save({ ...recordInfo, send_error: e.message, send_time: dayjs().toDate() });
        }
      }
      //保存已经发完信息
      await this.unLock(`${edmConfig['id']}-${this.redisCacheKey}`);
    }
  }

  async emdBindCode() {
    await this.edmConfigModel.bindCode();
  }
  async getHtml(htmlSource: string, params): Promise<string> {
    let render = tinyliquid.compile(htmlSource);
    let context = tinyliquid.newContext({ locals: { ...params } });
    return new Promise((resolve, reject) => {
      render(context, function (err, output) {
        if (err) {
          reject(err);
        } else {
          resolve(output);
        }
      });
    });
  }
}
