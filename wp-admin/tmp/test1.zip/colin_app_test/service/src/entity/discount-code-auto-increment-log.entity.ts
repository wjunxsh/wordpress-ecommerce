import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, Index } from 'typeorm';
import 'reflect-metadata';
import { ShopEntity } from './shop.entity';

export interface ControllerExtends {
  expired_m_set?: true;
  expired_m_set_time?: string;
  m_set?: boolean;
  m_set_time?: string;
}
@Entity('discount_code_auto_increament_log')
@Index(['discount_shopify_id'])
@Index(['discount_id'])
@Index(['shop_id'])
@Index(['shopify_domain'])
export class DiscountCodeAutoIncreamentLogEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: '活动id号' })
  discount_id: number;

  @Column({ type: 'bigint', comment: 'shopify活动id号', nullable: true })
  discount_shopify_id: number;

  @Column({ comment: '店铺域名', nullable: true })
  shopify_domain: string;

  @Column({ type: 'bigint', comment: 'code数量', default: 0 })
  left_code_quantity: number;

  @Column({ type: 'bigint', comment: 'code数量', default: 0 })
  add_code_quantity: number;

  @Column({ comment: '店铺id', type: 'bigint', nullable: true })
  shop_id: number;

  @Column({
    type: 'timestamp without time zone',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  created_at: Date;

  @Column({
    type: 'timestamp without time zone',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  updated_at: Date;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity;
}
