import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  Unique,
  Index,
  CreateDateColumn,
  UpdateDateColumn
} from 'typeorm';
import { ProductEntity } from './product.entity';
import { ShopEntity } from './shop.entity';

@Entity('variants', { schema: 'public', synchronize: true })
@Unique(['shopify_id'])
@Index(['shop_id'])
@Index(['title'])
@Index(['product_id'])
export class VariantEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: number;

  @Column('bigint', { name: 'shop_id', nullable: true })
  shop_id: number | null;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopify_id: number | null;

  @Column('timestamp without time zone', {
    name: 'shopify_created_at',
    nullable: true
  })
  shopify_created_at: Date | null;

  @Column('timestamp without time zone', {
    name: 'shopify_updated_at',
    nullable: true
  })
  shopify_updated_at: Date | null;

  @Column('bigint', { name: 'product_id', nullable: true })
  product_id: number | null;

  @Column('character varying', { name: 'title', nullable: true })
  title: string | null;

  @Column('numeric', {
    name: 'compare_at_price',
    nullable: true,
    precision: 10,
    scale: 2
  })
  compare_at_price: string | null;

  @Column('character varying', { name: 'barcode', nullable: true })
  barcode: string | null;

  @Column('character varying', {
    name: 'fulfillment_service',
    nullable: true
  })
  fulfillment_service: string | null;

  @Column('integer', { name: 'grams', nullable: true })
  grams: number | null;

  @Column('bigint', { name: 'shopify_image_id', nullable: true })
  shopify_image_id: number | null;

  @Column('bigint', { name: 'inventory_item_id', nullable: true })
  inventory_item_id: number | null;

  @Column('character varying', {
    name: 'inventory_management',
    nullable: true
  })
  inventory_management: string | null;

  @Column('character varying', { name: 'inventory_policy', nullable: true })
  inventory_policy: string | null;

  @Column('integer', { name: 'inventory_quantity', nullable: true })
  inventory_quantity: number | null;

  @Column('integer', { name: 'old_inventory_quantity', nullable: true })
  old_inventory_quantity: number | null;

  @Column('integer', {
    name: 'inventory_quantity_adjustment',
    nullable: true
  })
  inventory_quantity_adjustment: number | null;

  @Column('character varying', { name: 'option1', nullable: true })
  option1: string | null;

  @Column('character varying', { name: 'option2', nullable: true })
  option2: string | null;

  @Column('character varying', { name: 'option3', nullable: true })
  option3: string | null;

  @Column('jsonb', { name: 'presentment_prices', nullable: true })
  presentment_prices: object | null;

  @Column('integer', { name: 'position', nullable: true })
  position: number | null;

  @Column('numeric', {
    name: 'price',
    nullable: true,
    precision: 10,
    scale: 2
  })
  price: number;

  @Column('bigint', { name: 'shopify_product_id', nullable: true })
  shopify_product_id: number | null;

  @Column('boolean', { name: 'requires_shipping', nullable: true })
  requires_shipping: boolean | null;

  @Column('character varying', { name: 'sku', nullable: true })
  sku: string | null;

  @Column('boolean', { name: 'taxable', nullable: true })
  taxable: boolean | null;

  @Column('character varying', { name: 'tax_code', nullable: true })
  tax_code: string | null;

  @Column({
    name: 'weight',
    nullable: true,
    type: 'decimal',
    precision: 8,
    scale: 4,
    default: 0
  })
  weight: number | null;

  @Column('character varying', { name: 'weight_unit', nullable: true })
  weight_unit: string | null;

  @Column('boolean', {
    name: 'enable_price_sync',
    nullable: true,
    default: () => 'true'
  })
  enable_price_sync: boolean | null;

  @Column('boolean', {
    name: 'enable_inventory_sync',
    nullable: true,
    default: () => 'true'
  })
  enable_inventory_sync: boolean | null;

  @Column('numeric', {
    name: 'amazon_price',
    nullable: true,
    precision: 10,
    scale: 2
  })
  amazon_price: string | null;

  @Column('integer', { name: 'cloud_sale_status', nullable: true })
  cloud_sale_status: number | null;

  @Column('integer', { name: 'shopify_sale_status', nullable: true })
  shopify_sale_status: number | null;

  @Column('boolean', {
    name: 'need_sync_price',
    nullable: true,
    default: () => 'false'
  })
  need_sync_price: boolean | null;

  @Column('boolean', {
    name: 'need_sync_inventory',
    nullable: true,
    default: () => 'false'
  })
  need_sync_inventory: boolean | null;

  @Column('boolean', {
    name: 'need_sync_status',
    nullable: true,
    default: () => 'false'
  })
  need_sync_status: boolean | null;

  @Column('jsonb', { name: 'metafields', nullable: true })
  metafields: { key: string; namespace: string; value: any }[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column('character varying', { name: 'upc', nullable: true })
  upc: string | null;

  @Column({
    type: 'decimal',
    precision: 8,
    scale: 4,
    default: 0,
    name: 'cloud_weight',
    nullable: true
  })
  cloud_weight: number | null;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity | null;

  @ManyToOne(() => ProductEntity, product => product.variants)
  @JoinColumn({ name: 'product_id' })
  product: ProductEntity | null;
}
