import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
export type OperateType = 'add' | 'del';
@Entity('discount_product_tag_log')
@Index(['product_shopify_id'])
@Index(['discount_id'])
export class DiscountProductTagLogEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: '扫码的跳转识别' })
  tags: string;

  @Column({ comment: '变更的tag' })
  change_tag: string;

  @Column({ comment: '店铺id' })
  shop_id: number;

  @Column({ comment: '产品id' })
  product_id: number;

  @Column({ comment: '活动 id' })
  discount_id: number;

  @Column({ type: 'bigint', comment: '产品 shopify id' })
  product_shopify_id: number;

  @Column({ type: 'enum', enum: ['add', 'del'], comment: '操作类型' })
  operate_type: OperateType;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
