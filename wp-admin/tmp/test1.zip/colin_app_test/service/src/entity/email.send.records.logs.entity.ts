import { Entity, Column, PrimaryGeneratedColumn, UpdateDateColumn, CreateDateColumn, Index } from 'typeorm';
import 'reflect-metadata';
import { EmailOptions } from '../lib/responsys.lib';
@Entity('email_send_records_log')
@Index(['email_config_id'])
export class EmailSendRecordsLogsEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: '主题' })
  record_id: number;

  @Column({ comment: '发送人' })
  from: string;

  @Column({ comment: '邮件标题' })
  subject: string;

  @Column({ type: 'bigint', comment: '配置id' })
  email_config_id: number;

  @Column({ comment: '邮件' })
  email: string;

  @Column({
    comment: '发送的code',
    nullable: true
  })
  code: string;

  @Column({ default: false, comment: '是否已经发送' })
  is_send: boolean;

  @Column({ type: 'jsonb', default: null, comment: '是否已经发送', nullable: true })
  send_result: object;

  @Column({
    comment: 'thml_details',
    nullable: true
  })
  html_details: string;

  @Column('timestamp without time zone', {
    comment: '发送时间',
    nullable: true
  })
  send_time: Date;

  @Column({ type: 'jsonb', comment: 'edm额外的信息', nullable: true })
  extend: EmailOptions;

  @UpdateDateColumn()
  updated_at: Date;

  @CreateDateColumn()
  created_at: Date;
}
