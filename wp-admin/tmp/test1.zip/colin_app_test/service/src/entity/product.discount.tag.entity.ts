import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, Unique, UpdateDateColumn } from 'typeorm';
@Entity('discount_product_tag')
@Index(['product_shopify_id'])
@Unique(['product_id', 'change_tag', 'discount_id'])
export class DiscountProductTagEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: '扫码的跳转识别' })
  tags: string;

  @Column({ comment: '变更的tag' })
  change_tag: string;

  @Column({ comment: '店铺id' })
  shop_id: number;

  @Column({ comment: '产品id' })
  product_id: number;

  @Column({ comment: '活动 id' })
  discount_id: number;

  @Column({ type: 'bigint', comment: '产品 shopify id' })
  product_shopify_id: number;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
