import {
  Entity,
  Column,
  Unique,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  CreateDateColumn,
} from "typeorm";
import "reflect-metadata";
@Entity("birthday_code")
@Unique(["birthday", "email"])
@Unique(["code"])
export class BirthdayCodeEntity {
  @PrimaryGeneratedColumn({ type: "bigint" })
  id: number;

  @Column({ comment: "优惠券编码", nullable: true })
  code: string;

  @Column({ comment: "shopify活动id号" })
  email: string;

  @Column({ comment: "生日", nullable: true })
  birthday: string;

  @CreateDateColumn({ type: "timestamp without time zone" })
  created_at: Date;

  @UpdateDateColumn({ type: "timestamp without time zone" })
  updated_at: Date;
}
