import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  UpdateDateColumn,
  CreateDateColumn,
} from "typeorm";
import "reflect-metadata";
import { ShopEntity } from "./shop.entity";
@Entity("edm_config")
export class EdmConfigEntity {
  @PrimaryGeneratedColumn({ type: "bigint" })
  id: number;

  @Column({  comment: "主题" })
  title: string;

  @Column({ type:'bigint',comment: "店铺id" })
  shop_id: number;

  @Column({ comment: "描述" })
  details: string;

  @Column({  comment: "edm模版" })
  edm_template: string;

  @Column('timestamp without time zone',{  comment: "发送开始时间", nullable:true })
  starts_at: Date;

  @Column({  comment: "是否允许发送",default:false })
  is_verify: boolean;

  @Column({  comment: "是否准备好",default:false })
  is_ready: boolean;

  @Column({ type:"bigint", comment: "发送的活动id" ,nullable: true })
  price_rule_id: number;

  @Column({ comment: "裂变活动标题" ,nullable: true })
  price_rule_title: string;

  @Column({ type:"jsonb", comment: "发送的card配置" ,nullable: true })
  gift_card_config: object;

  @ManyToOne(() => ShopEntity, (shop) => null)
  @JoinColumn({ name: "shop_id" })
  shop: ShopEntity;

  @Column({type:'boolean', comment: '是否发送完成'})
  is_send_all: boolean;

  @UpdateDateColumn()
  updated_at: Date;

  @CreateDateColumn()
  created_at:Date;

}
