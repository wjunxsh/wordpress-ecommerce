import {
  Entity,
  Column,
  Unique,
  PrimaryGeneratedColumn,
  OneToMany,
  DeleteDateColumn,
  ManyToOne,
  JoinColumn,
  Index
} from 'typeorm';
import 'reflect-metadata';
import { BulkCodesSettingEntity } from './bulk-code-setting';
import { ShopEntity } from './shop.entity';

export interface ControllerExtends {
  expired_m_set?: true;
  expired_m_set_time?: string;
  m_set?: boolean;
  m_set_time?: string;
}
@Entity('discount')
@Unique(['shopify_id'])
@Index(['title'])
@Index(['shop_id'])
@Index(['shop_domain'])
@Index(['deleted_at'])
@Index(['shopify_created_at'])
@Index(['shopify_updated_at'])
export class DiscountEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: 'shopify活动id号' })
  shopify_id: number;

  @Column({ comment: '店铺域名', nullable: true })
  shop_domain: string;

  @Column({ type: 'bigint', comment: 'code数量', default: 0 })
  code_quantity: number;

  @Column({ comment: '店铺id', type: 'bigint', nullable: true })
  shop_id: number;

  @Column({ comment: '活动标题', nullable: true })
  title: string;

  @Column({ comment: '活动类型', nullable: true })
  value_type: string;

  @Column({ type: 'numeric', comment: '活动的值', nullable: true })
  value: number;

  @Column({ comment: '客户选择', nullable: true })
  customer_selection: string;

  @Column({ comment: '目标类型', nullable: true })
  target_type: string;

  @Column({ comment: '目标选择', nullable: true })
  target_selection: string;

  @Column({ nullable: true })
  allocation_method: string;

  @Column({ nullable: true })
  allocation_limit: string;

  @Column({ nullable: true })
  once_per_customer: boolean;

  @Column({ nullable: true })
  usage_limit: number;

  @Column({
    type: 'timestamp without time zone',
    nullable: true
  })
  starts_at: Date;

  @Column({
    type: 'timestamp without time zone',
    nullable: true
  })
  ends_at: Date;

  @Column({
    type: 'jsonb',
    nullable: true,
    comment: '其产品将有资格享受折扣的集合的 ID 列表'
  })
  entitled_product_ids: number[];

  @Column({ type: 'jsonb', nullable: true, comment: '授权国家ID' })
  entitled_variant_ids: number[];

  @Column({ type: 'jsonb', nullable: true, comment: '授权产品ID' })
  entitled_collection_ids: number[];

  @Column({ type: 'jsonb', nullable: true, comment: '授权country ID' })
  entitled_country_ids: object;

  @Column({ type: 'jsonb', nullable: true, comment: '授权目标产品 ID' })
  prerequisite_product_ids: object;

  @Column({ type: 'jsonb', nullable: true, comment: '授权目标VARIANT ID' })
  prerequisite_variant_ids: object;

  @Column({ type: 'jsonb', nullable: true, comment: '授权目标集合 ID' })
  prerequisite_collection_ids: object;

  @Column({ type: 'jsonb', nullable: true })
  customer_segment_prerequisite_ids: object;

  @Column({ type: 'jsonb', nullable: true })
  prerequisite_customer_ids: object;

  @Column({ type: 'jsonb', nullable: true })
  prerequisite_saved_search_ids: object;

  @Column({ type: 'jsonb', nullable: true })
  prerequisite_subtotal_range: object;

  @Column({ type: 'jsonb', nullable: true })
  prerequisite_quantity_range: object;

  @Column({ type: 'jsonb', nullable: true })
  prerequisite_shipping_price_range: object;

  @Column({ type: 'jsonb', nullable: true })
  prerequisite_to_entitlement_quantity_ratio: object;

  @Column({ type: 'jsonb', nullable: true })
  prerequisite_to_entitlement_purchase: object;

  @Column({ nullable: true })
  admin_graphql_api_id: string;

  @Column({ nullable: true })
  is_birthday: boolean;

  @Column({
    type: 'timestamp without time zone',
    nullable: true
  })
  sync_time: Date;

  @Column({
    type: 'timestamp without time zone',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  created_at: Date;

  @Column({
    type: 'timestamp without time zone',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  updated_at: Date;

  @Column({
    type: 'int',
    comment: '每天消耗平均数量',
    default: 0
  })
  everage_daily_used_count: number;

  @Column({
    comment: '是否自动增加code数量',
    default: false
  })
  auto_increment_code: boolean;

  @Column({
    comment: '是否是其他方式创建的活动',
    default: false
  })
  is_bulk_discount: boolean;

  @Column({
    type: 'timestamptz',
    nullable: true
  })
  @DeleteDateColumn({ type: 'timestamp without time zone' })
  deleted_at: Date;

  @Column({
    type: 'jsonb',
    comment: '保存一些额外的信息',
    nullable: true
  })
  extend: ControllerExtends;

  @Column({
    comment: '是否将对应的产品拆解到discount_variant表中',
    nullable: true,
    default: false
  })
  set_discount_variant: boolean;

  @OneToMany(() => BulkCodesSettingEntity, BulkCodesSetting => BulkCodesSetting.discount)
  bulk_code_setting: BulkCodesSettingEntity;

  @Column('timestamp without time zone', { comment: 'shopify创建时间', nullable: true })
  shopify_created_at: Date | null;

  @Column('timestamp without time zone', { comment: 'shopify更新时间', nullable: true })
  shopify_updated_at: Date | null;

  @Column({ comment: '更新code的最后一页的链接', nullable: true })
  last_page_info: string;

  @Column({ type: 'int', comment: 'code有效天数', default: 0 })
  code_effective_days: number;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity;
}
