import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import 'reflect-metadata';
export enum ApiType {
  OUT = 'out',
  INNER = 'inner'
}
@Entity('api_error_log')
@Index(['path'])
@Index(['created_at'])
export class ApiErrorLogEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: '接口path' })
  path: string;

  @Column({ comment: '接口方法' })
  method: string;

  @Column({ comment: '接口是内部接口还是外部接口', type: 'enum', enum: ApiType })
  api_type: ApiType;

  @Column({ type: 'jsonb', comment: '表单数据' })
  data: any;

  @Column({
    type: 'jsonb',
    name: 'error_data',
    comment: '错误信息',
    nullable: true
  })
  error_data: any;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;
}
