import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, UpdateDateColumn, CreateDateColumn } from 'typeorm';
import 'reflect-metadata';
import { ShopEntity } from './shop.entity';
export enum code_generate_type {
  IMPORT = 'import',
  HALF = 'half',
  ALL = 'all'
}
export enum import_type {
  IMPORT = 'update',
  HALF = 'create'
}
@Entity('discount_import_tasks')
export class DiscountImportTasksEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ comment: '用途说明' })
  title: string;

  @Column({ type: 'bigint', comment: '店铺id' })
  shop_id: number;

  @Column({ type: 'bigint', comment: '操作人' })
  user_id: number;

  @Column({ type: 'enum', comment: 'code生成方式', enum: code_generate_type })
  code_generate_type: code_generate_type;

  @Column({
    comment: '和其他产品折扣一起生效',
    nullable: true
  })
  combine_product_discount: boolean;

  @Column({ type: 'enum', comment: '导入类型', enum: import_type })
  import_type: import_type;

  @Column({ comment: '是否允许同步', default: false })
  promise_sync: boolean;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity;

  @Column({ type: 'boolean', comment: '是否发送完成', default: false })
  is_send_all: boolean;

  @UpdateDateColumn()
  updated_at: Date;

  @CreateDateColumn()
  created_at: Date;
}
