import { DiscountEntity } from './discount.entity';
import { DiscountMetafieldsEntity } from './discount.metafields.entity';
import { DiscountBulkCodeEntity } from './discount-bulk-code';
import { BulkCodesSettingEntity } from './bulk-code-setting';
import { DiscountBulkCodeBakEntity } from './discount-bulk-code-bak.entity';
import { EdmConfigEntity } from './edm.config.entity';
import { EdmSendRecordsEntity } from './edm.send.records.entity';
import { EmailSendRecordsEntity } from './email.send.records.entity';
import { EmailConfigEntity } from './email.config.entity';
import { EmailSendRecordsLogsEntity } from './email.send.records.logs.entity';
import { BirthdayCodeEntity } from './birthday-code.entity';
import { OutApiAuthEntity } from './authorization.entity';
import { VariantEntity } from './variant.entity';
import { ProductEntity } from './product.entity';
import { WebhookEntity } from './webhook.entity';
import { scriptEntitys } from './script';
import { ShopifySessionsEntity } from './script/shopify_sessions.entity';
import { DiscountProductTagLogEntity } from './product.discount.tag.log.entity';
import { DiscountProductTagEntity } from './product.discount.tag.entity';
import { DiscountVariantEntity } from './discount.variant.entity';
import { DiscountVariantLogEntity } from './discount.variant.log.entity';
import { ApiErrorLogEntity } from './api.error.log.entity';
import { DiscountImportTasksEntity } from './discount.import.task.entity';
import { DisocuntImportRecordsEntity } from './discount.import.records.entity';
import { DiscountCodeAutoIncreamentLogEntity } from './discount-code-auto-increment-log.entity';
export const allEntitys = [
  ...scriptEntitys,
  DiscountEntity,
  DiscountMetafieldsEntity,
  DiscountBulkCodeEntity,
  BulkCodesSettingEntity,
  DiscountBulkCodeBakEntity,
  EdmConfigEntity,
  EdmSendRecordsEntity,
  EmailSendRecordsEntity,
  EmailConfigEntity,
  EmailSendRecordsLogsEntity,
  BirthdayCodeEntity,
  ApiErrorLogEntity,
  ProductEntity,
  VariantEntity,
  OutApiAuthEntity,
  WebhookEntity,
  DiscountProductTagLogEntity,
  DiscountProductTagEntity,
  DiscountVariantEntity,
  DiscountVariantLogEntity,
  DiscountImportTasksEntity,
  DisocuntImportRecordsEntity,
  DiscountCodeAutoIncreamentLogEntity,
  ShopifySessionsEntity
];
