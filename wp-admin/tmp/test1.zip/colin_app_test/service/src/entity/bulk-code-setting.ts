import {
  Entity,
  Column,
  Unique,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  DeleteDateColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index
} from 'typeorm';
import 'reflect-metadata';
import { DiscountEntity } from './discount.entity';
import { ShopEntity } from './shop.entity';
@Entity('bulk_codes_setting')
@Unique(['id'])
@Index(['discount_id'])
@Index(['discount_shopify_id'])
export class BulkCodesSettingEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: 'shopify活动id号' })
  discount_id: number;

  @Column({ comment: '店铺id', name: 'shop_id', type: 'bigint', nullable: true })
  shop_id: number;

  @Column({ type: 'bigint', comment: 'shopify活动id号' })
  discount_shopify_id: number;

  @Column({ comment: '裂变方式' })
  type: string;

  @Column({ comment: '编码前缀', nullable: true })
  prefix: string;

  @Column({ comment: '编码后缀', nullable: true })
  suffix: string;

  @Column({ comment: '数量', nullable: true })
  counts: number;

  @Column({ comment: '随机长度', nullable: true })
  random_length: number;

  @Column({
    default: 'mix'
  })
  character_type: string;

  @Column({ type: 'jsonb', comment: '编码数组', nullable: true })
  codes: string;

  @Column({
    comment: '是否已经裂变'
  })
  is_bulk: boolean;

  @Column({
    type: 'timestamptz',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  @CreateDateColumn()
  created_at: Date;

  @Column({
    type: 'timestamptz',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  @UpdateDateColumn()
  updated_at: Date;

  @Column({
    type: 'timestamptz',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  bulk_at: Date;

  @ManyToOne(() => DiscountEntity, discount => discount.bulk_code_setting)
  @JoinColumn({ name: 'discount_id' })
  discount: DiscountEntity;

  @Column({
    type: 'timestamptz',
    nullable: true
  })
  @DeleteDateColumn()
  deleted_at: Date;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity;
}
