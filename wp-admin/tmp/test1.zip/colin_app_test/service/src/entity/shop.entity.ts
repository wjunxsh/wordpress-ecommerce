import { Column, Entity, PrimaryGeneratedColumn, Unique } from 'typeorm';
interface Extend {
  shop_discount_threshold_value: number;
}
@Entity('shops', { schema: 'public', synchronize: true })
@Unique(['shopify_id'])
export class ShopEntity {
  @PrimaryGeneratedColumn({ type: 'bigint', name: 'id' })
  id: number;

  @Column('character varying', { name: 'name', nullable: true })
  name: string;

  @Column('character varying', { name: 'shopify_domain' })
  shopify_domain: string;

  @Column('character varying', { name: 'shopify_token', nullable: true })
  shopify_token: string | null;

  @Column('bigint', { name: 'shopify_id', nullable: true })
  shopify_id: number | null;

  @Column('character varying', { name: 'country_code', nullable: true })
  country_code: string | null;

  @Column('character varying', { name: 'currency', nullable: true })
  currency: string | null;

  @Column('timestamp without time zone', { name: 'created_at' })
  created_at: Date;

  @Column('timestamp without time zone', { name: 'updated_at' })
  updated_at: Date;

  @Column({ name: 'state', comment: '店铺状态 1有效,0无效', default: 1 })
  state: number;

  @Column({ name: 'extend', type: 'jsonb', comment: '扩展', default: null, nullable: true })
  extend: Extend;

  @Column('character varying', { name: 'iana_timezone', nullable: true })
  iana_timezone: string | null;

  @Column('character varying', { name: 'custom_domain', nullable: true })
  custom_domain: string | null;

  @Column('character varying', { name: 'primary_locale', nullable: true })
  primary_locale: string | null;

  @Column('timestamp without time zone', { name: 'uninstalled_at', nullable: true })
  uninstalled_at: Date;

  @Column('character varying', { nullable: true })
  scope: string | null;
}
