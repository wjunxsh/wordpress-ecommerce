import { Entity, Column, PrimaryGeneratedColumn, DeleteDateColumn, Index, UpdateDateColumn, CreateDateColumn } from 'typeorm';
import 'reflect-metadata';
@Entity('discount_products')
@Index(['code'])
export class DiscountProductEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ comment: '店铺id', type: 'bigint', nullable: true })
  shop_id: number;

  @Column({ type: 'bigint', comment: 'shopify活动id号', nullable: true })
  discount_shopify_id: number;

  @Column({ type: 'bigint', comment: '活动id号' })
  discount_id: number;

  @Column({ type: 'bigint', comment: 'shopify id', nullable: true })
  product_id: number;

  @Column({ type: 'bigint', comment: 'shopify product id', nullable: true })
  shopify_product_id: number;

  @Column({ type: 'bigint', comment: 'shopify variant id', nullable: true })
  shopify_variant_id: number;

  @Column({ comment: '裂变码' })
  code: string;

  @CreateDateColumn({ type: 'timestamp without time zone' })
  created_at: Date;

  @Column({
    type: 'jsonb',
    comment: '从shopify同步时候的报错信息',
    nullable: true
  })
  sync_error: object;

  @Column('timestamp without time zone', { name: 'expired_at', comment: '过期时间', nullable: true })
  expired_at: Date | null;

  @UpdateDateColumn({ type: 'timestamp without time zone' })
  updated_at: Date;

  @DeleteDateColumn({ type: 'timestamp without time zone' })
  deleted_at: Date;

  @Column({
    comment: '同步到shopify的时间',
    type: 'timestamp without time zone',
    nullable: true
  })
  sync_at: Date;
}
