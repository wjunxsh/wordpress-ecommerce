import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  UpdateDateColumn,
  CreateDateColumn,
  Index
} from 'typeorm';
import 'reflect-metadata';
import { EdmConfigEntity } from './edm.config.entity';
import { TriggerEmailOptions } from '../lib/responsys.lib';
@Entity('edm_send_records')
@Index(['edm_config_id'])
export class EdmSendRecordsEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: '主题' })
  edm_config_id: number;

  @Column({ comment: '邮件' })
  email: string;

  @Column({
    comment: '发送的code',
    nullable: true
  })
  code: string;

  @Column({ default: false, comment: '是否已经发送' })
  is_send: boolean;

  @Column({ type: 'jsonb', default: null, comment: '是否已经发送', nullable: true })
  send_error: object;

  @Column({
    comment: 'edm_template',
    nullable: true
  })
  edm_template: string;

  @Column('timestamp without time zone', {
    comment: '发送时间',
    nullable: true
  })
  send_time: Date;

  @Column({ type: 'jsonb', comment: 'edm额外的信息', nullable: true })
  extend: TriggerEmailOptions;

  @UpdateDateColumn()
  updated_at: Date;

  @CreateDateColumn()
  created_at: Date;

  @ManyToOne(() => EdmConfigEntity)
  @JoinColumn({ name: 'edm_config_id' })
  edmConfig: EdmConfigEntity;
}
