import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, Index, UpdateDateColumn } from 'typeorm';
import 'reflect-metadata';
import { ShopEntity } from './shop.entity';
import { DiscountEntity } from './discount.entity';
@Entity('discount_variant_logs')
@Index(['discount_id'])
@Index(['shopify_variant_id'])
@Index(['shopify_product_id'])
export class DiscountVariantLogEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: 'shopify variant id号' })
  shopify_variant_id: number;

  @Column({ type: 'bigint', comment: 'shopify产品id号' })
  shopify_product_id: number;

  @Column({ type: 'bigint', comment: '活动主键' })
  discount_id: number;

  @Column({ type: 'bigint', comment: 'shopify 活动id号' })
  shopify_discount_id: number;

  @Column({ comment: '店铺域名', nullable: true })
  shop_domain: string;

  @Column({ comment: '活动code', nullable: true })
  title: string;

  @Column({ comment: '店铺id', type: 'bigint', nullable: true })
  shop_id: number;

  @Column({ type: 'bigint', comment: 'metafields id号', nullable: true })
  metafield_shopify_id: number;

  @Column('numeric', { comment: 'sku价格', nullable: true })
  variant_price: number;

  @Column({ comment: '活动类型', nullable: true })
  value_type: string;

  @Column('numeric', { comment: '活动的值', nullable: true })
  value: number;

  @Column({ type: 'numeric', comment: '折扣金额(abs之后的折扣金额)', nullable: true })
  fixed_value: number;

  @Column({ comment: 'fixed_amount 类型折扣可以使用这个字段展示带货币符号的降价金额', nullable: true })
  value_style: string;

  @Column('numeric', { comment: '折后价格', nullable: true })
  variant_price4wscode: number;

  @Column({ comment: '货币符号', nullable: true })
  currency_symbol: string;

  @Column('numeric', { comment: '用于 sort_key Query Params', nullable: true })
  fixed_amount_sort_key: number;

  @Column('numeric', { comment: '用于 sort_key Query Params', nullable: true })
  percentage_sort_key: number;

  @Column({
    comment: '是否是最大折扣',
    nullable: true
  })
  is_max_discount: boolean;

  @Column({
    type: 'timestamp without time zone',
    comment: '此商品是否已经写入metafield中',
    nullable: true
  })
  async_time: Date;

  @Column({
    type: 'timestamp without time zone',
    nullable: true
  })
  starts_at: Date;

  @Column({
    type: 'jsonb',
    nullable: true,
    comment: '其他信息'
  })
  extend: any;

  @Column({
    type: 'timestamp without time zone',
    nullable: true
  })
  ends_at: Date;

  @Column({
    type: 'timestamp without time zone',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  created_at: Date;

  @Column({
    type: 'timestamp without time zone',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  updated_at: Date;

  @UpdateDateColumn({
    type: 'timestamp without time zone',
    default: () => 'CURRENT_TIMESTAMP',
    nullable: true
  })
  log_at: Date;

  @UpdateDateColumn({
    type: 'varchar',
    comment: '操作类型',
    nullable: true
  })
  operate_type: 'create' | 'delete';

  @Column({ comment: '等待删除', nullable: true, default: false })
  need_delete: boolean;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity;

  @ManyToOne(() => DiscountEntity)
  @JoinColumn({ name: 'discount_id' })
  discount: DiscountEntity;
}
