import { Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn } from 'typeorm';

@Entity('script_product_tag')
export class ScriptProductTagEntity {
  @PrimaryColumn({ type: 'varchar', length: 36, name: 'uuid' })
  uuid: string;

  @Column({ type: 'bigint', comment: '函数的id号', nullable: true })
  discount_id: number;

  @Column({ type: 'bigint', comment: 'product shopify id', nullable: true })
  product_shopify_id: number;

  @Column({ comment: 'discount product tag', nullable: true })
  product_tag: string;

  @Column({ comment: '产品shopify id', nullable: true })
  is_need_delete: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column('timestamp without time zone', { comment: '开始同步到shopify的时间点', nullable: true })
  start_sync_at: Date;
  //同步到shopify的真正时间，
  @Column('timestamp without time zone', { comment: '同步的时间', nullable: true })
  sync_at: Date;
  //如果已经同步到shopify 但是活动生效时间往后更改了，则需要先将其删除，一个sync_at无法标记
  @Column({ comment: '同步的时间', default: false })
  sync_state: boolean;
}
