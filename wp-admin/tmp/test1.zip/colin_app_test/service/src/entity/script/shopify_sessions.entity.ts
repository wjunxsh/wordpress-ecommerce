import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
export interface OnlineAccessInfo {
  id: number;
  email: string;
  locale: string;
  last_name: string;
  first_name: string;
  collaborator: boolean;
  account_owner: boolean;
  email_verified: boolean;
}

@Entity('shopify_sessions', { schema: 'public', synchronize: false })
export class ShopifySessionsEntity {
  @PrimaryGeneratedColumn('uuid', { comment: '主键' })
  id: string;

  @Column({ comment: '域名' })
  shop: string;

  @Column({ comment: '状态' })
  state: string;

  @Column({ comment: '是否是在线' })
  is_online: boolean;

  @Column({ comment: '权限' })
  scope: string;

  @Column({ comment: '过期时间', nullable: true })
  expires: number;

  @Column({ type: 'jsonb', comment: '用户信息', nullable: true })
  online_access_info: OnlineAccessInfo | null;

  @Column({ comment: '权限token' })
  access_token: string;
}
