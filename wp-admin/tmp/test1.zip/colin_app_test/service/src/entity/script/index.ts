import { ScriptDiscountEntity } from './script_discount.entity';
import { ScriptDiscountMetafieldsEntity } from './script_discount.metafields.entity';
import { ScriptDiscountLogEntity } from './script_discount_log.entity';
import { ScriptFunctionEntity } from './script_function.entity';
import { ScriptLabelConfigEntity } from './script_label_config.entity';
import { ScriptProductTagEntity } from './script_product_tag.entity';
import { ScriptProgramManageEntity } from './script_program_manage.entity';

export const scriptEntitys = [
  ScriptDiscountEntity,
  ScriptDiscountLogEntity,
  ScriptDiscountMetafieldsEntity,
  ScriptFunctionEntity,
  ScriptLabelConfigEntity,
  ScriptProgramManageEntity,
  ScriptProductTagEntity
];
