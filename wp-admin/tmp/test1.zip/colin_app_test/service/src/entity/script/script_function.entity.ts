import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, Unique, UpdateDateColumn } from 'typeorm';

@Entity('script_functions')
@Unique(['function_key'])
export class ScriptFunctionEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: '扫码的跳转识别' })
  function_key: string;

  @Column({ comment: '标题' })
  title: string;

  @Column({ comment: '编码类型' })
  code_type: string;

  @Column({ comment: '是否订单维度的折扣，比如满减，满赠等，这种折扣要作为最高优先级处理', default: false })
  is_order: boolean;

  @Column({ comment: '店铺id', nullable: true })
  shop_id: number;

  @Column({ type: 'text', comment: '程序编码' })
  code: string;

  @Column({ type: 'text', comment: '详细描述' })
  details: string;

  @Column({ type: 'jsonb', comment: '依赖的函数', nullable: true })
  relate_functions: string[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
