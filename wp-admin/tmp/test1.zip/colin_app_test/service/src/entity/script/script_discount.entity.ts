import { Column, CreateDateColumn, DeleteDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('script_discounts')
export class ScriptDiscountEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: '函数的key值' })
  function_id: string;

  @Column({ comment: '标题' })
  title: string;

  @Column({ comment: '老的id', default: 0 })
  old_id: number;

  @Column({ comment: '店铺id', nullable: true })
  shop_id: number;

  @Column({ comment: '排序', nullable: true })
  sort: number;

  @Column({ comment: '活动状态' })
  state: string;

  @Column({ comment: '活动对应的产品tag' })
  product_tag: string;

  @Column('timestamp without time zone', { comment: '活动开始时间' })
  starts_at: Date;

  @Column('timestamp without time zone', { comment: '活动结束时间', default: null, nullable: true })
  ends_at: Date;
  @Column({ type: 'jsonb', comment: '前端传过来的活动规则' })
  config: any;

  @Column({ type: 'jsonb', comment: '活动规则' })
  scripts_config: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @DeleteDateColumn()
  deleted_at: Date;
}
