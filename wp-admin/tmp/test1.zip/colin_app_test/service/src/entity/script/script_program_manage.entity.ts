import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, Unique, UpdateDateColumn } from 'typeorm';

@Entity('script_program_manages')
@Unique(['shop_id'])
export class ScriptProgramManageEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: '店铺id', nullable: true })
  shop_id: number;

  @Column('timestamp without time zone', { comment: '发布时间', nullable: true })
  deploy_at: Date;

  @Column({ comment: '部署者', nullable: true })
  deployer: string;

  @Column({ comment: '拷贝次数', default: 0 })
  copty_times: number;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
