import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('script_discounts_log')
export class ScriptDiscountLogEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: 'product_id' })
  discount_id: number;

  @Column({ comment: 'user_id', type: 'bigint', nullable: true })
  user_id: number;

  @Column({ comment: '函数的key值' })
  function_id: string;

  @Column({ comment: '标题' })
  title: string;

  @Column({ comment: '店铺id', nullable: true })
  shop_id: number;

  @Column({ comment: '排序', nullable: true })
  sort: number;

  @Column({ comment: '活动操作类型' })
  operate_type: number;

  @Column({ comment: '活动状态' })
  state: string;

  @Column({ comment: '活动对应的产品tag' })
  product_tag: string;

  @Column('timestamp without time zone', { comment: '活动开始时间' })
  starts_at: Date;

  @Column('timestamp without time zone', { comment: '活动结束时间', default: null, nullable: true })
  ends_at: Date;

  @Column({ type: 'jsonb', comment: '前端传过来的活动规则' })
  config: string;

  @Column({ type: 'jsonb', comment: '活动规则' })
  scripts_config: string;

  @Column('timestamp without time zone', { comment: '活动创建时间' })
  created_at: Date;

  @Column('timestamp without time zone', { comment: '更新时间' })
  updated_at: Date;

  @CreateDateColumn({ comment: '日志时间' })
  log_at: Date;
}
