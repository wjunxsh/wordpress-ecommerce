import { Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn } from 'typeorm';

@Entity('script_discounts_metafields')
export class ScriptDiscountMetafieldsEntity {
  @PrimaryColumn({ type: 'varchar', length: 36, name: 'uuid' })
  uuid: string;

  @Column({ type: 'bigint', comment: '函数的id号', nullable: true })
  discount_id: number;

  @Column({ type: 'bigint', comment: '展示排序', nullable: true })
  sort: number;

  @Column({ type: 'bigint', comment: 'target shopify id' })
  target_shopify_id: number;

  @Column({ comment: '目标类型 product，variant，page' })
  target_type: string;

  @Column({ type: 'bigint', comment: 'metafields id号', nullable: true })
  metafield_shopify_id: number;

  @Column({ comment: '产品shopify id', nullable: true })
  is_need_delete: boolean;

  @Column({ type: 'varchar', comment: 'metafields的key值' })
  metafield_key: string;

  @Column({ comment: 'metafields的数据类型' })
  metafield_type: string;

  @Column({ comment: 'metafields的namespace' })
  metafield_namespace: string;

  @Column({ type: 'jsonb', comment: 'metafields的值' })
  metafield_value: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column('timestamp without time zone', { comment: '开始同步到shopify的时间点', nullable: true })
  start_sync_at: Date;
  //同步到shopify的真正时间，
  @Column('timestamp without time zone', { comment: '同步的时间', nullable: true })
  sync_at: Date;
}
