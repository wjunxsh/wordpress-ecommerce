import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, Unique, UpdateDateColumn } from 'typeorm';

@Entity('script_label_configs')
@Unique(['function_key', 'shop_id'])
export class ScriptLabelConfigEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ comment: '扫码的跳转识别' })
  function_key: string;

  @Column({ type: 'jsonb', comment: '前端文案汇总' })
  labels: string;

  @Column({ comment: '店铺id', nullable: true })
  shop_id: number;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
