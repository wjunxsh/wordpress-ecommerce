import { Entity, Column, PrimaryGeneratedColumn, DeleteDateColumn, Index, UpdateDateColumn, CreateDateColumn } from 'typeorm';
import 'reflect-metadata';
@Entity('discount_bulk_code_bak')
@Index(['code'])
@Index(['shop_id'])
@Index(['batch_id'])
@Index(['discount_id'])
export class DiscountBulkCodeBakEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: '设置的批次号', nullable: true })
  setting_id: number;

  @Column({ comment: '店铺id', type: 'bigint', nullable: true })
  shop_id: number;

  @Column({ type: 'bigint', comment: 'shopify活动id号', nullable: true })
  batch_id: number;

  @Column({ type: 'bigint', comment: 'shopify活动id号', nullable: true })
  discount_shopify_id: number;

  @Column({ type: 'bigint', comment: '活动id号' })
  discount_id: number;

  @Column({ type: 'bigint', comment: 'shopify id', nullable: true })
  shopify_id: number;

  @Column({ comment: '裂变码' })
  code: string;

  @Column({
    comment: '使用次数',
    default: 0
  })
  usage_count: number;

  @CreateDateColumn({ type: 'timestamp without time zone' })
  created_at: Date;

  @Column({
    type: 'jsonb',
    comment: '从shopify同步时候的报错信息',
    nullable: true
  })
  sync_error: object;

  @Column('boolean', { name: 'assigned', nullable: true })
  assigned: boolean | null;

  @Column('character varying', { name: 'assigned_email', nullable: true })
  assigned_email: string | null;

  @Column('timestamp without time zone', { name: 'assigned_at', nullable: true })
  assigned_at: Date | null;

  @Column('timestamp without time zone', { name: 'expired_at', nullable: true })
  expired_at: Date | null;

  @Column('boolean', { name: 'is_auto_increment', comment: '是否不足自增', default: false })
  is_auto_increment: boolean;

  @UpdateDateColumn({ type: 'timestamp without time zone' })
  updated_at: Date;

  @DeleteDateColumn({ type: 'timestamp without time zone' })
  deleted_at: Date;

  @Column({
    comment: '同步到shopify的时间',
    type: 'timestamp without time zone',
    nullable: true
  })
  sync_at: Date;
}
