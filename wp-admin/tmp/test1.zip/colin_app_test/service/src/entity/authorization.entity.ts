import { Entity, Column, Unique, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, Index } from "typeorm";
import "reflect-metadata";
@Entity("out_api_auth")
@Unique(["id"])
@Index(["public_token"])
export class OutApiAuthEntity {
  @PrimaryGeneratedColumn({ type: "bigint" })
  id: number;

  @Column({ comment: "私钥字符串" })
  private_key: string;

  @Column({ comment: "公钥字符串" })
  public_token: string;

  @Column({ comment: "平台名称" })
  platform_name: string;

  @Column({ comment: "状态" })
  state: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
