//start_ai_generated
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  UpdateDateColumn,
  CreateDateColumn,
  Index
} from 'typeorm';
import 'reflect-metadata';
import { DiscountImportTasksEntity } from './discount.import.task.entity';
@Entity('discount_import_records')
@Index(['import_task_id'])
export class DisocuntImportRecordsEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', comment: '导入任务id' })
  import_task_id: number;

  @Column({
    comment: '产品handle',
    nullable: true
  })
  handle: string;

  @Column({
    comment: '产品sku',
    nullable: true
  })
  sku: string;

  @Column({
    type: 'bigint',
    comment: '产品sku id',
    nullable: true
  })
  variant_id: number;

  @Column({
    comment: 'code信息',
    nullable: true
  })
  code: string;

  @Column({
    comment: '折扣的值',
    nullable: true
  })
  value: string;

  @Column({
    comment: '折扣值的类型 percentage, fixed_amount',
    nullable: true
  })
  value_type: string;

  @Column('timestamp without time zone', {
    comment: '开始时间',
    nullable: true
  })
  start_date: Date;

  @Column('timestamp without time zone', {
    comment: '结束时间',
    nullable: true
  })
  end_date: Date;

  @Column({
    comment: '和其他产品折扣一起生效',
    nullable: true
  })
  combine_product_discount: string;

  @Column({
    comment: '在一个订单中可以使用多次控制ACROSS,EACH',
    nullable: true
  })
  allocation_method: string;

  @Column({
    comment: '折扣总使用次数',
    nullable: true
  })
  usage_limit: string;

  @Column({
    comment: '折扣针对每个客户能够使用次数，Y表示只能使用一次，其他则表示1+',
    nullable: true
  })
  once_per_customer: string;

  @Column('timestamp without time zone', { comment: '同步到shopify的时间', nullable: true })
  sync_at: Date;

  @Column({ type: 'jsonb', default: null, comment: '发送的失败记录等额外的信息', nullable: true })
  extend: object;

  @UpdateDateColumn()
  updated_at: Date;

  @CreateDateColumn()
  created_at: Date;

  @ManyToOne(() => DiscountImportTasksEntity)
  @JoinColumn({ name: 'import_task_id' })
  discount_import_task: DiscountImportTasksEntity;
}

//end_ai_generated
