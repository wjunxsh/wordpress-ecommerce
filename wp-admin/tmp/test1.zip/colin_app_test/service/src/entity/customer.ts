import { Entity, Column, Unique, PrimaryGeneratedColumn } from "typeorm";
import "reflect-metadata";
@Entity("customer")
@Unique(["id"])
export class CustomerEntity {
  @PrimaryGeneratedColumn({ type: "bigint" })
  id: number;

  @Column({ comment: "邮箱" })
  email: string;

  @Column({ comment: "生日" })
  birthday: string;

  @Column({ comment: "状态" })
  state: boolean;

  @Column({
    type: "timestamptz",
    default: () => "CURRENT_TIMESTAMP",
    nullable: true,
  })
  created_at: Date;
}
