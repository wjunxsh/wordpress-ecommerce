import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, UpdateDateColumn, CreateDateColumn } from 'typeorm';
import 'reflect-metadata';
import { ShopEntity } from './shop.entity';
@Entity('email_config')
export class EmailConfigEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ comment: '主题' })
  title: string;

  @Column({ comment: '详细描述', nullable: true })
  details: string;

  @Column({ comment: '发送人之前的内容' })
  from: string;

  @Column({ comment: '发送邮件', nullable: true })
  from_email: string;

  @Column({ comment: '邮件标题' })
  subject: string;

  @Column({ type: 'bigint', comment: '店铺id' })
  shop_id: number;

  @Column({ comment: 'html模版内容' })
  html_template: string;

  @Column('timestamp without time zone', { comment: '发送开始时间', nullable: true })
  starts_at: Date;

  @Column({ comment: '是否允许发送', default: false })
  is_verify: boolean;

  @Column({ comment: '是否准备好', default: false })
  is_ready: boolean;

  @Column({ type: 'bigint', comment: '发送的活动id', nullable: true })
  price_rule_id: number;

  @Column({ comment: '裂变活动标题', nullable: true })
  price_rule_title: string;

  @Column({ type: 'jsonb', comment: '发送的card配置', nullable: true })
  gift_card_config: object;

  @ManyToOne(() => ShopEntity)
  @JoinColumn({ name: 'shop_id' })
  shop: ShopEntity;

  @Column({ type: 'boolean', comment: '是否发送完成' })
  is_send_all: boolean;

  @UpdateDateColumn()
  updated_at: Date;

  @CreateDateColumn()
  created_at: Date;
}
