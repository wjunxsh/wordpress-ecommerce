import * as qs from 'qs';
import axios from "axios"
export type TriggerEmailOptions = {
  name: string;
  value: string;
}[];

export type EmailOptions = {
  [key:string]:string
};

export class ResponsysLib {
  zeusHost = process.env.ZEUS_HOST;
  subscribeHost = process.env.SUBSCRIBE_HOST;
  constructor(
  ) {}

  async triggerEmail(campaign: string, email: string, options: TriggerEmailOptions): Promise<any> {
    try {
      const customerId = await this.getCustomerIdByEmail(email);
      const data = {
        fieldValues: [email, customerId],
      };

      if (options.length !== 0) {
        data['optionalData'] = options;
      }

      const payload = {
        mergeTriggerRecordData: {
          mergeTriggerRecords: [data],
          fieldNames: ['EMAIL_ADDRESS_', 'CUSTOMER_ID_'],
        },
        mergeRule: {
          htmlValue: 'H',
          matchColumnName1: 'CUSTOMER_ID_',
          optoutValue: 'O',
          insertOnNoMatch: true,
          defaultPermissionStatus: 'OPTIN',
          rejectRecordIfChannelEmpty: 'E',
          optinValue: 'I',
          updateOnMatch: 'NO_UPDATE',
          textValue: 'T',
          matchOperator: 'NONE',
        },
      };

      const preAuthRes = await this.preAuth();
      let result = await axios
        .post(`${preAuthRes.endPoint}/rest/api/v1.3/campaigns/${campaign}/email`, payload, {
          headers: {
            Authorization: preAuthRes.authToken,
            'Content-Type': 'application/json',
          },
        });
        return result.data;
    } catch (e) {
      throw new Error(JSON.stringify(e.response.data));
    }
  }

  async getCustomerIdByEmail(email: string): Promise<string> {
    try {
      const response = await axios
        .get(`${this.subscribeHost}/api/rsp_contact`, {
          params: {
            email: email,
          },
          headers: {
            Authorization: `Token token=${process.env.ZEUS_AUTH_TOKEN}`,
          },
        })
        console.log('response.status',response.status)
      return response.data.customer_id;
    } catch (e) {
      console.log(e);
      return '';
    }
  }

  async preAuth(): Promise<any> {
    try {
      const response = await axios
        .post(
          `${process.env.RSYS_HOST}/rest/api/v1.3/auth/token`,
          qs.stringify({
            user_name: process.env.RSYS_USERNAME,
            password: process.env.RSYS_PASSWORD,
            auth_type: 'password',
          })
        )
      return response.data;
    } catch (e) {
      console.log(e);
      // this.client.instance().captureException(e);
    }
    return null;
  }
}
