import pg from 'pg';
import { Session } from '@shopify/shopify-api';
import { SessionStorage } from '@shopify/shopify-app-session-storage';
import { ToolsLib } from './tools.lib';

export interface PostgreSQLSessionStorageOptions {
  sessionTableName: string;
  port: number;
}
const defaultPostgreSQLSessionStorageOptions: PostgreSQLSessionStorageOptions = {
  sessionTableName: 'shopify_sessions',
  port: 3211
};

export class PostgreSQLSessionStorage implements SessionStorage {
  static withCredentials(
    host: string,
    dbName: string,
    username: string,
    password: string,
    opts: Partial<PostgreSQLSessionStorageOptions>
  ) {
    return new PostgreSQLSessionStorage(
      new URL(
        `postgres://${encodeURIComponent(username)}:${encodeURIComponent(password)}@${host}/${encodeURIComponent(dbName)}`
      ),
      opts
    );
  }

  public readonly ready: Promise<void>;
  private options: PostgreSQLSessionStorageOptions;
  private client: pg.Client;

  constructor(
    private dbUrl: URL,
    opts: Partial<PostgreSQLSessionStorageOptions> = {}
  ) {
    if (typeof this.dbUrl === 'string') {
      this.dbUrl = new URL(this.dbUrl);
    }
    this.options = { ...defaultPostgreSQLSessionStorageOptions, ...opts };
    this.ready = this.init();
  }
  public async storeSession(session: Session): Promise<boolean> {
    await this.ready;
    // Note milliseconds to seconds conversion for `expires` property
    const entries = session.toPropertyArray().map(([key, value]) => {
      key = ToolsLib.camelToUnderline(key);
      return key === 'expires'
        ? [key, Math.floor((value as number) / 1000)]
        : key === 'online_access_info'
        ? [key, JSON.stringify(session.onlineAccessInfo?.associated_user || null)]
        : [key, value];
    });
    const query = `
      INSERT INTO ${this.options.sessionTableName}
      (${entries.map(([key]) => key).join(', ')})
      VALUES (${entries.map((_, i) => `$${i + 1}`).join(', ')})
      ON CONFLICT (id) DO UPDATE SET ${entries.map(([key]) => `${key} = Excluded.${key}`).join(', ')};
    `;
    await this.query(
      query,
      entries.map(([_key, value]) => value)
    );
    return true;
  }

  public async loadSession(id: string): Promise<Session | undefined> {
    await this.ready;
    const query = `
      SELECT * FROM ${this.options.sessionTableName}
      WHERE id = $1;
    `;
    const rows = await this.query(query, [id]);
    if (!Array.isArray(rows) || rows?.length !== 1) return undefined;
    const rawResult = rows[0] as any;
    return this.databaseRowToSession(rawResult);
  }

  public async deleteSession(id: string): Promise<boolean> {
    await this.ready;
    const query = `
      DELETE FROM ${this.options.sessionTableName}
      WHERE id = $1;
    `;
    await this.query(query, [id]);
    return true;
  }

  public async deleteSessions(ids: string[]): Promise<boolean> {
    await this.ready;
    const query = `
      DELETE FROM ${this.options.sessionTableName}
      WHERE id IN (${ids.map((_, i) => `$${i + 1}`).join(', ')});
    `;
    await this.query(query, ids);
    return true;
  }

  public async findSessionsByShop(shop: string): Promise<Session[]> {
    await this.ready;

    const query = `
      SELECT * FROM ${this.options.sessionTableName}
      WHERE shop = $1;
    `;
    const rows = await this.query(query, [shop]);
    if (!Array.isArray(rows) || rows?.length === 0) return [];

    const results: Session[] = rows.map((row: any) => {
      return this.databaseRowToSession(row);
    });
    return results;
  }

  public disconnect(): Promise<void> {
    return this.client.end();
  }

  private async init() {
    this.client = new pg.Client({ connectionString: this.dbUrl.toString() });
    await this.connectClient();
    await this.createTable();
  }
  private async connectClient(): Promise<void> {
    await this.client.connect();
  }

  private async createTable() {
    const query = `
        CREATE TABLE IF NOT EXISTS ${this.options.sessionTableName} (
          id varchar(255) NOT NULL PRIMARY KEY,
          shop varchar(255) NOT NULL,
          state varchar(255) NOT NULL,
          is_online boolean NOT NULL,
          scope text,
          expires integer,
          online_access_info jsonb,
          access_token varchar(255)
        )
      `;
    await this.query(query);
  }
  async deleteAllOnlineSession() {
    return await this.query(`delete from ${this.options.sessionTableName} where is_online=true`);
  }
  private async query(sql: string, params: any[] = []): Promise<any> {
    const result = await this.client.query(sql, params);
    return result.rows;
  }

  private databaseRowToSession(row: any): Session {
    let newRow = {};
    for (let key in row) {
      newRow[ToolsLib.underlineToCamel(key)] = row[key];
    }
    row = newRow;
    // convert seconds to milliseconds prior to creating Session object
    if (row.expires) row.expires *= 1000;
    let result = Session.fromPropertyArray(Object.entries(row));
    result.onlineAccessInfo = row.onlineAccessInfo;
    return result;
  }
}
