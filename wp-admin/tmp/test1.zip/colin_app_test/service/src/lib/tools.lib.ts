import { validate } from 'class-validator';
import xlsx from 'node-xlsx';
import { Redis } from 'ioredis';
export class ToolsLib {
  // 延迟
  static async sleep(time: number) {
    return new Promise((resolve: any) => setTimeout(() => resolve(), time));
  }

  static formatErr(msg: string, code?: number) {
    return { msg, code: code ? code : 500 };
  }
  static async validateData(Dto: any, data: { [key: string]: any }) {
    let dto = new Dto();
    for (let key in data) {
      dto[key] = data[key];
    }
    let msg = {};
    let errorData = await validate(dto);
    if (errorData.length) {
      errorData.forEach(item => {
        msg[item.property] = Object.values(item.constraints);
      });
    }
    if (Object.keys(msg).length) {
      return msg;
    }
    return true;
  }
  /**
   *
   * @param str 将驼峰法更改为下划线
   * @returns
   */
  static camelToUnderline(str: string) {
    return str.replace(/([A-Z])/g, '_$1').toLowerCase();
  }
  /**
   *
   * @param str 将下划线更改为驼峰
   * @returns
   */
  static underlineToCamel(str: string) {
    return str.replace(/\_(\w)/g, (all, letter) => letter.toUpperCase());
  }
  static analysisExcelData(buffer: Buffer) {
    let workbook = xlsx.parse(buffer, { cellDates: true });
    let data: any[] = [];
    let sheet = workbook[0];
    let fields = sheet['data'][0];
    sheet['data'].forEach((item, index) => {
      if (index == 0) return;
      let itemVal: any = {};
      //之所以用for 是因为如果字段为空用forEach就不会遍历到
      if (!item[0] && !item[1]) {
        return true;
      }
      for (let i = 0; i < item.length; i++) {
        itemVal[fields[i]] = item[i];
      }
      data.push({ ...itemVal, status: { code: 0 } });
    });
    return data;
  }
  static async lock(redis: Redis, lockKey, seconds: number = 20 * 60) {
    return await redis.set(`setnx-${lockKey}`, 1, 'EX', seconds, 'NX');
  }
  static async unLock(redis: Redis, lockKey) {
    if (await redis.get('setnx-' + lockKey)) {
      await redis.del('setnx-' + lockKey);
    }
    return true;
  }
  static async clearCache(redis: Redis, cacheKeys: string[]) {
    let keys = Object.values(cacheKeys);
    for (let key of keys) {
      await ToolsLib.unLock(redis, key);
    }
  }
  static bytesToMB(bytes) {
    return (bytes / 1024 / 1024).toFixed(2);
  }
}
