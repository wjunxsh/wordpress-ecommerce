import { authenticatedFetch } from "@shopify/app-bridge-utils";
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import * as qs from "qs";
import { useContext } from "react";
import {DataContext} from '@components/providers/DataProvider'
/**
 * A hook that returns an auth-aware fetch function.
 * @desc The returned fetch function that matches the browser's fetch API
 * See: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
 * It will provide the following functionality:
 *
 * 1. Add a `X-Shopify-Access-Token` header to the request.
 * 2. Check response for `X-Shopify-API-Request-Failure-Reauthorize` header.
 * 3. Redirect the user to the reauthorization URL if the header is present.
 *
 * @returns {Function} fetch function
 */
export function useAuthenticatedFetch() {
  const app = useAppBridge();
  const shopDomain = useContext(DataContext);
  const fetchFunction = authenticatedFetch(app);
  
  return async (uri: string, options: any) => {
    if((!options.query || !options.query.shop) && shopDomain) {
      options.query = options.query ? {...options.query, shop:shopDomain} : {shop:shopDomain}
    }
    let url = paramUrl(uri, options.query);
    try {
      if (["POST", "PUT"].includes(options.method.toUpperCase())) {
        if (
          !options["headers"] ||
          options["headers"]["Content-Type"] === undefined
        ) {
          options["headers"] = { "Content-Type": "application/json" };
        }
      }
      if (options.body) {
        options.body = JSON.stringify(options.body);
      }
      const response = await fetchFunction(url, options);
      checkHeadersForReauthorization(response.headers, app);
      if (response.status != 200) {
        return Promise.reject({
          code: response.status || 500,
          msg: response.statusText || "Server error!",
        });
      } else {
        let data = await response.json();
        if (!data.code || data.code !== 200) {
          return Promise.reject({
            code: data.code || 500,
            msg: data.msg || "Server error!",
          });
        }
        return data.data;
      }
    } catch (e) {
      Promise.reject({ code: 500, msg: "Server error!" });
    }
  };
}
export function useAuthenticatedFetchUpload() {
  const app = useAppBridge();
  const fetchFunction = authenticatedFetch(app);
  return async (uri: string, options: any) => {
    let url = paramUrl(uri, options.query);
    try {
      const response = await fetchFunction(url, {...options,timeout: 300000});
      checkHeadersForReauthorization(response.headers, app);
      if (response.status != 200) {
        return Promise.reject({
          code: response.status || 500,
          msg: response.statusText || "Server error!",
        });
      } else {
        let data = await response.json();
        if (!data.code || data.code !== 200) {
          return Promise.reject({
            code: data.code || 500,
            msg: data.msg || "Server error!",
          });
        }
        return data.data;
      }
    } catch (e) {
      Promise.reject({ code: 500, msg: "Server error!" });
    }
  };
}

export function useAuthenticatedFetchDownload() {
  const app = useAppBridge();
  const fetchFunction = authenticatedFetch(app);
  return async (uri: string, options: any) => {
    options.responseType = "blob";
    let url = paramUrl(uri, options.query);
    try {
      if (options.body) {
        options.body = JSON.stringify(options.body);
      }
      const response = await fetchFunction(url, options);
      checkHeadersForReauthorization(response.headers, app);
      const contentDisposition = response.headers.get("content-disposition");
      const filename = contentDisposition
        ? (contentDisposition as any).match(/filename="(.+)"/)[1]
        : "";
      let blob = await response.blob();
      const file = new Blob([blob], {
        type: "application/vnd.ms-excel;charset=utf-8",
      });
      const objectUrl = URL.createObjectURL(file);
      const a: any = document.createElement("a");
      document.body.appendChild(a);
      a.style = "display: none";
      a.href = objectUrl;
      a.download = filename;
      a.click();
      window.URL.revokeObjectURL(objectUrl);
      document.body.removeChild(a);
    } catch (e) {
      Promise.reject({ code: 500, msg: "Server error!!" });
    }
  };
}
function checkHeadersForReauthorization(headers: any, app: any) {
  if (headers.get("X-Shopify-API-Request-Failure-Reauthorize") === "1") {
    const authUrlHeader =
      headers.get("X-Shopify-API-Request-Failure-Reauthorize-Url") ||
      `/api/auth`;
    const redirect = Redirect.create(app);
    console.log('sfasdfa=====', authUrlHeader);
    redirect.dispatch(
      Redirect.Action.REMOTE,
      authUrlHeader.startsWith("/")
        ? `https://${window.location.host}${authUrlHeader}`
        : authUrlHeader
    );
  }
}
function paramUrl(uri: string, query: any) {
  let params = "";
  if (query && Object.keys(query).length) {
    params += qs.stringify(query);
  }
  let url = uri;
  if (uri.indexOf("?") === -1) {
    url = uri + "?" + params;
  } else {
    url = uri + params;
  }
  return url;
}
