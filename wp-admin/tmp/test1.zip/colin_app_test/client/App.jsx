import { BrowserRouter, useLocation } from "react-router-dom";
import { NavigationMenu } from "@shopify/app-bridge-react";
import Routes from "./Routes";
import queryString from 'qs';
import {
  AppBridgeProvider,
  QueryProvider,
  PolarisProvider,
  DiscountProvider,
  DataProvider,
} from "./components";
import { useState } from "react";
export const extendValidation = (url) => {
  const extend = Object.fromEntries(new URLSearchParams(window.location.search))
  const link = typeof url === 'string'
      ? { pathname: url, query: {} }
      : { ...url, query: url.query || {} };
  if (extend.hmac) Object.assign(link.query, extend);
  const search = '?' + queryString.stringify(link.query);
  link.search = search;
  link.fullPath = link.pathname + search;
  return link;
};
export default function App() {
  // Any .tsx or .jsx files in /pages will become a route
  // See documentation for <Routes /> for more info
  const pages = import.meta.globEager("./pages/**/!(*.test.[jt]sx)*.([jt]sx)");
  return (
    <PolarisProvider>
      <BrowserRouter>
        <AppBridgeProvider>
        <DiscountProvider>
          <QueryProvider>
            <DataProvider>
            <NavigationMenu
              navigationLinks={[
                {
                  label: "裂变券活动列表",
                  destination: extendValidation("/bulk_code/list").fullPath,
                },
                {
                  label: "新增裂变券",
                  destination: extendValidation("/bulk_code/add").fullPath,
                },
                {
                  label: "批量导入折扣功能工具",
                  destination: extendValidation("/import_discount").fullPath,
                },
                {
                  label: "Edm发送邮件工具",
                  destination: extendValidation("/edm_tools").fullPath,
                },
                {
                  label: "Email发送邮件工具",
                  destination: extendValidation("/email_tools").fullPath,
                },
                {
                  label: "脚本活动管理",
                  destination: extendValidation("/script/promotions").fullPath,
                },
                {
                  label: "活动文案管理",
                  destination: extendValidation("/script/labels").fullPath,
                },
                {
                  label: "脚本功能管理",
                  destination: extendValidation("/script/functions").fullPath,
                },
              
              ]}
            />
            <Routes pages={pages} />
            </DataProvider>
          </QueryProvider>
          </DiscountProvider>
        </AppBridgeProvider>
      </BrowserRouter>
    </PolarisProvider>
  );
}
