import { defineConfig } from "vite";
import { dirname } from "path";
import { fileURLToPath } from "url";
import react from "@vitejs/plugin-react";
import dotenv from "dotenv"
import path from "path"
import vitePluginImp from 'vite-plugin-imp'
import { createStyleImportPlugin, AntdResolve } from 'vite-plugin-style-import'
dotenv.config({override:true})

if (
  process.env.npm_lifecycle_event === "build" &&
  !process.env.CI &&
  !process.env.SHOPIFY_API_KEY
) {
  console.warn(
    "\nBuilding the frontend app without an API key. The frontend build will not run without an API key. Set the SHOPIFY_API_KEY environment variable when running the build command.\n"
  );
}

const proxyOptions = {
  target: `http://127.0.0.1:${process.env.BACKEND_PORT}`,
  changeOrigin: false,
  secure: true,
  ws: false,
};

const host = process.env.HOST
  ? process.env.HOST.replace(/https?:\/\//, "")
  : "localhost";
let hmrConfig;
if (host === "localhost") {
  hmrConfig = {
    protocol: "ws",
    host: "localhost",
    port: 64999,
    clientPort: 64999,
  };
} else {
  hmrConfig = {
    protocol: "wss",
    host: host,
    clientPort: 443,
  };
}

export default defineConfig({
  resolve: {
    alias: {
      "@components": path.resolve(__dirname, "components"),
      "@hooks": path.resolve(__dirname, "hooks"),
      "@pages": path.resolve(__dirname, "pages"),
    }
  },
  root: dirname(fileURLToPath(import.meta.url)),
  plugins: [react(),
    vitePluginImp({
      libList: [
        {
          libName: "antd",
          style: (name) => `antd/es/${name}/style`,
        },
      ],
    }),
  //   createStyleImportPlugin({
  //     resolves: [AntdResolve()]
  //  })
  ],
  css: {
    preprocessorOptions: {
      less: {
        javascriptEnabled: true,
        modifyVars: {
          '@primary-color': '#4377FE',//设置antd主题色
        },
      },
    }
  },
  esbuild: {
    jsxInject: `import React from 'react'`,
  },
  define: {
    "process.env.SHOPIFY_API_KEY": JSON.stringify(process.env.SHOPIFY_API_KEY),
  },
  server: {
    host: "localhost",
    port: process.env.FRONTEND_PORT,
    hmr: {
      protocol: 'ws',
      host: 'localhost'
    },
    proxy: {
      "^/(\\?.*)?$": proxyOptions,
      "^/api(/|(\\?.*)?$)": proxyOptions,
      "^/out-api(/|(\\?.*)?$)": proxyOptions,
      "^/pos-extension-api(/|(\\?.*)?$)": proxyOptions,
    },
  },
});
