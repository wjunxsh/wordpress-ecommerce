import { Breadcrumb, Button, Col, Form, Row, Select, Table } from 'antd';
import { useEffect, useState } from 'react';
import { useForm } from 'antd/es/form/Form';
import { FunctionItem } from '@components/script/functions/interface';
import { Istate } from '@components/script/labels/interface';
import { Pagination } from '@components/common_interface';
import { tableColumns } from '@components/script/labels/columns';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
import ScriptLabelsEdit from '@components/script/labels/edit_labels';
import { Card, Layout, Page } from '@shopify/polaris';
import { onBreadcrumbAction } from '@shopify/discount-app-components';
import { Redirect } from '@shopify/app-bridge/actions';
import { useAppBridge } from '@shopify/app-bridge-react';
const ScriptLabelConfigsList = () => {
  const [funList, setFunctions] = useState<FunctionItem[]>([]);
  const authenticatedFetch = useAuthenticatedFetch();
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  const [state, setState] = useState<Istate>({
    refresh: 0,
    edit_visible: false,
    scriptList: [],
    scriptInfo: null,
  });
  useEffect(() => {
    getList();
    getFunctions();
  }, []);
  const scrollY = document.body.scrollHeight - 340;
  const getFunctions = async () => {
    try {
      let result = await authenticatedFetch('/api/functions/list', {
        method: 'get', query: { code_type: "common", current_page: 1, page_size: 1000 }
      });
      let FunctionList = result['list'];
      setFunctions(FunctionList);
    } catch (e) { }
  };
  const [pagination, setPagination] = useState<Pagination>({ current_page: 1, total_pages: 1, page_size: 20, total_size: 1 });
  useEffect(() => {
    getList();
  }, [pagination]);

  const [loading, setLoading] = useState<boolean>(false);
  const columns = tableColumns.map(item => {
    switch (item.dataIndex) {
      case 'operate':
        item.render = (id: number, record) => (
          <>
            <Button
              type='link'
              onClick={() => {
                setState({ ...state, scriptInfo: record, edit_visible: true });
              }}
              size='small'>
              编辑
            </Button>
          </>
        );
        break;
    }
    return item;
  });
  const getList = async () => {
    if (loading) {
      return;
    }
    setLoading(true);
    let formData = searchForm.getFieldsValue();
    try {

      let data = await authenticatedFetch('/api/script/label_config/list', {
        method: 'get',
        query: {
          current_page: pagination.current_page,
          page_size: pagination.page_size,
          shop_id: formData.shop_id?.value,
          function_key: formData?.function_key,
        }
      });
      pagination.current_page = data.pagination.current_page;
      pagination.page_size = data.pagination.page_size;
      pagination.total_pages = data.pagination.total_page;
      pagination.total_size = data.pagination.total_size;
      setPagination(pagination);
      setLoading(false);
      setState({ ...state, scriptList: data.list });
    } catch (e) {
      console.log(e)
      setLoading(false);
    }
  };
  const [searchForm] = useForm();
  return (
    <Page
      title="功能前端文案管理"
      breadcrumbs={[
        {
          content: "Discounts",
          onAction: () => onBreadcrumbAction(redirect, true),
        },
      ]}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <Card.Section>
              <div className=''>
                <div className='rounded bg-white mb-5 p-5 '>
                  <div className='' style={{ marginBottom: '8px' }}>
                    <Form form={searchForm}>
                      <Row gutter={[8, 8]}>
                        <Col span={6}>
                          <Form.Item style={{ marginBottom: "0px" }} name={'function_key'} label='函数'>
                            <Select allowClear size="middle" style={{ width: '100%' }} options={funList} />
                          </Form.Item>
                        </Col>
                        <Col span={10} >
                          <Button
                            type='primary'
                            size="middle"
                            onClick={() => {
                              setPagination({ ...pagination, current_page: 1 });
                            }}>
                            搜索
                          </Button>
                          <Button
                            style={{ marginLeft: '4px' }}
                            size="middle"
                            type='primary'
                            onClick={() => {
                              setState({ ...state, edit_visible: true });
                            }}>
                            新增
                          </Button>
                        </Col>
                      </Row>
                    </Form>
                  </div>
                </div>
                <div className='page-container'>
                  <Table
                    size={"small"}
                    scroll={{ x: 800, y: scrollY }}
                    rowKey={(record) => record.id}
                    pagination={{
                      showSizeChanger: true,
                      pageSizeOptions: [10, 20, 50],
                      onChange: (page, page_size) => {
                        setPagination({ ...pagination, current_page: page, page_size });
                      },
                      current: pagination.current_page,
                      pageSize: pagination.page_size,
                      total: pagination.total_size,
                    }}
                    loading={loading}
                    dataSource={state.scriptList}
                    columns={columns}></Table>
                </div>
                <ScriptLabelsEdit
                  info={state.scriptInfo}
                  onSuccess={() => {
                    setState({ ...state, edit_visible: false, scriptInfo: null });
                    setPagination({ ...pagination });
                  }}
                  onCancel={() => {
                    setState({ ...state, edit_visible: false, scriptInfo: null });
                  }}
                  visible={state.edit_visible}
                />
              </div>
            </Card.Section></Card></Layout.Section></Layout></Page>
  );
};
export default ScriptLabelConfigsList;
