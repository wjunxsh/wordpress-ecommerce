import { Pagination } from '@components/common_interface';
import { Breadcrumb, Button, Col, Form, Input, Modal, Row, Select, Table } from 'antd';
import { useEffect, useState } from 'react';
import { Highlight, themes } from 'prism-react-renderer';
import { EditProps, FunctionItem, Istate } from '@components/script/functions/interface';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
import { ColumnType } from 'antd/lib/table';
import { columns as totalColumns } from '@components/script/functions/columns';
import { FunctionEdit } from '@components/script/functions/function_edit';
import { onBreadcrumbAction } from '@shopify/discount-app-components';
import { Redirect } from '@shopify/app-bridge/actions';
import { useAppBridge } from '@shopify/app-bridge-react';
import { Card, Layout, Page } from '@shopify/polaris';
const FunctionList = () => {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  const [state, setState] = useState<Istate>({
    edit_info: null,
    edit_visible: false,
    funcList: [],
    show_details: '',
    show_visible: false,
    show_code: '',
    show_code_visible: false,
  });
  const scrollY = document.body.scrollHeight - 340;
  useEffect(() => {
    getList();
  }, []);
  const [pagination, setPagination] = useState<Pagination>({ current_page: 1, total_pages: 1, page_size: 20, total_size: 1 });
  useEffect(() => {
    getList();
  }, [pagination]);
  const authenticatedFetch = useAuthenticatedFetch();
  const [loading, setLoading] = useState<boolean>(false);
  const columns = totalColumns.map((item: ColumnType<FunctionItem>) => {
    switch (item.dataIndex) {
      case 'id':
        item.render = (id: number, record: FunctionItem) => (
          <>
            <Button type='link' onClick={() => editClick(record)} size='small'>
              编辑
            </Button>
          </>
        );
        break;
      case 'details':
        item.render = (id: number, record: FunctionItem) => (
          <>
            <Button size='small' type='link' onClick={() => setState({ ...state, show_visible: true, show_details: record.details })} >
              查看描述
            </Button>
          </>
        );
        break;
      case 'code':
        item.render = (id: number, record: FunctionItem) => (
          <>
            <Button type='link' size='small'  onClick={() => setState({ ...state, show_code_visible: true, show_code: record.code })} >
              查看代码
            </Button>
          </>
        );
        break;
    }
    return item;
  });
  const getList = async () => {
    if (loading) {
      return;
    }
    setLoading(true);
    let formData = searchForm.getFieldsValue();
    try {
      let data = await authenticatedFetch('/api/functions/list', {
        method: "get",
        query: {
          current_page: pagination.current_page,
          page_size: pagination.page_size,
          ...formData
        }
      });
      pagination.current_page = data.pagination.current_page;
      pagination.page_size = data.pagination.page_size;
      pagination.total_pages = data.pagination.total_page;
      pagination.total_size = data.pagination.total_size;
      console.log(data.list);
      setPagination(pagination);
      setLoading(false);
      setState({ ...state, funcList: data.list });
    } catch (e) {
      setLoading(false);
    }
  };
  const editClick = (record: FunctionItem) => {
    setState({ ...state, edit_visible: true, edit_info: record });
  };
  const editProps: EditProps = {
    info: state.edit_info,
    visible: state.edit_visible,
    onCancel: () => {
      setState({ ...state, edit_visible: false, edit_info: null });
    },
    onSuccess: () => {
      setState({ ...state, edit_visible: false, edit_info: null });
      setPagination({ ...pagination });
    },
  };
  const [searchForm] = Form.useForm();
  return (
    <Page
      title="脚本功能管理"
      breadcrumbs={[
        {
          content: "Discounts",
          onAction: () => onBreadcrumbAction(redirect, true),
        },
      ]}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <Card.Section>
              <div className='rounded bg-white mb-5 p-5 '>
                <div style={{ marginBottom: '12px' }}>
                  <Form form={searchForm} style={{ width: '100%' }}>
                    <Row gutter={[8, 0]}>
                      <Col span={6}>
                        <Form.Item name={'title'} style={{ marginBottom: '0px' }} label='函数名称'>
                          <Input allowClear style={{ width: '100%' }} placeholder='' />
                        </Form.Item>
                      </Col>
                      <Col span={6}>
                        <Form.Item name={'code_type'} style={{ marginBottom: '0px' }} label='函数类型'>
                          <Select allowClear options={[{ label: '活动函数', value: 'common' }, { label: '店铺私有代码', value: 'shop_self' }, { label: '公共函数', value: 'util_common' }]} />
                        </Form.Item>
                      </Col>
                      <Col span={6}>
                        <Button
                          type='primary'
                          onClick={() => {
                            setPagination({ ...pagination, current_page: 1 });
                            setState({ ...state });
                          }}>
                          搜索
                        </Button>
                        <Button
                          style={{ marginLeft: '4px' }}
                          type='primary'
                          onClick={() => {
                            setState({ ...state, edit_visible: true });
                          }}>
                          新增
                        </Button>
                      </Col>
                    </Row>
                  </Form>
                </div>
              </div>

              <div className='page-container'>
                <Table
                  size="small"
                  scroll={{ x: 800, y: scrollY }}
                  pagination={{
                    showSizeChanger: true,
                    pageSizeOptions: [10, 20, 50],
                    onChange: (page, page_size) => {
                      setPagination({ ...pagination, current_page: page, page_size });
                    },
                    current: pagination.current_page,
                    pageSize: pagination.page_size,
                    total: pagination.total_size,
                  }}
                  loading={loading}
                  dataSource={state.funcList}
                  columns={columns}></Table>
              </div>
              <FunctionEdit {...editProps} />
              <Modal
                title={'函数详细描述'}
                cancelButtonProps={{ disabled: true, type: 'link' }}
                onCancel={() => {
                  setState({ ...state, show_visible: false, show_details: '' });
                }}
                onOk={() => {
                  setState({ ...state, show_visible: false, show_details: '' });
                }}
                okText={'关闭'}
                cancelText={' '}
                width={'80vw'}
                open={state.show_visible}>
                <div style={{ maxHeight: '500px', overflowY: 'scroll' }}>
                  <div className='ql-snow'>
                    <div className='ql-editor' dangerouslySetInnerHTML={{ __html: state.show_details }}></div>
                  </div>
                </div>
              </Modal>
              <Modal
                title={'代码详情'}
                cancelButtonProps={{ type: 'link', disabled: true }}
                onCancel={() => {
                  setState({ ...state, show_code_visible: false, show_code: '' });
                }}
                onOk={() => {
                  setState({ ...state, show_code_visible: false, show_code: '' });
                }}
                okText={'关闭'}
                cancelText={' '}
                width={'80vw'}
                open={state.show_code_visible}>
                <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                  <Highlight theme={themes.nightOwlLight} code={state.show_code} language='python'>
                    {({ className, style, tokens, getLineProps, getTokenProps }) => (
                      <pre className={className} style={style}>
                        {tokens.map((line, i) => (
                          <div {...getLineProps({ line, key: i })}>
                            {line.map((token, key) => (
                              <span {...getTokenProps({ token, key })} />
                            ))}
                          </div>
                        ))}
                      </pre>
                    )}
                  </Highlight>
                  {/* <Highlight>
                  {state.show_code || ""}
                </Highlight> */}
                </div>
              </Modal>
              {/* <Highlight>
                  {state.show_code || ""}
                </Highlight> */}
            </Card.Section>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
};
export default FunctionList;