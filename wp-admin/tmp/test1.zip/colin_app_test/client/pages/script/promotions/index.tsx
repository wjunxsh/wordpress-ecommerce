import { Breadcrumb, Button, Col, Form, Input, Row, Table, Modal, Dropdown, Select, Tag } from 'antd';
import { ColumnType } from 'antd/lib/table';
import { useCallback, useEffect, useRef, useState } from 'react';
import { columns as tableColumns } from '@components/script/promotions/columns';
import BuyMainSendGiftEdit from '@components/script/promotions/templates/buy_main_send_gift';
import { EditProps, DiscountItem, Istate } from '@components/script/promotions/interface';
import SelectFunctionModal from '@components/script/promotions/select_function';
import BundleSuiteSaleEdit from '@components/script/promotions/templates/bundle_suite_sale';
import { useForm } from 'antd/es/form/Form';
import BuyEnoughSendGiftEdit from '@components/script/promotions/templates/buy_enough_send_gift';
import './style.less';
import LevelManLiJianEdit from '@components/script/promotions/templates/level_man_li_jian';
import CreateScriptsModal from '@components/script/codes/create_scripts';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import update from 'immutability-helper';
import ProductBundleSuiteSaleEdit from '@components/script/promotions/templates/product_bundle_suite_sale';
import LogsModal from '@components/script/promotions/discount_log_modal';
import PriceDropEdit from '@components/script/promotions/templates/product_price_drop';
import QuantityLevelDiscountEdit from '@components/script/promotions/templates/quantity_level_discount';
import { Pagination } from '@components/common_interface';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
import { Card, Layout, Page } from '@shopify/polaris';
import { onBreadcrumbAction } from '@shopify/discount-app-components';
import { useAppBridge } from '@shopify/app-bridge-react';
import { Redirect } from '@shopify/app-bridge/actions';
import { campaignState, judgements } from '@components/script/simple_data';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import EveryManLiJianEdit from '@components/script/promotions/templates/every_man_li_jian';
import BuyMoreThanOneDiscountEdit from '@components/script/promotions/templates/buy_more_than_one_discount';
import { VarintSelect } from '@components/common/variant_select';
import PackSalesEdit from '@components/script/promotions/templates/pack_sales';
dayjs.extend(utc);
dayjs.extend(timezone);
const { confirm } = Modal;
interface DraggableBodyRowProps extends React.HTMLAttributes<HTMLTableRowElement> {
  index: number;
  moveRow: (dragIndex: number, hoverIndex: number) => void;
}

const type = 'DraggableBodyRow';
const DraggableBodyRow = ({ index, moveRow, className, style, ...restProps }: DraggableBodyRowProps) => {
  const ref = useRef<HTMLTableRowElement>(null);
  const [{ isOver, dropClassName }, drop] = useDrop({
    accept: type,
    collect: (monitor) => {
      const { index: dragIndex } = monitor.getItem() || {};
      if (dragIndex === index) {
        return {};
      }
      return {
        isOver: monitor.isOver(),
        dropClassName: dragIndex < index ? ' drop-over-downward' : ' drop-over-upward',
      };
    },
    drop: (item: { index: number }) => {
      moveRow(item.index, index);
    },
  });
  const [, drag] = useDrag({
    type,
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });
  drop(drag(ref));

  return <tr ref={ref} className={`${className}${isOver ? dropClassName : ''}`} style={{ cursor: 'move', ...style }} {...restProps} />;
};
const editComponents: { [key: string]: any } = {
  'dd5bf48a-2fc4-4db7-a17a-a9a6e672f865': BuyMainSendGiftEdit,
  'f8a8fe72-7643-4b6d-9f03-7c8794e4ae2b': BundleSuiteSaleEdit,
  'b4d5ebd5-936e-4795-bbf7-673c07d97947': BuyEnoughSendGiftEdit,
  '36bf72bf-3fb6-4f05-8916-b42810f2718f': QuantityLevelDiscountEdit,
  '94ee915b-038f-4015-b110-2070c8a04805': LevelManLiJianEdit,
  '8f8da1fa-a169-4446-b635-d331e63a0c06': ProductBundleSuiteSaleEdit,
  '3293e534-628d-4395-b495-63dd0e48035a': PriceDropEdit,
  '13eb1103-f68e-4639-8aa2-4f1b701cf5fb': EveryManLiJianEdit,
  'b4846a0f-4b70-4c75-bd08-f22b3bfdc7c1': BuyMoreThanOneDiscountEdit,
  'd01ee379-17b5-484d-9893-315ef04bf3a8': PackSalesEdit,
};
const DiscountList = () => {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  const [state, setState] = useState<Istate<any>>({
    edit_info: null,
    edit_func_key: '',
    edit_visible: false,
    func_visible: false,
    script_visible: false,
    logRecord: null,
    time_zone:'',
    funcList: [],
  });
  const authenticatedFetch = useAuthenticatedFetch();
  const scrollY = document.body.scrollHeight - 340;
  const [copyInfo, setCopy] = useState<{ copy_visible: boolean }>({ copy_visible: false });
  useEffect(() => {
    getList();
  }, []);
  const [pagination, setPagination] = useState<Pagination>({ current_page: 1, total_pages: 1, page_size: 10, total_size: 1 });
  useEffect(() => {
    getList();
  }, [pagination]);
  const [loading, setLoading] = useState<boolean>(false);
  const changeState = async (record: any) => {
    if (loading) {
      return;
    }
    setLoading(true);
    try {
      await authenticatedFetch('/api/script/discount/change_state', {
        method: 'post',
        body: {
          id: record.id,
        }
      });
      setLoading(false);
      setPagination({ ...pagination });
      setCopy({ copy_visible: true });
    } catch (e) {
      setLoading(false);
      console.log(e);
    }

  };
  const editLogs = (record: DiscountItem<any>) => {
    setState({ ...state, logRecord: record });
  }
  const columns = tableColumns.map((item: ColumnType<DiscountItem<any>>) => {
    switch (item.dataIndex) {
      case 'handle':
        item.render = (id: number, record: DiscountItem<any>) => (
          <>
            <Dropdown.Button size="small" type="primary"
              menu={{
                items: [
                  {
                    label: '复制',
                    key: '1',
                    icon: null,

                    onClick: () => copyClick(record),
                  },
                  {
                    label: '删除',
                    key: '2',
                    icon: null,
                    onClick: () => removeClick(record),
                  },
                  {
                    label: record.state == 'active' ? '取消活动' : '激活活动',
                    key: '3',
                    icon: null,
                    onClick: () => changeState(record),
                  },
                  {
                    label: '修改日志',
                    key: '4',
                    icon: null,
                    onClick: () => editLogs(record),
                  },

                ]
              }}
              onClick={() => editClick(record)}>
              编辑
            </Dropdown.Button>
          </>
        );
        break;
        case 'ends_at':
          item.render = (ends_at: string, record: DiscountItem<any>) => ends_at ? dayjs(ends_at).tz(state.time_zone).format('YYYY-MM-DD HH:mm:ss') : <Tag color="magenta">Permanent</Tag>
          break;
    }
    return item;
  });
  const getList = async () => {
    if (loading) {
      return;
    }
    setLoading(true);
    let formData = searchForm.getFieldsValue();
    try {
      let data = await authenticatedFetch('/api/script/discount/list', {
        method: 'get',
        query: {
          current_page: pagination.current_page,
          page_size: pagination.page_size,
          ...formData,
        }
      });
      pagination.current_page = data.pagination.current_page;
      pagination.page_size = data.pagination.page_size;
      pagination.total_pages = data.pagination.total_page;
      pagination.total_size = data.pagination.total_size;
      setPagination(pagination);
      setLoading(false);
      setState({ ...state, funcList: data.list,time_zone:data.time_zone || '' });
    } catch (e) {
      setLoading(false);
    }
  };
  const components = {
    body: {
      row: DraggableBodyRow,
    },
  };
  const moveRow = useCallback(
    async (dragIndex: number, hoverIndex: number) => {
      const dragRow = state.funcList[dragIndex];
      setState({
        ...state,
        funcList: update(state.funcList as any, {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, dragRow],
          ],
        }),
      });
      //调整两个活动之间的所有活动的sort值，起到后台更改的作用
      await sort(state.funcList[dragIndex]['id'], state.funcList[hoverIndex]['id']);
    },
    [state.funcList]
  );
  const sort = useCallback(
    async (sourceDiscountId: number, targetDiscountId: number) => {
      try {
        await authenticatedFetch('/api/script/discount/sort', {
          method: 'post',
          body: {
            source_id: sourceDiscountId,
            target_id: targetDiscountId,
          }
        });
        setPagination({ ...pagination });
      } catch (e) {
        console.log(e);
      }
    },
    [state.funcList]
  );
  const editClick = (record: DiscountItem<any>) => {
    setState({ ...state, edit_visible: true, edit_info: record, edit_func_key: record.function_id });
  };
  const copyClick = (record: DiscountItem<any>) => {
    setState({ ...state, edit_visible: true, edit_info: { ...record, id: 0 }, edit_func_key: record.function_id });
  };
  const removeClick = async (record: DiscountItem<any>) => {
    if (loading) {
      return;
    }
    confirm({
      title: 'Warn!',
      content: '删除后将不能恢复，确定需要删除吗?',
      okText: '确定',
      cancelText: '放弃',
      async onOk() {
        setLoading(true);
        try {
          await authenticatedFetch('/api/script/discount/delete', {
            method: 'post',
            body: {
              id: record.id,
            }
          });
          setPagination({ ...pagination });
          setLoading(false);
          setCopy({ copy_visible: true });
        } catch (e) {
          setLoading(false);
        }
      },
    });
  };
  const editProps: EditProps<any> = {
    info: state.edit_info,
    visible: state.edit_visible,
    timeZone:state.time_zone,
    onCancel: () => {
      setState({ ...state, edit_visible: false, edit_info: null });
    },
    onSuccess: (discountInfo: DiscountItem<any>) => {
      setState({ ...state, edit_visible: false, edit_info: null });
      setPagination({ ...pagination });
      setTimeout(() => {
        setCopy({ copy_visible: true });
      }, 100);
    },
  };
  const EditComponent = state.edit_func_key && editComponents[state.edit_func_key] ? editComponents[state.edit_func_key] : null;
  const [searchForm] = useForm();
  return (<Page
    title="脚本活动管理"
    breadcrumbs={[
      {
        content: "Discounts",
        onAction: () => onBreadcrumbAction(redirect, true),
      },
    ]}
  >
    <Form>
    <Form.Item name='tst' initialValue={[]}>
      {/* <VarintSelect/> */}
    </Form.Item>
    </Form>
    <Layout>
      <Layout.Section>
        <Card>
          <Card.Section>
            <div className='rounded bg-white mb-5 p-5'>
              <div className='' style={{ marginBottom: '12px' }}>
                <Form initialValues={{
        price: {
          number: 0,
          currency: 'rmb',
        },
      }} form={searchForm} style={{ width: '100%' }}>
                  <Row gutter={[8, 8]}>
                    <Col span={12} md={8}>
                      <Form.Item name={'title'} style={{ marginBottom: '0px' }} label='活动标题'>
                        <Input size='middle' style={{ width: '100%' }} placeholder='活动标题' />
                      </Form.Item>
                    </Col>
                    <Col span={12} md={8} >
                      <Form.Item initialValue={''} name={'state'} style={{ marginBottom: '0px' }} label='活动状态'>
                        <Select options={campaignState} />
                      </Form.Item>
                    </Col>
                    <Col span={24} md={8} >
                      <Button
                        size='middle'
                        type='primary'
                        onClick={() => {
                          setPagination({ ...pagination, current_page: 1 });
                          setState({ ...state });
                        }}>
                        搜索
                      </Button>
                      <Button
                        size='middle'
                        style={{ marginLeft: '4px' }}
                        type='primary'
                        onClick={() => {
                          setState({ ...state, func_visible: true });
                        }}>
                        新增
                      </Button>
                      <Button
                        style={{ marginLeft: '4px' }}
                        type="primary"
                        onClick={() => setCopy({ copy_visible: true })}
                        size='middle'>
                        查看代码
                      </Button>
                    </Col>
                  </Row>
                </Form>
              </div>
            </div>
            <div className='page-container'>
              <DndProvider backend={HTML5Backend}>
                <Table
                  size="small"
                  components={components}
                  onRow={(_, index) => {
                    const attr = {
                      index,
                      moveRow,
                    };
                    return attr as React.HTMLAttributes<any>;
                  }}
                  rowKey={(record) => record.id}
                  scroll={{ x: 800, y: scrollY }}
                  loading={loading}
                  dataSource={state.funcList}
                  pagination={{
                    showSizeChanger: true,
                    pageSizeOptions: [10, 20, 50],
                    onChange: (page, page_size) => {
                      setPagination({ ...pagination, current_page: page, page_size });
                    },
                    current: pagination.current_page,
                    pageSize: pagination.page_size,
                    total: pagination.total_size,
                  }}
                  columns={columns}></Table>
              </DndProvider>
            </div>
            {EditComponent ? <EditComponent {...editProps} /> : null}
            <SelectFunctionModal
              visible={state.func_visible}
              onCancel={() => {
                setState({ ...state, func_visible: false });
              }}
              onOk={(value) => {
                console.log('edit-', value);
                setState({ ...state, edit_func_key: value, edit_visible: true, func_visible: false });
              }}
            />
            <CreateScriptsModal
              onCancel={() => {
                setCopy({ ...copyInfo, copy_visible: false });
              }}
              visible={copyInfo.copy_visible}
            />
            <LogsModal record={state.logRecord} onCancel={() => { setState({ ...state, logRecord: null }) }} />
          </Card.Section>
        </Card>
      </Layout.Section>
    </Layout>
  </Page>
  );
};
export default DiscountList;
