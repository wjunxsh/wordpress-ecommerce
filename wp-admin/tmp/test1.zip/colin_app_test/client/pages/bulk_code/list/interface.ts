export interface Item {
  id: number;
  title: string;
  is_birthday: boolean;
  code_quantity: number;
  shopify_id: number;
  is_loading:boolean;
}
export interface Pagination {
  total_pages: number;
  current_page: number;
  total_sizes: number;
  page_size: number;
}
export interface Istate {
  [key:string]: any;
  filter: string;
  list: Item[];
  visible: boolean;
  auto_increment_code:'true' | 'false';
  sort_by: string;
  type: string;
  mVisible: boolean;
  rLoading: boolean;
  codes_str: string;
  counts: string;
  random_length: string;
  suffix: string;
  cLoading: boolean;
  prefix: string;
  character_type:string;
  edit_id: number;
  pagination: Pagination;
  is_consult: boolean;
}
