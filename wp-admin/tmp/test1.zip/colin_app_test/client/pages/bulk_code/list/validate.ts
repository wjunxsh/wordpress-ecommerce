import { Istate } from "./interface";

export interface Error {
  [key: string]: "";
}
export interface RulePrice {
  [key: string]: any;
}
export interface ValidateRules {
  [key:string]: { type: string };
}
export const validateRules: ValidateRules = {
  counts: {
    type: "number",
  },
  random_length: {
    type: "number",
  },
};

export const validateCodes = (data: Istate) => {
  let error: { [key: string]: string } = {};
  if (data.type == "manual") {
    if (!data.codes_str) {
      error["codes_str"] = "Manual codes can not be blank!";
    }
  } else {
    if (!data.counts) {
      error["counts"] = "The codes quantity can not be blank!";
    }
    if (!data.random_length) {
      error["random_length"] = "The random length can not be blank!";
    }
  }
  return error;
};

export const afterInputValidate = (rule: any, value: any, oldValue: any) => {
  for (let key in rule) {
    if (key == "type" && rule[key] === "number" && !intRegs.test(value)) {
      return oldValue;
    }
    if (key == "max" && rule[key] < parseInt(value)) {
      return rule[key];
    }
    if (key == "min" && rule[key] > parseInt(value)) {
      return rule[key];
    }
  }
  return value;
};
export const onBlurValidate = (rule: any, value: any) => {
  for (let key in rule) {
    if (key == "type" && rule[key] === "numeric") {
      if (floatRegs.test(value) || intRegs.test(value)) {
        return value;
      } else {
        return "";
      }
    }
  }
};
export const floatRegs = /^(\d+)(\.\d+)?$/;
export const intRegs = /^(\d+)?$/;
const isMoreThanZeroNumber = (value: string) => {
  return intRegs.test(value) && parseInt(value) != 0;
};
const isMoreThanZeroNumeric = (value: string) => {
  return floatRegs.test(value) && parseFloat(value) != 0;
};
