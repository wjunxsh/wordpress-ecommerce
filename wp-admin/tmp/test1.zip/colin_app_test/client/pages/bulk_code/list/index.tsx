import React, { useCallback, useEffect, useRef, useState } from "react";
import { Redirect } from "@shopify/app-bridge/actions";
import {
  Card,
  Layout,
  Page,
  Pagination,
  ResourceList,
  ResourceItem,
  Stack,
  TextField,
  TextStyle,
  Button,
  FormLayout,
  ChoiceList,
  EmptyState,
  Frame,
  Icon,
  Modal,
  Select,
  Tag,
  TextContainer,
  Banner,
} from "@shopify/polaris";
import { SearchMajor, RefreshMajor } from "@shopify/polaris-icons";
import { useNavigate } from "react-router-dom";
import { useAuthenticatedFetch } from "../../../hooks";
import { Drawer, Space, Alert } from "antd";
import { Istate, Item } from "./interface";
import { afterInputValidate, validateCodes, validateRules } from "./validate";
let timeHandle: any = null;
let intervalHandle: any = null;
import "./style.less";
import { SearchCode } from "../../../components/discount/search-code";
import { useAuthenticatedFetchDownload } from "../../../hooks/useAuthenticatedFetch";
import { message } from "antd";
import { useAppBridge } from "@shopify/app-bridge-react";
const BulkCodeList = () => {
  const [selectValues, setSelected] = useState<string[] | "All">([]);
  const [state, setState] = useState<Istate>({
    filter: "",
    list: [1, 2].map((item) => ({
      id: item,
      is_loading: false,
      title: "",
      code_quantity: 0,
      shopify_id: 0,
      is_birthday: false,
    })),
    auto_increment_code: "false",
    visible: false,
    sort_by: "id:desc",
    type: "auto",
    codes_str: "",
    counts: "",
    random_length: "",
    suffix: "",
    prefix: "",
    character_type: "",
    cLoading: false,
    edit_id: 0,
    pagination: {
      page_size: 50,
      total_pages: 1,
      current_page: 1,
      total_sizes: 1,
    },
    rLoading: false,
    mVisible: false,
    is_consult: false,
  });
  const [loading, setLoading] = useState(false);
  const [errData, setErrorData] = useState<any>({});
  const [errArrData, setErrorArrData] = useState<String[]>([]);
  const navigate = useNavigate();
  const [reList, setReList] = useState<number>(0);
  const authenticatedFetch = useAuthenticatedFetch();
  const interval = () => {
    if (!listRef.current.length) return;
    let isLoading = listRef.current.some((item) => item.is_loading);
    if (isLoading) {
      setReList(new Date().getTime());
    }
  };
  const listRef = useRef(state.list);
  useEffect(() => {
    listRef.current = state.list;
  }, [state.list]);
  useEffect(() => {
    getList();
    let id = setInterval(() => {
      interval();
    }, 3000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    if (timeHandle) {
      clearTimeout(timeHandle);
    }
    timeHandle = setTimeout(() => {
      getList();
    }, 300);
  }, [state.filter]);
  useEffect(() => {
    getList();
  }, [reList, state.sort_by, state.pagination.current_page]);

  const stateChange = (key: string, value: any) => {
    let newState = { ...state };
    if (validateRules[key]) {
      value = afterInputValidate(validateRules[key], value, state[key]);
    }
    if (key == "sort_by") {
      newState["pagination"] = { ...state.pagination, current_page: 1 };
    }
    newState[key] = value;
    setState(newState);
  };
  const onFilter = (key: string, value: string) => {
    let newState = { ...state };
    newState["pagination"] = { ...state.pagination, current_page: 1 };
    newState[key] = value;
    setState(newState);
  };

  const getList = async () => {
    if (loading) return;
    setLoading(true);
    try {
      let data = await authenticatedFetch("/api/bulk_code/list", {
        method: "get",
        query: {
          search: state.filter,
          current_page: state.pagination.current_page,
          page_size: state.pagination.page_size,
          sort_by: state.sort_by,
        },
      });
      if (data === undefined) {
        return false;
      }
      setState({ ...state, list: data.list, pagination: data.pagination });
    } catch (e) { }
    setLoading(false);
  };
  const onSave = async () => {
    let codeErrorData = validateCodes(state);
    if (Object.keys(codeErrorData).length) {
      setErrorData(codeErrorData);
      setErrorArrData(Object.values(codeErrorData));
      return false;
    }
    setState({ ...state, cLoading: true });
    let codes: string[] = [];
    if (state.type == "manual") {
      codes = state.codes_str.split("\n");
      codes = [...new Set(codes)];
    }
    try {
      await authenticatedFetch("/api/bulk/code", {
        method: "put",
        body: {
          suffix: state.suffix || '',
          prefix: state.prefix || '',
          codes: codes,
          type: state.type,
          random_length: parseInt(`${state.random_length}`),
          counts: parseInt(`${state.counts}`),
          character_type: state.character_type,
          auto_increment_code: state.auto_increment_code === 'true' || false,
        },
        query: {
          discount_id: state.edit_id,
        },
      });
      setState({ ...state, visible: false, cLoading: false });
      setErrorArrData([]);
      setErrorData([]);
      setReList(new Date().getTime());
    } catch (e: any) {
      setState({ ...state, cLoading: false });
      let msgArr: string[] = [];
      Object.values(e.msg as string[][]).forEach((item: string[]) => {
        msgArr = [...msgArr, ...item];
      });
      setErrorArrData(msgArr);
    }
  };
  const onAddCodes = async (id: number) => {
    if (loading) {
      return;
    }
    setLoading(true);
    try {
      let data = await authenticatedFetch("/api/bulk_code/setting", {
        method: "get",
        query: { discount_id: id },
      });
      let info = data.info;
      setState({
        ...state,
        ...{
          prefix: info.prefix,
          suffix: info.suffix,
          random_length: info.random_length,
          counts: info.counts,
          edit_id: id,
          auto_increment_code: info.auto_increment_code ? "true" : "false",
          character_type: info.character_type,
        },
        visible: true,
      });
      
      setErrorArrData([]);
      setErrorData([]);
    } catch (e) {
      console.log(e);
    }

    setLoading(false);
    //获取discount 最后一次设置的规则
  };
  const deleteDiscount = async () => {
    setState({ ...state, rLoading: true });
    try {
      let result = await authenticatedFetch("/api/bulk_code/delete", {
        method: "delete",
        query: { id: selectValues },
      });
      setState({ ...state, rLoading: false, mVisible: false });
      setReList(new Date().getTime());
    } catch (e: any) {
      setState({ ...state, rLoading: false, mVisible: false });
      message.error(e.msg || e.message);
    }
  };
  const addDiscount = () => {
    navigate("/bulk_code/add");
  };
  return (
    <div>
      <Page>
        <Frame
          topBar={
            <div className="list-top">
              <Stack alignment="center" wrap={false} spacing="loose">
                <Stack.Item fill>
                  <TextStyle variation="strong">
                    <span style={{ fontSize: "16px" }}>Discount List</span>
                  </TextStyle>
                </Stack.Item>
                <Stack.Item>
                  <Button
                    primary
                    onClick={() => {
                      addDiscount();
                    }}
                  >
                    Add Discount set
                  </Button>
                </Stack.Item>
                <Stack.Item></Stack.Item>
              </Stack>
            </div>
          }
        >
          <Layout>
            <Layout.Section>
              <Card>
                <ResourceList
                  items={state.list}
                  emptyState={
                    <EmptyState
                      heading="There no Discount"
                      action={{
                        content: "Add Discount",
                        onAction: addDiscount,
                      }}
                      image={''}
                    ></EmptyState>
                  }
                  renderItem={(item, id, index) => (
                    <RenderItem
                      data={item}
                      onAddCodes={() => {
                        onAddCodes(item.id);
                      }}
                    />
                  )}
                  selectable={true}
                  showHeader={true}
                  loading={loading}
                  totalItemsCount={state.pagination.total_sizes}
                  filterControl={
                    <Stack alignment="center" wrap={false} spacing="loose">
                      <Stack.Item fill>
                        <FilterControl
                          disabled={loading}
                          value={state.filter}
                          onChange={onFilter}
                        />
                      </Stack.Item>
                      <Stack.Item>
                        <Button
                          onClick={() => {
                            setReList(new Date().getTime());
                          }}
                          icon={RefreshMajor}
                        ></Button>
                      </Stack.Item>
                    </Stack>
                  }
                  selectedItems={selectValues}
                  onSelectionChange={(values) => {
                    setSelected(values);
                  }}
                  sortValue={state.sort_by}
                  promotedBulkActions={[
                    {
                      content: "Delete Discount Bulk",
                      onAction: () => {
                        setState({ ...state, mVisible: true });
                      },
                    },
                  ]}
                  sortOptions={[
                    { label: "Oldest", value: "id:asc" },
                    { label: "Newest", value: "id:desc" },
                    { label: "Title(a-z)", value: "title:asc" },
                    { label: "Title(z-a)", value: "title:desc" },
                  ]}
                  onSortChange={(selected) => {
                    stateChange("sort_by", selected);
                  }}
                  resourceName={{
                    singular: "discount",
                    plural: "Discounts",
                  }}
                />
                <Card.Section>
                  <Stack distribution="center" alignment="center">
                    <Stack.Item>
                      {loading ? null : (
                        <Pagination
                          hasPrevious={state.pagination.current_page > 1}
                          onPrevious={() => {
                            setState({
                              ...state,
                              pagination: {
                                ...state.pagination,
                                current_page: state.pagination.current_page - 1,
                              },
                            });
                          }}
                          hasNext={
                            state.pagination.total_pages >
                            state.pagination.current_page
                          }
                          onNext={() => {
                            setState({
                              ...state,
                              pagination: {
                                ...state.pagination,
                                current_page: state.pagination.current_page + 1,
                              },
                            });
                          }}
                        />
                      )}
                    </Stack.Item>
                  </Stack>
                </Card.Section>
              </Card>
            </Layout.Section>
            <Layout.Section secondary>
              {/* <Card>
                <Card.Section>放置公司的其他app推荐广告</Card.Section>
              </Card> */}
              <SearchCode />
            </Layout.Section>
          </Layout>
          <div style={{ height: "300px" }}></div>
        </Frame>
      </Page>
      <Drawer
        title="Add Bulk Codes"
        placement={"right"}
        width={500}
        onClose={() => {
          !state.cLoading && setState({ ...state, visible: false });
        }}
        visible={state.visible}
        extra={
          <Space>
            <Button
              disabled={state.cLoading}
              onClick={() => {
                setState({ ...state, visible: false });
              }}
            >
              Cancel
            </Button>
            <Button loading={state.cLoading} primary onClick={() => onSave()}>
              OK
            </Button>
          </Space>
        }
      >
        <Card>
          {errArrData.length > 0 ? (
            <Card.Section>
              <Banner status="critical">
                <p>There were some issues with your form submission:</p>
                <ul>
                  {errArrData.map((message, index) => {
                    return <li key={`${index}`}>{message}</li>;
                  })}
                </ul>
              </Banner>
            </Card.Section>
          ) : null}
          <Card.Section>
            <FormLayout>
              <ChoiceList
                disabled={state.cLoading}
                title="The type of generating the codes"
                choices={[
                  { label: "Auto", value: "auto" },
                  { label: "Manual", value: "manual" },
                ]}
                selected={[state.type]}
                onChange={(value) => stateChange("type", value[0])}
              />
            </FormLayout>
            {state.type === "manual" ? (
              <FormLayout>
                <TextField
                  error={errData["codes_str"] || undefined}
                  label="Discount Codes"
                  onFocus={() => {
                    setErrorData({ ...errData, codes_str: null });
                  }}
                  value={state.codes_str || ''}
                  maxHeight={240}
                  onChange={(value) => {
                    stateChange("codes_str", value);
                  }}
                  multiline={4}
                  autoComplete="off"
                />
              </FormLayout>
            ) : (
              <FormLayout>
                <FormLayout.Group>
                  <TextField
                    label="Generate quantity"
                    type="text"
                    error={errData["counts"]}
                    disabled={state.cLoading}
                    onFocus={() => {
                      setErrorData({ ...errData, counts: null });
                    }}
                    value={`${state.counts || 0}`}
                    onChange={(value) => {
                      stateChange("counts", value);
                    }}
                    autoComplete="off"
                  />
                  <TextField
                    label="Code random length"
                    type="text"
                    onFocus={() => {
                      setErrorData({ ...errData, random_length: null });
                    }}
                    disabled={state.cLoading}
                    error={errData["random_length"]}
                    value={`${state.random_length || ''}`}
                    onChange={(value) => {
                      stateChange("random_length", value);
                    }}
                    autoComplete="off"
                  />
                </FormLayout.Group>
                <FormLayout.Group>
                  <TextField
                    label="Code prefix"
                    type="text"
                    autoComplete="off"
                    error={errData["prefix"]}
                    disabled={state.cLoading}
                    onFocus={() => {
                      setErrorData({ ...errData, prefix: null });
                    }}
                    value={state.prefix || ''}
                    onChange={(value) => {
                      stateChange("prefix", value);
                    }}
                  />
                  <TextField
                    label="Code suffix"
                    type="text"
                    error={errData["suffix"]}
                    onFocus={() => {
                      setErrorData({ ...errData, suffix: null });
                    }}
                    disabled={state.cLoading}
                    value={state.suffix || ''}
                    onChange={(value) => {
                      stateChange("suffix", value);
                    }}
                    autoComplete="off"
                  />
                  <ChoiceList
                    title={<b>Allowed characters</b>}
                    choices={[
                      { label: "Letters and numbers", value: "mix" },
                      { label: "Letters only", value: "letter" },
                      { label: "Numbers only", value: "number" },
                    ]}
                    selected={[state.character_type]}
                    onChange={(value) =>
                      stateChange("character_type", value[0])
                    }
                  />
                </FormLayout.Group>
                <FormLayout.Group>
                  <ChoiceList
                    title=""
                    allowMultiple
                    choices={[
                      {
                        label:
                          "Automatically increment when the unused quantity is insufficient",
                        value: "true",
                      },
                    ]}
                    selected={
                      state.auto_increment_code == "false"
                        ? []
                        : [state.auto_increment_code]
                    }
                    onChange={(value) =>
                      stateChange(
                        "auto_increment_code",
                        value.length ? value[0] : "false"
                      )
                    }
                  />
                </FormLayout.Group>
              </FormLayout>
            )}
          </Card.Section>
        </Card>
      </Drawer>
      <Modal
        title="Notice"
        onClose={() => {
          setState({ ...state, mVisible: false });
        }}
        primaryAction={{
          content: "Delete",
          loading: state.rLoading,
          onAction: () => {
            deleteDiscount();
          },
        }}
        secondaryActions={[
          {
            content: "Cancel",

            onAction: () => {
              setState({ ...state, mVisible: false });
            },
          },
        ]}
        open={state.mVisible}
      >
        <TextContainer>
          <div style={{ margin: "10px", fontSize: "16px" }}>
            Cound you Confirm removing the {selectValues.length}{" "}
            {selectValues.length > 1 ? "discounts" : "discount"}?
          </div>
        </TextContainer>
      </Modal>
    </div>
  );
};
const RenderItem = (props: { data: Item; onAddCodes: () => void }) => {
  const { data, onAddCodes } = props;
  const navigate = useNavigate();
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  const urlDetails = () => {
    redirect.dispatch(Redirect.Action.ADMIN_SECTION, {
      name: Redirect.ResourceType.Discount,
      resource: {
        id: `${data.shopify_id}`,
      },
    });
  };
  const authenticatedFetch = useAuthenticatedFetchDownload();
  const download = async () => {
    let result = await authenticatedFetch("/api/bulk_code/download", {
      method: "get",
      query: {
        discount_id: data.id,
      },
    });
  };
  return (
    <ResourceItem
      key={data.id}
      id={`${data.id}`}
      url={""}
      shortcutActions={[
        {
          content: "download codes",
          url: "",
          onAction: () => {
            download();
          },
        },
        { content: "View discount", url: "", onAction: () => urlDetails() },
        {
          content: "Add Bulk Code",
          url: "",
          onAction: () => {
            onAddCodes();
          },
        },
      ]}
      accessibilityLabel={`View details for ${data.title}`}
    >
      <Stack>
        <Stack.Item fill>
          <TextStyle variation="strong">
            {data.title + " "}
            {data.is_birthday ? (
              <Tag>
                <TextStyle variation="negative">Birthday</TextStyle>
              </Tag>
            ) : null}
          </TextStyle>
        </Stack.Item>
        <Stack.Item>
          <TextStyle variation="subdued">
            {data.is_loading ? (
              <Button loading plain></Button>
            ) : (
              <>
                {data.code_quantity} {data.code_quantity == 1 ? "code" : "codes"}
              </>
            )}
          </TextStyle>
        </Stack.Item>
      </Stack>
    </ResourceItem>
  );
};
const FilterControl = (props: {
  value: string;
  disabled: boolean;
  onChange: (key, value) => void;
}) => {
  const { value, onChange } = props;
  return (
    <TextField
      disabled={props.disabled}
      autoComplete="false"
      label=""
      placeholder="Filter the discount"
      prefix={<Icon source={SearchMajor} />}
      value={value}
      onChange={(value) => onChange("filter", value)}
    />
  );
};
export default BulkCodeList;
