import { Eligibility } from "@shopify/discount-app-components";
import { Istate } from "./interface";

export interface Error {
  [key: string]: "";
}
export interface RulePrice {
  [key: string]: any;
}
export const validateRules:any = {
  prerequisite_amount: {
    type: "number",
  },
  prerequisite_quantity: {
    type: "number",
  },
  code_effective_days: {
    type: "number",
  },
  entitled_quantity: {
    type: "number",
  },

  limited_amount: {
    type: "numeric",
  },

  limited_quantity: {
    type: "number",
  },

  usage_limit: {
    type: "number",
  },

  counts: {
    type: "number",
  },

  random_length: {
    type: "number",
  },
  percentage_value: {
    type: "number",
    max: 100,
    min: 1,
  },
  amount_value: {
    type: "numeric",
  },
  less_than_or_equal_to: {
    type: "numeric",
  },
};
export const validatePriceRule = (data: Istate): any => {
  let error:any = {};
  if (!data.title) {
    error["title"] = "Title can't be blank";
  }
  if(data.eligibility === Eligibility.CustomerSegments && data.customer_segment_prerequisite_ids.length == 0){
    error["customer_segment_prerequisite_ids"] = "Specific customer segments must be added";
  }else if(data.eligibility === Eligibility.Customers && data.prerequisite_customer_ids.length == 0){
    error["prerequisite_customer_ids"] = "Specific customers must be added";
  }
  if (data.target_type == "gift") {
    if (
      data.prerequisite_type == "collection" &&
      !data.prerequisite_collections.length
    ) {
      error["prerequisite_collections"] =
        "Specific collections must be added for Customer buys";
    }
    if (
      data.entitled_type == "collection" &&
      !data.entitled_collections.length
    ) {
      error["entitled_collections"] =
        "Specific collections must be added for Customer gets";
    }
    if (
      data.prerequisite_type == "product" &&
      !data.prerequisite_products.length
    ) {
      error["prerequisite_products"] =
        "Specific products must be added for Customer buys";
    }
    if (data.entitled_type == "product" && !data.entitled_products.length) {
      error["entitled_products"] =
        "Specific products must be added for Customer gets";
    }
    if (data.prerequisite_method == "quantity" && !data.prerequisite_quantity) {
      error["prerequisite_quantity"] =
        "Quantity for Customer buys can’t be blank";
    }
    if (data.prerequisite_method == "amount" && !data.prerequisite_amount) {
      error["prerequisite_amount"] = "Amount for Customer buys can’t be blank";
    }

    if (!data.entitled_quantity) {
      error["entitled_quantity"] = "Quantity for Customer gets can’t be blank";
    }

    if (
      data.is_allocation_limit.length &&
      !isMoreThanZeroNumber(data.prerequisite_quantity)
    ) {
      error["allocation_limit"] =
        "Maximum number of uses per order can’t be blank";
    }
  } else if (data.target_type == "product") {
    if (
      ["product", "variant"].includes(data.target_selection) &&
      !data.entitled_products.length
    ) {
      error["products"] = "Specific products must be added";
    } else if (
      ["collection"].includes(data.target_selection) &&
      !data.entitled_collections.length
    ) {
      error["products"] = "Specific collection must be added";
    }
  }else if (data.target_type == "shipping_line"){
    if(data.country_select == "1" && data.entitled_country_ids.length == 0){
      error["entitled_country_ids"] = "Specific countries must be added"
    }
    if(data.exclude_shipping == "1" && !isMoreThanZeroNumeric(data["less_than_or_equal_to"])){
      error["less_than_or_equal_to"] = "Shipping rate amount can’t be blank"
    }
  }
  if (data.discount_use_limit.includes("usage_limit")) {
    if (!isMoreThanZeroNumber(data["usage_limit"])) {
      error["usage_limit"] = "Total usage limit can’t be blank";
    }
  }
  if (data.active_limit == "limited_amount") {
    if (!isMoreThanZeroNumeric(data["limited_amount"])) {
      error["limited_amount"] = "Minimum purchase can’t be blank";
    }
  } else if (data.active_limit == "limited_quantity") {
    if (!isMoreThanZeroNumber(data["limited_quantity"])) {
      error["limited_quantity"] = "Minimum quantity can’t be blank";
    }
  }
  if(data.target_type != "shipping_line"){
    if (
      data.value_type == "percentage" &&
      !isMoreThanZeroNumber(data.percentage_value)
    ) {
      error["percentage_value"] = "Discount value can’t be blank";
    } else if (
      data.value_type == "fixed_amount" &&
      !isMoreThanZeroNumeric(data.amount_value)
    ) {
      error["amount_value"] = "Discount value can’t be blank";
    }
  }

  return error;
};

export const validateCodes = (data: Istate) => {
  let error:any = {};
  if (data.type == "manual") {
    if (!data.codes_str) {
      error["codes_str"] = "Manual codes can not be blank!";
    }
  } else {
    if (!data.counts) {
      error["counts"] = "The codes quantity can not be blank!";
    }
    if (!data.random_length) {
      error["random_length"] = "The random length can not be blank!";
    }
    if(data.character_type == 'number'  ) {
      if(Math.pow(10,parseInt(`${data.random_length}`) + 1) < data.counts) {
        error['random_length'] = `The Generate quantity can not create by ${data.random_length} of number!`;
      }
    }

  }
  return error;
};

export const afterInputValidate = (rule: any, value: any, oldValue: any) => {
  for (let key in rule) {
    if (key == "type" && rule[key] === "number" && !intRegs.test(value)) {
      return oldValue;
    }
    if (key == "max" && rule[key] < parseInt(value)) {
      return rule[key];
    }
    if (key == "min" && rule[key] > parseInt(value)) {
      return rule[key];
    }
  }
  return value;
};
export const onBlurValidate = (rule: any, value: any) => {
  for (let key in rule) {
    if (key == "type" && rule[key] === "numeric") {
      if (floatRegs.test(value) || intRegs.test(value)) {
        return value;
      } else {
        return "";
      }
    }
  }
};
export const floatRegs = /^(\d+)(\.\d+)?$/;
export const intRegs = /^(\d+)?$/;
const isMoreThanZeroNumber = (value:string) => {
  return value !== '' && intRegs.test(value) && parseInt(value) != 0;
};
const isMoreThanZeroNumeric = (value:string) => {
  return value !== '' && floatRegs.test(value) && parseFloat(value) != 0;
};
