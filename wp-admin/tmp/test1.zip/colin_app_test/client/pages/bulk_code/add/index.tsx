import {
  Badge,
  Banner,
  Button,
  ButtonGroup,
  Card,
  ChoiceList,
  FormLayout,
  Frame,
  Layout,
  Page,
  Select,
  Stack,
  TextField,
  TextStyle,
} from "@shopify/polaris";
import {
  ActiveDatesCard,
  CountriesAndRatesCard,
  Eligibility,
} from "@shopify/discount-app-components";
import { useAuthenticatedFetch } from "../../../hooks";
import React, { useCallback, useState } from "react";
import { useNavigate } from "@shopify/app-bridge-react";
import "./style.less";
import { ProductList } from "../../../components/discount/product-list";
import { CollectionList } from "../../../components/discount/collection-list";
import { Istate } from "./interface";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
dayjs.extend(utc);
dayjs.extend(timezone);
import {
  afterInputValidate,
  onBlurValidate,
  validateCodes,
  validatePriceRule,
  validateRules,
} from "./validate";
import { Summary } from "../../../components/discount/summary";
import { ResourceButton } from "../../../components/discount/ResourceButtton";
import { CountrySector } from "../../../components/discount/countrySector";
import CustomerCart from "../../../components/discount/customerCart";
const BulkCodeDiscountCreate = () => {
  const navigate = useNavigate();
  const [errData, setErrorData] = useState<{ [key: string]: any }>({});
  const [errArrData, setErrorArrData] = useState<String[]>([]);
  const [loading, setLoading] = useState(false);
  const [state, setState] = useState<Istate>({
    title: "",
    type: "auto",
    target_type: "shipping_line",
    codes: [],
    auto_increment_code: 'false',
    value_type: "percentage",
    counts: 0,
    suffix: "",
    prefix: "",
    target_selection: "all",
    percentage_value: "",
    amount_value: "",
    random_length: 6,
    codes_str: "",
    products: [],
    prerequisite_products: [],
    entitled_products: [],
    collections: [],
    prerequisite_collections: [],
    entitled_collections: [],
    active_limit: "",
    startDate: dayjs
      .tz(dayjs().format("YYYY-MM-DD HH:mm:ss"), "EST")
      .format("YYYY-MM-DD HH:mm:ssZZ"),
    endDate: null,
    discount_use_limit: [],
    usage_limit: "0",
    prerequisite_quantity: "",
    prerequisite_amount: 0,
    entitled_quantity: "",
    is_allocation_limit: [],
    allocation_limit: "", //买送的次数限制
    prerequisite_method: "quantity",
    prerequisite_type: "product",
    entitled_type: "product",
    is_edit: false,
    is_free: "0",
    character_type: "mix",
    entitled_country_ids: [],
    country_select: "0",
    eligibility: Eligibility.Everyone,
    prerequisite_customer_ids: [],
    customer_segment_prerequisite_ids: [],
    less_than_or_equal_to: "",
    exclude_shipping: "0",
  });
  const authenticatedFetch = useAuthenticatedFetch();
  const stateChange = (key: string, value: any) => {
    console.log(key,value);
    let newState = { ...state };
    if (validateRules[key]) {
      value = afterInputValidate(validateRules[key], value, state[key]);
    }
    newState["is_edit"] = true;
    newState[key] = value;
    if (key == "target_type" && value == "gift") {
      newState["value_type"] = "percentage";
      newState["percentage_value"] = "";
    }
    if (newState.target_type == "gift" && newState.percentage_value == "100") {
      newState["is_free"] = "1";
      newState["percentage_value"] = "";
    }
    setState(newState);
  };
  const getCodesInfo = () => {
    let codes: string[] = [];
    if (state.type == "manual") {
      codes = state.codes_str.split("\n");
      codes = [...new Set(codes)];
    }
    let codes_setting: any = {
      type: state.type,
      codes: state.type == "manual" ? codes : [],
      counts: parseInt(`${state.counts}`),
      suffix: state.suffix,
      random_length: parseInt(`${state.random_length}`),
      prefix: state.prefix,
      character_type: state.character_type,
    };
    return codes_setting;
  };
  const saveBulkData = async () => {
    await createPriceRule();
  };
  const deleteProducts = (key: string, index: number) => {
    let newState = { ...state };
    let products = newState[key];
    products.splice(index, 1);
    setState(newState);
  };
  const createPriceRule = async () => {
    let errData: any = validatePriceRule(state);
    let codeErrorData = validateCodes(state);
    errData = { ...errData, ...codeErrorData };
    if (Object.keys(errData).length) {
      setErrorData(errData);
      setErrorArrData(Object.values(errData));
      window.scrollTo(0, 0);
      return;
    } else {
      setErrorData({});
      setErrorArrData([]);
    }
    setLoading(true);
    let target_type =
      state.target_type == "shipping_line" ? "shipping_line" : "line_item";
    let target_selection = state.target_selection == "all" ? "all" : "entitled";
    if (state.target_type == "gift") {
      target_selection = "entitled";
    }
    let allocation_method = target_selection == "all" ? "across" : "each";
    if (state.target_type == "shipping_line") {
      target_selection = state.country_select == "0" ? "all" : "entitled";
      allocation_method = "each";
    }
    let priceRule: any = {
      title: state.title,
      auto_increment_code: state.auto_increment_code == 'true' || false,
      code_effective_days: state.code_effective_days || 0,
      target_type: target_type,
      target_selection: target_selection, //entitled
      allocation_method: allocation_method,
      value_type: state.value_type,
      value:
        state.value_type == "percentage"
          ? -state.percentage_value
          : -state.amount_value,
      starts_at: dayjs(state.startDate).tz("EST").format("YYYY-MM-DD HH:mm:ss"),
      ends_at: state.endDate
        ? dayjs(state.endDate).tz("EST").format("YYYY-MM-DD HH:mm:ss")
        : null,
      allocation_limit: state.is_allocation_limit.length
        ? state.allocation_limit
        : null,
      customer_selection:
        state.eligibility == Eligibility.Everyone ? "all" : "prerequisite",
      customer_segment_prerequisite_ids:
        state.eligibility == Eligibility.CustomerSegments
          ? state.customer_segment_prerequisite_ids
          : [],
      prerequisite_customer_ids:
        state.eligibility == Eligibility.Customers
          ? state.prerequisite_customer_ids
          : [],
    };
    if (state.target_type == "gift") {
      if (state.prerequisite_type == "collection") {
        priceRule.prerequisite_collection_ids =
          state.prerequisite_collections.map((collection) => {
            let tmpArr = collection.id.split("/");
            return tmpArr[tmpArr.length - 1];
          });
      } else if (state.prerequisite_type == "product") {
        priceRule.prerequisite_product_ids = state.prerequisite_products.map(
          (product) => {
            let tmpArr = product.id.split("/");
            return tmpArr[tmpArr.length - 1];
          }
        );
      } else {
        priceRule.prerequisite_variant_ids = [];
        state.prerequisite_products.forEach((product) => {
          product.variants.forEach((variant) => {
            let tmpArr = variant.id.split("/");
            priceRule.prerequisite_variant_ids.push(tmpArr[tmpArr.length - 1]);
          });
        });
      }

      if (state.entitled_type == "collection") {
        priceRule.entitled_collection_ids = state.entitled_collections.map(
          (collection) => {
            let tmpArr = collection.id.split("/");
            return tmpArr[tmpArr.length - 1];
          }
        );
      } else if (state.entitled_type == "product") {
        priceRule.entitled_product_ids = state.entitled_products.map(
          (product) => {
            let tmpArr = product.id.split("/");
            return tmpArr[tmpArr.length - 1];
          }
        );
      } else {
        priceRule.entitled_variant_ids = [];
        state.entitled_products.forEach((product) => {
          product.variants.forEach((variant) => {
            let tmpArr = variant.id.split("/");
            priceRule.entitled_variant_ids.push(tmpArr[tmpArr.length - 1]);
          });
        });
      }

      if (state.prerequisite_method == "amount") {
        priceRule.prerequisite_to_entitlement_purchase = {
          prerequisite_amount: state.prerequisite_amount,
        };
      } else {
        priceRule.prerequisite_to_entitlement_quantity_ratio = {
          prerequisite_quantity: state.prerequisite_quantity,
          entitled_quantity: state.entitled_quantity,
        };
      }
      if (state.is_free == "1") {
        priceRule.value = "-100";
        priceRule.value_type = "percentage";
      }
    } else if (state.target_type == "shipping_line") {
      priceRule.entitled_country_ids =
        state.country_select == "1"
          ? state.entitled_country_ids.map((item) => parseInt(item))
          : [];
      if (state.exclude_shipping == "1") {
        priceRule.prerequisite_subtotal_range = {
          greater_than_or_equal_to: state.greater_than_or_equal_to,
        };
      }
      priceRule.value = "-100";
      priceRule.value_type = "percentage";
    } else {
      if (state.target_selection == "collection") {
        priceRule.entitled_collection_ids = state.entitled_collections.map(
          (collection) => {
            let tmpArr = collection.id.split("/");
            return tmpArr[tmpArr.length - 1];
          }
        );
      } else if (state.target_selection == "product") {
        priceRule.entitled_product_ids = state.entitled_products.map(
          (product) => {
            let tmpArr = product.id.split("/");
            return tmpArr[tmpArr.length - 1];
          }
        );
      } else if (state.target_selection == "variant") {
        priceRule.entitled_variant_ids = [];
        state.entitled_products.forEach((product) => {
          product.variants.forEach((variant) => {
            let tmpArr = variant.id.split("/");
            priceRule.entitled_variant_ids.push(tmpArr[tmpArr.length - 1]);
          });
        });
      }
    }
    if (state.discount_use_limit.length) {
      if (state.discount_use_limit.includes("once_per_customer")) {
        priceRule.usage_limit = parseInt(state.usage_limit);
      }
      if (state.discount_use_limit.includes("usage_limit")) {
        priceRule.once_per_customer = true;
      }
    }
    if (state.target_type == "product") {
      if (state.active_limit == "limited_amount") {
        priceRule.prerequisite_subtotal_range = {
          greater_than_or_equal_to: state.limited_amount,
        };
      } else if (state.active_limit == "limited_quantity") {
        priceRule.prerequisite_quantity_range = {
          greater_than_or_equal_to: state.limited_quantity,
        };
      }
    }
    let data = { price_rule: priceRule, codes_setting: getCodesInfo() };
    try {
      await authenticatedFetch("/api/bulk/code", {
        method: "post",
        headers: { "Content-Type": "application/json" },
        body: data,
      });
      navigate("/bulk_code/list");
    } catch (e: any) {
      let msg: string[] = [];
      if (!e.msg || typeof e.msg == "string") {
        msg = [e.msg || e.message];
      } else {
        for (let key in e.msg) {
          e.msg[key].forEach((item: string) => {
            msg.push(key + " " + item);
          });
        }
      }
      setErrorArrData(msg);
    }
    setLoading(false);
  };
  const backClick = () => {
    window.history.go(-1);
  };
  return (
    <Page>
      <Frame
        topBar={
          <div className="list-top">
            <Stack alignment="center" wrap={false} spacing="loose">
              <Stack.Item fill>
                <Button onClick={backClick}>Back</Button>
              </Stack.Item>
              <Stack.Item>
                <ButtonGroup>
                  <Button
                    disabled={!state.is_edit}
                    loading={loading}
                    primary
                    onClick={saveBulkData}
                  >
                    Save
                  </Button>
                </ButtonGroup>
              </Stack.Item>
            </Stack>
          </div>
        }
      >
        <Layout>
          {errArrData.length ? (
            <Layout.Section>
              <Banner status="critical">
                <p>There were some issues with your form submission:</p>
                <ul>
                  {errArrData.map((message, index) => {
                    return <li key={`${index}`}>{message}</li>;
                  })}
                </ul>
              </Banner>
            </Layout.Section>
          ) : null}

          <Layout.Section>
            <Card>
              <Card.Section>
                <FormLayout>
                  <TextField
                    error={errData["title"] || undefined}
                    label={<b>Title</b>}
                    type="text"
                    onFocus={() => {
                      setErrorData({ ...errData, title: null });
                    }}
                    placeholder="Title"
                    disabled={state.discountId ? true : false}
                    value={state.title}
                    onChange={(value) => stateChange("title", value)}
                    //   helpText="输入优惠券搜索."
                    autoComplete="off"
                  />
                  <TextStyle variation="subdued">
                    The name of the discount the codes will be grouped under.
                  </TextStyle>
                </FormLayout>
                <FormLayout>
                  <ChoiceList
                    title=""
                    choices={[
                      { label: "Generate random codes", value: "auto" },
                      { label: "Provide specific codes", value: "manual" },
                    ]}
                    selected={[state.type]}
                    onChange={(value) => stateChange("type", value[0])}
                  />
                </FormLayout>
                {state.type === "manual" ? (
                  <FormLayout>
                    <TextField
                      error={errData["codes_str"] || undefined}
                      label="Discount Codes"
                      onFocus={() => {
                        setErrorData({ ...errData, codes_str: null });
                      }}
                      value={state.codes_str}
                      maxHeight={240}
                      onChange={(value) => {
                        stateChange("codes_str", value);
                      }}
                      multiline={4}
                      autoComplete="off"
                    />
                  </FormLayout>
                ) : (
                  <FormLayout>
                    <FormLayout.Group>
                      <TextField
                        label="Generate quantity"
                        type="text"
                        error={errData["counts"]}
                        onFocus={() => {
                          setErrorData({ ...errData, counts: null });
                        }}
                        value={`${state.counts}`}
                        onChange={(value) => {
                          stateChange("counts", value);
                        }}
                        autoComplete="off"
                      />
                      <TextField
                        label="Code random length"
                        type="text"
                        onFocus={() => {
                          setErrorData({ ...errData, random_length: null });
                        }}
                        error={errData["random_length"]}
                        value={`${state.random_length}`}
                        onChange={(value) => {
                          stateChange("random_length", value);
                        }}
                        autoComplete="off"
                      />
                    </FormLayout.Group>
                    <FormLayout.Group>
                      <TextField
                        label="Code prefix"
                        type="text"
                        autoComplete="off"
                        error={errData["prefix"]}
                        onFocus={() => {
                          setErrorData({ ...errData, prefix: null });
                        }}
                        value={state.prefix}
                        onChange={(value) => {
                          stateChange("prefix", value);
                        }}
                      />
                      <TextField
                        label="Code suffix"
                        type="text"
                        error={errData["suffix"]}
                        onFocus={() => {
                          setErrorData({ ...errData, suffix: null });
                        }}
                        value={state.suffix}
                        onChange={(value) => {
                          stateChange("suffix", value);
                        }}
                        autoComplete="off"
                      />
                      <ChoiceList
                        title={<b>Allowed characters</b>}
                        choices={[
                          { label: "Letters and numbers", value: "mix" },
                          { label: "Letters only", value: "letter" },
                          { label: "Numbers only", value: "number" },
                        ]}
                        selected={[state.character_type]}
                        onChange={(value) =>
                          stateChange("character_type", value[0])
                        }
                      />
                    </FormLayout.Group>
                    <FormLayout.Group>
                    <ChoiceList
                      title=""
                      allowMultiple
                      choices={[
                        {
                          label: "Automatically increment when the unused quantity is insufficient",
                          value: "true",
                        },
                      ]}
                      selected={
                        state.auto_increment_code == "false"
                          ? []
                          : [state.auto_increment_code]
                      }
                      onChange={(value) =>
                        stateChange(
                          "auto_increment_code",
                          value.length ? value[0] : "false"
                        )
                      }
                    />
                    </FormLayout.Group>
                    <FormLayout.Group>
                      <TextField
                        label="Effective days(Used for self built systems）"
                        type="text"
                        error={errData["code_effective_days"]}
                        onFocus={() => {
                          setErrorData({ ...errData, code_effective_days: null });
                        }}
                        value={state.code_effective_days}
                        onChange={(value) => {
                          stateChange("code_effective_days", value);
                        }}
                        autoComplete="off"
                      />
                    </FormLayout.Group>
                  </FormLayout>
                )}
              </Card.Section>
            </Card>
            <Card>
              <Card.Section>
                <FormLayout>
                  <ChoiceList
                    title={<b>Choice discount type</b>}
                    choices={[
                      { label: "Product", value: "product" },
                      { label: "Free Shipping", value: "shipping_line" },
                      { label: "Buy X send Y", value: "gift" },
                    ]}
                    selected={[state.target_type]}
                    onChange={(value) => stateChange("target_type", value[0])}
                  />
                </FormLayout>
              </Card.Section>
            </Card>
            {state.target_type == "gift" ? (
              <Card>
                <Card.Section title="Customer target">
                  <ChoiceList
                    title="Customer spends"
                    choices={[
                      { label: "Minimum quantity of items", value: "quantity" },
                      { label: "Minimum purchase amount", value: "amount" },
                    ]}
                    selected={[state.prerequisite_method]}
                    onChange={(value) =>
                      stateChange("prerequisite_method", value[0])
                    }
                  />
                </Card.Section>
                <Card.Section title="Customer target">
                  <Stack>
                    <Stack.Item fill>
                      {state.prerequisite_method == "quantity" ? (
                        <TextField
                          autoComplete="off"
                          error={errData["prerequisite_quantity"]}
                          onFocus={() => {
                            setErrorData({
                              ...errData,
                              prerequisite_quantity: null,
                            });
                          }}
                          value={`${state.prerequisite_quantity}`}
                          label=""
                          prefix={
                            state.prerequisite_method == "amount" ? "$" : ""
                          }
                          placeholder={
                            state.prerequisite_method == "amount" ? "0.00" : ""
                          }
                          connectedRight={
                            <Select
                              value={state.prerequisite_type}
                              options={["collection", "product", "variant"]}
                              onChange={(value) =>
                                stateChange("prerequisite_type", value)
                              }
                              label=""
                            />
                          }
                          onChange={(value) =>
                            stateChange("prerequisite_quantity", value)
                          }
                        />
                      ) : (
                        <TextField
                          autoComplete="off"
                          error={errData["prerequisite_amount"]}
                          onFocus={() => {
                            setErrorData({
                              ...errData,
                              prerequisite_amount: null,
                            });
                          }}
                          value={`${state.prerequisite_amount}`}
                          label=""
                          connectedRight={
                            <Select
                              value={state.prerequisite_type}
                              options={["collection", "product"]}
                              onChange={(value) =>
                                stateChange("prerequisite_type", value)
                              }
                              label=""
                            />
                          }
                          prefix={
                            state.prerequisite_method == "amount" ? "$" : ""
                          }
                          placeholder={
                            state.prerequisite_method == "amount" ? "0.00" : ""
                          }
                          onChange={(value) =>
                            stateChange("prerequisite_amount", value)
                          }
                        />
                      )}
                    </Stack.Item>
                    <Stack.Item>
                      <ResourceButton
                        sourceType={state.prerequisite_type}
                        onChange={(data) =>
                          stateChange(
                            state.prerequisite_type == "collection"
                              ? "prerequisite_collections"
                              : "prerequisite_products",
                            data
                          )
                        }
                      ></ResourceButton>
                    </Stack.Item>
                  </Stack>
                  {state.prerequisite_type == "collection" ? (
                    <CollectionList
                      collections={state.prerequisite_collections}
                      delete={(index: number) =>
                        deleteProducts("prerequisite_collections", index)
                      }
                    />
                  ) : (
                    <ProductList
                      products={state.prerequisite_products}
                      delete={(index: number) =>
                        deleteProducts("prerequisite_products", index)
                      }
                    />
                  )}
                </Card.Section>
                <Card.Section title="Customer get">
                  <Stack>
                    <Stack.Item fill>
                      <TextField
                        autoComplete="off"
                        value={`${state.entitled_quantity}`}
                        label=""
                        error={errData["entitled_quantity"]}
                        onFocus={() => {
                          setErrorData({ ...errData, entitled_quantity: null });
                        }}
                        connectedRight={
                          <Select
                            value={state.entitled_type}
                            options={["collection", "product"]}
                            onChange={(value) =>
                              stateChange("entitled_type", value)
                            }
                            label=""
                          />
                        }
                        onChange={(value) =>
                          stateChange("entitled_quantity", value)
                        }
                      />
                    </Stack.Item>
                    <Stack.Item>
                      <ResourceButton
                        sourceType={state.entitled_type}
                        onChange={(data) =>
                          stateChange(
                            state.entitled_type == "collection"
                              ? "entitled_collections"
                              : "entitled_products",
                            data
                          )
                        }
                      ></ResourceButton>
                    </Stack.Item>
                  </Stack>
                  {state.entitled_type == "collection" ? (
                    <CollectionList
                      collections={state.entitled_collections}
                      delete={(index: number) =>
                        deleteProducts("entitled_collections", index)
                      }
                    />
                  ) : (
                    <ProductList
                      products={state.entitled_products}
                      delete={(index: number) =>
                        deleteProducts("entitled_products", index)
                      }
                    />
                  )}
                </Card.Section>
                <Card.Section>
                  <ChoiceList
                    title={<a>APPLIES TO</a>}
                    choices={[
                      {
                        label: "Percentage",
                        value: "0",
                        renderChildren: () =>
                          state.is_free == "0" ? (
                            <div style={{ width: "120px" }}>
                              <TextField
                                autoComplete="off"
                                suffix="%"
                                error={errData["percentage_value"]}
                                onFocus={() => {
                                  setErrorData({
                                    ...errData,
                                    percentage_value: null,
                                  });
                                }}
                                value={state.percentage_value}
                                onChange={(value) =>
                                  stateChange("percentage_value", value)
                                }
                                label=""
                              />
                            </div>
                          ) : null,
                      },
                      { label: "Gift", value: "1" },
                    ]}
                    selected={[state.is_free]}
                    onChange={(value) => stateChange("is_free", value[0])}
                  />
                </Card.Section>
                <Card.Section>
                  <ChoiceList
                    allowMultiple
                    title=""
                    choices={[
                      {
                        label: "Set a maximum number of uses per order",
                        value: "1",
                        renderChildren: () =>
                          state.is_allocation_limit[0] == "1" ? (
                            <div style={{ width: "120px" }}>
                              <TextField
                                autoComplete="off"
                                type="number"
                                value={state.allocation_limit}
                                onChange={(value) =>
                                  stateChange("allocation_limit", value)
                                }
                                label=""
                              />
                            </div>
                          ) : null,
                      },
                    ]}
                    selected={state.is_allocation_limit}
                    onChange={(value) =>
                      stateChange("is_allocation_limit", value)
                    }
                  />
                </Card.Section>
              </Card>
            ) : state.target_type == "shipping_line" ? (
              <>
                <Card title={<b>Countries</b>}>
                  <Card.Section>
                    <ChoiceList
                      title=""
                      choices={[
                        {
                          label: "All countries",
                          value: "0",
                        },
                        { label: "Specific countries", value: "1" },
                      ]}
                      selected={[state.country_select]}
                      onChange={(value) =>
                        stateChange("country_select", value[0])
                      }
                    />
                    {state.country_select == "1" ? (
                      <CountrySector
                        ids={state.entitled_country_ids}
                        onChange={(value) => {
                          setErrorData({
                            ...errData,
                            entitled_country_ids: null,
                          });
                          stateChange("entitled_country_ids", value);
                        }}
                      />
                    ) : null}
                  </Card.Section>
                  <Card.Section title="SHIPPING RATES">
                    <ChoiceList
                      title=""
                      allowMultiple
                      choices={[
                        {
                          label: "Exclude shipping rates over a certain amount",
                          value: "1",
                          renderChildren: () =>
                            state.exclude_shipping === "1" ? (
                              <Stack>
                                <Stack.Item>
                                  <TextField
                                    prefix="$"
                                    autoComplete="off"
                                    label=""
                                    error={errData["less_than_or_equal_to"]}
                                    onFocus={() =>
                                      setErrorData({
                                        ...errData,
                                        less_than_or_equal_to: null,
                                      })
                                    }
                                    onBlur={() => {
                                      stateChange(
                                        "less_than_or_equal_to",
                                        onBlurValidate(
                                          validateRules[
                                            "less_than_or_equal_to"
                                          ],
                                          state.less_than_or_equal_to
                                        )
                                      );
                                    }}
                                    placeholder=""
                                    onChange={(value) =>
                                      stateChange(
                                        "less_than_or_equal_to",
                                        value
                                      )
                                    }
                                    value={state.less_than_or_equal_to}
                                  />
                                </Stack.Item>
                              </Stack>
                            ) : null,
                        },
                      ]}
                      selected={
                        state.exclude_shipping == "0"
                          ? []
                          : [state.exclude_shipping]
                      }
                      onChange={(value) =>
                        stateChange(
                          "exclude_shipping",
                          value.length ? value[0] : "0"
                        )
                      }
                    />
                  </Card.Section>
                </Card>
              </>
            ) : (
              <>
                <Card>
                  <Card.Section title={<b>Discount setting</b>}>
                    <Stack>
                      <Stack.Item>
                        <ButtonGroup segmented>
                          <Button
                            pressed={state.value_type === "percentage"}
                            onClick={() => {
                              stateChange("value_type", "percentage");
                            }}
                            outline
                          >
                            Percentage
                          </Button>
                          <Button
                            pressed={state.value_type !== "percentage"}
                            onClick={() => {
                              stateChange("value_type", "fixed_amount");
                            }}
                            outline
                          >
                            Fixed amount
                          </Button>
                        </ButtonGroup>
                      </Stack.Item>
                      <Stack.Item fill>
                        {state.value_type == "percentage" ? (
                          <TextField
                            autoComplete="off"
                            label=""
                            error={errData["percentage_value"]}
                            onFocus={() => {
                              setErrorData({ ...errData, value: null });
                            }}
                            value={state.percentage_value}
                            onChange={(value) => {
                              stateChange("percentage_value", value);
                            }}
                            suffix="%"
                          />
                        ) : (
                          <TextField
                            autoComplete="off"
                            label=""
                            error={errData["amount_value"]}
                            onFocus={() => {
                              setErrorData({ ...errData, amount_value: null });
                            }}
                            onBlur={() => {
                              stateChange(
                                "amount_value",
                                onBlurValidate(
                                  validateRules["amount_value"],
                                  state.amount_value
                                )
                              );
                            }}
                            value={state.amount_value}
                            onChange={(value) => {
                              stateChange("amount_value", value);
                            }}
                            prefix="$"
                            placeholder={"0.00"}
                          />
                        )}
                      </Stack.Item>
                    </Stack>
                  </Card.Section>
                </Card>
                <Card>
                  <Card.Section>
                    <FormLayout>
                      <ChoiceList
                        title={<b>APPLIES TO</b>}
                        choices={[
                          { label: "All products", value: "all" },
                          {
                            label: "Specific collections",
                            value: "collection",
                          },
                          { label: "Specific products", value: "product" },
                          { label: "Specific variants", value: "variant" },
                        ]}
                        selected={[state.target_selection]}
                        onChange={(value) =>
                          stateChange("target_selection", value[0])
                        }
                      />
                    </FormLayout>
                  </Card.Section>
                  {state.target_selection !== "all" ? (
                    <Card.Section>
                      <Stack>
                        <Stack.Item>
                          <ResourceButton
                            sourceType={state.target_selection}
                            onChange={(data) =>
                              stateChange(
                                state.target_selection == "collection"
                                  ? "entitled_collections"
                                  : "entitled_products",
                                data
                              )
                            }
                          ></ResourceButton>
                        </Stack.Item>
                      </Stack>
                    </Card.Section>
                  ) : null}
                  {state.target_selection !== "all" ? (
                    <Card.Section>
                      {state.target_selection == "collection" ? (
                        <CollectionList
                          collections={state.entitled_collections}
                          delete={(index: number) =>
                            deleteProducts("entitled_collections", index)
                          }
                        />
                      ) : (
                        <ProductList
                          products={state.entitled_products}
                          delete={(index: number) =>
                            deleteProducts("entitled_products", index)
                          }
                        />
                      )}
                    </Card.Section>
                  ) : null}
                </Card>
              </>
            )}

            <Card>
              <Card.Section>
                <ChoiceList
                  allowMultiple
                  title={<b>Maximum discount uses</b>}
                  choices={[
                    {
                      label:
                        "Limit number of times this discount can be used in total",
                      value: "usage_limit",
                      renderChildren: () =>
                        state.discount_use_limit.includes("usage_limit") ? (
                          <Stack>
                            <Stack.Item>
                              <TextField
                                autoComplete="off"
                                label=""
                                error={errData["usage_limit"]}
                                onFocus={() =>
                                  setErrorData({
                                    ...errData,
                                    usage_limit: null,
                                  })
                                }
                                placeholder=""
                                onChange={(value) =>
                                  stateChange("usage_limit", value)
                                }
                                value={state.usage_limit}
                              />
                            </Stack.Item>
                          </Stack>
                        ) : null,
                    },
                    {
                      label: "Limit to one use per customer",
                      value: "once_per_customer",
                    },
                  ]}
                  selected={state.discount_use_limit}
                  onChange={(value) => stateChange("discount_use_limit", value)}
                />
              </Card.Section>
            </Card>

            <Card>
              <Card.Section>
                <FormLayout>
                  <ChoiceList
                    title={<b>Minimum purchase requirements</b>}
                    choices={[
                      {
                        label: "No minimum requirements",
                        value: "",
                      },
                      {
                        label: "Minimum purchase amount ($)",
                        value: "limited_amount",
                        renderChildren: () =>
                          state.active_limit == "limited_amount" ? (
                            <Stack>
                              <Stack.Item>
                                <TextField
                                  autoComplete="off"
                                  label=""
                                  error={errData["limited_amount"]}
                                  placeholder=""
                                  onChange={(value) =>
                                    stateChange("limited_amount", value)
                                  }
                                  onBlur={() => {
                                    stateChange(
                                      "limited_amount",
                                      onBlurValidate(
                                        validateRules["limited_amount"],
                                        state["limited_amount"]
                                      )
                                    );
                                  }}
                                  value={state.limited_amount}
                                  prefix="$ 0.00"
                                />
                              </Stack.Item>
                            </Stack>
                          ) : null,
                      },
                      {
                        label: "Minimum quantity of items",
                        value: "limited_quantity",
                        renderChildren: () =>
                          state.active_limit == "limited_quantity" ? (
                            <Stack>
                              <Stack.Item>
                                <TextField
                                  autoComplete="off"
                                  label=""
                                  suffix="Pcs"
                                  error={errData["limited_quantity"]}
                                  placeholder=""
                                  onChange={(value) =>
                                    stateChange("limited_quantity", value)
                                  }
                                  value={state.limited_quantity}
                                />
                              </Stack.Item>
                            </Stack>
                          ) : null,
                      },
                    ]}
                    selected={[state.active_limit]}
                    onChange={(value) => stateChange("active_limit", value[0])}
                  />
                </FormLayout>
              </Card.Section>
            </Card>
            <CustomerCart
              eligibility={state.eligibility}
              onChange={(key, ids) => {
                stateChange(key, ids);
                setErrorData({ ...errData, [key]: null });
              }}
            />
            <Card>
              <Card.Section>
                <ActiveDatesCard
                  startDate={{
                    value: state.startDate,
                    onChange: (startDate: any) => {
                      stateChange("startDate", startDate);
                    },
                  }}
                  endDate={{
                    value: state.endDate,
                    onChange: (endDate: any) => {
                      stateChange("endDate", endDate);
                    },
                  }}
                  timezoneAbbreviation="EST"
                />
              </Card.Section>
            </Card>
            {/* <Card title="Set birthday">
              <Card.Section>
              <Checkbox
                label="Dirthday discount"
                checked={state.is_birthday}
                onChange={(value)=>stateChange("is_birthday",value)}
              />

              <div>
              <TextStyle>每个店铺只能有一个 生日券活动，如果设置本次活动为生日券活动，则之前设置的生日券活动将自动失效</TextStyle>
              </div>

              </Card.Section>
            </Card> */}
          </Layout.Section>
          <Layout.Section secondary>
            <Summary data={state} />
          </Layout.Section>
        </Layout>
      </Frame>
    </Page>
  );
};

export default BulkCodeDiscountCreate;
