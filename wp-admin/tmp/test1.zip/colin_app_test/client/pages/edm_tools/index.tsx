import { configColumns } from "@components/edm_tools/config.column";
import { EdmConfig, Pagination } from "@components/edm_tools/interface";
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { onBreadcrumbAction } from "@shopify/discount-app-components";
import { Page, Layout, Card } from "@shopify/polaris";
import { Button, Col, Drawer, Dropdown, Form, Input, Modal, Row, Space, Table, message } from "antd";
import { useForm } from "antd/es/form/Form";
import { ColumnType } from "antd/lib/table";
import { useEffect, useState } from "react";
import { useAuthenticatedFetch } from "../../hooks";
import { EditEdmConfig } from "@components/edm_tools/editConfig";
import { EdmSendRecordsModal } from "@components/edm_tools/records";
import dayjs, { Dayjs } from "dayjs";
interface Shop {
  id:number;
  shopify_domain:string;
  iana_timezone:string;
  shopify_id:number;
}
interface Istate {
  list: EdmConfig[];
  editVisible: boolean;
  editEdmConfig: EdmConfig | null;
  shop:Shop|null;
  recordConfig: EdmConfig| null;
  recordVisible: boolean;
}

const EdmTools = () => {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  const [pagination, setPagination] = useState<Pagination>({
    current_page: 1,
    total_pages: 1,
    page_size: 10,
    total_size: 1,
  });
  const [loading, setLoading] = useState<boolean>(false);
  const [state, setState] = useState<Istate>({
    list: [],
    editVisible: false,
    editEdmConfig: null,
    shop:null,
    recordConfig:null,
    recordVisible:false,
  });
  const authenticatedFetch = useAuthenticatedFetch();
  useEffect(() => {
    getList();
  }, []);
  useEffect(() => {
    getList();
  }, [pagination]);
  const getList = async () => {
    if (loading) {
      return;
    }
    let formData = searchForm.getFieldsValue();
    setLoading(true);
    try {
      let data: { list: EdmConfig[]; pagination: Pagination;shop:Shop } =
        await authenticatedFetch("/api/edm-config/list", {
          method: "GET",
          query: {
            current_page: pagination.current_page,
            page_size: pagination.page_size,
            search: formData.search || "",
          },
        });
      pagination.current_page = data.pagination.current_page;
      pagination.page_size = data.pagination.page_size;
      pagination.total_pages = data.pagination.total_pages;
      pagination.total_size = data.pagination.total_size;
      console.log(pagination);
      setPagination(pagination);
      setLoading(false);
      setState({ ...state, list: data.list, shop: data.shop });
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };
  const onVerify = async (edmConfig:EdmConfig) =>  {
    if(!edmConfig.is_verify) {
      Modal.confirm({
        onOk:async ()=> {
          try{
            await authenticatedFetch("/api/edm-config/verify",{
              method:'POST',
              body: {
                id:edmConfig.id,
              }
            });
            setPagination({...pagination});
          }catch(e:any) {
            message.error(e.message || e.msg);
            setPagination({...pagination});
          }

          Modal.destroyAll();
        },
        title:'Confirm',
        content:'审核后将不允许继续修改，如果发送时间已经达到就会自动发送，确定审核吗?',
      })
    }else {
      try{
        await authenticatedFetch("/api/edm-config/verify",{
          method:'POST',
          body: {
            id:edmConfig.id,
          }
        });
        setPagination({...pagination});
      }catch(e:any) {
        console.log(e);
        message.error(e.message || e.msg);
        setPagination({...pagination});
      }
    }
  }
  const showRecords = (edmConfig:EdmConfig) => {
    setState({...state,recordConfig:edmConfig, recordVisible:true});
  }
  const columns = configColumns.map((item: ColumnType<EdmConfig>) => {
    switch (item.dataIndex) {
      case "operate":
        item.render = (operate: "", record: EdmConfig) => {
          if (!record.is_verify) {
            return (
              <>
                <Dropdown.Button size="small" type="primary"
              menu={{
                items:[
                {
                  label: '查看记录',
                  key: '1',
                  icon:null,
                  onClick: () => showRecords(record),
                },
                {
                  label: '审核',
                  key: '2',
                  disabled: record.is_verify,
                  icon:null,
                  onClick: ()=>onVerify(record),
                },

              ]}}
              disabled={false}
              onClick={() => setState({...state, editVisible: true,editEdmConfig:record})}>
              编辑
            </Dropdown.Button>
              </>
            );
          } else {
            return (
              <>
                <Button type="link" size="small" onClick={()=>showRecords(record)}>
                  查看记录
                </Button>
                {record.is_send_all ? null : <Button type="link" size="small" onClick={()=>onVerify(record)}>
                  弃审
                </Button>}
              </>
            );
          }
        };
        break;
    }
    return item;
  });
  const importClick = () => {
    setState({...state,editVisible:true})
  };
  const [searchForm] = useForm();
  return (
    <Page
      title="Edm发送邮件小工具"
      breadcrumbs={[
        {
          content: "Discounts",
          onAction: () => onBreadcrumbAction(redirect, true),
        },
      ]}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <Card.Section>
              <Form form={searchForm}>
                <Row gutter={[4, 4]}>
                  <Col span={8}>
                    <Form.Item name={"search"}>
                      <Input allowClear />
                    </Form.Item>
                  </Col>
                  <Col span={8}>
                    <Button
                      type="primary"
                      onClick={() => {
                        setPagination({ ...pagination, current_page: 1 });
                      }}
                    >
                      搜索
                    </Button>
                    <Button
                      style={{ marginLeft: "4px" }}
                      type="primary"
                      onClick={importClick}
                    >
                      导入
                    </Button>
                  </Col>
                </Row>
              </Form>
              <Table
                rowKey={(record) => record.id}
                scroll={{ x: 800,y:500 }}
                pagination={{
                  showSizeChanger: true,
                  pageSizeOptions: [10, 20, 50],
                  onChange: (page, page_size) => {
                    setPagination({
                      ...pagination,
                      current_page: page,
                      page_size,
                    });
                  },
                  current: pagination.current_page,
                  pageSize: pagination.page_size,
                  total: pagination.total_size,
                }}
                loading={loading}
                columns={columns}
                size={"small"}
                dataSource={state.list}
              ></Table>
            </Card.Section>
          </Card>
        </Layout.Section>
      </Layout>
      <EditEdmConfig
      iana_timezone={state.shop?.iana_timezone || ''}
        onOk={() => {
          setState({ ...state, editEdmConfig: null, editVisible: false });
          setPagination({ ...pagination });
        }}
        onCancel={() =>
          setState({ ...state, editVisible: false, editEdmConfig: null })
        }
        visible={state.editVisible}
        data={state.editEdmConfig}
      />
      <EdmSendRecordsModal iana_timezone={state.shop?.iana_timezone || ''} onCancel={()=> setState({...state, recordVisible:false, recordConfig:null})} edmConfig={state.recordConfig} visible={state.recordVisible}/>
    </Page>
  );
};
export default EdmTools;
