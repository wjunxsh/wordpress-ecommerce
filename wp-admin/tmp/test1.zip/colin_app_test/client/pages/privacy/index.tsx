import { Card } from "antd";
import React from "react";
import "./style.less";
const PrivatePage = () => {
  return (
    <div>
      <Card>
          <div style={{ textAlign: "center" }}>
            <h2 style={{ fontSize: "18px" }}>
            AKR‑Massive discount code gene Privacy Policy{" "}
            </h2>
          </div>
          <div className="privacy-content">
            <p>
              AKR‑Massive discount code gene(“the App”) will help you create discount codes
              quickly.{" "}
            </p>
            <p>
              This Privacy Policy describes how Personal Information is
              collected, used, and shared when you install, use the App in
              connection with your Shopify-supported store. And how we treat
              gathered Personal Information of you when you (“Staff Users(s)")
              are accessing our website and services as well as the data (“user
              data”) gathered about your end users (“Customer User(s)") relevant
              to the services we provide.
            </p>
            <p>
              When you install the App, to ensure Service delivery we are
              automatically able to access certain types of information about
              your shop from your Shopify account:
            </p>
            <ul>
              <li>Shopify domain,</li>
              <li>Primary domain,</li>
              <li>Shop’s email address,</li>
              <li>Shop’s owner email address,</li>
              <li>Shop’s country code,</li>
              <li>App’s installment and uninstallment dates</li>
              <li>FAQ page text info:</li>
            </ul>
            <p>
              Additionally, for Service delivery purpose upon your visit to our
              website, we automatically collect information about your device,
              including your IP address and potentially other unique device
              identifiers (for example, if you are using a phone with iOS or
              Android installed), Internet browser type and language,
              information about any website that referred you, the date/time of
              your visit, and any search keywords. We refer to this information
              collectively as “Device Information.” When we refer to “Personal
              Information” in this Privacy Policy, we’re including both Device
              Information and Account Information that means information
              relating to the Discount Bulk Code app's account.
            </p>
            <p>
              In order to ensure network and information security, and to
              identify and resolve product defects we log IP and device
              information in logs which are kept secure and limited to no more
              than 90 days and securely deleted thereafter. This log information
              is subject to restricted access and not used with any other
              identifying information to identify or otherwise track Staff
              User’s and Customer User’s behavior and is not shared with any
              third parties and is not used otherwise for the purposes of
              general analytics or marketing.
            </p>
            <h3>HOW DO WE USE YOUR PERSONAL INFORMATION?</h3>
            <p>
              We use the Personal Information we collect from you and your
              customers in order to provide the Service and to operate the App.
            </p>
            <p>Additionally, we use this Personal Information to:</p>
            <ul>
              <li>To communicate with you,</li>
              <li> To optimize or improve the App,</li>
              <li>
                To provide merchants with information or advertising related to
                our products or services,
              </li>
              <li> To provide reporting and analytics,</li>
              <li>
                To help merchants find and integrate with apps through our app
                store,
              </li>
              <li>
                To provide troubleshooting, support services or to answer
                questions,
              </li>
              <li>To prevent risk and fraud on our platform,</li>
              <li>To test out features or additional services,</li>
              <li>To ask for ratings and/or reviews of services,</li>
              <li>To improve our services applications and website.</li>
            </ul>
            <p>
              App will never provide or sell your information (and your customer
              end-user Information) to any third party not related with Help
              Center, except as permitted by law and except as written within
              this Policy below.
            </p>
            <p>
              We will only send personal information about you and your
              customers to other companies or people if we need to share your
              information to provide the products or services you have
              requested.
            </p>
            <p>
              {" "}
              If you use Platform to Process Platform Data, you will provide and
              comply with a publicly available and easily accessible privacy
              policy.
            </p>
            <p>
              This policy must comply with applicable law and regulations and
              must accurately and clearly explain what data you are Processing,
              how you are Processing it, the purposes for which you are
              Processing it, and how Users may request deletion of that data.
            </p>
            <p>
              You may only Process Platform Data as clearly described in your
              privacy policy and in accordance with all applicable law and
              regulations, these Terms, and all other applicable terms and
              policies.
            </p>
            <p>
              We may update this privacy policy from time to time in order to
              reflect, for example, changes to our practices or for other
              operational, legal or regulatory reasons.
            </p>
            <p>
              For more information about our privacy practices, if you have
              questions, or if you would like to make a complaint, please
              contact us by e-mail at dtc-it@anker-in.com
            </p>
          </div>
      </Card>
    </div>
  );
};
export default PrivatePage;
