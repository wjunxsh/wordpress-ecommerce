import {
  Page
} from "@shopify/polaris";
import React from "react";
import { TitleBar } from "@shopify/app-bridge-react";

export default function HomePage() {
  return (
    <Page narrowWidth>
      <TitleBar title="App name" />
      sdfsf
    </Page>
  );
}
