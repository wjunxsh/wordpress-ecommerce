import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { onBreadcrumbAction } from "@shopify/discount-app-components";
import { Page, Card, Layout } from "@shopify/polaris";
import { PlusOutlined } from "@ant-design/icons";
import { Checkbox, Radio, Spin, Tag, Typography, Tooltip, message } from "antd";
import { ExclamationCircleOutlined} from '@ant-design/icons';
const { Text, Link } = Typography;
import {
  Button,
  Form,
  Input,
  InputNumber,
  Row,
  Col,
  Upload,
  Modal,
  Table,
} from "antd";
import { useForm } from "antd/lib/form/Form";
import React, { useState } from "react";
import {
  DiscountItem,
  columns as tableColumns,
} from "../../components/mult_export_discount/column";
import { ColumnType } from "antd/lib/table";
import { RcFile, UploadFile } from "antd/lib/upload";
import { useAuthenticatedFetchUpload } from "../../hooks/useAuthenticatedFetch";
interface Istate {
  is_edit: boolean;
  loading: boolean;
  open: boolean;
  code_type: string;
}
const MultExportDiscounts = () => {
  const [form] = useForm();
  const aFetch = useAuthenticatedFetchUpload();
  const [dataSource,setDataSource] = useState([]);
  const [state, setState] = useState<Istate>({
    is_edit: false,
    loading: false,
    open: false,
    code_type: "import",
  });
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };
  const app = useAppBridge();
  const redirect = Redirect.create(app);

  const importData = async (values:any) => {
    let formData = new FormData();
    if(state.loading) {
      return false;
    }
    setState({...state,loading:true});
    formData.append('file', values.file.file as RcFile);
    formData.append("code_type", values.code_type);
    formData.append("code_prefix", values.code_prefix || '');
    formData.append("code_num", values.code_num || '');
    formData.append("combine_product_discount", values.combine_product_discount || false);
    try{
      let result = await aFetch("/api/discounts/mult_update_import", {
        body:formData,
        method:"post",
      });
      setDataSource(result.list.map((item:any,index:number)=>({...item,index})));
      setFileList([]);
      setState({...state,loading:false, open: true});
      form.resetFields();
    }catch(e:any) {
      message.error(e.message || e.msg);
      setState({...state,loading:false});
    }

  };
  const columns = tableColumns.map((item: ColumnType<DiscountItem>) => {
    switch (item.dataIndex) {
      case "status":
        item.render = (status: DiscountItem["status"], record) => {
          if (status?.code == 200) {
            return <Text style={{width:"168px"}} color="success">成功</Text>;
          } else if (status?.code == 1001) {
            return <Text style={{width:"168px"}} type="danger">折扣码已经存在，请手动修改</Text>
          } else if (status?.code == 404) {
            return <Text style={{width:"168px"}} type="danger">未找到Sku</Text>;
          }
        };
        break;
        case "operate":
        // item.render = (operate, record) => {
        //   console.log(record.status);
        //   if (record.status.code == 1001) {
        //     return <Button size={"small"}>更新活动</Button>
        //   }
        // };
        break;
    }
    return item;
  });
  return (
    <Page
      title="批量更新折扣"
      breadcrumbs={[
        {
          content: "Discounts",
          onAction: () => onBreadcrumbAction(redirect, true),
        },
      ]}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <Card.Section>
              <Form
                {...layout}
                onChange={()=> {
                }}
                style={{
                  marginLeft: "16%",
                  marginTop: "48px",
                  marginBottom: "48px",
                  maxWidth: 412,
                }}
                form={form}
              >
                <Form.Item
                  initialValue={state.code_type}
                  label="Code生成方式"
                  name="code_type"
                >
                  <Radio.Group
                    onChange={(e) => {
                      setState({ ...state, code_type: e.target.value });
                    }}
                  >
                    <Radio value={"import"}>导入</Radio>
                    <Radio value={"half"}>部分生成</Radio>
                    <Radio value={"all"}>全部生成</Radio>
                  </Radio.Group>
                </Form.Item>
                <Form.Item
                  hidden={state.code_type != "half"}
                  rules={[
                    {
                      required: state.code_type == "half",
                      message: "code前缀必须填写",
                    },
                  ]}
                  label="活动码前缀"
                  name="code_prefix"
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  hidden={state.code_type == "import"}
                  rules={[{required:state.code_type != "import",message: "请输入信息"}]}
                  label="自动生成的位数"
                  name="code_num"
                >
                  <InputNumber
                    onChange={(value) => {
                      setState({ ...state, is_edit: true });
                    }}
                  />
                </Form.Item>
                <Form.Item label="提醒">
                  <label>
                    请严格按照<a target="_blank" href="https://anker-in.feishu.cn/docx/D2lydRosRoRzONxUWmWcV1Amnjh">《批量导入文件模版》</a>创建文件
                  </label>
                </Form.Item>
                <Form.Item name="combine_product_discount" valuePropName="checked" label={<Tooltip  color='geekblue' title='目前只有品牌Anker才生效'>联合其他产品折扣<ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} /></Tooltip>}>
                  <Checkbox/>
                </Form.Item>
                <Form.Item
                  required={true}
                  rules={[{ required: true, message: "请上传文件" }]}
                  name={"file"}
                  label="选择文件"
                >
                  <Upload fileList={fileList} onChange={(info)=> {
                    let newFileList = [...info.fileList];
                    newFileList = newFileList.slice(-1);
                    newFileList = newFileList.map((file) => {
                      if (file.response) {

                        file.url = file.response.url;
                      }
                      return file;
                    });

                    setFileList(newFileList);
                  }} accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,.csv" beforeUpload={()=>{return false}} listType="text">
                    <div>
                      <Button
                        style={{ borderRadius: "4px" }}
                        icon={<PlusOutlined />}
                      >
                        仅支持xls/xlsx/csv
                      </Button>
                    </div>
                  </Upload>
                </Form.Item>
                
                <Row>
                  <Col span={8}></Col>
                  <Col span={16}>
                    <Button
                      onClick={() => {
                        form.validateFields().then(values=> {
                          importData(values);
                        }).catch(e=> {

                        });
                      }}
                      loading={state.loading}
                      type="primary"
                    >
                      导入
                    </Button>
                  </Col>
                </Row>
              </Form>
            </Card.Section>
          </Card>
        </Layout.Section>
      </Layout>
      <Modal
        width="800px"
        cancelText={" "}
        cancelButtonProps={{type:"link"}}
        okText="关闭"
        onOk={()=> { setState({ ...state, open: false });}}
        open={state.open}
        onCancel={()=> {setState({ ...state, open: false });}}
        title="导入明细"
      >
        <Table
          size={"small"}
          scroll={{ x: 800, y: 260 }}
          columns={columns}
          pagination={false}
          dataSource={dataSource}
        ></Table>
      </Modal>
    </Page>
  );
};
export default MultExportDiscounts;
