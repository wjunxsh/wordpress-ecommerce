import { useAppBridge, ResourcePicker } from "@shopify/app-bridge-react";
import { BaseResource } from "@shopify/app-bridge/actions/ResourcePicker";
import { Button } from "@shopify/polaris";
import React, { useEffect, useState } from "react";
export interface Collection {
  id: string;
  image: { id: string; originalSrc: string; altText?: string } | undefined;
  productsCount?: number;
  variants?:any[];
  title: string;
}
interface Props {
  sourceType: "product" | "collection" | "variant";
  onChange: (collections: Collection[]) => void;
  initialSelectionIds?:BaseResource[];
  buttonText?:string;
}

export const ResourceButton = (props: Props) => {
  const app = useAppBridge();
  const [text, setText] = useState("Add Button");
  useEffect(() => {
    switch (props.sourceType) {
      case "product":
        setText("Add product");
        break;
      case "variant":
        setText("Add variant");
        break;
    }
  }, [props.sourceType]);
  const [open, setOpen] = useState<boolean>(false);
  const onSelect = (selectPayload:any) => {
    let { selection } = selectPayload;
    let data:Collection[] = [];
    for (const select of selection) {
      if(props.sourceType == "collection"){
        data.push({
          id:select.id,
          title:select.title,
          image:select.image,
          productsCount:select.productsCount
        });
      }else{
        data.push({
          id:select.id,
          title:select.title,
          image:select.images[0],
          variants:select.variants
        });
      }

    }
    setOpen(false);
    props.onChange(data);
  };
  return (
    <>
      <Button outline onClick={() => {setOpen(true)}}>
        {props.buttonText ?? text}
      </Button>
      {props.sourceType == "collection" ? (
        <ResourcePicker
          key={1}
          resourceType={"Collection"}
          onCancel={() => {
            setOpen(false);
          }}
          onSelection={onSelect}
          selectMultiple={false}
          open
        />
      ) : (
        <ResourcePicker
          key={2}
          resourceType={"Product"}
          onCancel={() => {
            setOpen(false);
          }}
          initialSelectionIds={props.initialSelectionIds}
          onSelection={onSelect}
          showVariants={props.sourceType == "product" ? false : true}
          selectMultiple={true}
          open={open}
        />
      )}
    </>
  );
};
