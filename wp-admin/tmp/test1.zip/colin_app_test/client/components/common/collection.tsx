import { Button, Modal, Input, List, Skeleton, Avatar, Checkbox } from "antd"
import { useEffect, useRef, useState } from "react"
import {
    LoadingOutlined,
    CloseOutlined
} from '@ant-design/icons';
import "./style.less";
import { Pagination } from "@components/common_interface";
import { useAuthenticatedFetch } from "@hooks/useAuthenticatedFetch";
const { Search } = Input;
interface VariantSelect {
    checked?: boolean;
    title: string;
    id: number;
    sku: string;
}
interface ProductSelect {
    checked?: boolean;
    title: string;
    id: number;
    avatar?: string;
    variants: VariantSelect[]
}
export interface Iprops {
    onChange?: (value: any) => void;
    value?: ProductSelect[];
}
interface Istate {
    visible: boolean;
    value: ProductSelect[];
}
export const VarintSelect = (props: Iprops) => {
    const [state, setState] = useState<Istate>({
        visible: false,
        value: []
    })

    const onClick = () => {
        setState({ ...state, visible: true });
    }
    useEffect(() => {
        setState({ ...state, value: JSON.parse(JSON.stringify(props.value || [])) });
    }, [props.value]);

    const variantDelete = (pIndex: number, vIndex: number) => {
        let value = state.value;
        value[pIndex].variants.splice(vIndex,1)
        if(!value[pIndex].variants.length) {
            value.splice(pIndex,1);
        }
        props.onChange && props.onChange([...value]);
    }
    const productDelete = (pIndex: number) => {
        let value = state.value;
        value.splice(pIndex,1)
       
        props.onChange && props.onChange([...value]);
    }

    const onOk = (value:ProductSelect[]) => {
        setState({ ...state, visible: false,value });
        props.onChange && props.onChange(value);
    }


    return <div>
        <Button  type="primary" style={{ marginBottom: '16px' }} size="middle" onClick={() => onClick()}>选择Sku</Button>
        <div className="anker-list value">
            <ul className="anker-list-container">
                {(props.value || state.value).map((item, pIndex) =>
                    <li key={item.id} className="anker-list-item">
                        <div className="anker-list-content">
                            <div className="anker-list-content-avatar">{item.avatar ? <img src={item.avatar} /> : null}</div>
                            <div className="anker-list-content-title">{item.title}</div>
                            <div className="anker-list-item-action">
                                <Button  type='link' icon={<CloseOutlined />} onClick={()=> productDelete(pIndex)}></Button>
                            </div>
                        </div>
                        <ul className="anker-list-container">
                            {item.variants && item.variants.map((variant: any, vIndex: number) =>
                                <li key={variant.id} className="anker-list-item">
                                    <div className="anker-list-content">
                                        <div className="anker-list-content-title">{variant.title}</div>
                                        <div className="anker-list-item-action"></div>
                                        <Button type='link' icon={<CloseOutlined />} onClick={()=> variantDelete(pIndex,vIndex)}></Button>
                                    </div>
                                </li>
                            )}

                        </ul>
                    </li>
                )}
            </ul>
        </div>
       <VariantSelectModal onOk={onOk} visible={state.visible} value={state.value} onCancel={()=>{setState({...state,visible:false})}}/>
    </div>
}
export interface IModalprops {
    onOk: (value: any) => void;
    onCancel: (value: any) => void;
    value?: ProductSelect[];
    visible:boolean;
}
interface IModalstate {
    search: string;
    value: ProductSelect[];
}
const VariantSelectModal = (props:IModalprops) => {
    const authenticatedFetch = useAuthenticatedFetch();
    const [pagination, setPagination] = useState<Pagination>({ current_page: 1, total_pages: 2, page_size: 100, total_size: 2 });
    const [loading, setLoading] = useState(false);
    const [state, setState] = useState<IModalstate>({
        search: '',
        value: []
    })
    useEffect(() => {
        setState({ ...state, value: JSON.parse(JSON.stringify(props.value || [])) });
    }, [props.value]);
    const getList = async () => {
        if (loading) return;
        setLoading(true);
        fetchRef.current += 1;
        const fetchId = fetchRef.current;
        //从数据库获取数据
        let result = await authenticatedFetch('/api/basic/get_product_with_variants', {
            method: "GET",
            query: {
                page_size: pagination.page_size,
                search: state.search,
                current_page: pagination.current_page,
            }

        });
        if (fetchId !== fetchRef.current) {
            return;
        }
        let list = result.list
        pagination.current_page = result.pagination.current_page;
        pagination.page_size = result.pagination.page_size;
        pagination.total_pages = result.pagination.total_page;
        pagination.total_size = result.pagination.total_size;
        let newProductList = pagination.current_page == 1 ? [...list] : [...productList, ...list];
        setLoading(false);
        initModalCheck(newProductList);
    }
    useEffect(() => {
        props.visible && !productList.length && getList();
        props.visible && productList.length && initModalCheck(productList);
    }, [props.visible]);
    useEffect(()=> {
        getList();
    },[pagination]);
    useEffect(() => {
        setState({ ...state, value: JSON.parse(JSON.stringify(props.value || [])) });
    }, [props.value]);
    const setValue = (product: ProductSelect) => {
        //如果sourceValue 的值存在并设置了
        product = JSON.parse(JSON.stringify(product));
        let value = state.value;
        let index = value?.findIndex(item => item.id == product.id);
        if (index !== -1) {
            if (!product.checked) {
                value.splice(index, 1);
            } else {
                value[index]['variants'] = product.variants.filter(item => item.checked);
            }
        } else {
            if (product.checked) {
                value.push(product);
                value[value.length - 1].variants = product.variants.filter(item => item.checked)
            }
        }
        setState({ ...state, value });
    }
    const onSearch = (value: string) => {
        console.log(value);
        setState({...state,search:value});
        setPagination({ ...pagination, current_page: 1 });
    }
    const variantCheckedChange = (pIndex: number, vIndex: number) => {
        productList[pIndex]['variants'][vIndex]['checked'] = !productList[pIndex]['variants'][vIndex]['checked'];
        productList[pIndex]['checked'] = productList[pIndex]['variants'].every((variant: any) => variant.checked);
        setValue(productList[pIndex]);
        setProductList([...productList]);
    }
    const productCheckedChange = (pIndex: number) => {
        productList[pIndex]['checked'] = !productList[pIndex]['checked'];
        productList[pIndex]['variants'] && productList[pIndex]['variants'].forEach((variant: any) => {
            variant['checked'] = productList[pIndex]['checked'];
        })
        setValue(productList[pIndex]);
        setProductList([...productList]);
    }
    const initModalCheck = (productList: ProductSelect[]) => {
        productList.forEach(product => {
            product.checked = false;
            product.variants.forEach(item => item.checked = false)
            if (state.value && state.value.length) {
                let productValue = state.value.find(item => item.id == product.id);
                if (productValue) {
                    product.checked = true;
                    product.variants.forEach(variant => {
                        let variantValue = productValue?.variants.find(item => item.id == variant.id)
                        if (variantValue) {
                            variant['checked'] = true;
                        }
                    })
                }
            }
        })
        setProductList([...productList]);
    }
    const [productList, setProductList] = useState<ProductSelect[]>([]);
    const onOk = () => {
        props.onOk(state.value);
    }
    const onCancel = () => {
        props.onCancel(state.value);
    }
    const fetchRef = useRef(0);
   return <Modal title="选择Variant" width="600px"
    onOk={() => onOk()}
    onCancel={() => onCancel()}
    open={props.visible}>
    <div className="anker-search-box">
        <Search allowClear onPressEnter={(e:any)=>onSearch(e.target.value)} placeholder="Search product or variants" onSearch={onSearch} enterButton />
    </div>
    <div className="anker-list-main">
        <div className="anker-list">
            {loading ? <div className='anker-list-loading visible'>
                <LoadingOutlined style={{ fontSize: "24px" }} />
            </div> : null}
            <ul className="anker-list-container">
                {productList.map((item, pIndex) =>

                    <li key={item.id} className="anker-list-item">
                        <div className="anker-list-content">
                            <div className="anker-list-content-check"><Checkbox onChange={() => productCheckedChange(pIndex)} checked={item.checked} /></div>
                            <div className="anker-list-content-avatar">{item.avatar ? <img src={item.avatar} /> : null}</div>
                            <div className="anker-list-content-title">{item.title}</div>
                        </div>
                        <ul className="anker-list-container">
                            {item.variants && item.variants.map((variant: any, vIndex: number) =>
                                <li key={variant.id} className="anker-list-item">
                                    <div className="anker-list-content">
                                        <div className="anker-list-content-check"><Checkbox onChange={() => variantCheckedChange(pIndex, vIndex)} checked={variant.checked} /></div>
                                        <div className="anker-list-content-title">{variant.title}</div>
                                    </div>
                                </li>
                            )}

                        </ul>
                    </li>
                )}
            </ul>

        </div>
    </div>
    
    <div className="anker-list-load-more">
    {loading ? <Button type="link" disabled>...</Button> : 
        <Button onClick={()=>{
            setPagination({...pagination,current_page:pagination.current_page + 1});
        }} type="link" disabled={pagination.current_page == pagination.total_pages}>{pagination.current_page != pagination.total_pages ? '加载更多' : '没有更多'}</Button>
    }
    </div>
</Modal>
}