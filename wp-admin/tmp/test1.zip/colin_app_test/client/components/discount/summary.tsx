import React, { useEffect, useState } from "react";
import { Istate } from "../../pages/bulk_code/add/interface";
import {
  Badge,
  Banner,
  Button,
  ButtonGroup,
  Card,
  ChoiceList,
  FormLayout,
  Frame,
  Layout,
  Page,
  Select,
  Stack,
  List,
  TextField,
  TextStyle,
} from "@shopify/polaris";
export const Summary = (props: { data: Istate }) => {
  const { data } = props;
  const [details, setDetails] = useState<string[]>([]);
  const [code,setCode] = useState<string>("");
  useEffect(() => {
    let details = [];
    let { data } = props;
    details.push(getValueText(data));
    setDetails(details)
  }, [props.data]);
  useEffect(()=> {
    if(props.data.type == "auto"){
      if(!props.data.random_length){
        setCode("")
      }else{
        const code = randomStr(props.data.random_length,props.data.character_type)
        setCode(code)
      }
    }else if(props.data.codes_str){
      const code =  props.data.codes_str.split("\n")[0].toUpperCase();
      setCode(code);
    }else{
      setCode("");
    }

  },[props.data.random_length,props.data.codes_str,props.data.character_type]);

  const randomStr = (length: number,character_type:string) => {

    const letters = "ABCDEFGHIGKLMNOPQRSTUVWXYZ";
    const numbers = "0123456789";
    let charSource = letters + numbers;
    if(character_type == "letter"){
      charSource = letters;
    }else if(character_type == "number"){
      charSource = numbers;
    }
    let str: string = "";
    for (let i = 0; i < length; i++) {
      let cIndex = Math.round(Math.random() * (charSource.length - 1));
      let c = charSource[cIndex];
      str += c;
    }
    return str;
  }
  const getValueText = (data: Istate) => {
    if((data.value_type == "fixed_amount" && !data.amount_value) || (data.value_type == "percentage" && !data.percentage_value)){
      return "";
    }
    let msg =
      data.value_type == "percentage"
        ? data.percentage_value + "% "
        : data.amount_value + "$ ";
        if (
          data.target_selection == "all" ||
          (data.target_selection == "product" &&
            !data.entitled_products.length) ||
          (data.target_selection == "collection" &&
            !data.entitled_products.length)
        ) {
          msg += "of all products";
        } else if (
          data.target_selection == "product" &&
          data.entitled_products.length
        ) {
          msg += `of ${data.entitled_products.length} products`;
        } else if (
          data.target_selection == "collection" &&
          data.entitled_collections.length
        ) {
          msg += `of ${data.entitled_collections.length} collections`;
        }
    return msg;
  };
  return (
    <Card title="Summary">
      <Card.Section>
        <Stack vertical spacing="loose">
          {data.title ? (
            <Stack.Item>
              <div>
                <TextStyle variation="strong">{data.title}</TextStyle>
              </div>
            </Stack.Item>
          ) : null}

          <Stack.Item>
            <Stack vertical spacing="tight">
              <Stack.Item>
                <h3>Type</h3>
              </Stack.Item>
              <Stack.Item>
                <List type="bullet">
                  <List.Item>
                    {data.target_type == "product"
                      ? "Product or order"
                      : "Buy X send Y"}
                  </List.Item>
                </List>
              </Stack.Item>
            </Stack>
          </Stack.Item>
          <Stack.Item>
            <Stack vertical spacing="tight">
              <Stack.Item>
                <h3>Details</h3>
              </Stack.Item>
              <Stack.Item>
                <List type="bullet">
                  {details.map((item,index) => (
                    <List.Item key={index}>{item}</List.Item>
                  ))}
                </List>
              </Stack.Item>
            </Stack>
          </Stack.Item>
        </Stack>
      </Card.Section>
      <Card.Section>
        {data.type == "auto" ?
        <Stack vertical spacing="loose">
        <Stack.Item>
          <div className="code-sample">{data.counts > 0 ? `${data.prefix.toUpperCase()}${code}${data.suffix.toUpperCase()}` : ""}</div>
        </Stack.Item>
        <Stack.Item>
          {data.counts ? `${data.counts} unique codes` :""}
        </Stack.Item>
      </Stack>
      :<Stack>
      <Stack.Item>
        <div className="code-sample">{code}</div>
      </Stack.Item>
    </Stack>
      }

      </Card.Section>
    </Card>
  );
};
