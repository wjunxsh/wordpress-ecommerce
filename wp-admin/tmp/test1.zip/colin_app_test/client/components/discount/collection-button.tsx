import { useAppBridge } from "@shopify/app-bridge-react";
import { ResourcePicker } from "@shopify/app-bridge/actions";
import {Button} from "@shopify/polaris"
import React from "react";
export interface Collection {
    id:string;
    image:{id:string;originalSrc:string;altText?:string} | undefined;
    productsCount:number;
    title:string;
}
interface Props {
  onChange: (collections: Collection[]) => void;
}

export const CollectionButton = (props: Props) => {
  const app = useAppBridge();
  const collectionPicker = ResourcePicker.create(app, {
    resourceType: ResourcePicker.ResourceType.Collection,
    options: {
      selectMultiple: true,
      showVariants: true,
    },
  });
  collectionPicker.subscribe(ResourcePicker.Action.SELECT, (selectPayload) => {
    const { selection } = selectPayload;
    //@ts-ignore
    if (process.dev) console.warn({ selection, select }); // handle, title, images
    let collections:Collection[] = [];
    for (const select of selection) {
      const { id, title, image, productsCount } = select;
      collections.push({
        id,
        title,
        image,
        productsCount,
      });
    }
    props.onChange(collections);
  });

  return (
    <Button
    outline
    onClick={() =>
      collectionPicker.dispatch(ResourcePicker.Action.OPEN)
    }
  >
    Add collection
  </Button>
  );
};
