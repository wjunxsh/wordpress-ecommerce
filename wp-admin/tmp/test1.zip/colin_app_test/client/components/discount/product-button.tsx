import { useAppBridge } from "@shopify/app-bridge-react";
import { ResourcePicker } from "@shopify/app-bridge/actions";
import {Button} from "@shopify/polaris"
import React from "react";
export interface Products {
    id:string;
        handle:string;
        title:string;
        image:{originalSrc:string;id:string;altText?:string}
        variants:any[];
        variant_counts: number;
}
interface Props {
  onChange: (products: Products[]) => void;
}
export const ProductButton = (props: Props) => {
  const app = useAppBridge();
  const productPicker = ResourcePicker.create(app, {
    resourceType: ResourcePicker.ResourceType.Product, // Product, ProductVariant, Collection
    options: {
      selectMultiple: true,
      showVariants: false,
    },
  });

  productPicker.subscribe(ResourcePicker.Action.SELECT, (selectPayload) => {
    const { selection } = selectPayload;
    //@ts-ignore
    if (process.dev) console.warn({ selection, select }); // handle, title, images
    let products = [];
    for (const select of selection) {
      const { id, title, images, variants } = select;
      products.push({
        id,
        title,
        images,
        variants,
      });
    }
    props.onChange(products);
  });
  return (
    <Button
    outline
    onClick={() =>
        productPicker.dispatch(ResourcePicker.Action.OPEN)
    }
  >
    Add products
  </Button>
  );
};
