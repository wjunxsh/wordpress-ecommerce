import { DiscountMethod } from "@shopify/discount-app-components";
import { DiscountData } from "./interface";
import { dateIsInRange } from "@shopify/polaris/build/ts/latest/src/utilities/dates";

export interface Error {
  [key: string]: "";
}
export interface RulePrice {
  [key: string]: any;
}
export const validatePriceRule = (discount: any): any => {
  let error: any = {};
  if (discount.discountMethod == DiscountMethod.Automatic) {
    if (!discount.discountTitle) {
      error["discountTitle"] = "Title can't be blank";
    }
  } else {
    if (!discount.discountCode) {
      error["discountCode"] = "Code can't be blank";
    }
  }
  if (!discount.mainVariants || !discount.mainVariants.length) {
    error["mainVariants"] = "Main variants can't be empty";
  }
  if (!discount.giftVariants || !discount.giftVariants.length) {
    error["giftVariants"] = "Gift variants can't be empty";
  }
  if (!discount.startsAt) {
    error["startsAt"] = "Start date can't be blank";
  }
  if (!discount.startsAt) {
    error["startsAt"] = "Start date can't be blank";
  }


  if (!discount.configuration.value_type) {
    error["value_type"] = "Value type can't be blank";
  }
  if (!discount.configuration.value) {
    error["value"] = "Value can't be blank";
  }else if (discount.configuration.value_type == "percentage") {
    if (discount.configuration.value > 100 || discount.configuration.value <= 0) {
      error["value"] = "Value must between 0 and 100";
    }
  }
  return error;
};
