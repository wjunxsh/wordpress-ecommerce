import { Button, Card, Icon, TextField, TextStyle } from "@shopify/polaris";
import React, { useEffect, useState } from "react";
import { useAuthenticatedFetch } from "../../hooks";
import { Loading, useAppBridge, useNavigate } from "@shopify/app-bridge-react";
let timeHandle = null;
export const SearchCode = () => {
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [discount, setDiscount] = useState({
    title: "",
    shopify_id: 0,
    shopify_domain: "",
    id: 0,
  });
  const navigate = useNavigate();
  const authenticatedFetch = useAuthenticatedFetch();
  useEffect(() => {
    if (timeHandle) {
      clearTimeout(timeHandle);
    }
    timeHandle = setTimeout(() => {
      getInfo();
    }, 300);
  }, [value]);
  const getInfo = async () => {
    if (!value) {
      setDiscount({ title: "", shopify_domain: "", shopify_id: 0, id: 0 });
      return false;
    }
    setLoading(true);
    try {
      let data = await authenticatedFetch("/api/bulk_code/search_code", {
        method: "get",
        query: {
          code: value,
        },
      });
      setDiscount({
        shopify_domain: data.info.shop_domain,
        title: data.info.title,
        shopify_id: data.info.shopify_id,
        id: data.info.id,
      });
    } catch (e) {
      setDiscount({ title: "", shopify_id: 0, shopify_domain: "", id: 0 });
      console.log(e);
    }
    setLoading(false);
  };
  const buttonClick = () => {
    navigate(
      `https://${discount.shopify_domain}/admin/discounts/${discount.shopify_id}/codes?query=${value}`
    );
  };
  return (
    <Card>
      <Card.Section>
        <TextField
          suffix={
            loading ? (
              <div style={{ marginTop: "-8px" }}>
                <Button size={"slim"} plain loading />
              </div>
            ) : null
          }
          label="Find discount by code"
          autoComplete="false"
          onChange={(value) => setValue(value)}
          value={value}
        />
        <TextStyle variation="subdued">
          {discount.id ? (
            <div style={{padding:"8px 0"}}>
              Code found in the{" "}
              <Button plain onClick={buttonClick}>
                {discount.title}
              </Button>{" "}
              discount.{" "}
            </div>
          ) : null}
        </TextStyle>
      </Card.Section>
    </Card>
  );
};
