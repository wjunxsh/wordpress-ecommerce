import { useAppBridge } from "@shopify/app-bridge-react";
import { ResourcePicker } from "@shopify/app-bridge/actions";
import {Button} from "@shopify/polaris"
import React from "react";
export interface Products {
    id:string;
        handle:string;
        title:string;
        images:{originalSrc:string;id:string;altText?:string}[]
        variants:any[];
        variant_counts: number;
}
interface Props {
  onChange: (products: Products[]) => void;
}
export const VariantsButton = (props: Props) => {
  const app = useAppBridge();
  const variantsPicker = ResourcePicker.create(app, {
    resourceType: ResourcePicker.ResourceType.Product, // Product, ProductVariant, Collection
    options: {
      selectMultiple: true,
      showVariants: true,
    },
  });

  variantsPicker.subscribe(ResourcePicker.Action.SELECT, (selectPayload) => {
    const { selection } = selectPayload;
    //@ts-ignore
    if (process.dev) console.warn({ selection, select }); // handle, title, images
    let products = [];
    for (const select of selection) {
      const { id, handle, title, images, variants } = select;
      products.push({
        id,
        handle,
        title,
        images,
        variants,
      });
    }
    props.onChange(products);
  });
  return (
    <Button
    outline
    onClick={() =>
      variantsPicker.dispatch(ResourcePicker.Action.OPEN)
    }
  >
    Add variants
  </Button>
  );
};
