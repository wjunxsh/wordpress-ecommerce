import React, { useState,memo } from "react";
import {
  CustomerEligibilityCard,
  Eligibility,
} from "@shopify/discount-app-components";

import CustomerSelector from "./customerSelector";
import { CustomerSegmentSelector } from "./customerSegmentSelector";
interface IProps {
  eligibility:Eligibility;
  prerequisite_customer_ids:number[];
  customer_segment_prerequisite_ids:number[];
}
export default memo( (props: {
  onChange: <T extends keyof IProps>(key:T,value:IProps[T]) => void;
  eligibility:Eligibility;
})=> {
  const [selectedCustomerSegments, setSelectedCustomerSegments] = useState([]);
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const onChangeSegments = (
    data: { id: string; name:string }[]
  ) => {
    props.onChange("customer_segment_prerequisite_ids",
      data.map((item) => {
        let paramsData = item.id.split("/");
        return parseInt(paramsData[paramsData.length - 1]);
      })
    );
    setSelectedCustomerSegments(data);

  };
  const onCustomerChange = (data: { id: string; email: string; displayName: string }[]) => {
    setSelectedCustomers(data);
    props.onChange("prerequisite_customer_ids",
      data.map((item) => {
        let paramsData = item.id.split("/");
        return parseInt(paramsData[paramsData.length - 1]);
      })
    );
  };
  return (
    <CustomerEligibilityCard
      eligibility={{
        value: props.eligibility,
        onChange: (data) => {props.onChange("eligibility",data)},
      }}
      selectedCustomerSegments={{
        value: selectedCustomerSegments,
        onChange: onChangeSegments,
      }}
      selectedCustomers={{
        value: selectedCustomers,
        onChange: onCustomerChange,
      }}
      customerSelector={
        <CustomerSelector
          selectedCustomers={selectedCustomers}
          setSelectedCustomers={onCustomerChange}
        />
      }
      customerSegmentSelector={
        <CustomerSegmentSelector
          selectedCustomerSegments={selectedCustomerSegments}
          setSelectedCustomerSegments={onChangeSegments}
        />
      }
    />
  );
})
