import {Badge, Button, Stack, Thumbnail } from "@shopify/polaris";
import React from "react";
import { CircleCancelMajor } from "@shopify/polaris-icons";
import { Collection } from "./collection-button";
import {ImageMajor} from "@shopify/polaris-icons"
interface Props {
  delete: (index: number) => void;
  collections: Collection[];
}
export const CollectionList = (props: Props) => {
  return (
    <>
      {props.collections.map((collection, index) => (
        <div className="product-item" key={collection.id}>
          <Stack>
            <Stack.Item fill>
              <Stack alignment="center" wrap={false}>
                {
                  <Thumbnail
                    size={"small"}
                    source={
                        collection.image
                        ? collection.image["originalSrc"]
                        : ImageMajor
                    }
                    alt={collection.image
                        ? collection.image["altTxt"]
                        : undefined}
                  />
                }
                <Stack.Item fill>{collection.title}</Stack.Item>
                <Badge>{`${collection.productsCount}`}</Badge>
                <Button
                  onClick={() => props.delete(index)}
                  plain
                  icon={CircleCancelMajor}
                ></Button>
              </Stack>
            </Stack.Item>
          </Stack>
        </div>
      ))}
    </>
  );
};
