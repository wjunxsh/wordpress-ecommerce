import { Badge, Button, Stack, Thumbnail } from "@shopify/polaris";
import React from "react";
import { Products } from "./product-button";
import { CircleCancelMajor } from "@shopify/polaris-icons";
import {ImageMajor} from "@shopify/polaris-icons"
interface Props {
  delete: (index: number) => void;
  products: Products[];
}
export const ProductList = (props: Props) => {
  return (
    <>
      {props.products.map((product, index) => (
        <div className="product-item" key={product.id}>
          <Stack>
            <Stack.Item fill>
              <Stack alignment="center" wrap={false}>
                {
                  <Thumbnail

                    size={"small"}
                    source={
                      product.image
                        ? product.image["originalSrc"]
                        : ImageMajor
                    }
                    alt={product.image
                        ? product.image["altText"]
                        : undefined}
                  />
                }
                <Stack.Item fill>{product.title}</Stack.Item>
                {product.variants.length > 0 && (
                  <Badge>{`${product.variants.length} variants selected`}</Badge>
                )}
                <span style={{display:"inline-block",marginTop:"10px"}}>
                <Button
                  onClick={() => props.delete(index)}
                  plain
                  size="slim"
                  icon={CircleCancelMajor}
                ></Button>
                </span>
              </Stack>
            </Stack.Item>
          </Stack>
        </div>
      ))}
    </>
  );
};
