import { useAppBridge, ResourcePicker } from "@shopify/app-bridge-react";
import { ResourcePicker as RP } from "@shopify/app-bridge/actions";
import { Button, ResourceItem } from "@shopify/polaris";
import React, { useEffect, useState } from "react";
export interface Collection {
  id: string;
  image: { id: string; originalSrc: string; altText?: string } | undefined;
  productsCount: number;
  title: string;
}
interface Props {
  sourceType: "product" | "collection" | "variant";
  onChange: (collections: Collection[]) => void;
}

export const ResourceButton = (props: Props) => {
  const app = useAppBridge();
  const [text, setText] = useState("Add Button");
  useEffect(() => {
    switch (props.sourceType) {
      case "collection":
        setText("Add collection");
        break;
      case "product":
        setText("Add product");
        break;
      case "variant":
        setText("Add variant");
        break;
    }
  }, [props.sourceType]);
  const [open, setOpen] = useState<boolean>(false);
  const onSelect = (selectPayload) => {
    let { selection } = selectPayload;
    let data = [];
    for (const select of selection) {
      if(props.sourceType == "collection"){
        data.push({
          id:select.id,
          title:select.title,
          image:select.image,
          productsCount:select.productsCount
        });
      }else{
        data.push({
          id:select.id,
          title:select.title,
          image:select.images[0],
          variants:select.variants
        });
      }

    }
    setOpen(false);
    props.onChange(data);
  };
  return (
    <>
      <Button outline onClick={() => setOpen(true)}>
        {text}
      </Button>
      {props.sourceType == "collection" ? (
        <ResourcePicker
          key={1}
          resourceType={"Collection"}
          onCancel={() => {
            setOpen(false);
          }}
          onSelection={onSelect}
          selectMultiple={true}
          open={open}
        />
      ) : (
        <ResourcePicker
        key={2}
          resourceType={"Product"}
          onCancel={() => {
            setOpen(false);
          }}
          onSelection={onSelect}
          showVariants={props.sourceType == "product" ? false : true}
          selectMultiple={true}
          open={open}
        />
      )}
    </>
  );
};
