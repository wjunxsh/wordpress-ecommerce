import { CurrencyCode } from "@shopify/react-i18n";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAppBridge } from "@shopify/app-bridge-react";
import React, { useEffect } from "react";
import {
  ActiveDatesCard,
  DiscountClass,
  DiscountMethod,
  MethodCard,
  DiscountStatus,
  RequirementType,
  SummaryCard,
  UsageLimitsCard,
  onBreadcrumbAction,
} from "@shopify/discount-app-components";
import {
  Banner,
  Card,
  Layout,
  Page,
  PageActions,
  FormLayout,
  Checkbox,
  DisplayText,
} from "@shopify/polaris";
import { useAuthenticatedFetch } from "../../hooks";
import RuleConfig from "../ruleConfig";
import { useState } from "react";
import { useParams } from "react-router-dom";
const todaysDate = new Date();
// const METAFIELD_NAMESPACE = "YOUR_NAMESPACE";
const METAFIELD_NAMESPACE = process.env.METAFIELD_NAMESPACE||"Volume";
const METAFIELD_CONFIGURATION_KEY = "volume-config";
const FUNCTION_ID = process.env.FUNCTION_ID || "01GF2X6SWCRS70H0N64C50R9RH";
export default function VolumeNew() {
  const params = useParams();
  const [discountData, setDiscountData] = useState({
    discountTitle: "",
    discountCode: "",
    discountMethod: DiscountMethod.Automatic,
    combinesWith: {
      orderDiscounts: false,
      productDiscounts: false,
      shippingDiscounts: false,
    },
    requirementType: RequirementType.None,
    requirementSubtotal: "0",
    requirementQuantity: "0",
    usageTotalLimit: null,
    usageOncePerCustomer: false,
    startDate: todaysDate,
    discountId: 0,
    metafieldId: 0,
    endDate: null,
    configuration: {
      isLevelSend: true,
      ruleConfig: [
        {
          mainSku: "",
          giftRules: [
            {
              sku: "",
              quantity: 0,
              price: 0,
            },
          ],
        },
      ],
    },
  });

  const app = useAppBridge();
  const redirect = Redirect.create(app);
  const currencyCode = CurrencyCode.Cad;
  const authenticatedFetch = useAuthenticatedFetch();

  const [act, setAct] = useState({
    isLoading: false,
    disabled: false,
  });
  const [submitErrors, setSubmitErrors] = useState([]);
  useEffect(() => {
    initData();
  }, []);
  const initData = async () => {
    if (!params.id) {
      return;
    }
    let response = await authenticatedFetch(
      "/api/discounts/code?id=" + params.id,
      {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      }
    );
    const data = (await response.json()).data;
    if (!data) {
      return false;
    }
    let discount = { ...discountData };
    discount.combinesWith = data.discountNode.discount.combinesWith;
    discount.discountId = data.discountNode.id;
    discount.endDate = data.discountNode.discount.endsAt;
    discount.startDate = data.discountNode.discount.startsAt;
    discount.discountTitle = data.discountNode.discount.title;
    discount.configuration = JSON.parse(data.discountNode.metafield.value);
    discount.metafieldId = data.discountNode.metafield.id;
    setDiscountData({ ...discount });
  };
  const onChange = (key: string, itemData: any) => {
    setDiscountData({ ...discountData, [key]: itemData });
  };
  const onSubmit = async (form: any) => {
    discountData.configuration.ruleConfig.map((rule) => {
      rule.giftRules.map((giftRule) => {
        giftRule.quantity = parseInt(`${giftRule.quantity}`);
        giftRule.price = parseFloat(`${giftRule.price}`);
      });
    });
    const discount: any = {
      //functionId: FUNCTION_ID,
      combinesWith: form.combinesWith,
      startsAt: form.startDate,
      endsAt: form.endDate,
      title: discountData.discountTitle,
      metafields: [
        {
          namespace: METAFIELD_NAMESPACE,
          key: METAFIELD_CONFIGURATION_KEY,
          type: "json",
          value: JSON.stringify({
            ...discountData.configuration,
            isLevelSend: true,
          }),
        },
      ],
    };
    if (discountData.metafieldId) {
      discount.metafields[0].id = discountData.metafieldId;
    }
    if (form.discountId) {
      discount.id = form.discountId;
    } else {
      discount.functionId = FUNCTION_ID;
    }

    let response;
    if (discount.id) {
      if (form.discountMethod === DiscountMethod.Automatic) {
        response = await authenticatedFetch(
          "/api/discounts/automatic?id=" + params.id,
          {
            method: "put",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ...discount, title: form.discountTitle }),
          }
        );
      } else {
        response = await authenticatedFetch(
          "/api/discounts/code?id=" + params.id,
          {
            method: "put",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              ...discount,
              title: form.discountCode,
              code: form.discountCode,
            }),
          }
        );
      }
    } else {
      if (form.discountMethod === DiscountMethod.Automatic) {
        response = await authenticatedFetch("/api/discounts/automatic", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: { ...discount, title: form.discountTitle },
        });
      } else {
        response = await authenticatedFetch("/api/discounts/code", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: {
            ...discount,
            title: form.discountCode,
            code: form.discountCode,
          },
        });
      }
    }

    const data = (await response.json()).data;
    const remoteErrors = data.discountCreate.userErrors;
    if (remoteErrors.length > 0) {
      return { status: "fail", errors: remoteErrors };
    }

    redirect.dispatch(Redirect.Action.ADMIN_SECTION, {
      name: Redirect.ResourceType.Discount,
    });
    return { status: "success" };
  };
  const errorBanner =
    submitErrors.length > 0 ? (
      <Layout.Section>
        <Banner status="critical">
          <p>There were some issues with your form submission:</p>
          <ul>
            {submitErrors.map(({ message, field }, index) => {
              return <li key={`${message}${index}`}>{message}</li>;
            })}
          </ul>
        </Banner>
      </Layout.Section>
    ) : null;

  return (
    <Page
      title="Create volume discount"
      breadcrumbs={[
        {
          content: "Discounts",
          onAction: () => onBreadcrumbAction(redirect, true),
        },
      ]}
      primaryAction={{
        content: "Save",
        //@ts-ignore
        onAction: () => onSubmit({ ...discountData }),
        disabled: act.disabled,
        loading: act.isLoading,
      }}
    >
      <Layout>
        {errorBanner}
        <Layout.Section>
          <MethodCard
            title="Volume"
            discountTitle={{
              value: discountData.discountTitle,
              onChange: (value) => {
                onChange("discountTitle", value);
              },
            }}
            discountClass={DiscountClass.Product}
            discountCode={{
              value: discountData.discountCode,
              onChange: (value) => {
                onChange("discountCode", value);
              },
            }}
            discountMethod={{
              value: discountData.discountMethod,
              onChange: (value) => {
                onChange("discountMethod", value);
              },
            }}
          />
          <RuleConfig
            onChange={(value) =>
              onChange("configuration", {
                ...discountData.configuration,
                ruleConfig: value,
              })
            }
            ruleConfig={discountData.configuration.ruleConfig || []}
          />
          {discountData.discountMethod === DiscountMethod.Code && (
            <UsageLimitsCard
              totalUsageLimit={{
                value: discountData.usageTotalLimit,
                onChange: (value) => {
                  onChange("usageTotalLimit", value);
                },
              }}
              oncePerCustomer={{
                value: discountData.usageOncePerCustomer,
                onChange: (value) => {
                  onChange("usageOncePerCustomer", value);
                },
              }}
            />
          )}
          <Card title="Combinations">
            <Card.Section>
              <FormLayout>
                <DisplayText size="small">Good evening, Dominic.</DisplayText>
                <Checkbox
                  onChange={() => {
                    onChange("combinesWith", {
                      ...discountData.combinesWith,
                      productDiscounts:
                        !discountData.combinesWith.productDiscounts,
                    });
                  }}
                  checked={discountData.combinesWith.productDiscounts}
                  label="Other product discounts"
                />
                <Checkbox
                  onChange={() => {
                    onChange("combinesWith", {
                      ...discountData.combinesWith,
                      shippingDiscounts:
                        !discountData.combinesWith.shippingDiscounts,
                    });
                  }}
                  checked={discountData.combinesWith.shippingDiscounts}
                  label="Shipping discounts"
                />
              </FormLayout>
            </Card.Section>
          </Card>
          <ActiveDatesCard
            startDate={{
              value: discountData.startDate,
              onChange: (startDate) => {
                onChange("startDate", startDate);
              },
            }}
            endDate={{
              value: discountData.endDate,
              onChange: (endDate) => {
                onChange("endDate", endDate);
              },
            }}
            timezoneAbbreviation="EST"
          />
        </Layout.Section>
        <Layout.Section secondary>
          <SummaryCard
            header={{
              discountMethod: discountData.discountMethod,
              discountDescriptor:
                discountData.discountMethod === DiscountMethod.Automatic
                  ? discountData.discountTitle
                  : discountData.discountCode,
              appDiscountType: "Volume",
              isEditing: false,
            }}
            performance={{
              status: DiscountStatus.Scheduled,
              isEditing: false,
              usageCount: 0,
            }}
            activeDates={{
              startDate: discountData.startDate,
              endDate: discountData.endDate,
            }}
          />
        </Layout.Section>
        <Layout.Section>
          <PageActions
            primaryAction={{
              content: "Save discount",
              //@ts-ignore
              onAction: () => onSubmit({ ...discountData }),
              disabled: act.disabled,
              loading: act.isLoading,
            }}
            secondaryActions={[
              {
                content: "Discard",
                onAction: () => onBreadcrumbAction(redirect, true),
              },
            ]}
          />
        </Layout.Section>
      </Layout>
    </Page>
  );
}
