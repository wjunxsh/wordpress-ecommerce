import {
  DiscountMethod,
  RequirementType,
} from "@shopify/discount-app-components";
export interface DiscountData {
  shopify_id:number;
  id:number;
  graphql_shopify_id:string;
  discountTitle: string;
  discountCode: string;
  discountMethod: DiscountMethod;
  combinesWith: {
    orderDiscounts: boolean;
    productDiscounts: boolean;
    shippingDiscounts: boolean;
  };
  usageTotalLimit: number | null;
  usageOncePerCustomer: boolean;
  startsAt: Date | null;
  endsAt: Date | null;
  configuration: {
    value: number;
    value_type: "percentage" | "fixed_amount";
  };
}
