import { Button, Select, Stack, TextField } from "@shopify/polaris";
import React, { useState, useCallback, useEffect, memo } from "react";
import { useAuthenticatedFetch } from "../../hooks";
import { useLocalizeCountry } from "@shopify/discount-app-components";
import { CircleCancelMajor } from "@shopify/polaris-icons";
interface Option {
  value: string;
  label: string;
}
export const CountrySector = memo(
  (props: { ids: string[]; onChange: (list: string[]) => void;}) => {
    const [state, setState] = useState<{
      value: string;
      countries: Option[];
      origin_countries: Option[];
      list: Option[];
    }>({ value: "", countries: [], list: [], origin_countries: [] });
    const onChange = (value: string) => {
      setState({ ...state, value: value });
    };
    const authenticatedFetch = useAuthenticatedFetch();
    useEffect(() => {
      setState({
        ...state,
        countries: state.origin_countries.filter(
          (item) => !props.ids.includes(item.value)
        ),
        list: state.origin_countries.filter((item) =>
          props.ids.includes(item.value)
        ),
        value: "",
      });
    }, [props.ids]);
    useEffect(() => {
      getCountries();
    }, []);
    const getCountries = async () => {
      let data = await authenticatedFetch("/api/discounts/countries", {
        method: "post",
      });
      let countries = data;
      let origin_countries: Option[] = [
        { label: "Select country", value: "" },
        ...countries
          .filter((item) => item.code != "*")
          .map((item) => ({ label: item.name, value: `${item.id}` })),
      ];
      setState({
        ...state,
        countries: [...origin_countries],
        origin_countries,
      });
    };
    const add = () => {
      let ids = [...props.ids];
      ids.push(state.value);
      props.onChange(ids);
    };
    const del = (value) => {
      let ids = props.ids.filter((id) => id !== value);
      props.onChange(ids);
    };
    return (
      <div>
        <Stack>
          <Stack.Item fill>
            <Select
              label=""
              options={state.countries}
              onChange={onChange}
              value={state.value}
            ></Select>
          </Stack.Item>
          <Stack.Item>
            <Button disabled={state.value == ""} onClick={add}>
              Add
            </Button>
          </Stack.Item>
        </Stack>
        {state.list.map((item) => (
          <div className="common-item" key={item.value}>
            <Stack>
              <Stack.Item fill>{item.label}</Stack.Item>
              <Stack.Item>
                <Button
                  onClick={() => del(item.value)}
                  plain
                  size="slim"
                  icon={CircleCancelMajor}
                ></Button>
              </Stack.Item>
            </Stack>
          </div>
        ))}
      </div>
    );
  }
);
