
export interface SelectOption{
  value:string|number;
  label:string;
}

export interface Pagination{
  current_page:number;
  page_size:number;
  total_size:number;
  total_pages:number;
}
export interface ShopItem{
  id:number;
  shopify_domain:string;
}

export interface ResultData<ResultType> {
  code:number;
  msg:string;
  data:ResultType
}
