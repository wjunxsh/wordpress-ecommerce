import { ColumnsType } from "antd/lib/table";
import { LoadingOutlined } from "@ant-design/icons";
import React from "react";
import { Spin, Tag } from "antd";
export interface DiscountItem {
  variant_id: number;
  loading: boolean;
  handle: string;
  sku: string;
  value: number;
  value_type: string;
  start_date: string;
  end_date: string;
  status: {
    code: number;
    msg: string;
    data: any;
  } | null;
}
export const columns: ColumnsType<DiscountItem> = [
  {
    title: "index",
    dataIndex: "index",
    align: "center",
    width: 78,
    ellipsis: true,
  },
  {
    title: "状态",
    dataIndex: "status",
    width: 200,
    ellipsis: true,
  },
  {
    title: "Code",
    dataIndex: "code",
    width: 200,
    ellipsis: true,
    render: (text) => <Tag color="error">{text}</Tag>,
  },
  {
    title: "产品handle",
    dataIndex: "handle",
    width: 180,
  },
  {
    title: "Sku",
    dataIndex: "sku",
    width: 180,
  },
  {
    title: "活动值",
    dataIndex: "value",
    width: 78,
    ellipsis: true,
  },
  {
    title: "活动类型",
    dataIndex: "value_type",
    width: 120,
    ellipsis: true,
  },
  {
    title: "开始时间",
    dataIndex: "start_date",
    width: 210,
    ellipsis: true,
  },
  {
    title: "结束时间",
    dataIndex: "end_date",
    width: 210,
    ellipsis: true,
  },
];
