import { Tag } from 'antd';
import { ColumnsType } from 'antd/lib/table';
import { FunctionItem } from './interface';
export const columns: ColumnsType<FunctionItem> = [
  {
    title: 'uuid',
    dataIndex: 'index',
    align: 'center',
    width: 180,
    ellipsis: true,
    render: (text, record: FunctionItem) => record.function_key,
  },
  {
    title: '标题',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'title',
  },
  {
    title: '函数描述',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'details',
  },
  {
    title: '代码',
    align: 'left',
    width: 120,
    ellipsis: true,
    dataIndex: 'code',
  },
  {
    title: '活动类型',
    align: 'left',
    width: 120,
    dataIndex:"is_order",
    ellipsis: true,
    render: (text)=>  text ? <Tag color="magenta">订单维度</Tag>: <Tag color="blue">产品维度</Tag>,
  },
  {
    title: '操作',
    dataIndex: 'id',
    ellipsis: true,
    width: 68,
    align: 'left',
    fixed: 'right',
    render: (text) => text,
  },
];
