import { FormInstance } from "antd";

export type CodeType = "common"|"shop_self"|"util_common";
export interface FunctionItem{
  id:number;
  function_key:string;
  title:string;
  code_type:CodeType;
  shop_id:string;
  details:string;
  code:string;
  is_order:boolean;
  created_at:string;
  updated_at:string;
  label:string;
  value:string;
  relate_functions:any[];
}
export interface Istate{
  edit_info:null | FunctionItem;
  edit_visible:boolean;
  funcList:FunctionItem[];
  show_details:string;
  show_visible:boolean,
  show_code_visible:boolean,
  show_code:string;
}
export interface EditProps{
  info:FunctionItem | null;
  visible:boolean;
  onSuccess:()=> void;
  onCancel:()=> void;
}
