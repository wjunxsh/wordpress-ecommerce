import { Modal, Input, Select, Form, Space, Button, message } from 'antd';
import { CodeType, EditProps, FunctionItem } from './interface';
import { useEffect, useMemo, useRef, useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import './style.less';
import Editor from "@monaco-editor/react";
import { ResultData } from '@components/common_interface';
import { judgements } from '../simple_data';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
export const codeOptions = {
  selectOnLineNumbers: true,
  renderSideBySide: false,
};

const CODE_TYPE = [
  { label: 'common', value: 'common' },
  { label: 'shop_self', value: 'shop_self' },
  { label: 'util_common', value: 'util_common' },
];
const createGuid = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0,
      v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export const FunctionEdit = (props: EditProps) => {
  const { visible, info } = props;
  const authenticatedFetch = useAuthenticatedFetch();
  const [type, setCopyType] = useState<CodeType>('common');
  const [shops, setShops] = useState([]);
  const [funList, setFunctions] = useState<FunctionItem[]>([]);
  useEffect(() => {
    setTimeout(() => {
      //要等富文本渲染完成再初始化
      linkForm.resetFields();
    }, 100)

    if (visible) {
      if (!funList.length) getFunList();
    }
    setCopyType(info && info.code_type ? info.code_type : 'common');
  }, [visible]);
  const modules: any = useMemo(
    // useMemo: 解决自定义失焦问题
    () => ({
      toolbar: {
        container: [
          ['bold', 'italic'], // 加粗，斜体，下划线，删除线
          ['link' /**'video' */], // 上传链接、图片、上传视频
          [{ list: 'ordered' }, { list: 'bullet' }], // 列表
          [{ indent: '-1' }, { indent: '+1' }], // 缩进
          [{ direction: 'rtl' }], // 文本方向
          [{ size: ['small', false, 'large', 'huge'] }], // 字体大小
          [{ header: [1, 2, 3, 4, 5, 6, false] }], // 几级标题
          [{ color: [] }, { background: [] }], // 字体颜色，字体背景颜色
          ['clean'], // 清除字体样式
        ],
      },
    }),
    []
  );
  const onCreate = async (data: any) => {
    try {
      let result: any = await authenticatedFetch('/api/functions/save', {
        method: 'post',
        body: {
          function_key: data.function_key,
          shop_id: data.shop_id == 'null' ? undefined : data.shop_id,
          code: data.code,
          id: data.id,
          title: data.title,
          relate_functions: data.relate_functions,
          code_type: data.code_type,
          is_order: data.is_order,
          details: data.details,
        }
      });
      props.onSuccess();
    } catch (e:any) {
      message.error(e.message || e.msg);
      console.error(e);
    }
  };
  const [linkForm] = Form.useForm();
  const reactQuillRef = useRef();
  const options: any = {
    placeholder: '请输入内容...',
    theme: 'snow',
    readOnly: false, // 是否只读
    className: 'ql-editor', //组件要加上(className=“ql-editor”)样式类名,否则空格不回显
    modules: modules,
    ref: reactQuillRef,
    style: {
      height: 300,
      overflow: 'hidden',
      borderBottom: '1px solid #ccc',
    },
  };

  const getFunList = async () => {
    try {
      let data = await authenticatedFetch('/api/functions/list', {
        method: 'get',
        query: {
          current_page: 1,
          page_size: 100,
        }
      });
      setFunctions(data.list.map((item: any) => ({ ...item, label: item.title, value: item.function_key })));
    } catch (e) {
      console.log(e);
    }
  };
  return (
    <Modal
      title='编辑链接'
      onCancel={() => {
        props.onCancel();
      }}
      className={'func-edit-modal'}
      width={1200}
      cancelText={'放弃'}
      okText={'保存'}
      onOk={() => {
        linkForm
          .validateFields()
          .then((values) => {
            onCreate(values);
          })
          .catch((info) => {
            console.log('Validate Failed:', info);
          });
      }}
      open={visible}>
      <div style={{ maxHeight: '520px', marginBottom: '12px', overflowY: 'auto' }}>
        <Form form={linkForm} initialValues={undefined} labelCol={{ span: 4 }} labelWrap layout='horizontal' wrapperCol={{ span: 16 }}>
          <Form.Item initialValue={info ? info.id : 0} hidden label='id号' name='id'>
            <Input />
          </Form.Item>
          <Form.Item initialValue={info ? info.function_key : ""} label='函数唯一识别码' name='function_key' rules={[{ required: true, message: '请输入识别码' }]}>
            <Input suffix={<Button size={"small"} type={"primary"} onClick={() => {
              linkForm.setFieldValue("function_key", createGuid());
            }}>Auto</Button>} />
          </Form.Item>
          <Form.Item rules={[{ required: true, message: '请输入标题' }]} initialValue={info ? info.title : ""} label='标题' name='title'>
            <Input />
          </Form.Item>
          <Form.Item initialValue={info ? info.code_type : 'common'} label='函数类型' name='code_type'>
            <Select onChange={(value) => setCopyType(value)} options={CODE_TYPE} />
          </Form.Item>
          <Form.Item
            initialValue={info ? info.is_order : false}
            label='订单维度活动'
            name='is_order'>
            <Select
              options={judgements}
            />
          </Form.Item>
          <Form.Item
            initialValue={info?.relate_functions ? info.relate_functions : undefined}
            label='选择依赖的函数'
            name='relate_functions'>
            <Select mode="multiple" options={funList} />
          </Form.Item>
          <Form.Item initialValue={info ? info.code : '# some comment'} label='折扣代码' name='code' rules={[{ required: true, message: '请输入代码' }]}>
            <div style={{ border: '1px solid #efefef' }}>
              <Editor
                height="300px"
                defaultLanguage="ruby"
                theme='Active4D'
                onChange={(value) => {
                  linkForm.setFieldValue('code', value);
                }}
                defaultValue={info ? info.code : '# some comment'}
              />
            </div>
          </Form.Item>
          <Form.Item initialValue={info ? info.details : '//请输入内容'} label='详情' name='details' rules={[{ required: true, message: '请输入描述' }]}>
            <ReactQuill style={{ padding: 0 }} {...options} />
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
};
