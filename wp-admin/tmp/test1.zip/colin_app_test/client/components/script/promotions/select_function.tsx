
import { Col, Modal, Row, Select } from 'antd';
import { useEffect, useState } from 'react';
import { FunctionItem } from '../functions/interface';
import { ResultData } from '@components/common_interface';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
export interface FProps {
  visible: boolean;
  onCancel: () => void;
  onOk: (value: string) => void;
}

const SelectFunctionModal = ({ visible, onCancel, onOk, ...props }: FProps) => {
  const [funList, setFunctions] = useState<FunctionItem[]>([]);
  const [functionKey, setKey] = useState<string>('');
  const authenticatedFetch = useAuthenticatedFetch();
  useEffect(() => {
    if (visible && !funList.length) {
      getList();
    }
  }, [visible]);
  const getList = async () => {
    try {
      let data: {list:any[]} = await authenticatedFetch('/api/functions/list', {
        method: "get",
        query: {
          current_page: 1,
          page_size: 100,
          code_type: "common"
        }
      });
      console.log(data);
      setFunctions(data.list.map((item: any) => ({ ...item, label: item.title, value: item.function_key })));
    } catch (e) {
      console.log(e);
    }
  };
  return (
    <Modal title={"请选择活动类型"} width={600} open={visible} onCancel={() => onCancel()} okButtonProps={{ disabled: functionKey ? false : true }} onOk={() => onOk(functionKey)}>
      <div style={{ maxHeight: '450px', padding: "8px", overflowY: 'auto', marginTop: "30px" }}>
        <Row gutter={[8, 8]}>
          <Col span={24}>
            <Select
              style={{ width: "100%" }}
              value={functionKey}
              onChange={(value) => {
                setKey(value);
              }}
              options={funList}
            />
          </Col>
          <Col span={24}>
            <div style={{ minHeight: '240px' }}>
              <div className='ql-snow'>
                <div className='ql-editor' dangerouslySetInnerHTML={{ __html: functionKey ? funList.find(item => item.function_key == functionKey)?.details || "" : "" }}></div>
              </div>
            </div>
          </Col>
        </Row>
      </div>
    </Modal>
  );
};

export default SelectFunctionModal;
