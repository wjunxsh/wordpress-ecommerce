import { Select, Spin } from "antd"
import type { SelectProps } from 'antd/es/select';
import { useEffect, useMemo, useRef, useState } from "react";
import debounce from 'lodash/debounce';
import { useAuthenticatedFetch } from "@hooks/useAuthenticatedFetch";
export interface SearchSelectProps<ValueType = any>
  extends Omit<SelectProps<ValueType | ValueType[]>, 'options' | 'children'> {
  url: string;
  is_sync_search?: boolean;
  debounceTimeout?: number,
  query?: { [key: string]: any, shop_id: string; }
}
function SearchSelect
  <ValueType extends { key?: string; label: React.ReactNode; value: string | number } = any>
  ({ url, debounceTimeout = 800, is_sync_search = true, query, ...props }: SearchSelectProps<ValueType>) {
  const [options, setOptions] = useState<ValueType[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const authenticatedFetch = useAuthenticatedFetch();
  const onSearch = useMemo(() => {
    return debounce(async (value: string) => {
      fetchRef.current += 1;
      const fetchId = fetchRef.current;
      setOptions([]);
      setLoading(true);
      try {
        let result = await authenticatedFetch(url, {
          method: 'get',
          query: {
            page_size: 100,
            search: value,
            ...query
          }
        });
        let list = result.list
        setOptions(list);

        if (fetchId !== fetchRef.current) {
          return;
        }
      } catch (e) {
        console.log(e)
      }

      setLoading(false);

    }, debounceTimeout)
  }, [options, query]);
  const fetchRef = useRef(0);
  return <Select
    onFocus={() => { onSearch("") }}
    labelInValue
    filterOption={is_sync_search ? false : (input, option) => `${option?.label ?? ''}`.toLowerCase().includes(input.toLowerCase())}
    {...props}
    showSearch={true}
    notFoundContent={loading ? <Spin size="small" /> : null}
    options={options} onSearch={onSearch}>

  </Select>
}

export { SearchSelect };
