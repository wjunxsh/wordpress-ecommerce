import { Col, Modal, Row, Select, Table } from 'antd';
import { useEffect, useState } from 'react';
import { DiscountItem } from './interface';
import { columns } from './log_columns';
import { Pagination, ResultData } from '@components/common_interface';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
export interface FProps {
  onCancel: () => void;
  record:DiscountItem<any> | null
}
const scrollY = document.body.scrollHeight - 480;
const LogsModal = ({ record, onCancel, ...props }: FProps) => {
  const [logList, setLogs] = useState<DiscountItem<any>[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [pagination, setPagination] = useState<Pagination>({ current_page: 1, total_pages: 1, page_size: 10, total_size: 1 });
  const authenticatedFetch = useAuthenticatedFetch();
  useEffect(() => {
    if (record) {
      getList();
    }else{
      setLogs([]);
    }
  }, [record]);
  const getList = async () => {
    if (loading) {
      return;
    }
    setLoading(true);
    try {
      let data = await authenticatedFetch('/api/script/discount/log/list', {
        method: 'get',
        query:{
          current_page: 1,
          page_size: 100,
          code_type:"common",
          discount_id:record?.id,
        }
      });
      setLogs(data.list.map((item: any) => ({ ...item, label: item.title, value: item.function_key })));
      pagination.current_page = data.pagination.current_page;
      pagination.page_size = data.pagination.page_size;
      pagination.total_pages = data.pagination.total_page;
      pagination.total_size = data.pagination.total_size;
      setPagination(pagination);
      setLoading(false);
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };
  return (
    <Modal okText={"关闭"} cancelText={" "} title={`${record ? record.title : ""} 活动日志`} width={800} open={record ? true : false} onOk={() => onCancel()} onCancel={() => onCancel()} cancelButtonProps={{ disabled:true,type:"link" }}>
      <div style={{ padding:"8px", overflowY: 'auto' }}>
      <Table
            rowKey={(record) => record.id}
            scroll={{ x: 1040, y: scrollY }}
            loading={loading}
            dataSource={logList}
            pagination={{
              showSizeChanger: true,
              pageSizeOptions: [10, 20, 50],
              onChange: (page, page_size) => {
                setPagination({ ...pagination, current_page: page, page_size });
              },
              current: pagination.current_page,
              pageSize: pagination.page_size,
              total: pagination.total_size,
            }}
            columns={columns}></Table>
      </div>
    </Modal>
  );
};

export default LogsModal;
