import { Input, Select, Form, Button, Drawer, Row, Col, DatePicker, Divider, Tooltip, InputNumber, Alert } from 'antd';
import { BuyMoreThanOneDiscount, EditProps, EveryManLiJian, LevelManLiJian } from '../interface';
import { useEffect, useState } from 'react';
import 'react-quill/dist/quill.snow.css';
import { ExclamationCircleOutlined, MinusCircleOutlined, PlusOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { SearchSelect } from '../search_select';
import dayjs, { Dayjs } from 'dayjs';
import { discountTypes, discountTypesObj, judgements } from '@components/script/simple_data';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
const BuyMoreThanOneDiscountEdit = (props: EditProps<BuyMoreThanOneDiscount>) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [discount_type, setType] = useState<string>('');
  const authenticatedFetch = useAuthenticatedFetch();
  const { info, visible } = props;
  useEffect(() => {
    ruleForm.resetFields();
    setType(info ? info.config.discount_type : 'fix_discount_amount');
  }, [visible]);
  const onCreate = async (data: any) => {
    if (loading) return;
    setLoading(true);
    try {
      let result = await authenticatedFetch('/api/script/discount/save', {
        method: "post",
        body: {
          title: data.title,
          starts_at: dayjs(data.starts_at).format('YYYY-MM-DD HH:mm:ss'),
          ends_at: data.ends_at ? dayjs(data.ends_at).format('YYYY-MM-DD HH:mm:ss') : null,
          active: 'active',
          function_id: 'b4846a0f-4b70-4c75-bd08-f22b3bfdc7c1',
          id: data.id ?? 0,
          config: {
            dc_mutex: data.dc_mutex,
            mutex: data.mutex,
            promise_repeat:data.promise_repeat,
            limit_skus: data.limit_skus || [],
            discount_value: data.discount_value,
            discount_type: data.discount_type,
            min_buy_qty: data.min_buy_qty,
            limit_product_tag: data.limit_product_tag,
            property_key: data.property_key || '',
            message: data.message,
          },
        }

      });
      props.onSuccess(result.discountInfo);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };
  const disabledDate = (current: Dayjs) => {
    return current && current < dayjs().subtract(1, 'day').startOf('day');
  };
  const [ruleForm] = Form.useForm();
  return (
    <Drawer onClose={props.onCancel} width={'88vw'} open={visible} title='买X件产品最便宜的打折活动'>
      <div className='page'>
        <Form disabled={loading} form={ruleForm}>
          <Row gutter={[4, 0]}>
            <Col span={12}>
              <Form.Item hidden initialValue={info?.id} name='id' label='id号'>
                <Input />
              </Form.Item>
              <Form.Item name='title' initialValue={info?.title} rules={[{ required: true, message: '请输入活动标题' }]} label='活动标题'>
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='discount_type' initialValue={info?.config.discount_type} rules={[{ required: true, message: '请选择活动类型' }]} label='折扣类型'>
                <Select
                  options={discountTypes.filter(item => item.value != "fix_amount")}
                  onChange={(value) => {
                    setType(value);
                  }}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='dc_mutex' initialValue={info?.config.dc_mutex} rules={[{ required: true, message: '请选择是否互斥' }]} label='code互斥'>
                <Select options={judgements} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='mutex' initialValue={info?.config.mutex ?? true} rules={[{ required: true, message: '请选择' }]} label='与其他script互斥'>
                <Select options={judgements} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='promise_repeat' initialValue={info?.config.promise_repeat ?? false} rules={[{ required: true, message: '请选择' }]} label='允许叠加'>
                <Select options={judgements} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='property_key'
                initialValue={info?.config.property_key}
                label={
                  <Tooltip title='如果活动是针对特定主题页的，则此属性为必填项目。不填则默认为针对全场活动，而且属性必须以__划线开头' color='geekblue'>
                    专题页活动特有属性
                    <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                  </Tooltip>
                }>
                <Input />
              </Form.Item>
            </Col>
            
            <Col span={12}>
              <Form.Item name='min_buy_qty' initialValue={info?.config.min_buy_qty || 1} label='最小购买量'>
                <InputNumber style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item rules={[
                  {
                    validator: (rule, value: Dayjs) => {
                      let limit_skus = ruleForm.getFieldValue('limit_skus');
                      if((!limit_skus || !limit_skus.length) && !value){
                        return Promise.reject('产品标记或者sku限制不能都为空');
                      }
                      return Promise.resolve();
                    },
                  },
                ]} label={
                <Tooltip title='如果只想部分产品参与这个活动的时候，则在对应的产品上设置这个product_tag进行活动范围的控制，如果活动的这个值为空，则表明除了赠品外的所有产品价格都会计入到参与活动的总金额中' color='geekblue'>
                  限制活动生效范围的产品标签
                  <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                </Tooltip>
              } name='limit_product_tag' initialValue={info?.config.limit_product_tag}>
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='limit_skus'
                initialValue={info?.config.limit_skus}
                label={'选择参与活动的sku'}>
                <SearchSelect mode={'multiple'} url={'/api/basic/variants'} />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item label='Checkout页展示的文案' name='message' initialValue={info?.config.message} rules={[{ required: true, message: '活动文案必须填写' }]} >
                <Input />
              </Form.Item>
            </Col>

            <Col span={24}><Alert style={{ marginBottom: '8px' }} message={`针对订单维度的活动，发布即生效，开始时间和结束时间不再生效`} type="error" /></Col>
            <Col span={12}>
              <Form.Item
                initialValue={info ? dayjs(info.starts_at, 'YYYY-MM-DD HH:mm:ss') : dayjs()}
                rules={[{ required: true, message: '活动开始时间必须填写' }]}
                name='starts_at'
                label={<Tooltip title='时间对应的时区为shopify对应的店铺所在时区' color='geekblue'>
                  活动开始时间
                  <ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                </Tooltip>}>
                <DatePicker disabled disabledDate={disabledDate} showTime format='YYYY-MM-DD HH:mm:ss' style={{ display: 'block' }} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='ends_at'
                initialValue={info?.ends_at ? dayjs(info.ends_at, 'YYYY-MM-DD HH:mm:ss') : null}
                rules={[
                  {
                    validator: (rule, value: Dayjs) => {
                      if (!value) return Promise.resolve();
                      if (value.isBefore(new Date(), 'day')) {
                        return Promise.reject('结束时间不能晚于当前时间');
                      }
                      let starts_at = ruleForm.getFieldValue('starts_at');
                      if (starts_at && value.isBefore(starts_at, 'day')) {
                        return Promise.reject('结束时间不能早于开始时间');
                      }
                      return Promise.resolve();
                    },
                  },
                ]}
                label={<Tooltip title='时间对应的时区为shopify对应的店铺所在时区' color='geekblue'>
                  活动结束时间
                  <ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                </Tooltip>}>
                <DatePicker disabled showTime format='YYYY-MM-DD HH:mm:ss' style={{ display: 'block' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                initialValue={info?.config.discount_value}
                rules={[{ type: 'number' }, {
                  validator: (rule, value) => {
                    if (value < 0) {
                      return Promise.reject("必须大于0");
                    }
                    if (discount_type == "percentage" && value > 100) {
                      return Promise.reject("折扣百分比不能大于100%")
                    }
                    return Promise.resolve();
                  }
                }, { required: true, message: '不允许为空' }]}
                name={'discount_value'}
                label={discount_type ? discountTypesObj[discount_type] : '固定价格'}>
                <InputNumber style={{ width: '100%' }} />
              </Form.Item>
            </Col>
          </Row>

        </Form>
        <Divider />
        <div style={{ textAlign: 'right' }}>
          <Button
            onClick={() => {
              ruleForm
                .validateFields()
                .then((values) => {
                  onCreate(values);
                })
                .catch((info) => {
                });
            }}
            loading={loading}
            type='primary'>
            Save
          </Button>
        </div>
      </div>
    </Drawer>
  );
};

export default BuyMoreThanOneDiscountEdit;
