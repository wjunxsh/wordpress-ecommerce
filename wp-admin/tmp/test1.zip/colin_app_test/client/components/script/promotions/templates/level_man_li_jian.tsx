import { Input, Select, Form, Button, Drawer, Row, Col, DatePicker, Divider, Tooltip, InputNumber, Alert, Upload, message } from 'antd';
import { EditProps, LevelManLiJian } from '../interface';
import { useEffect, useState } from 'react';
import 'react-quill/dist/quill.snow.css';
import { ExclamationCircleOutlined, MinusCircleOutlined, PlusOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { SearchSelect } from '../search_select';
import dayjs, { Dayjs } from 'dayjs';
import { discountTypes, discountTypesObj, judgements } from '@components/script/simple_data';
import { useAuthenticatedFetch, useAuthenticatedFetchUpload } from '@hooks/useAuthenticatedFetch';
import { UploadFile } from 'antd/lib/upload';
import { RcFile } from 'antd/es/upload';
const FUNCTION_ID = '94ee915b-038f-4015-b110-2070c8a04805';
const LevelManLiJianEdit = (props: EditProps<LevelManLiJian>) => {
  const [discount_type, setType] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const authenticatedFetch = useAuthenticatedFetch();
  const aFetch = useAuthenticatedFetchUpload();
  const { info, visible } = props;
  useEffect(() => {
    setType(info ? info.config.discount_type : 'fix_discount_amount');
    ruleForm.resetFields();
  }, [visible]);
  const onCreate = async (data: any) => {
    if (loading) return;
    setLoading(true);
    try {
      let result = await authenticatedFetch('/api/script/discount/save', {
        method: "post",
        body: {
          title: data.title,
          starts_at: dayjs(data.starts_at).format('YYYY-MM-DD HH:mm:ss'),
          ends_at: data.ends_at ? dayjs(data.ends_at).format('YYYY-MM-DD HH:mm:ss') : null,
          active: 'active',
          function_id: FUNCTION_ID,
          id: data.id ?? 0,
          config: {
            dc_mutex: data.dc_mutex,
            metafield_key:data.metafield_key,
            discount_type: data.discount_type,
            exclude_skus: data.exclude_skus,
            discount_rule: data.discount_rule,
            min_buy_qty: data.min_buy_qty,
            limit_product_tag: data.limit_product_tag,
            property_key: data.property_key || '',
            message: data.message,
          },
        }

      });
      props.onSuccess(result.discountInfo);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };
  const disabledDate = (current: Dayjs) => {
    return current && current < dayjs().subtract(1, 'day').startOf('day');
  };
  const multUpload = async (file: RcFile) => {
    let formData = new FormData();
    if (loading) {
      return false;
    }
    setLoading(true);
    formData.append('file', file);
    formData.append('function_id', FUNCTION_ID);
    try {
      let result = await aFetch("/api/script/discount/mult_upload", {
        body: formData,
        method: "post",
      });
      ruleForm.setFieldValue('exclude_skus', result);
    } catch (e: any) {
      message.error(e.msg);
      console.log(e);
    }
    setLoading(false);

  };
  const [ruleForm] = Form.useForm();
  return (
    <Drawer onClose={props.onCancel} width={'88vw'} open={visible} title='满减活动'>
      <div className='page'>
        <Form disabled={loading} form={ruleForm}>
          <Row gutter={[4, 0]}>
            <Col span={12}>
              <Form.Item hidden initialValue={info?.id} name='id' label='id号'>
                <Input />
              </Form.Item>
              <Form.Item name='title' initialValue={info?.title} rules={[{ required: true, message: '请输入活动标题' }]} label='活动标题'>
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='dc_mutex' initialValue={info?.config.dc_mutex} rules={[{ required: true, message: '请选择是否互斥' }]} label='code互斥'>
                <Select options={judgements} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='discount_type' initialValue={info?.config.discount_type} rules={[{ required: true, message: '请选择活动类型' }]} label='折扣类型'>
                <Select
                  options={discountTypes.filter(item => item.value != 'fix_amount')}
                  onChange={(value) => {
                    setType(value);
                  }}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='property_key'
                initialValue={info?.config.property_key}
                label={
                  <Tooltip title='如果活动是针对特定主题页的，则此属性为必填项目。不填则默认为针对全场活动，而且属性必须以__划线开头' color='geekblue'>
                    专题页活动特有属性
                    <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                  </Tooltip>
                }>
                <Input />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item name='min_buy_qty' initialValue={info?.config.min_buy_qty || 1} label='最小购买量'>
                <InputNumber style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label={
                <Tooltip title='如果只想部分产品参与这个活动的时候，则在对应的产品上设置这个product_tag进行活动范围的控制，如果活动的这个值为空，则表明除了赠品外的所有产品价格都会计入到参与活动的总金额中' color='geekblue'>
                  限制活动生效范围的产品标签
                  <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                </Tooltip>
              } name='limit_product_tag' initialValue={info?.config.limit_product_tag}>
                <Input />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item label='Checkout页展示的文案' name='message' initialValue={info?.config.message} rules={[{ required: true, message: '活动文案必须填写' }]} >
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='metafield_key' initialValue={info?.config.metafield_key} label='店铺级别的metafields专有key值'>
                <Input />
              </Form.Item>
            </Col>
            <Col span={24}><Alert style={{ marginBottom: '8px' }} message={`针对订单维度的活动，发布即生效，开始时间和结束时间不再生效`} type="success" /></Col>
            <Col span={12}>
              <Form.Item
                initialValue={info ? dayjs(info.starts_at, 'YYYY-MM-DD HH:mm:ss').subtract(1,'day') : dayjs().subtract(1,'day')}
                rules={[{ required: true, message: '活动开始时间必须填写' }]}
                name='starts_at'
                label={<Tooltip title='时间对应的时区为shopify对应的店铺所在时区' color='geekblue'>
                  活动开始时间
                  <ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                </Tooltip>}>
                <DatePicker disabled disabledDate={disabledDate} showTime format='YYYY-MM-DD HH:mm:ss' style={{ display: 'block' }} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='ends_at'
                initialValue={info?.ends_at ? dayjs(info.ends_at, 'YYYY-MM-DD HH:mm:ss') : null}
                rules={[
                  {
                    validator: (rule, value: Dayjs) => {
                      if (!value) return Promise.resolve();
                      if (value.isBefore(new Date(), 'day')) {
                        return Promise.reject('结束时间不能晚于当前时间');
                      }
                      let starts_at = ruleForm.getFieldValue('starts_at');
                      if (starts_at && value.isBefore(starts_at, 'day')) {
                        return Promise.reject('结束时间不能早于开始时间');
                      }
                      return Promise.resolve();
                    },
                  },
                ]}
                label={<Tooltip title='时间对应的时区为shopify对应的店铺所在时区' color='geekblue'>
                  活动结束时间
                  <ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                </Tooltip>}>
                <DatePicker disabled showTime format='YYYY-MM-DD HH:mm:ss' style={{ display: 'block' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                name='exclude_skus'
                initialValue={info?.config.exclude_skus}
                label={
                  <Tooltip title='优惠券或者其他购物券不参与计算' color='geekblue'>
                    不参与计算的sku?
                    <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                  </Tooltip>
                }>
                <SearchSelect mode={'multiple'} url={'/api/basic/variants'} />
              </Form.Item>
            </Col>
            <Col span={16} style={{display:'flex'}}>
              <Upload multiple={false} fileList={[]} onChange={(info) => {
                multUpload(info.file as RcFile);
              }} accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,.csv" beforeUpload={() => { return false }} listType="text">
                <div>
                  <Button
                    type='dashed'
                    style={{ borderRadius: "4px" }}
                    icon={<PlusOutlined />}
                  >
                    批量导入sku
                  </Button>
                  
                </div>
              </Upload>
              <label style={{marginTop:"3px",paddingLeft:"4px"}}>
                    请严格按照<a target="_blank" href="https://anker-in.feishu.cn/docx/SOIVdIWmRoIBwwx0sxgcj2Qbn5f">《excel模版》</a>编写
                  </label>
            </Col>
          </Row>
          <Form.List initialValue={info ? info.config.discount_rule : [{ value: '', money: '' }]} name='discount_rule'>
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, ...restField }) => (
                  <Row key={key} gutter={[4, 0]} style={{ position: 'relative', marginBottom: '8px', marginTop: '8px', padding: '8px', border: '1px solid #dedede' }}>
                    {fields.length > 1 ? (
                      <Button
                        onClick={() => remove(name)}
                        style={{ zIndex: 100, position: 'absolute', right: 0, top: 0 }}
                        type={'link'}
                        icon={<MinusCircleOutlined />}
                      />
                    ) : null}
                    <Col span={8}>
                      <Form.Item rules={[{ required: true, message: '不允许为空' }]} name={[name, 'money']} label='金额'>
                        <InputNumber style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                    <Col span={8}>
                      <Form.Item
                        rules={[{ type: 'number' }, {
                          validator: (rule, value) => {
                            if (value < 0) {
                              return Promise.reject("必须大于0");
                            }
                            if (discount_type == "percentage" && value > 100) {
                              return Promise.reject("折扣百分比不能大于100%")
                            }
                            return Promise.resolve();
                          }
                        }, { required: true, message: '不允许为空' }]}
                        name={[name, 'value']}
                        label={discount_type ? discountTypesObj[discount_type] : '固定价格'}>
                        <InputNumber style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                  </Row>
                ))}
                <Button icon={<PlusOutlined />} type={'link'} size={'large'} onClick={() => add()} />
              </>
            )}
          </Form.List>
        </Form>
        <Divider />
        <div style={{ textAlign: 'right' }}>
          <Button
            onClick={() => {
              ruleForm
                .validateFields()
                .then((values) => {
                  onCreate(values);
                })
                .catch((info) => {
                  console.log('Validate Failed:', info);
                });
            }}
            loading={loading}
            type='primary'>
            Save
          </Button>
        </div>
      </div>
    </Drawer>
  );
};

export default LevelManLiJianEdit;
