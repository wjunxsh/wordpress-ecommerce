import { Input, Select, Form, Button, Drawer, Row, Col, DatePicker, Divider, Tooltip, InputNumber, message, Alert } from 'antd';
import { BuyMainSendGift, EditProps } from '../interface';
import { useEffect, useState } from 'react';
import 'react-quill/dist/quill.snow.css';
import { ExclamationCircleOutlined, MinusCircleOutlined, PlusCircleOutlined, PlusOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { SearchSelect } from '../search_select';
import dayjs,{Dayjs} from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
dayjs.extend(utc);
dayjs.extend(timezone);
import { LabelConfig } from '@components/script/labels/interface';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
import { SelectOption } from '@components/common_interface';
import { accessoryBuyTypes, campaignTypes, discountTypes, discountTypesObj, judgements } from '@components/script/simple_data';
const function_key = 'dd5bf48a-2fc4-4db7-a17a-a9a6e672f865';
const BuyMainSendGiftEdit = (props: EditProps<BuyMainSendGift>) => {
  const [discount_type, setType] = useState<string>('');
  const [labels, setLabels] = useState<LabelConfig[]>([]);
  const [campaignType, setCampaignType] = useState<'gift'|'exchange'>('exchange')
  const authenticatedFetch = useAuthenticatedFetch();
  const [loading,setLoading] = useState<boolean>(false);
  const { info, visible } = props;
  useEffect(() => {
    setType(info ? info.config.discount_type : 'fix_amount');
    setCampaignType(info?.config.campaign_type || 'exchange');
    ruleForm.resetFields();
    ruleForm.resetFields(['active_rules']);
  }, [visible]);
  useEffect(() => {
    if (!visible) {
      return;
    }
    ruleForm.setFieldValue('active_rules', info ? info.config.active_rules : [{ main_sku: [], gift_rules: [{ sku: [], discount_value: '' }] }]);
    //获取对应的文案配置
    getLabelConfig();
  }, []);
  const getLabelConfig = async () => {
    try {
      let result = await authenticatedFetch('/api/script/label_config/info', 
      { method:"get",query:{function_key }});
      setLabels(result.info.labels);
    } catch (e) {
      console.log(e);
    }
  };
  const onCreate = async (data: any) => {
    if(loading) {
      message.warning("不允许重复提交");
      return;
    }
    setLoading(true);
    try {
      let result = await authenticatedFetch('/api/script/discount/save', {
        method:'post',
        body: {
          title: data.title,
          starts_at: dayjs(data.starts_at).format('YYYY-MM-DD HH:mm:ss'),
          ends_at: data.ends_at ? dayjs(data.ends_at).format('YYYY-MM-DD HH:mm:ss') : null,
          active: 'active',
          function_id: function_key,
          id: data.id ?? 0,
          config: {
            text_arr: data.text_arr,
            discount_type: campaignType == 'exchange' ? data.discount_type : 'fix_amount',
            dc_mutex: data.dc_mutex,
            active_rules: data.active_rules,
            is_level_send: data.is_level_send,
            message: data.message,
            property_key: data.property_key ?? '',
            mutex: data.mutex,
            campaign_type: campaignType
          },
        }
      });
      props.onSuccess(result.discountInfo);
    } catch (e:any) {
      message.error(e.msg || e.message);
      console.error(e);
    }
    setLoading(false);
  };
  const disabledDate = (current: Dayjs) => {
    return current && current < dayjs().subtract(1, 'day').startOf('day');
  };
  const [ruleForm] = Form.useForm();
  return (
    <Drawer onClose={props.onCancel} width={'88vw'} open={visible} title='买赠 & 加购活动编辑'>
      <div className='page'>
        <Form disabled={loading} form={ruleForm}>
          <Row gutter={[4, 0]}>
            <Col span={12}>
              <Form.Item hidden initialValue={info?.id} name='id' label='id号'>
                <Input />
              </Form.Item>
              <Form.Item name='title' initialValue={info?.title} rules={[{ required: true, message: '请输入活动标题' }]} label='活动标题'>
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
            <Form.Item name='campaign_type' initialValue={info?.config.campaign_type || 'exchange'} rules={[{ required: true, message: '请选择活动类型' }]} label='活动类型'>
                <Select options={campaignTypes} onChange={(value)=> setCampaignType(value)}/>
              </Form.Item>
            </Col>
            {campaignType == 'exchange' ? <Col span={12}>
              <Form.Item name='discount_type' initialValue={info?.config.discount_type} rules={[{ required: true, message: '请选择活动类型' }]} label='折扣类型'>
                <Select
                  options={discountTypes}
                  onChange={(value) => {
                    setType(value);
                  }}
                />
              </Form.Item>
            </Col>: null}
            
            <Col span={12}>
              <Form.Item name='dc_mutex' initialValue={info?.config.dc_mutex ?? true} rules={[{ required: true, message: '请选择是否与code互斥' }]} label='code互斥'>
                <Select options={judgements} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name='mutex' initialValue={info?.config.mutex ?? true} rules={[{ required: true, message: '请选择' }]} label='与其他script互斥'>
                <Select options={judgements} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='is_level_send'
                initialValue={info?.config.is_level_send}
                rules={[{ required: true, message: '请选择活动方式' }]}
                label={
                  <Tooltip title='如果一个主商品对应多个附属产品做优惠，并且客户将多个附属产品都加入了购物车，则活动会根据这个选项决定是1对多优惠还是1对1优惠' color='geekblue'>
                   多附属产品的购买方式
                    <InfoCircleOutlined  style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                  </Tooltip>
                }>
                <Select options={accessoryBuyTypes} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label='Checkout页展示的文案' name='message' initialValue={info?.config.message} rules={[{ required: true, message: '活动文案必须填写' }]} >
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='property_key'
                initialValue={info?.config.property_key}
                label={
                  <Tooltip title='如果活动是针对特定主题页的，则此属性为必填项目。不填则默认为针对全场活动，而且属性必须以__划线开头' color='geekblue'>
                    专题页活动特有属性
                    <InfoCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
                  </Tooltip>
                }>
                <Input />
              </Form.Item>
            </Col>
            <Col span={24}><Alert style={{marginBottom:'8px'}} message={`活动的开始时间和结束时间是根据店铺的${props.timeZone}时区进行设置`} type="success" /></Col>
            <Col span={12}>
              <Form.Item
                initialValue={info ? dayjs(info.starts_at, 'YYYY-MM-DD HH:mm:ss') : null}
                rules={[{ required: true, message: '活动开始时间必须填写' }]}
                name='starts_at'
                label={<Tooltip title='时间对应的时区为shopify对应的店铺所在时区' color='geekblue'>
                活动开始时间
                <ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
              </Tooltip>}>
                <DatePicker disabledDate={disabledDate} showTime format='YYYY-MM-DD HH:mm:ss' style={{ display: 'block' }} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name='ends_at'
                initialValue={info?.ends_at ? dayjs(info.ends_at, 'YYYY-MM-DD HH:mm:ss'): undefined}
                rules={[
                  {
                    validator: (rule, value: Dayjs) => {
                      if (!value) return Promise.resolve();
                      if (value.isBefore(new Date(), 'day')) {
                        return Promise.reject('结束时间不能晚于当前时间');
                      }
                      let starts_at = ruleForm.getFieldValue('starts_at');
                      if (starts_at && value.isBefore(starts_at, 'day')) {
                        return Promise.reject('结束时间不能早于开始时间');
                      }
                      return Promise.resolve();
                    },
                  },
                ]}
                label={<Tooltip title='时间对应的时区为shopify对应的店铺所在时区' color='geekblue'>
                活动结束时间
                <ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} />
              </Tooltip>}>
                <DatePicker disabledDate={disabledDate} showTime format='YYYY-MM-DD HH:mm:ss' style={{ display: 'block' }} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={[4, 0]} className='form-list-item'>
            {labels.map((item, index) => (
              <Col key={index} span={24}>
                <Form.Item
                  initialValue={info && info.config.text_arr && info.config.text_arr[index] !== undefined ? info.config.text_arr[index] : item.default||""}
                  rules={[{ required: item.required, message: '请输入' + item.title }]}
                  name={['text_arr', index]}
                  label={item.title}>
                  <Input />
                </Form.Item>
              </Col>
            ))}
          </Row>
          <Form.List initialValue={info ? info.config.active_rules : [{ main_sku: [], gift_rules: [{ sku: [], discount_value: '' }] }]} name='active_rules'>
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, ...restField }) => (
                  <Row key={key} gutter={[4, 0]} className='form-list-item'>
                    {fields.length > 1 ? (
                      <Button
                        onClick={() => remove(name)}
                        style={{ zIndex: 100, position: 'absolute', right: 0, top: 0 }}
                        type={'link'}
                        icon={<MinusCircleOutlined />}
                      />
                    ) : null}
                    <Col span={12}>
                      <Form.Item
                        rules={[
                          {
                            validator: (rule, value) => {
                              let activeRules = ruleForm.getFieldValue('active_rules');
                              let mainSkus: string[] = [];
                              activeRules.forEach((item: any) => {
                                if (!item.main_sku) {
                                  return;
                                }
                                mainSkus = mainSkus.concat(item.main_sku.map((val: SelectOption) => val.value));
                              });
                              if (mainSkus.length != Array.from(new Set(mainSkus)).length) {
                                for (let mainSku of value) {
                                  if (mainSkus.filter((val) => mainSku.value == val).length >= 2) {
                                    return Promise.reject('主sku不允许重复！');
                                  }
                                }
                              }
                              return Promise.resolve();
                            },
                          },
                          { required: true, message: '请选择主商品' },
                        ]}
                        name={[name, 'main_sku']}
                        label='主商品SKU'>
                        <SearchSelect mode='multiple' url={'/api/basic/variants'} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.List
                        name={[name, 'gift_rules']}
                        initialValue={info && info.config.active_rules[name] ? info.config.active_rules[name]['gift_rules'] : [{ sku: [], discount_value: '' }]}>
                        {(subFields, subEvent) => (
                          <>
                            {subFields.map(({ key, name }, index: number) => (
                              <Row gutter={[4, 0]} key={key}>
                                <Col span={10}>
                                  <Form.Item label={campaignType == 'exchange'? '加购SKU': "赠品SKU"} rules={[{ required: true, message: '请选择赠品' }]} name={[name, 'sku']}>
                                    <SearchSelect mode='multiple' url={'/api/basic/variants'} />
                                  </Form.Item>
                                </Col>
                                {campaignType == 'exchange' ? <Col span={5}>
                                  <Form.Item
                                    rules={[{ type: 'number' },{validator:(rule,value)=> {
                                      if(value < 0){
                                        return Promise.reject("必须大于0");
                                      }
                                      if(discount_type == "percentage" && value > 100){
                                        return Promise.reject("折扣百分比不能大于100%")
                                      }
                                      return Promise.resolve();
                                    }},  { required: true, message: '不允许为空' }]}
                                    name={[name, 'discount_value']}
                                    label={discount_type ? discountTypesObj[discount_type] : '固定价格'}>
                                    <InputNumber style={{ width: '100%' }} />
                                  </Form.Item>
                                </Col> : null}

                                <Col span={5}>
                                  <Form.Item
                                    name={[name, 'label']}
                                    label="补充文案">
                                    <Input style={{ width: '100%' }} />
                                  </Form.Item>
                                </Col>
                                <Col span={4}>
                                  {subFields.length > 1 ? (
                                    <Button onClick={() => subEvent.remove(name)} style={{ marginRight: '8px' }} icon={<MinusCircleOutlined />}></Button>
                                  ) : null}
                                  {subFields.length == index + 1 ? <Button onClick={() => subEvent.add()} icon={<PlusCircleOutlined />} /> : null}
                                </Col>
                              </Row>
                            ))}
                          </>
                        )}
                      </Form.List>
                    </Col>
                  </Row>
                ))}
                <Button icon={<PlusOutlined />} type={'link'} size={'large'} onClick={() => add()} />
              </>
            )}
          </Form.List>
        </Form>
        <Divider />
        <div style={{ textAlign: 'right' }}>
          <Button
            onClick={() => {
              ruleForm
                .validateFields()
                .then((values) => {
                  onCreate(values);
                })
                .catch((info) => {
                  console.log('Validate Failed:', info);
                });
            }}
            loading={loading}
            type='primary'>
            Save
          </Button>
        </div>
      </div>
    </Drawer>
  );
};

export default BuyMainSendGiftEdit;
