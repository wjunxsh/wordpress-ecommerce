import { Tag, Tooltip } from 'antd';
import { ColumnsType } from 'antd/lib/table';
import { DiscountItem } from './interface';
import dayjs from 'dayjs'
const setDiscountState = (record:DiscountItem<any>) => {
  if(record.state == "draft"){
    return <Tag>{record.state}</Tag>
  }else{
    if(dayjs(record.starts_at).isAfter(new Date())){
      return <Tag color={"orange"}>Scheduled</Tag>
    }else if(dayjs(record.ends_at).isBefore(new Date(),"minute")){
      return <Tag color={"orange"}>Expired</Tag>
    }else{
      return <Tag color={"blue"}>active</Tag>
    }
  }
}

export const columns: ColumnsType<DiscountItem<any>> = [
  {
    title: 'id',
    dataIndex: 'index',
    align: 'center',
    width: 60,
    ellipsis: true,
    render: (text, record: DiscountItem<any>) => record.id,
  },
  {
    title: '标题',
    align: 'left',
    width: 240,
    ellipsis: true,
    dataIndex: 'title',
    render:(text) => <Tooltip placement="topRight" title={text}>{text}</Tooltip>
  },
  {
    title: '状态',
    align: 'left',
    width: 120,
    ellipsis: true,
    dataIndex: 'state',
    render:(state,record) => setDiscountState(record)
  },
  {
    title: '功能类型',
    align: 'left',
    width: 150,
    ellipsis: true,
    dataIndex: 'function_title',
    render: (text:any,record:any)=> record.function.title,
  },
  {
    title: '开始时间',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'starts_at',
  },
  {
    title: '结束时间',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'ends_at',
  },
  {
    title: '活动类型',
    align: 'left',
    width: 120,
    ellipsis: true,
    dataIndex: 'function',
    render: (text:any)=> text.is_order  ? <Tag color="magenta">订单维度</Tag>: <Tag color="blue">产品维度</Tag>,
  },
  {
    title: '操作',
    dataIndex: 'handle',
    ellipsis: true,
    width: 88,
    align: 'left',
    fixed: 'right',
    render: (text) => text,
  },
];
