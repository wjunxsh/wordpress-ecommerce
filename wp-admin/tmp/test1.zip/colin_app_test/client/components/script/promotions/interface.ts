import { FormInstance } from 'antd';
export type CodeType = 'common' | 'shop_self' | 'util_common';
export interface GiftRule {
  sku: string;
  discount_value: string;
}
export interface ActiveRule {
  main_sku: string;
  gift_rules: GiftRule[];
}

export interface BundleSuiteSale {
  message: string;
  dc_mutex: boolean;
  mutex:boolean;
  property_key: string;
  discount_type: string;
  text_arr:string[];
  bundle_config: BundleConfig[][];
}
export interface BundleConfig {
  sku: string;
  price: number;
  qty: number;
}
export interface BuyEnoughSendGift {
  is_repeat: boolean;
  is_level_send: boolean;
  message: string;
  dc_mutex: boolean;
  mutex:boolean;
  limit_product_tag:string;
  exclude_skus: string[];
  rules: [{ money: number; gift_skus: string[] }];
}
export interface BuyMainSendGift {
  discount_type: 'percentage' | 'fix_amount' | 'fix_discount_amount';
  is_level_send: boolean;
  dc_mutex: boolean;
  mutex:boolean;
  message: string;
  property_key: string;
  text_arr:string[],
  active_rules: ActiveRule[];
  campaign_type: 'gift' | 'exchange';
}
export interface QtyActiveRule {
  skus: [{ label: string; value: string }];
  rules: [{ quantity: number; value: number }];
}
export interface QuantityLevelDiscount {
  discount_type: 'percentage' | 'fix_amount' | 'fix_discount_amount';
  dc_mutex: boolean;
  message: string;
  property_key: string;
  metafield_key:string;
  text_arr:string[];
  mutex: boolean;
  campaign_type: 'level'|'drop';
  active_rules: QtyActiveRule[];
}

export interface LevelRule {
  discount_rule: [{ quantity: number; value: number }];
}

export interface PackRule {
  discount_rule: [{ skus:[{ value: string; label: string }],quantity: number; value: number }];
}
export interface LevelManLiJian {
  discount_type: 'percentage' | 'fix_amount' | 'fix_discount_amount';
  dc_mutex: boolean;
  message: string;
  exclude_skus: [{ value: string; label: string }];
  limit_product_tag:string;
  property_key:string;
  metafield_key:string;
  min_buy_qty:number;
  discount_rule: LevelRule[];
}

export interface PackSales {
  discount_type: 'percentage' | 'fix_amount' | 'fix_discount_amount';
  dc_mutex: boolean;
  mutex: boolean;
  message: string;
  property_key:string;
  discount_rule: PackRule[];
}

export interface EveryManLiJian {
  dc_mutex: boolean;
  message: string;
  exclude_skus: [{ value: string; label: string }];
  limit_product_tag:string;
  property_key:string;
  min_buy_qty:number;
  discount_amount:number;
  discount_value:number;
}
export interface BuyMoreThanOneDiscount {
  dc_mutex: boolean;
  message: string;
  limit_skus: [{ value: string; label: string }];
  limit_product_tag:string;
  property_key:string;
  min_buy_qty:number;
  mutex:boolean;
  promise_repeat:boolean;
  discount_type:'percentage' | 'fix_discount_amount';
  discount_value:number;
}

export interface ProductBundleSuiteSales {
  message: string;
  dc_mutex: boolean;
  property_key: string;
  sold_out_text: string;
  node: string;
  discount_type: string;
  text_arr:string[];
  bundle_config: { price: number; tag: string; productList: [
    {
      display: string;
      product: { value: string; label: string };
      show_sku: { value: string; label: string };
     }] }[];
}

export interface DiscountItem<ScriptTypes> {
  id: number;
  shop_id: string;
  function_id: string;
  title: string;
  starts_at: string;
  ends_at: string;
  state: string;
  config: ScriptTypes;
  shop: { shopify_domain: string; id: number };
  user: {email:string}
  created_at: string;
  updated_at: string;
}
export interface Istate<ScriptTypes> {
  edit_info: null | DiscountItem<ScriptTypes>;
  edit_visible: boolean;
  func_visible: boolean;
  script_visible: boolean;
  time_zone:string;
  edit_func_key: string;
  logRecord:DiscountItem<any> | null;
  funcList: DiscountItem<ScriptTypes>[];
}

export interface EditProps<ScriptTypes> {
  info: DiscountItem<ScriptTypes> | null;
  visible: boolean;
  timeZone:string;
  onSuccess: (discountInfo:DiscountItem<ScriptTypes>) => void;
  onCancel: () => void;
}
