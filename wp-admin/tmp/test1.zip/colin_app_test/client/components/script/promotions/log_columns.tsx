import { Tag, Tooltip } from 'antd';
import { ColumnsType } from 'antd/lib/table';
import { DiscountItem } from './interface';

export const columns: ColumnsType<DiscountItem<any>> = [
  {
    title: 'id',
    dataIndex: 'index',
    align: 'center',
    width: 60,
    ellipsis: true,
    render: (text, record: DiscountItem<any>) => record.id,
  },
  {
    title: '标题',
    align: 'left',
    width: 240,
    ellipsis: true,
    dataIndex: 'title',
    render:(text) => <Tooltip placement="topRight" title={text}>{text}</Tooltip>
  },
  {
    title: '操作人',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: "user",
    render:(text,record) => record.user ? record.user.email : ""
  },
  {
    title: '修改时间',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'log_at',
  },
  {
    title: '开始时间',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'starts_at',
  },
  {
    title: '结束时间',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'ends_at',
  },
  {
    title: '活动状态',
    align: 'left',
    width: 90,
    ellipsis: true,
    dataIndex: 'state',
  },

  {
    title: '功能名称',
    align: 'left',
    width: 120,
    ellipsis: true,
    dataIndex: 'function_title',
    render: (text:any,record:any)=> record.function.title,
  },
  {
    title: '活动类型',
    align: 'left',
    width: 120,
    ellipsis: true,
    dataIndex: 'function',
    render: (text:any)=> text.is_order  ? <Tag color="magenta">订单维度</Tag>: <Tag color="blue">产品维度</Tag>,
  },
];
