import { Input, Select, Form, Button, Drawer, Row, Col, DatePicker, Divider, Tooltip, InputNumber, message } from 'antd';
import { useEffect, useState } from 'react';
import 'react-quill/dist/quill.snow.css';
import { MinusCircleOutlined, PlusCircleOutlined, PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { LabelConfig, ScriptItem } from './interface';
import { ResultData } from '@components/common_interface';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
import { judgements } from '../simple_data';
interface EditProps {
  info: ScriptItem|null;
  visible: boolean;
  onSuccess: () => void;
  onCancel: () => void;
}
const ScriptLabelsEdit = (props: EditProps) => {
  const { info, visible } = props;
  const authenticatedFetch = useAuthenticatedFetch();
  const [FunctionList, setFunctions] = useState([]);
  const [loading,setLoading] = useState<boolean>(false);
  useEffect(() => {
    visible && FunctionList.length == 0 && getFunctions();
    ruleForm.resetFields();
  }, [visible]);
  const getFunctions = async () => {
    try {
      let result = await authenticatedFetch('/api/functions/list', { method:'get',
      query:{code_type:"common",current_page: 1, page_size: 1000 }});
      let FunctionList = result['list'];
      setFunctions(FunctionList);
    } catch (e) {}
  };
  const onCreate = async (data: any) => {
    if(loading) return ;
    setLoading(true);
    try {
       await authenticatedFetch('/api/script/label_config/save', {
        method:'post',
        body:{
          id:data.id,
          shop_id: data.shop_id,
          function_key: data.function_key,
          labels:data.labels?.map((item:LabelConfig)=>({...item,default:item.default||""})),
        }
      });
      props.onSuccess();
    } catch (e:any) {
      message.error(e.message || e.msg || '');
      console.error(e);
    }
    setLoading(false);
  };
  const [ruleForm] = Form.useForm();
  return (
    <Drawer onClose={props.onCancel} width={'88vw'} open={visible} title='活动文案配置'>
      <div className='page'>
        <Form disabled={loading} form={ruleForm}>
          <Row gutter={[4, 0]}>
            <Col span={24} lg={12} md={16} >
            <Form.Item hidden initialValue={info?.id} name='id' label='id号'>
                <Input />
              </Form.Item>
              <Form.Item name='function_key' initialValue={`${info ? info.function_key : ''}`} rules={[{ required: true, message: '请选择活动类型' }]} label='活动类型'>
                <Select showSearch filterOption={(input, option:any) => `${option?.label ?? ''}`.toLowerCase().includes(input.toLowerCase())} options={FunctionList} />
              </Form.Item>
            </Col>
          </Row>
          <Form.List initialValue={info ? info.labels : [{ title: '', required: true,default:"" }]} name='labels'>
            {(fields, event) => (
              <div className='form-list-item'>
                {fields.map(({ key, name }, index: number) => (
                  <Row gutter={[4, 0]} key={key}>
                    <Col span={8}>
                      <Form.Item rules={[{ required: true, message: '请输入' }]} name={[name, 'title']} label={'文案名称'}>
                        <Input />
                      </Form.Item>
                    </Col>
                    <Col span={5}>
                      <Form.Item name={[name, 'required']} initialValue={info && info.labels[name] ? info.labels[name]['required'] : true} label='是否必填'>
                        <Select options={judgements} />
                      </Form.Item>
                    </Col>
                    <Col span={7}>
                      <Form.Item name={[name, 'default']} initialValue={info && info.labels[name] ? info.labels[name]['default'] : ""} label='默认值'>
                        <Input/>
                      </Form.Item>
                    </Col>
                    <Col span={3}>
                      {fields.length > 1 ? <Button onClick={() => event.remove(name)} style={{ marginRight: '8px' }} icon={<MinusCircleOutlined />}></Button> : null}
                      {fields.length == index + 1 ? <Button onClick={() => event.add()} icon={<PlusCircleOutlined />} /> : null}
                    </Col>
                  </Row>
                ))}
              </div>
            )}
          </Form.List>
        </Form>
        <Divider />
        <div style={{ textAlign: 'right' }}>
          <Button
            onClick={() => {
              ruleForm
                .validateFields()
                .then((values) => {
                  onCreate(values);
                })
                .catch((info) => {
                  console.log('Validate Failed:', info);
                });
            }}
            loading={loading}
            type='primary'>
            Save
          </Button>
        </div>
      </div>
    </Drawer>
  );
};

export default ScriptLabelsEdit;
