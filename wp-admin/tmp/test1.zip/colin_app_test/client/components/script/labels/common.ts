export const codeOptions = {
  selectOnLineNumbers: true,
  renderSideBySide: false,
};
