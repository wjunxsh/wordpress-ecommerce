import { FormInstance } from "antd";

export type CodeType = "common"|"shop_self"|"util_common";
export interface LabelConfig{
  title:string;
  required:boolean;
  default:string;
}
export interface ScriptItem{
  id:number;
  shop_id:string;
  function_key:string;
  updated_at:string;
  created_at:string;
  function:any;
  shop:any;
  labels:LabelConfig[];
}
export interface Istate{
  scriptList:ScriptItem[];
  refresh:number;
  edit_visible:boolean;
  scriptInfo:ScriptItem | null;
}
