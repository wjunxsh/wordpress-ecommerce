import { ColumnsType, ColumnType } from 'antd/lib/table';
import { ScriptItem } from './interface';
import { Tag } from 'antd';
export const tableColumns: ColumnType<ScriptItem>[] = [
  {
    title: '函数名称',
    align: 'left',
    width: 180,
    ellipsis: true,
    dataIndex: 'function_key',
    render:(text,record) => record.function.title
  },
  {
    title: '最后更新时间',
    align: 'left',
    width: 300,
    ellipsis: true,
    dataIndex: 'updated_at',
  },
  {
    title: '文案列表',
    align: 'left',
    width: 300,
    dataIndex: 'labels',
    render:(labels:ScriptItem["labels"]) => labels.map((item,index)=><Tag key={index} color="blue">{item.title}</Tag>)
  },
  {
    title: '操作',
    dataIndex: 'operate',
    ellipsis: true,
    width: 80,
    align: 'left',
    fixed: 'right',
    render: (text) => text,
  },
];
