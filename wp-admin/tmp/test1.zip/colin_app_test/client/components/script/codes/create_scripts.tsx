import { Alert, Button, Col, Form, message, Modal, Row, Select } from 'antd';
import { useForm } from 'antd/es/form/Form';
import copy from 'copy-to-clipboard';
import { useEffect, useState } from 'react';
// import Highlight from 'react-highlight';
import {Highlight, themes} from 'prism-react-renderer';
import { useAuthenticatedFetch } from '@hooks/useAuthenticatedFetch';
export interface FProps {
  visible: boolean;
  onCancel: () => void;
}

const CreateScriptsModal = ({ visible, onCancel }: FProps) => {
  const [code, setCode] = useState<string>('');
  const authenticatedFetch = useAuthenticatedFetch();
  const onCreate = async () => {
    let result = await authenticatedFetch('/api/script/discount/create_scripts', {
      method:"post",
    });
    setCode(result.code);
  };
  useEffect(() => {
    if (visible) {
      searchForm.resetFields();
      onCreate();
    }
  }, [visible]);
  const onCopy = () => {};
  const [searchForm] = useForm();
  return (
    <Modal
      cancelText={'关闭'}
      onOk={() => {
        if (copy(code)) {
          message.success('复制成功!');
        }
      }}
      okText='复制&发布'
      width={800}
      open={visible}
      onCancel={() => onCancel()}>
      <div style={{ maxHeight: '580px', padding: '8px', overflowY: 'auto', marginTop: '30px' }}>
        <Row gutter={[8, 8]}>
          <Col span={24}>
            <Alert message='' description='Script代码发布后活动才能生效哦！！！' type='error' />
          </Col>
          <Col span={24}>
            <div className='code-container' style={{ minHeight: '300px', maxHeight: '400px', overflowY: 'auto' }}>
              <Highlight theme={themes.vsDark} code={code} language='python'>
                {({ className, style, tokens, getLineProps, getTokenProps }) => (
                  <pre className={className} style={style}>
                    {tokens.map((line, i) => (
                      <div {...getLineProps({ line, key: i })}>
                        {line.map((token, key) => (
                          <span {...getTokenProps({ token, key })} />
                        ))}
                      </div>
                    ))}
                  </pre>
                )}
              </Highlight>
            </div>
          </Col>
        </Row>
      </div>
    </Modal>
  );
};

export default CreateScriptsModal;
