export const discountTypes = [
  { label: '固定折扣%', value: 'percentage' },
  { label: '固定价格', value: 'fix_amount' },
  { label: '固定折扣金额', value: 'fix_discount_amount' },
];
export const discountTypesObj: any = {};
for (let discountType of discountTypes) {
  discountTypesObj[discountType['value']] = discountType['label'];
}

export const judgements = [
  { label: 'Yes', value: true },
  { label: 'No', value: false },
];

export const accessoryBuyTypes = [
  { label: '前一个附属产品(赠品)数量满足不了优惠，则自动落到下一个附属产品(赠品)上', value: true },
  { label: '每个附属产品针对主商品优惠一次', value: false },
];

export const accessoryEnoughBuyTypes = [
  { label: '多赠品时，前一个赠品数量少于应赠送数量，则落到落到下一个赠品上，直到数量满足阶层赠送数量为止', value: true },
  { label: '每个附属产品针对主商品优惠N次', value: false },
];


export const accessoryEnoughRepeatBuyTypes = [
  { label: '总金额是满足赠送条件的N倍数，则送N个赠品', value: true },
  { label: '总金额是满足赠送条件的N倍数，赠品只送1个', value: false },
];

export const campaignTypes = [
  { label: '换购', value: 'exchange' },
  { label: '赠品', value: 'gift' },
];

export const campaignOnyProductTypes = [
  { label: '阶梯价格', value: 'level' },
  { label: '价格直降', value: 'drop' },
];

export const campaignState = [
  { label: 'All', value: '' },
  { label: 'Active', value: 'active' },
  { label: 'Draft', value: 'draft' },
  { label: 'Scheduled', value: 'scheduled' },
  { label: 'Expored', value: 'expired' },
];