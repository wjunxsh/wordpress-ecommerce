import { DiscountItem } from "@components/mult_export_discount/column";
import { ColumnsType } from "antd/lib/table";
import { TaskItem } from "./interface";
import dayjs from "dayjs"
import { Tag } from "antd";
import {CheckOutlined, CloseOutlined} from '@ant-design/icons'
import { CodeTypes, importTypes } from "./editTask";
export const taskColumns: ColumnsType<TaskItem> = [
  {
    title: '标题',
    dataIndex: 'title',
    width: 200,
    ellipsis:true,
  },
  {
    title: '操作人',
    dataIndex: 'user_email',
    width: 180,
    ellipsis: true,
  },
  {
    title: 'code生成方式',
    dataIndex: 'code_generate_type',
    width: 80,
    ellipsis:true,
    render:(text) => CodeTypes.find(item => item.value === text)?.label
  },
  {
    title: '导入类型',
    dataIndex: 'import_type',
    width: 80,
    ellipsis: true,
    render:(text) =>importTypes.find(item => item.value === text)?.label
  },
  {
    title: '联合其他产品折扣',
    dataIndex: 'combine_product_discount',
    width: 120,
    ellipsis: true,
    render:(text) => {
      return text ? <Tag color="success" icon={<CheckOutlined color={"success"} />} >Yes</Tag> : null;
    }
  },

  {
    title: '发送状态',
    dataIndex: 'is_send_all',
    width: 120,
    ellipsis: true,
    render:(text) => {
      return text ? <Tag color="success" icon={<CheckOutlined color={"success"} />} >Completed</Tag> : null;
    }
  },

  {
    title: '操作',
    dataIndex: 'operate',
    width: 80
  }
];
