import { ColumnsType } from "antd/lib/table";
import { DiscountImportRecord } from "./interface";
import {CheckOutlined, CloseOutlined,LoadingOutlined} from '@ant-design/icons'
import { Tag } from "antd";
export const recordColumns: ColumnsType<DiscountImportRecord> = [
  {
    title: '产品handle',
    dataIndex: 'handle',
    width: 240,
  },
  {
    title: 'sku',
    dataIndex: 'sku',
    width: 240,
    ellipsis:true,
  },
  {
    title: 'code',
    dataIndex: 'code',
    width: 120,
  },
  {
    title: 'status',
    dataIndex: 'extend',
    width: 240,
    ellipsis:true,
    render: (extend: any) => {
      if (extend && extend.code == 200) {
        return <Tag color="success" icon={<CheckOutlined color={"success"} />} >Success</Tag>
      }else if(!extend){
        return <Tag color="success" icon={<LoadingOutlined color={"success"} />} ></Tag>
      }else {
        return <Tag color="error" icon={<CloseOutlined color={"error"} />} >Failed</Tag>
      }
      ;
    }
  },
  {
    title: '同步时间',
    dataIndex: 'sync_at',
    width: 180,
    ellipsis:true,
  },
  {
    title: '错误信息',
    dataIndex: 'extend',
    width: 180,
    ellipsis:true,
    render: (extend: any) => {
      if (extend && extend.code !== 200) {
        return extend.msg
      }else {
        return ''
      }
      ;
    }
  },
];
