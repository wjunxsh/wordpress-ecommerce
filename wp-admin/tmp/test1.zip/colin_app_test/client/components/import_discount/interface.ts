export interface TaskItem {
  id:number;
  title:string;
  code_generate_type:string;
  import_type:string;
  edm_template:string;
  promise_sync:boolean;
  is_send_all:boolean;
  updated_at:Date,
  created_at:Date,
}

export interface DiscountImportRecord {
  id:number;
  import_task_id:number;
  handle:string;
  sku:string;
  code:string;
  value:string;
  value_type:string;
  start_date:string;
  end_date:string;
  combine_product_discount:string;
  allocation_method:string;
  usage_limit:string;
  once_per_customer:string;
  sync_at:string;
  extend:string;
}

export interface Pagination{
  current_page:number;
  page_size:number;
  total_size:number;
  total_pages:number;
}
