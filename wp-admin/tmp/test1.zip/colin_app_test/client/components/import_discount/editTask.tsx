import {
  Alert,
  Button,
  Checkbox,
  Col,
  DatePicker,
  Drawer,
  Form,
  Input,
  InputNumber,
  Radio,
  Row,
  Space,
  Tooltip,
  Upload,
  message,
} from "antd";
import { useEffect, useState } from "react";
import { TaskItem } from "./interface";
import { UploadFile } from "antd/lib/upload";
import { PlusOutlined } from "@ant-design/icons";
import { RcFile } from "antd/es/upload";
import { ExclamationCircleOutlined } from '@ant-design/icons';
import { useAuthenticatedFetchUpload } from "@hooks/useAuthenticatedFetch";
interface Istate {
  is_edit: boolean;
  loading: boolean;
  code_type: string;
}
interface IProps {
  visible: boolean;
  onOk: () => void;
  onCancel: () => void;
  iana_timezone: string;
  data: TaskItem | null;
}
export const CodeTypes = [{
  label: '导入',
  value: 'import'
}, {
  label: '部分生成',
  value: 'half'
}, {
  label: '全部生成',
  value: 'all'
}]
export const importTypes = [
  {
    label: "创建折扣",
    value: "create",
  },
  {
    label: "更新折扣",
    value: "update",
  },
];
export const EditImportFormDrawer = ({
  visible,
  onOk,
  onCancel,
}: IProps) => {
  const [state, setState] = useState<Istate>({
    loading: false,
    is_edit: false,
    code_type: "import",
  });
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const aFetch = useAuthenticatedFetchUpload();
  useEffect(() => {
    form.resetFields();
    visible && setState({ ...state, loading: false });
  }, [visible]);
 

  const importData = async (values: any) => {
    let formData = new FormData();
    if (state.loading) {
      return false;
    }
    setState({ ...state, loading: true });
    formData.append('file', values.file.file as RcFile);
    formData.append("code_type", values.code_type);
    formData.append("code_prefix", values.code_prefix || '');
    formData.append("code_num", values.code_num || '');
    formData.append("title", values.title || '');
    formData.append("import_type", values.import_type || '');
    formData.append("combine_product_discount", values.combine_product_discount || false);
    try {
      await aFetch("/api/discounts/import_task", {
        body: formData,
        method: "post",
      });
      setFileList([]);
      onOk();
      setState({ ...state, loading: false });
      form.resetFields();
    } catch (e: any) {
      message.error(e.message || e.msg);
      setState({ ...state, loading: false });
    }

  };
  const [form] = Form.useForm();
  return (
    <Drawer
      title="导入"
      placement={"right"}
      width={600}
      onClose={onCancel}
      open={visible}
      extra={
        <Space>
          <Button disabled={state.loading} onClick={onCancel}>
            Cancel
          </Button>
          <Button
                onClick={() => {
                  form.validateFields().then(values => {
                    importData(values);
                  }).catch(e => {

                  });
                }}
                loading={state.loading}
                type="primary"
              >
                导入
              </Button>
        </Space>
      }
    >
      <div style={{ minHeight: "600px" }}>
        <Form

          labelCol={{ span: 8 }}
          wrapperCol={{ span: 16 }}

          onChange={() => {
          }}
          style={{
            marginLeft: "16%",
            marginTop: "48px",
            marginBottom: "48px",
            maxWidth: 412,
          }}
          form={form}
        >
          <Form.Item
            rules={[
              {
                required:true,
                message: "标题必须填写",
              },
            ]}
            label="活动码前缀"
            name="title"
          >
            <Input />
            </Form.Item>
          <Form.Item
            initialValue={'create'}
            label="操作类型"
            name="import_type"
          >
            <Radio.Group>
              <Radio value={'create'}>创建折扣</Radio>
              <Radio value={'update'}>更新折扣</Radio>
            </Radio.Group>
          </Form.Item>
          <Form.Item
            initialValue={state.code_type}
            label="Code生成方式"
            name="code_type"
          >
            <Radio.Group
              onChange={(e) => {
                setState({ ...state, code_type: e.target.value });
              }}
            >
              <Radio value={"import"}>导入</Radio>
              <Radio value={"half"}>部分生成</Radio>
              <Radio value={"all"}>全部生成</Radio>
            </Radio.Group>
          </Form.Item>
          <Form.Item
            hidden={state.code_type != "half"}
            rules={[
              {
                required: state.code_type == "half",
                message: "code前缀必须填写",
              },
            ]}
            label="活动码前缀"
            name="code_prefix"
          >
            <Input />
          </Form.Item>
          <Form.Item
            hidden={state.code_type == "import"}
            rules={[{ required: state.code_type != "import", message: "请输入信息" }]}
            label="自动生成的位数"
            name="code_num"
          >
            <InputNumber
              onChange={(value) => {
                setState({ ...state, is_edit: true });
              }}
            />
          </Form.Item>
          <Form.Item label="提醒">
            <label>
              请严格按照<a target="_blank" href="https://anker-in.feishu.cn/docx/QKDmdBs7Uo3TbzxRGTbcyQOnnTd">《批量导入文件模版》</a>创建文件
            </label>
          </Form.Item>
          <Form.Item name="combine_product_discount" valuePropName="checked" label={<Tooltip color='geekblue' title='目前只有品牌Anker才生效'>联合其他产品折扣<ExclamationCircleOutlined style={{ color: '#eb2f96', verticalAlign: 'middle', marginTop: '-2px' }} size={10} /></Tooltip>}>
            <Checkbox />
          </Form.Item>
          <Form.Item
            required={true}
            rules={[{ required: true, message: "请上传文件" }]}
            name={"file"}
            label="选择文件"
          >
            <Upload fileList={fileList} onChange={(info) => {
              let newFileList = [...info.fileList];
              newFileList = newFileList.slice(-1);
              newFileList = newFileList.map((file) => {
                if (file.response) {

                  file.url = file.response.url;
                }
                return file;
              });

              setFileList(newFileList);
            }} accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,.csv" beforeUpload={() => { return false }} listType="text">
              <div>
                <Button
                  style={{ borderRadius: "4px" }}
                  icon={<PlusOutlined />}
                >
                  仅支持xls/xlsx/csv
                </Button>
              </div>
            </Upload>
          </Form.Item>
        </Form>
      </div>
    </Drawer>
  );
};
