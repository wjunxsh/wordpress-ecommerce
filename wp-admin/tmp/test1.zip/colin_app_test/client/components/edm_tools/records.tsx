import {
  Button,
  Modal,
  Table,
} from "antd";
import { useEffect, useState } from "react";
import { EdmConfig, EdmSendRecord, Pagination } from "./interface";
import {
  useAuthenticatedFetch,
} from "@hooks/useAuthenticatedFetch";
import { recordColumns } from "./record.column";
import { ColumnType } from "antd/es/table";
interface IProps {
  visible: boolean;
  onCancel: () => void;
  iana_timezone: string;
  edmConfig: EdmConfig|null;
}
export const EdmSendRecordsModal = ({
  visible,
  onCancel,
  edmConfig,
}: IProps) => {
  const [pagination, setPagination] = useState<Pagination>({
    current_page: 1,
    total_pages: 1,
    page_size: 10,
    total_size: 1,
  });
  const [state, setState] = useState<{ list: EdmSendRecord[] }>({ list: [] });
  const [lineLoadings,setLineLoadings] = useState<{[key:number]:boolean}>({});
  const [loading, setLoading] = useState<boolean>(false);
  useEffect(() => {
    visible && getList();
  }, [visible,pagination]);
  const authenticatedFetch = useAuthenticatedFetch();
  const getList = async () => {
    if (loading) {
      return;
    }
    setLoading(true);
    try {
      let data: { list: EdmSendRecord[]; pagination: Pagination } =
        await authenticatedFetch("/api/edm-config/record_list", {
          method: "GET",
          query: {
            current_page: pagination.current_page,
            page_size: pagination.page_size,
            edm_config_id: edmConfig?.id,
          },
        });
      pagination.current_page = data.pagination.current_page;
      pagination.page_size = data.pagination.page_size;
      pagination.total_pages = data.pagination.total_pages;
      pagination.total_size = data.pagination.total_size;
      setPagination(pagination);
      setLoading(false);
      setState({ ...state, list: data.list });
      setLineLoadings({});
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };
  const sendEmail = async (record:EdmSendRecord) => {
    if(lineLoadings[record.id]) return;
    setLineLoadings({...lineLoadings, [record.id]: true});
    try{
      await authenticatedFetch('/api/edm-config/send_email',{
        method:'POST',
        body: {
          edm_config_id: record.edm_config_id,
          id:record.id
        }
      });
      setLineLoadings({...lineLoadings, [record.id]: false});
      setPagination({...pagination});
    }catch(e) {
      setLineLoadings({...lineLoadings, [record.id]: false});
      setPagination({...pagination});
    }

  }
  const onRefresh = () => {
    setPagination({...pagination});
  }
  const columns = recordColumns.map((item: ColumnType<EdmSendRecord>) => {
    switch (item.dataIndex) {
      case "operate":
        item.render = (operate: "", record: EdmSendRecord) => {
          return <Button type="primary" size='small' loading={lineLoadings[record.id]} onClick={()=> sendEmail(record)}>{record.is_send ? '重新推送': '推送'}</Button>;
        };
        break;
    }
    return item;
  });
  return (
    <Modal width={800} open={visible} onCancel={onCancel} okText={'刷新'} cancelText={'关闭'} onOk={onRefresh} title="发送Edm记录">
      <Table
        rowKey={(record) => record.id}
        scroll={{ x: 800,y:500 }}
        pagination={{
          showSizeChanger: true,
          pageSizeOptions: [10, 20, 50],
          onChange: (page, page_size) => {
            setPagination({
              ...pagination,
              current_page: page,
              page_size,
            });
          },
          current: pagination.current_page,
          pageSize: pagination.page_size,
          total: pagination.total_size,
        }}
        loading={loading}
        columns={columns}
        size={"small"}
        dataSource={state.list}
      />
    </Modal>
  );
};
