import { DiscountItem } from "@components/mult_export_discount/column";
import { ColumnsType } from "antd/lib/table";
import { EdmConfig, EdmSendRecord } from "./interface";
import dayjs from "dayjs"
import {CheckOutlined, CloseOutlined} from '@ant-design/icons'
import { Tag } from "antd";
export const recordColumns: ColumnsType<EdmSendRecord> = [
  {
    title: '邮箱',
    dataIndex: 'email',
    width: 240,
  },
  {
    title: 'code',
    dataIndex: 'code',
    width: 120,
  },
  {
    title: 'edm模版',
    dataIndex: 'edm_template',
    width: 240,
    ellipsis:true,
  },
  {
    title: '已发送',
    dataIndex: 'is_send',
    width: 90,
    ellipsis: true,
    render:(text,record) => {
      return text ? <Tag color="success" icon={<CheckOutlined color={"success"} label='completed'/>}>Sended</Tag> : record.send_error ? <Tag color="error" icon={<CloseOutlined color={"error"}/>}>failed</Tag>: null
    }
  },
  {
    title: '发送时间',
    dataIndex: 'send_time',
    width: 180,
    ellipsis:true,
  },
  {
    title: '错误信息',
    dataIndex: 'send_error',
    width: 120,
    ellipsis:true,
  },
  {
    title: '操作',
    dataIndex: 'operate',
    width: 120
  }
];
