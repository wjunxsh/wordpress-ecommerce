import { DiscountItem } from "@components/mult_export_discount/column";
import { ColumnsType } from "antd/lib/table";
import { EdmConfig } from "./interface";
import dayjs from "dayjs"
import { Tag } from "antd";
import {CheckOutlined, CloseOutlined} from '@ant-design/icons'
export const configColumns: ColumnsType<EdmConfig> = [
  {
    title: '标题',
    dataIndex: 'title',
    width: 160,
    ellipsis:true,
  },
  {
    title: '描述',
    dataIndex: 'details',
    width: 120,
    ellipsis:true,
  },
  {
    title: 'edm模版',
    dataIndex: 'edm_template',
    width: 180,
    ellipsis: true,
  },
  {
    title: '审核状态',
    dataIndex: 'is_verify',
    width: 80,
    render:(text) => {
      return text ? '通过' : '未通过';
    }
  },
  {
    title: '发送状态',
    dataIndex: 'is_send_all',
    width: 120,
    ellipsis: true,
    render:(text) => {
      return text ? <Tag color="success" icon={<CheckOutlined color={"success"} />} >Completed</Tag> : null;
    }
  },
  {
    title: '是否已就绪',
    dataIndex: 'is_ready',
    width: 120,
    ellipsis: true,
    render:(text) => {
      return text ? <Tag color="success" icon={<CheckOutlined color={"success"} />} >Ready</Tag> : <Tag color="error" >Code生成中...</Tag>
    }
  },
  {
    title: '发送时间',
    dataIndex: 'starts_at',
    width: 180,
    ellipsis: true,
    render:(text) => dayjs(text).format('YYYY-MM-DD HH:mm:ss')
  },

  {
    title: '操作',
    dataIndex: 'operate',
    width: 140
  }
];
