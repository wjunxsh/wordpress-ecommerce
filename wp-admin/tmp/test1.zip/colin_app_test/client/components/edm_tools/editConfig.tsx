import {
  Alert,
  Button,
  DatePicker,
  Drawer,
  Form,
  Input,
  Space,
  Upload,
  message,
} from "antd";
import { useEffect, useState } from "react";
import { EdmConfig } from "./interface";
import { SearchSelect } from "../common/search_select";
import dayjs, { Dayjs } from "dayjs";
import { UploadFile } from "antd/lib/upload";
import { PlusOutlined } from "@ant-design/icons";
import { RcFile } from "antd/es/upload";
import { useAuthenticatedFetchUpload } from "@hooks/useAuthenticatedFetch";
interface Istate {
  loading: boolean;
}
interface IProps {
  visible: boolean;
  onOk: () => void;
  onCancel: () => void;
  iana_timezone: string;
  data: EdmConfig | null;
}
export const EditEdmConfig = ({
  visible,
  onOk,
  onCancel,
  data,
  iana_timezone,
}: IProps) => {
  const [state, setState] = useState<Istate>({
    loading: false,
  });
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const aFetch = useAuthenticatedFetchUpload();
  useEffect(() => {
    editForm.resetFields();
    visible && setState({ ...state, loading: false });
  }, [visible]);
  const onSave = async (values: any) => {
    let formData = new FormData();
    if (state.loading) {
      return false;
    }
    setState({ ...state, loading: true });
    if (!data) {
      formData.append("file", values.file.file as RcFile);
      formData.append("price_rule_id", values.price_rule?.value || "");
      formData.append("price_rule_title", values.price_rule?.label || "");
    }
    formData.append("title", values.title);
    formData.append("id", values.id);
    formData.append("details", values.details || "");
    formData.append("edm_template", values.edm_template);
    formData.append(
      "starts_at",
      values.starts_at.format("YYYY-MM-DD HH:mm:ss")
    );
    try {
      await aFetch("/api/edm-config/config_save", {
        body: formData,
        method: "post",
        timeout:500000,
      });
      setFileList([]);
      setState({ ...state, loading: false });
      editForm.resetFields();
      onOk();
    } catch (e: any) {
      message.error(e.message || e.msg);
      setState({ ...state, loading: false });
    }
  };

  const disabledDate = (current: Dayjs) => {
    console.log(iana_timezone,dayjs().tz(iana_timezone || 'UTC').startOf('day').format('YYYY-MM-DD'));
    return (
      current &&
      current < dayjs().subtract(1, 'day').startOf('day')
    );
  };
  const [editForm] = Form.useForm();
  return (
    <Drawer
      title="编辑发送邮件规则"
      placement={"right"}
      width={500}
      onClose={onCancel}
      open={visible}
      extra={
        <Space>
          <Button disabled={state.loading} onClick={onCancel}>
            Cancel
          </Button>
          <Button
            loading={state.loading}
            type="primary"
            onClick={() => {
              editForm
                .validateFields()
                .then((values) => {
                  onSave(values);
                })
                .catch((e) => {});
            }}
          >
            OK
          </Button>
        </Space>
      }
    >
      <div style={{minHeight: "600px"}}>
      <Form form={editForm}>
        <Form.Item
          initialValue={data?.title || ""}
          label={"标题"}
          name={"title"}
          rules={[{ required: true }]}
        >
          <Input />
        </Form.Item>
        <Form.Item hidden initialValue={data?.id || ""} label={""} name={"id"}>
          <Input />
        </Form.Item>
        <Form.Item
          initialValue={data?.details || ""}
          label={"描述"}
          name={"details"}
        >
          <Input />
        </Form.Item>
        <Form.Item
          initialValue={data?.edm_template || ""}
          label={"Edm 模版"}
          name={"edm_template"}
        >
          <Input />
        </Form.Item>
        {data ? null : (
          <Form.Item
            hidden={data ? true : false}
            initialValue={null}
            label={"裂变code活动"}
            name={"price_rule"}
          >
            <SearchSelect
              style={{ width: "100%" }}
              placeholder="裂变券"
              allowClear
              url="/api/price_rule/simple_list"
            />
          </Form.Item>
        )}
 <Alert message={`所在时区为店铺所在时区${iana_timezone}`} type="success" style={{marginBottom:'8px'}} />
        <Form.Item
          initialValue={data ? dayjs(data?.starts_at || new Date()) : null}
          rules={[{ required: true, message: "Must Input" }]}
          name="starts_at"
          label="开始发送时间"
        >

          <DatePicker
            disabledDate={disabledDate}
            showTime
            format="YYYY-MM-DD HH:mm:ss"
            style={{ display: "block" }}
          />
        </Form.Item>
        {data ? null : (
          <>
            <Form.Item hidden={data ? true : false} label="提醒">
              <label>
                请严格按照
                <a
                  target="_blank"
                  href="https://anker-in.feishu.cn/docx/VNhAdgr7eovZ62xJoXrcrIaCnab"
                >
                  《批量导入模版》
                </a>
                创建文件
              </label>
            </Form.Item>

            <Form.Item
              hidden={data ? true : false}
              required={true}
              rules={[{ required: true, message: "请上传邮箱" }]}
              name={"file"}
              label="上传邮箱列表"
            >
              <Upload
                fileList={fileList}
                onChange={(info) => {
                  let newFileList = [...info.fileList];
                  newFileList = newFileList.slice(-1);
                  newFileList = newFileList.map((file) => {
                    if (file.response) {
                      file.url = file.response.url;
                    }
                    return file;
                  });

                  setFileList(newFileList);
                }}
                accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,.csv"
                beforeUpload={() => {
                  return false;
                }}
                listType="text"
              >
                <div>
                  <Button
                    style={{ borderRadius: "4px" }}
                    icon={<PlusOutlined />}
                  >
                    仅支持xls/xlsx/csv
                  </Button>
                </div>
              </Upload>
            </Form.Item>
          </>
        )}
      </Form>
      </div>
    </Drawer>
  );
};
