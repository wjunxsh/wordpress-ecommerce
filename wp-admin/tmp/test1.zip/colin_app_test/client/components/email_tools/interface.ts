export interface EmailConfig {
  id:number;
  title:string;
  details:string;
  html_template:string;
  from:string;
  from_email:string;
  subject:string;
  price_rule_id:string;
  gift_card_config:string;
  is_verify:boolean;
  is_send_all:boolean;
  updated_at:Date,
  starts_at:Date,
  created_at:Date,
  is_ready: boolean;
  price_rule_title:string;
}

export interface EmailSendRecord {
  details:string;
  id:number;
  email_config_id:number;
  html_details:string;
  is_send:boolean;
  send_time:Date;
  extend:string;
  send_error:string;
  created_at:Date;
}

export interface Pagination{
  current_page:number;
  page_size:number;
  total_size:number;
  total_pages:number;
}
